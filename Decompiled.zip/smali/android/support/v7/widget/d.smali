###### Class android.support.v7.widget.d (android.support.v7.widget.d)
.class public interface abstract Landroid/support/v7/widget/d;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()Z
.end method

.method public abstract b()Z
.end method
