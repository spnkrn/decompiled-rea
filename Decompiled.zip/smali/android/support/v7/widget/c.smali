###### Class android.support.v7.widget.c (android.support.v7.widget.c)
.class public interface abstract Landroid/support/v7/widget/c;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()Z
.end method
