###### Class android.support.v7.widget.b (android.support.v7.widget.b)
.class public interface abstract Landroid/support/v7/widget/b;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()Z
.end method
