###### Class android.support.v7.internal.view.c (android.support.v7.internal.view.c)
.class public final Landroid/support/v7/internal/view/c;
.super Landroid/support/v7/internal/view/b;
.source "SourceFile"


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/view/ActionMode;)V
    .registers 3

    .prologue
    .line 28
    invoke-direct {p0, p1, p2}, Landroid/support/v7/internal/view/b;-><init>(Landroid/content/Context;Landroid/view/ActionMode;)V

    .line 29
    return-void
.end method
