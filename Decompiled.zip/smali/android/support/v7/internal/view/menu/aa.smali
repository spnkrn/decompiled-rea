###### Class android.support.v7.internal.view.menu.aa (android.support.v7.internal.view.menu.aa)
.class public interface abstract Landroid/support/v7/internal/view/menu/aa;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Landroid/content/Context;Landroid/support/v7/internal/view/menu/n;)V
.end method

.method public abstract a(Landroid/support/v7/internal/view/menu/n;Z)V
.end method

.method public abstract a(Landroid/support/v7/internal/view/menu/ag;)Z
.end method

.method public abstract b(Landroid/support/v7/internal/view/menu/r;)Z
.end method

.method public abstract c(Z)V
.end method

.method public abstract c(Landroid/support/v7/internal/view/menu/r;)Z
.end method

.method public abstract i()Z
.end method
