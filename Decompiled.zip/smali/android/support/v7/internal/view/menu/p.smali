###### Class android.support.v7.internal.view.menu.p (android.support.v7.internal.view.menu.p)
.class public interface abstract Landroid/support/v7/internal/view/menu/p;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Landroid/support/v7/internal/view/menu/r;)Z
.end method
