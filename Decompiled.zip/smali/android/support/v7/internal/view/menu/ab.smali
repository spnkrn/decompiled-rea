###### Class android.support.v7.internal.view.menu.ab (android.support.v7.internal.view.menu.ab)
.class public interface abstract Landroid/support/v7/internal/view/menu/ab;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Landroid/support/v7/internal/view/menu/n;Z)V
.end method

.method public abstract b(Landroid/support/v7/internal/view/menu/n;)Z
.end method
