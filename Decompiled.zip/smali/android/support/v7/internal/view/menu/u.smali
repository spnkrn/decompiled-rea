###### Class android.support.v7.internal.view.menu.u (android.support.v7.internal.view.menu.u)
.class final Landroid/support/v7/internal/view/menu/u;
.super Landroid/widget/FrameLayout;
.source "SourceFile"

# interfaces
.implements Landroid/view/CollapsibleActionView;


# instance fields
.field final a:Landroid/support/v7/b/b;


# direct methods
.method constructor <init>(Landroid/view/View;)V
    .registers 3

    .prologue
    .line 442
    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-direct {p0, v0}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    move-object v0, p1

    .line 443
    check-cast v0, Landroid/support/v7/b/b;

    iput-object v0, p0, Landroid/support/v7/internal/view/menu/u;->a:Landroid/support/v7/b/b;

    .line 444
    invoke-virtual {p0, p1}, Landroid/support/v7/internal/view/menu/u;->addView(Landroid/view/View;)V

    .line 445
    return-void
.end method


# virtual methods
.method public final onActionViewCollapsed()V
    .registers 2

    .prologue
    .line 454
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/u;->a:Landroid/support/v7/b/b;

    invoke-interface {v0}, Landroid/support/v7/b/b;->b()V

    .line 455
    return-void
.end method

.method public final onActionViewExpanded()V
    .registers 2

    .prologue
    .line 449
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/u;->a:Landroid/support/v7/b/b;

    invoke-interface {v0}, Landroid/support/v7/b/b;->a()V

    .line 450
    return-void
.end method
