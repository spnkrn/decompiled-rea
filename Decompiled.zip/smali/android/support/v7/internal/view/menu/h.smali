###### Class android.support.v7.internal.view.menu.h (android.support.v7.internal.view.menu.h)
.class public interface abstract Landroid/support/v7/internal/view/menu/h;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract d()Z
.end method

.method public abstract e()Z
.end method
