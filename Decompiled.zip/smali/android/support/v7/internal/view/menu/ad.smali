###### Class android.support.v7.internal.view.menu.ad (android.support.v7.internal.view.menu.ad)
.class public interface abstract Landroid/support/v7/internal/view/menu/ad;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()Landroid/support/v7/internal/view/menu/r;
.end method

.method public abstract a(Landroid/support/v7/internal/view/menu/r;)V
.end method

.method public abstract b()Z
.end method
