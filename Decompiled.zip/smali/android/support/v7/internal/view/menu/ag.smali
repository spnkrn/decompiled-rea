###### Class android.support.v7.internal.view.menu.ag (android.support.v7.internal.view.menu.ag)
.class public final Landroid/support/v7/internal/view/menu/ag;
.super Landroid/support/v7/internal/view/menu/n;
.source "SourceFile"

# interfaces
.implements Landroid/view/SubMenu;


# instance fields
.field private d:Landroid/support/v7/internal/view/menu/n;

.field private e:Landroid/support/v7/internal/view/menu/r;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/support/v7/internal/view/menu/n;Landroid/support/v7/internal/view/menu/r;)V
    .registers 4

    .prologue
    .line 38
    invoke-direct {p0, p1}, Landroid/support/v7/internal/view/menu/n;-><init>(Landroid/content/Context;)V

    .line 40
    iput-object p2, p0, Landroid/support/v7/internal/view/menu/ag;->d:Landroid/support/v7/internal/view/menu/n;

    .line 41
    iput-object p3, p0, Landroid/support/v7/internal/view/menu/ag;->e:Landroid/support/v7/internal/view/menu/r;

    .line 42
    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .registers 4

    .prologue
    .line 138
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/ag;->e:Landroid/support/v7/internal/view/menu/r;

    if-eqz v0, :cond_e

    iget-object v0, p0, Landroid/support/v7/internal/view/menu/ag;->e:Landroid/support/v7/internal/view/menu/r;

    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->getItemId()I

    move-result v0

    .line 139
    :goto_a
    if-nez v0, :cond_10

    .line 140
    const/4 v0, 0x0

    .line 142
    :goto_d
    return-object v0

    .line 138
    :cond_e
    const/4 v0, 0x0

    goto :goto_a

    .line 142
    :cond_10
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-super {p0}, Landroid/support/v7/internal/view/menu/n;->a()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ":"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_d
.end method

.method public final a(Landroid/support/v7/internal/view/menu/o;)V
    .registers 3

    .prologue
    .line 74
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/ag;->d:Landroid/support/v7/internal/view/menu/n;

    invoke-virtual {v0, p1}, Landroid/support/v7/internal/view/menu/n;->a(Landroid/support/v7/internal/view/menu/o;)V

    .line 75
    return-void
.end method

.method public final a(Landroid/support/v7/internal/view/menu/n;Landroid/view/MenuItem;)Z
    .registers 4

    .prologue
    .line 83
    invoke-super {p0, p1, p2}, Landroid/support/v7/internal/view/menu/n;->a(Landroid/support/v7/internal/view/menu/n;Landroid/view/MenuItem;)Z

    move-result v0

    if-nez v0, :cond_e

    iget-object v0, p0, Landroid/support/v7/internal/view/menu/ag;->d:Landroid/support/v7/internal/view/menu/n;

    invoke-virtual {v0, p1, p2}, Landroid/support/v7/internal/view/menu/n;->a(Landroid/support/v7/internal/view/menu/n;Landroid/view/MenuItem;)Z

    move-result v0

    if-eqz v0, :cond_10

    :cond_e
    const/4 v0, 0x1

    :goto_f
    return v0

    :cond_10
    const/4 v0, 0x0

    goto :goto_f
.end method

.method public final a(Landroid/support/v7/internal/view/menu/r;)Z
    .registers 3

    .prologue
    .line 128
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/ag;->d:Landroid/support/v7/internal/view/menu/n;

    invoke-virtual {v0, p1}, Landroid/support/v7/internal/view/menu/n;->a(Landroid/support/v7/internal/view/menu/r;)Z

    move-result v0

    return v0
.end method

.method public final b()Z
    .registers 2

    .prologue
    .line 51
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/ag;->d:Landroid/support/v7/internal/view/menu/n;

    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/n;->b()Z

    move-result v0

    return v0
.end method

.method public final b(Landroid/support/v7/internal/view/menu/r;)Z
    .registers 3

    .prologue
    .line 133
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/ag;->d:Landroid/support/v7/internal/view/menu/n;

    invoke-virtual {v0, p1}, Landroid/support/v7/internal/view/menu/n;->b(Landroid/support/v7/internal/view/menu/r;)Z

    move-result v0

    return v0
.end method

.method public final c()Z
    .registers 2

    .prologue
    .line 61
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/ag;->d:Landroid/support/v7/internal/view/menu/n;

    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/n;->c()Z

    move-result v0

    return v0
.end method

.method public final clearHeader()V
    .registers 1

    .prologue
    .line 124
    return-void
.end method

.method public final getItem()Landroid/view/MenuItem;
    .registers 2

    .prologue
    .line 69
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/ag;->e:Landroid/support/v7/internal/view/menu/r;

    return-object v0
.end method

.method public final o()Landroid/support/v7/internal/view/menu/n;
    .registers 2

    .prologue
    .line 78
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/ag;->d:Landroid/support/v7/internal/view/menu/n;

    return-object v0
.end method

.method public final r()Landroid/view/Menu;
    .registers 2

    .prologue
    .line 65
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/ag;->d:Landroid/support/v7/internal/view/menu/n;

    return-object v0
.end method

.method public final setHeaderIcon(I)Landroid/view/SubMenu;
    .registers 3

    .prologue
    .line 103
    invoke-virtual {p0}, Landroid/support/v7/internal/view/menu/ag;->e()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-super {p0, v0}, Landroid/support/v7/internal/view/menu/n;->a(Landroid/graphics/drawable/Drawable;)Landroid/support/v7/internal/view/menu/n;

    .line 104
    return-object p0
.end method

.method public final setHeaderIcon(Landroid/graphics/drawable/Drawable;)Landroid/view/SubMenu;
    .registers 2

    .prologue
    .line 98
    invoke-super {p0, p1}, Landroid/support/v7/internal/view/menu/n;->a(Landroid/graphics/drawable/Drawable;)Landroid/support/v7/internal/view/menu/n;

    .line 99
    return-object p0
.end method

.method public final setHeaderTitle(I)Landroid/view/SubMenu;
    .registers 3

    .prologue
    .line 113
    invoke-virtual {p0}, Landroid/support/v7/internal/view/menu/ag;->e()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-super {p0, v0}, Landroid/support/v7/internal/view/menu/n;->a(Ljava/lang/CharSequence;)Landroid/support/v7/internal/view/menu/n;

    .line 114
    return-object p0
.end method

.method public final setHeaderTitle(Ljava/lang/CharSequence;)Landroid/view/SubMenu;
    .registers 2

    .prologue
    .line 108
    invoke-super {p0, p1}, Landroid/support/v7/internal/view/menu/n;->a(Ljava/lang/CharSequence;)Landroid/support/v7/internal/view/menu/n;

    .line 109
    return-object p0
.end method

.method public final setHeaderView(Landroid/view/View;)Landroid/view/SubMenu;
    .registers 2

    .prologue
    .line 118
    invoke-super {p0, p1}, Landroid/support/v7/internal/view/menu/n;->a(Landroid/view/View;)Landroid/support/v7/internal/view/menu/n;

    .line 119
    return-object p0
.end method

.method public final setIcon(I)Landroid/view/SubMenu;
    .registers 3

    .prologue
    .line 93
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/ag;->e:Landroid/support/v7/internal/view/menu/r;

    invoke-virtual {v0, p1}, Landroid/support/v7/internal/view/menu/r;->setIcon(I)Landroid/view/MenuItem;

    .line 94
    return-object p0
.end method

.method public final setIcon(Landroid/graphics/drawable/Drawable;)Landroid/view/SubMenu;
    .registers 3

    .prologue
    .line 88
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/ag;->e:Landroid/support/v7/internal/view/menu/r;

    invoke-virtual {v0, p1}, Landroid/support/v7/internal/view/menu/r;->setIcon(Landroid/graphics/drawable/Drawable;)Landroid/view/MenuItem;

    .line 89
    return-object p0
.end method

.method public final setQwertyMode(Z)V
    .registers 3

    .prologue
    .line 46
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/ag;->d:Landroid/support/v7/internal/view/menu/n;

    invoke-virtual {v0, p1}, Landroid/support/v7/internal/view/menu/n;->setQwertyMode(Z)V

    .line 47
    return-void
.end method
