###### Class android.support.v7.internal.view.menu.i (android.support.v7.internal.view.menu.i)
.class public abstract Landroid/support/v7/internal/view/menu/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/support/v7/internal/view/menu/aa;


# instance fields
.field private a:Landroid/support/v7/internal/view/menu/ab;

.field private b:I

.field protected c:Landroid/content/Context;

.field protected d:Landroid/content/Context;

.field protected e:Landroid/support/v7/internal/view/menu/n;

.field protected f:Landroid/view/LayoutInflater;

.field protected g:Landroid/view/LayoutInflater;

.field protected h:Landroid/support/v7/internal/view/menu/ac;

.field private i:I

.field private j:I


# direct methods
.method public constructor <init>(Landroid/content/Context;II)V
    .registers 5

    .prologue
    .line 56
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 57
    iput-object p1, p0, Landroid/support/v7/internal/view/menu/i;->c:Landroid/content/Context;

    .line 58
    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    iput-object v0, p0, Landroid/support/v7/internal/view/menu/i;->f:Landroid/view/LayoutInflater;

    .line 59
    iput p2, p0, Landroid/support/v7/internal/view/menu/i;->b:I

    .line 60
    iput p3, p0, Landroid/support/v7/internal/view/menu/i;->i:I

    .line 61
    return-void
.end method


# virtual methods
.method public a(Landroid/view/ViewGroup;)Landroid/support/v7/internal/view/menu/ac;
    .registers 5

    .prologue
    .line 71
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/i;->h:Landroid/support/v7/internal/view/menu/ac;

    if-nez v0, :cond_1c

    .line 72
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/i;->f:Landroid/view/LayoutInflater;

    iget v1, p0, Landroid/support/v7/internal/view/menu/i;->b:I

    const/4 v2, 0x0

    invoke-virtual {v0, v1, p1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/view/menu/ac;

    iput-object v0, p0, Landroid/support/v7/internal/view/menu/i;->h:Landroid/support/v7/internal/view/menu/ac;

    .line 73
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/i;->h:Landroid/support/v7/internal/view/menu/ac;

    iget-object v1, p0, Landroid/support/v7/internal/view/menu/i;->e:Landroid/support/v7/internal/view/menu/n;

    invoke-interface {v0, v1}, Landroid/support/v7/internal/view/menu/ac;->a(Landroid/support/v7/internal/view/menu/n;)V

    .line 74
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/view/menu/i;->c(Z)V

    .line 77
    :cond_1c
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/i;->h:Landroid/support/v7/internal/view/menu/ac;

    return-object v0
.end method

.method public a(Landroid/support/v7/internal/view/menu/r;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .registers 7

    .prologue
    .line 175
    instance-of v0, p2, Landroid/support/v7/internal/view/menu/ad;

    if-eqz v0, :cond_d

    .line 176
    check-cast p2, Landroid/support/v7/internal/view/menu/ad;

    move-object v0, p2

    .line 180
    :goto_7
    invoke-virtual {p0, p1, v0}, Landroid/support/v7/internal/view/menu/i;->a(Landroid/support/v7/internal/view/menu/r;Landroid/support/v7/internal/view/menu/ad;)V

    .line 181
    check-cast v0, Landroid/view/View;

    return-object v0

    .line 178
    :cond_d
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/i;->f:Landroid/view/LayoutInflater;

    iget v1, p0, Landroid/support/v7/internal/view/menu/i;->i:I

    const/4 v2, 0x0

    invoke-virtual {v0, v1, p3, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/view/menu/ad;

    goto :goto_7
.end method

.method public a(Landroid/content/Context;Landroid/support/v7/internal/view/menu/n;)V
    .registers 4

    .prologue
    .line 65
    iput-object p1, p0, Landroid/support/v7/internal/view/menu/i;->d:Landroid/content/Context;

    .line 66
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/i;->d:Landroid/content/Context;

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    iput-object v0, p0, Landroid/support/v7/internal/view/menu/i;->g:Landroid/view/LayoutInflater;

    .line 67
    iput-object p2, p0, Landroid/support/v7/internal/view/menu/i;->e:Landroid/support/v7/internal/view/menu/n;

    .line 68
    return-void
.end method

.method public final a(Landroid/support/v7/internal/view/menu/ab;)V
    .registers 2

    .prologue
    .line 150
    iput-object p1, p0, Landroid/support/v7/internal/view/menu/i;->a:Landroid/support/v7/internal/view/menu/ab;

    .line 151
    return-void
.end method

.method public a(Landroid/support/v7/internal/view/menu/n;Z)V
    .registers 4

    .prologue
    .line 204
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/i;->a:Landroid/support/v7/internal/view/menu/ab;

    if-eqz v0, :cond_9

    .line 205
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/i;->a:Landroid/support/v7/internal/view/menu/ab;

    invoke-interface {v0, p1, p2}, Landroid/support/v7/internal/view/menu/ab;->a(Landroid/support/v7/internal/view/menu/n;Z)V

    .line 207
    :cond_9
    return-void
.end method

.method public abstract a(Landroid/support/v7/internal/view/menu/r;Landroid/support/v7/internal/view/menu/ad;)V
.end method

.method public a(Landroid/support/v7/internal/view/menu/ag;)Z
    .registers 3

    .prologue
    .line 210
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/i;->a:Landroid/support/v7/internal/view/menu/ab;

    if-eqz v0, :cond_b

    .line 211
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/i;->a:Landroid/support/v7/internal/view/menu/ab;

    invoke-interface {v0, p1}, Landroid/support/v7/internal/view/menu/ab;->b(Landroid/support/v7/internal/view/menu/n;)Z

    move-result v0

    .line 213
    :goto_a
    return v0

    :cond_b
    const/4 v0, 0x0

    goto :goto_a
.end method

.method public a(Landroid/support/v7/internal/view/menu/r;)Z
    .registers 3

    .prologue
    .line 200
    const/4 v0, 0x1

    return v0
.end method

.method protected a(Landroid/view/ViewGroup;I)Z
    .registers 4

    .prologue
    .line 145
    invoke-virtual {p1, p2}, Landroid/view/ViewGroup;->removeViewAt(I)V

    .line 146
    const/4 v0, 0x1

    return v0
.end method

.method public final b(I)V
    .registers 2

    .prologue
    .line 233
    iput p1, p0, Landroid/support/v7/internal/view/menu/i;->j:I

    .line 234
    return-void
.end method

.method public final b(Landroid/support/v7/internal/view/menu/r;)Z
    .registers 3

    .prologue
    .line 221
    const/4 v0, 0x0

    return v0
.end method

.method public c(Z)V
    .registers 12

    .prologue
    const/4 v5, 0x0

    .line 84
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/i;->h:Landroid/support/v7/internal/view/menu/ac;

    check-cast v0, Landroid/view/ViewGroup;

    .line 85
    if-nez v0, :cond_8

    .line 121
    :cond_7
    return-void

    .line 90
    :cond_8
    iget-object v1, p0, Landroid/support/v7/internal/view/menu/i;->e:Landroid/support/v7/internal/view/menu/n;

    if-eqz v1, :cond_71

    .line 91
    iget-object v1, p0, Landroid/support/v7/internal/view/menu/i;->e:Landroid/support/v7/internal/view/menu/n;

    invoke-virtual {v1}, Landroid/support/v7/internal/view/menu/n;->l()V

    .line 92
    iget-object v1, p0, Landroid/support/v7/internal/view/menu/i;->e:Landroid/support/v7/internal/view/menu/n;

    invoke-virtual {v1}, Landroid/support/v7/internal/view/menu/n;->k()Ljava/util/ArrayList;

    move-result-object v7

    .line 93
    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    move-result v8

    move v6, v5

    move v4, v5

    .line 94
    :goto_1d
    if-ge v6, v8, :cond_60

    .line 95
    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v7/internal/view/menu/r;

    .line 96
    invoke-virtual {p0, v1}, Landroid/support/v7/internal/view/menu/i;->a(Landroid/support/v7/internal/view/menu/r;)Z

    move-result v2

    if-eqz v2, :cond_6f

    .line 97
    invoke-virtual {v0, v4}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    .line 98
    instance-of v2, v3, Landroid/support/v7/internal/view/menu/ad;

    if-eqz v2, :cond_5e

    move-object v2, v3

    check-cast v2, Landroid/support/v7/internal/view/menu/ad;

    invoke-interface {v2}, Landroid/support/v7/internal/view/menu/ad;->a()Landroid/support/v7/internal/view/menu/r;

    move-result-object v2

    .line 100
    :goto_3a
    invoke-virtual {p0, v1, v3, v0}, Landroid/support/v7/internal/view/menu/i;->a(Landroid/support/v7/internal/view/menu/r;Landroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v9

    .line 101
    if-eq v1, v2, :cond_43

    .line 103
    invoke-virtual {v9, v5}, Landroid/view/View;->setPressed(Z)V

    .line 107
    :cond_43
    if-eq v9, v3, :cond_57

    .line 108
    invoke-virtual {v9}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    check-cast v1, Landroid/view/ViewGroup;

    if-eqz v1, :cond_50

    invoke-virtual {v1, v9}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    :cond_50
    iget-object v1, p0, Landroid/support/v7/internal/view/menu/i;->h:Landroid/support/v7/internal/view/menu/ac;

    check-cast v1, Landroid/view/ViewGroup;

    invoke-virtual {v1, v9, v4}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    .line 110
    :cond_57
    add-int/lit8 v1, v4, 0x1

    .line 94
    :goto_59
    add-int/lit8 v2, v6, 0x1

    move v6, v2

    move v4, v1

    goto :goto_1d

    .line 98
    :cond_5e
    const/4 v2, 0x0

    goto :goto_3a

    .line 116
    :cond_60
    :goto_60
    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v1

    if-ge v4, v1, :cond_7

    .line 117
    invoke-virtual {p0, v0, v4}, Landroid/support/v7/internal/view/menu/i;->a(Landroid/view/ViewGroup;I)Z

    move-result v1

    if-nez v1, :cond_60

    .line 118
    add-int/lit8 v4, v4, 0x1

    goto :goto_60

    :cond_6f
    move v1, v4

    goto :goto_59

    :cond_71
    move v4, v5

    goto :goto_60
.end method

.method public final c(Landroid/support/v7/internal/view/menu/r;)Z
    .registers 3

    .prologue
    .line 225
    const/4 v0, 0x0

    return v0
.end method

.method public i()Z
    .registers 2

    .prologue
    .line 217
    const/4 v0, 0x0

    return v0
.end method
