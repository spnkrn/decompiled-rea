###### Class android.support.v7.internal.view.menu.m (android.support.v7.internal.view.menu.m)
.class final Landroid/support/v7/internal/view/menu/m;
.super Landroid/widget/BaseAdapter;
.source "SourceFile"


# instance fields
.field final synthetic a:Landroid/support/v7/internal/view/menu/l;

.field private b:I


# direct methods
.method public constructor <init>(Landroid/support/v7/internal/view/menu/l;)V
    .registers 3

    .prologue
    .line 234
    iput-object p1, p0, Landroid/support/v7/internal/view/menu/m;->a:Landroid/support/v7/internal/view/menu/l;

    invoke-direct {p0}, Landroid/widget/BaseAdapter;-><init>()V

    .line 232
    const/4 v0, -0x1

    iput v0, p0, Landroid/support/v7/internal/view/menu/m;->b:I

    .line 235
    invoke-direct {p0}, Landroid/support/v7/internal/view/menu/m;->a()V

    .line 236
    return-void
.end method

.method private a()V
    .registers 6

    .prologue
    .line 273
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/m;->a:Landroid/support/v7/internal/view/menu/l;

    iget-object v0, v0, Landroid/support/v7/internal/view/menu/l;->c:Landroid/support/v7/internal/view/menu/n;

    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/n;->q()Landroid/support/v7/internal/view/menu/r;

    move-result-object v2

    .line 274
    if-eqz v2, :cond_29

    .line 275
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/m;->a:Landroid/support/v7/internal/view/menu/l;

    iget-object v0, v0, Landroid/support/v7/internal/view/menu/l;->c:Landroid/support/v7/internal/view/menu/n;

    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/n;->n()Ljava/util/ArrayList;

    move-result-object v3

    .line 276
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v4

    .line 277
    const/4 v0, 0x0

    move v1, v0

    :goto_18
    if-ge v1, v4, :cond_29

    .line 278
    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/view/menu/r;

    .line 279
    if-ne v0, v2, :cond_25

    .line 280
    iput v1, p0, Landroid/support/v7/internal/view/menu/m;->b:I

    .line 286
    :goto_24
    return-void

    .line 277
    :cond_25
    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_18

    .line 285
    :cond_29
    const/4 v0, -0x1

    iput v0, p0, Landroid/support/v7/internal/view/menu/m;->b:I

    goto :goto_24
.end method


# virtual methods
.method public final a(I)Landroid/support/v7/internal/view/menu/r;
    .registers 5

    .prologue
    .line 248
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/m;->a:Landroid/support/v7/internal/view/menu/l;

    iget-object v0, v0, Landroid/support/v7/internal/view/menu/l;->c:Landroid/support/v7/internal/view/menu/n;

    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/n;->n()Ljava/util/ArrayList;

    move-result-object v1

    .line 249
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/m;->a:Landroid/support/v7/internal/view/menu/l;

    invoke-static {v0}, Landroid/support/v7/internal/view/menu/l;->a(Landroid/support/v7/internal/view/menu/l;)I

    move-result v0

    add-int/2addr v0, p1

    .line 250
    iget v2, p0, Landroid/support/v7/internal/view/menu/m;->b:I

    if-ltz v2, :cond_19

    iget v2, p0, Landroid/support/v7/internal/view/menu/m;->b:I

    if-lt v0, v2, :cond_19

    .line 251
    add-int/lit8 v0, v0, 0x1

    .line 253
    :cond_19
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/view/menu/r;

    return-object v0
.end method

.method public final getCount()I
    .registers 3

    .prologue
    .line 239
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/m;->a:Landroid/support/v7/internal/view/menu/l;

    iget-object v0, v0, Landroid/support/v7/internal/view/menu/l;->c:Landroid/support/v7/internal/view/menu/n;

    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/n;->n()Ljava/util/ArrayList;

    move-result-object v0

    .line 240
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    iget-object v1, p0, Landroid/support/v7/internal/view/menu/m;->a:Landroid/support/v7/internal/view/menu/l;

    invoke-static {v1}, Landroid/support/v7/internal/view/menu/l;->a(Landroid/support/v7/internal/view/menu/l;)I

    move-result v1

    sub-int/2addr v0, v1

    .line 241
    iget v1, p0, Landroid/support/v7/internal/view/menu/m;->b:I

    if-gez v1, :cond_18

    .line 244
    :goto_17
    return v0

    :cond_18
    add-int/lit8 v0, v0, -0x1

    goto :goto_17
.end method

.method public final synthetic getItem(I)Ljava/lang/Object;
    .registers 3

    .prologue
    .line 231
    invoke-virtual {p0, p1}, Landroid/support/v7/internal/view/menu/m;->a(I)Landroid/support/v7/internal/view/menu/r;

    move-result-object v0

    return-object v0
.end method

.method public final getItemId(I)J
    .registers 4

    .prologue
    .line 259
    int-to-long v0, p1

    return-wide v0
.end method

.method public final getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;
    .registers 7

    .prologue
    .line 263
    if-nez p2, :cond_1a

    .line 264
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/m;->a:Landroid/support/v7/internal/view/menu/l;

    iget-object v0, v0, Landroid/support/v7/internal/view/menu/l;->b:Landroid/view/LayoutInflater;

    iget-object v1, p0, Landroid/support/v7/internal/view/menu/m;->a:Landroid/support/v7/internal/view/menu/l;

    iget v1, v1, Landroid/support/v7/internal/view/menu/l;->f:I

    const/4 v2, 0x0

    invoke-virtual {v0, v1, p3, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v1

    :goto_f
    move-object v0, v1

    .line 267
    check-cast v0, Landroid/support/v7/internal/view/menu/ad;

    .line 268
    invoke-virtual {p0, p1}, Landroid/support/v7/internal/view/menu/m;->a(I)Landroid/support/v7/internal/view/menu/r;

    move-result-object v2

    invoke-interface {v0, v2}, Landroid/support/v7/internal/view/menu/ad;->a(Landroid/support/v7/internal/view/menu/r;)V

    .line 269
    return-object v1

    :cond_1a
    move-object v1, p2

    goto :goto_f
.end method

.method public final notifyDataSetChanged()V
    .registers 1

    .prologue
    .line 290
    invoke-direct {p0}, Landroid/support/v7/internal/view/menu/m;->a()V

    .line 291
    invoke-super {p0}, Landroid/widget/BaseAdapter;->notifyDataSetChanged()V

    .line 292
    return-void
.end method
