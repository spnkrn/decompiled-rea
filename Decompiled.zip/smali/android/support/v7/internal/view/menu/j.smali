###### Class android.support.v7.internal.view.menu.j (android.support.v7.internal.view.menu.j)
.class abstract Landroid/support/v7/internal/view/menu/j;
.super Landroid/support/v7/internal/view/menu/k;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Landroid/support/v7/internal/view/menu/k",
        "<TT;>;"
    }
.end annotation


# instance fields
.field private b:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap",
            "<",
            "Landroid/view/MenuItem;",
            "Landroid/support/v4/a/a/b;",
            ">;"
        }
    .end annotation
.end field

.field private c:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap",
            "<",
            "Landroid/view/SubMenu;",
            "Landroid/view/SubMenu;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Ljava/lang/Object;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TT;)V"
        }
    .end annotation

    .prologue
    .line 33
    invoke-direct {p0, p1}, Landroid/support/v7/internal/view/menu/k;-><init>(Ljava/lang/Object;)V

    .line 34
    return-void
.end method


# virtual methods
.method final a(Landroid/view/MenuItem;)Landroid/support/v4/a/a/b;
    .registers 4

    .prologue
    .line 37
    if-eqz p1, :cond_3a

    .line 39
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/j;->b:Ljava/util/HashMap;

    if-nez v0, :cond_d

    .line 40
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Landroid/support/v7/internal/view/menu/j;->b:Ljava/util/HashMap;

    .line 43
    :cond_d
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/j;->b:Ljava/util/HashMap;

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/a/a/b;

    .line 45
    if-nez v0, :cond_27

    .line 46
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x10

    if-lt v0, v1, :cond_28

    new-instance v0, Landroid/support/v7/internal/view/menu/w;

    invoke-direct {v0, p1}, Landroid/support/v7/internal/view/menu/w;-><init>(Landroid/view/MenuItem;)V

    .line 47
    :goto_22
    iget-object v1, p0, Landroid/support/v7/internal/view/menu/j;->b:Ljava/util/HashMap;

    invoke-virtual {v1, p1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 52
    :cond_27
    :goto_27
    return-object v0

    .line 46
    :cond_28
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0xe

    if-lt v0, v1, :cond_34

    new-instance v0, Landroid/support/v7/internal/view/menu/s;

    invoke-direct {v0, p1}, Landroid/support/v7/internal/view/menu/s;-><init>(Landroid/view/MenuItem;)V

    goto :goto_22

    :cond_34
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0

    .line 52
    :cond_3a
    const/4 v0, 0x0

    goto :goto_27
.end method

.method final a(Landroid/view/SubMenu;)Landroid/view/SubMenu;
    .registers 4

    .prologue
    .line 56
    if-eqz p1, :cond_2e

    .line 58
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/j;->c:Ljava/util/HashMap;

    if-nez v0, :cond_d

    .line 59
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    iput-object v0, p0, Landroid/support/v7/internal/view/menu/j;->c:Ljava/util/HashMap;

    .line 62
    :cond_d
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/j;->c:Ljava/util/HashMap;

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/SubMenu;

    .line 64
    if-nez v0, :cond_27

    .line 65
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0xe

    if-lt v0, v1, :cond_28

    new-instance v0, Landroid/support/v7/internal/view/menu/ah;

    invoke-direct {v0, p1}, Landroid/support/v7/internal/view/menu/ah;-><init>(Landroid/view/SubMenu;)V

    .line 66
    iget-object v1, p0, Landroid/support/v7/internal/view/menu/j;->c:Ljava/util/HashMap;

    invoke-virtual {v1, p1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 70
    :cond_27
    :goto_27
    return-object v0

    .line 65
    :cond_28
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0

    .line 70
    :cond_2e
    const/4 v0, 0x0

    goto :goto_27
.end method

.method final a()V
    .registers 2

    .prologue
    .line 75
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/j;->b:Ljava/util/HashMap;

    if-eqz v0, :cond_9

    .line 76
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/j;->b:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->clear()V

    .line 78
    :cond_9
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/j;->c:Ljava/util/HashMap;

    if-eqz v0, :cond_12

    .line 79
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/j;->c:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->clear()V

    .line 81
    :cond_12
    return-void
.end method

.method final a(I)V
    .registers 4

    .prologue
    .line 84
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/j;->b:Ljava/util/HashMap;

    if-nez v0, :cond_5

    .line 97
    :cond_4
    return-void

    .line 88
    :cond_5
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/j;->b:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .line 91
    :cond_f
    :goto_f
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_4

    .line 92
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/MenuItem;

    .line 93
    invoke-interface {v0}, Landroid/view/MenuItem;->getGroupId()I

    move-result v0

    if-ne p1, v0, :cond_f

    .line 94
    invoke-interface {v1}, Ljava/util/Iterator;->remove()V

    goto :goto_f
.end method

.method final b(I)V
    .registers 4

    .prologue
    .line 100
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/j;->b:Ljava/util/HashMap;

    if-nez v0, :cond_5

    .line 111
    :cond_4
    :goto_4
    return-void

    .line 104
    :cond_5
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/j;->b:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    .line 107
    :cond_f
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_4

    .line 108
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/MenuItem;

    .line 109
    invoke-interface {v0}, Landroid/view/MenuItem;->getItemId()I

    move-result v0

    if-ne p1, v0, :cond_f

    .line 110
    invoke-interface {v1}, Ljava/util/Iterator;->remove()V

    goto :goto_4
.end method
