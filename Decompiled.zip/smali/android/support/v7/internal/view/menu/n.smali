###### Class android.support.v7.internal.view.menu.n (android.support.v7.internal.view.menu.n)
.class public Landroid/support/v7/internal/view/menu/n;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/support/v4/a/a/a;


# static fields
.field private static final d:[I


# instance fields
.field a:Ljava/lang/CharSequence;

.field b:Landroid/graphics/drawable/Drawable;

.field c:Landroid/view/View;

.field private final e:Landroid/content/Context;

.field private final f:Landroid/content/res/Resources;

.field private g:Z

.field private h:Z

.field private i:Landroid/support/v7/internal/view/menu/o;

.field private j:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList",
            "<",
            "Landroid/support/v7/internal/view/menu/r;",
            ">;"
        }
    .end annotation
.end field

.field private k:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList",
            "<",
            "Landroid/support/v7/internal/view/menu/r;",
            ">;"
        }
    .end annotation
.end field

.field private l:Z

.field private m:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList",
            "<",
            "Landroid/support/v7/internal/view/menu/r;",
            ">;"
        }
    .end annotation
.end field

.field private n:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList",
            "<",
            "Landroid/support/v7/internal/view/menu/r;",
            ">;"
        }
    .end annotation
.end field

.field private o:Z

.field private p:I

.field private q:Landroid/view/ContextMenu$ContextMenuInfo;

.field private r:Z

.field private s:Z

.field private t:Z

.field private u:Z

.field private v:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList",
            "<",
            "Landroid/support/v7/internal/view/menu/r;",
            ">;"
        }
    .end annotation
.end field

.field private w:Ljava/util/concurrent/CopyOnWriteArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/CopyOnWriteArrayList",
            "<",
            "Ljava/lang/ref/WeakReference",
            "<",
            "Landroid/support/v7/internal/view/menu/aa;",
            ">;>;"
        }
    .end annotation
.end field

.field private x:Landroid/support/v7/internal/view/menu/r;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .prologue
    .line 47
    const/4 v0, 0x6

    new-array v0, v0, [I

    fill-array-data v0, :array_a

    sput-object v0, Landroid/support/v7/internal/view/menu/n;->d:[I

    return-void

    nop

    :array_a
    .array-data 4
        0x1
        0x4
        0x5
        0x3
        0x2
        0x0
    .end array-data
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 6

    .prologue
    const/4 v0, 0x1

    const/4 v1, 0x0

    .line 192
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 114
    iput v1, p0, Landroid/support/v7/internal/view/menu/n;->p:I

    .line 142
    iput-boolean v1, p0, Landroid/support/v7/internal/view/menu/n;->r:Z

    .line 144
    iput-boolean v1, p0, Landroid/support/v7/internal/view/menu/n;->s:Z

    .line 146
    iput-boolean v1, p0, Landroid/support/v7/internal/view/menu/n;->t:Z

    .line 148
    iput-boolean v1, p0, Landroid/support/v7/internal/view/menu/n;->u:Z

    .line 150
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, Landroid/support/v7/internal/view/menu/n;->v:Ljava/util/ArrayList;

    .line 152
    new-instance v2, Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-direct {v2}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    iput-object v2, p0, Landroid/support/v7/internal/view/menu/n;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 193
    iput-object p1, p0, Landroid/support/v7/internal/view/menu/n;->e:Landroid/content/Context;

    .line 194
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    iput-object v2, p0, Landroid/support/v7/internal/view/menu/n;->f:Landroid/content/res/Resources;

    .line 196
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    .line 198
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, Landroid/support/v7/internal/view/menu/n;->k:Ljava/util/ArrayList;

    .line 199
    iput-boolean v0, p0, Landroid/support/v7/internal/view/menu/n;->l:Z

    .line 201
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, Landroid/support/v7/internal/view/menu/n;->m:Ljava/util/ArrayList;

    .line 202
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, p0, Landroid/support/v7/internal/view/menu/n;->n:Ljava/util/ArrayList;

    .line 203
    iput-boolean v0, p0, Landroid/support/v7/internal/view/menu/n;->o:Z

    .line 205
    iget-object v2, p0, Landroid/support/v7/internal/view/menu/n;->f:Landroid/content/res/Resources;

    invoke-virtual {v2}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object v2

    iget v2, v2, Landroid/content/res/Configuration;->keyboard:I

    if-eq v2, v0, :cond_5c

    iget-object v2, p0, Landroid/support/v7/internal/view/menu/n;->f:Landroid/content/res/Resources;

    sget v3, Landroid/support/v7/a/d;->d:I

    invoke-virtual {v2, v3}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result v2

    if-eqz v2, :cond_5c

    :goto_59
    iput-boolean v0, p0, Landroid/support/v7/internal/view/menu/n;->h:Z

    .line 206
    return-void

    :cond_5c
    move v0, v1

    .line 205
    goto :goto_59
.end method

.method private static a(Ljava/util/ArrayList;I)I
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList",
            "<",
            "Landroid/support/v7/internal/view/menu/r;",
            ">;I)I"
        }
    .end annotation

    .prologue
    .line 790
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    move v1, v0

    :goto_7
    if-ltz v1, :cond_1c

    .line 791
    invoke-virtual {p0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/view/menu/r;

    .line 792
    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->b()I

    move-result v0

    if-gt v0, p1, :cond_18

    .line 793
    add-int/lit8 v0, v1, 0x1

    .line 797
    :goto_17
    return v0

    .line 790
    :cond_18
    add-int/lit8 v0, v1, -0x1

    move v1, v0

    goto :goto_7

    .line 797
    :cond_1c
    const/4 v0, 0x0

    goto :goto_17
.end method

.method private a(ILandroid/view/KeyEvent;)Landroid/support/v7/internal/view/menu/r;
    .registers 15

    .prologue
    const/4 v2, 0x0

    const/4 v4, 0x0

    .line 871
    iget-object v5, p0, Landroid/support/v7/internal/view/menu/n;->v:Ljava/util/ArrayList;

    .line 872
    invoke-virtual {v5}, Ljava/util/ArrayList;->clear()V

    .line 873
    invoke-direct {p0, v5, p1, p2}, Landroid/support/v7/internal/view/menu/n;->a(Ljava/util/List;ILandroid/view/KeyEvent;)V

    .line 875
    invoke-virtual {v5}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_12

    move-object v0, v2

    .line 906
    :cond_11
    :goto_11
    return-object v0

    .line 879
    :cond_12
    invoke-virtual {p2}, Landroid/view/KeyEvent;->getMetaState()I

    move-result v6

    .line 880
    new-instance v7, Landroid/view/KeyCharacterMap$KeyData;

    invoke-direct {v7}, Landroid/view/KeyCharacterMap$KeyData;-><init>()V

    .line 882
    invoke-virtual {p2, v7}, Landroid/view/KeyEvent;->getKeyData(Landroid/view/KeyCharacterMap$KeyData;)Z

    .line 885
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v8

    .line 886
    const/4 v0, 0x1

    if-ne v8, v0, :cond_2c

    .line 887
    invoke-virtual {v5, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/view/menu/r;

    goto :goto_11

    .line 890
    :cond_2c
    invoke-virtual {p0}, Landroid/support/v7/internal/view/menu/n;->b()Z

    move-result v9

    move v3, v4

    .line 893
    :goto_31
    if-ge v3, v8, :cond_67

    .line 894
    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/view/menu/r;

    .line 895
    if-eqz v9, :cond_62

    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->getAlphabeticShortcut()C

    move-result v1

    .line 897
    :goto_3f
    iget-object v10, v7, Landroid/view/KeyCharacterMap$KeyData;->meta:[C

    aget-char v10, v10, v4

    if-ne v1, v10, :cond_49

    and-int/lit8 v10, v6, 0x2

    if-eqz v10, :cond_11

    :cond_49
    iget-object v10, v7, Landroid/view/KeyCharacterMap$KeyData;->meta:[C

    const/4 v11, 0x2

    aget-char v10, v10, v11

    if-ne v1, v10, :cond_54

    and-int/lit8 v10, v6, 0x2

    if-nez v10, :cond_11

    :cond_54
    if-eqz v9, :cond_5e

    const/16 v10, 0x8

    if-ne v1, v10, :cond_5e

    const/16 v1, 0x43

    if-eq p1, v1, :cond_11

    .line 893
    :cond_5e
    add-int/lit8 v0, v3, 0x1

    move v3, v0

    goto :goto_31

    .line 895
    :cond_62
    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->getNumericShortcut()C

    move-result v1

    goto :goto_3f

    :cond_67
    move-object v0, v2

    .line 906
    goto :goto_11
.end method

.method private a(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;
    .registers 13

    .prologue
    .line 400
    const/high16 v0, -0x10000

    and-int/2addr v0, p3

    shr-int/lit8 v0, v0, 0x10

    if-ltz v0, :cond_c

    sget-object v1, Landroid/support/v7/internal/view/menu/n;->d:[I

    array-length v1, v1

    if-lt v0, v1, :cond_14

    :cond_c
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "order does not contain a valid category."

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_14
    sget-object v1, Landroid/support/v7/internal/view/menu/n;->d:[I

    aget v0, v1, v0

    shl-int/lit8 v0, v0, 0x10

    const v1, 0xffff

    and-int/2addr v1, p3

    or-int v5, v0, v1

    .line 402
    new-instance v0, Landroid/support/v7/internal/view/menu/r;

    iget v7, p0, Landroid/support/v7/internal/view/menu/n;->p:I

    move-object v1, p0

    move v2, p1

    move v3, p2

    move v4, p3

    move-object v6, p4

    invoke-direct/range {v0 .. v7}, Landroid/support/v7/internal/view/menu/r;-><init>(Landroid/support/v7/internal/view/menu/n;IIIILjava/lang/CharSequence;I)V

    .line 405
    iget-object v1, p0, Landroid/support/v7/internal/view/menu/n;->q:Landroid/view/ContextMenu$ContextMenuInfo;

    if-eqz v1, :cond_35

    .line 407
    iget-object v1, p0, Landroid/support/v7/internal/view/menu/n;->q:Landroid/view/ContextMenu$ContextMenuInfo;

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/view/menu/r;->a(Landroid/view/ContextMenu$ContextMenuInfo;)V

    .line 410
    :cond_35
    iget-object v1, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    iget-object v2, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    invoke-static {v2, v5}, Landroid/support/v7/internal/view/menu/n;->a(Ljava/util/ArrayList;I)I

    move-result v2

    invoke-virtual {v1, v2, v0}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    .line 411
    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Landroid/support/v7/internal/view/menu/n;->b(Z)V

    .line 413
    return-object v0
.end method

.method private a(IZ)V
    .registers 4

    .prologue
    .line 521
    if-ltz p1, :cond_a

    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lt p1, v0, :cond_b

    .line 530
    :cond_a
    :goto_a
    return-void

    .line 525
    :cond_b
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 527
    if-eqz p2, :cond_a

    .line 528
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/view/menu/n;->b(Z)V

    goto :goto_a
.end method

.method private a(Ljava/lang/CharSequence;Landroid/graphics/drawable/Drawable;Landroid/view/View;)V
    .registers 6

    .prologue
    const/4 v1, 0x0

    .line 1154
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->f:Landroid/content/res/Resources;

    .line 1156
    if-eqz p3, :cond_10

    .line 1157
    iput-object p3, p0, Landroid/support/v7/internal/view/menu/n;->c:Landroid/view/View;

    .line 1160
    iput-object v1, p0, Landroid/support/v7/internal/view/menu/n;->a:Ljava/lang/CharSequence;

    .line 1161
    iput-object v1, p0, Landroid/support/v7/internal/view/menu/n;->b:Landroid/graphics/drawable/Drawable;

    .line 1180
    :goto_b
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/view/menu/n;->b(Z)V

    .line 1181
    return-void

    .line 1163
    :cond_10
    if-eqz p1, :cond_14

    .line 1166
    iput-object p1, p0, Landroid/support/v7/internal/view/menu/n;->a:Ljava/lang/CharSequence;

    .line 1169
    :cond_14
    if-eqz p2, :cond_18

    .line 1172
    iput-object p2, p0, Landroid/support/v7/internal/view/menu/n;->b:Landroid/graphics/drawable/Drawable;

    .line 1176
    :cond_18
    iput-object v1, p0, Landroid/support/v7/internal/view/menu/n;->c:Landroid/view/View;

    goto :goto_b
.end method

.method private a(Ljava/util/List;ILandroid/view/KeyEvent;)V
    .registers 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List",
            "<",
            "Landroid/support/v7/internal/view/menu/r;",
            ">;I",
            "Landroid/view/KeyEvent;",
            ")V"
        }
    .end annotation

    .prologue
    const/16 v10, 0x43

    const/4 v3, 0x0

    .line 825
    invoke-virtual {p0}, Landroid/support/v7/internal/view/menu/n;->b()Z

    move-result v4

    .line 826
    invoke-virtual {p3}, Landroid/view/KeyEvent;->getMetaState()I

    move-result v5

    .line 827
    new-instance v6, Landroid/view/KeyCharacterMap$KeyData;

    invoke-direct {v6}, Landroid/view/KeyCharacterMap$KeyData;-><init>()V

    .line 829
    invoke-virtual {p3, v6}, Landroid/view/KeyEvent;->getKeyData(Landroid/view/KeyCharacterMap$KeyData;)Z

    move-result v0

    .line 831
    if-nez v0, :cond_19

    if-eq p2, v10, :cond_19

    .line 855
    :cond_18
    return-void

    .line 836
    :cond_19
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v7

    move v2, v3

    .line 837
    :goto_20
    if-ge v2, v7, :cond_18

    .line 838
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/view/menu/r;

    .line 839
    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->hasSubMenu()Z

    move-result v1

    if-eqz v1, :cond_39

    .line 840
    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->getSubMenu()Landroid/view/SubMenu;

    move-result-object v1

    check-cast v1, Landroid/support/v7/internal/view/menu/n;

    invoke-direct {v1, p1, p2, p3}, Landroid/support/v7/internal/view/menu/n;->a(Ljava/util/List;ILandroid/view/KeyEvent;)V

    .line 843
    :cond_39
    if-eqz v4, :cond_67

    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->getAlphabeticShortcut()C

    move-result v1

    .line 845
    :goto_3f
    and-int/lit8 v8, v5, 0x5

    if-nez v8, :cond_63

    if-eqz v1, :cond_63

    iget-object v8, v6, Landroid/view/KeyCharacterMap$KeyData;->meta:[C

    aget-char v8, v8, v3

    if-eq v1, v8, :cond_5a

    iget-object v8, v6, Landroid/view/KeyCharacterMap$KeyData;->meta:[C

    const/4 v9, 0x2

    aget-char v8, v8, v9

    if-eq v1, v8, :cond_5a

    if-eqz v4, :cond_63

    const/16 v8, 0x8

    if-ne v1, v8, :cond_63

    if-ne p2, v10, :cond_63

    :cond_5a
    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->isEnabled()Z

    move-result v1

    if-eqz v1, :cond_63

    .line 852
    invoke-interface {p1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 837
    :cond_63
    add-int/lit8 v0, v2, 0x1

    move v2, v0

    goto :goto_20

    .line 843
    :cond_67
    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->getNumericShortcut()C

    move-result v1

    goto :goto_3f
.end method


# virtual methods
.method protected final a(Landroid/graphics/drawable/Drawable;)Landroid/support/v7/internal/view/menu/n;
    .registers 3

    .prologue
    const/4 v0, 0x0

    .line 1215
    invoke-direct {p0, v0, p1, v0}, Landroid/support/v7/internal/view/menu/n;->a(Ljava/lang/CharSequence;Landroid/graphics/drawable/Drawable;Landroid/view/View;)V

    .line 1216
    return-object p0
.end method

.method protected final a(Landroid/view/View;)Landroid/support/v7/internal/view/menu/n;
    .registers 3

    .prologue
    const/4 v0, 0x0

    .line 1239
    invoke-direct {p0, v0, v0, p1}, Landroid/support/v7/internal/view/menu/n;->a(Ljava/lang/CharSequence;Landroid/graphics/drawable/Drawable;Landroid/view/View;)V

    .line 1240
    return-object p0
.end method

.method protected final a(Ljava/lang/CharSequence;)Landroid/support/v7/internal/view/menu/n;
    .registers 3

    .prologue
    const/4 v0, 0x0

    .line 1191
    invoke-direct {p0, p1, v0, v0}, Landroid/support/v7/internal/view/menu/n;->a(Ljava/lang/CharSequence;Landroid/graphics/drawable/Drawable;Landroid/view/View;)V

    .line 1192
    return-object p0
.end method

.method protected a()Ljava/lang/String;
    .registers 2

    .prologue
    .line 389
    const-string v0, "android:menu:actionviewstates"

    return-object v0
.end method

.method public final a(Landroid/os/Bundle;)V
    .registers 9

    .prologue
    .line 332
    const/4 v1, 0x0

    .line 334
    invoke-virtual {p0}, Landroid/support/v7/internal/view/menu/n;->size()I

    move-result v3

    .line 335
    const/4 v0, 0x0

    move v2, v0

    move-object v0, v1

    :goto_8
    if-ge v2, v3, :cond_49

    .line 336
    invoke-virtual {p0, v2}, Landroid/support/v7/internal/view/menu/n;->getItem(I)Landroid/view/MenuItem;

    move-result-object v4

    .line 337
    invoke-static {v4}, Landroid/support/v4/view/x;->a(Landroid/view/MenuItem;)Landroid/view/View;

    move-result-object v1

    .line 338
    if-eqz v1, :cond_34

    invoke-virtual {v1}, Landroid/view/View;->getId()I

    move-result v5

    const/4 v6, -0x1

    if-eq v5, v6, :cond_34

    .line 339
    if-nez v0, :cond_22

    .line 340
    new-instance v0, Landroid/util/SparseArray;

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    .line 342
    :cond_22
    invoke-virtual {v1, v0}, Landroid/view/View;->saveHierarchyState(Landroid/util/SparseArray;)V

    .line 343
    invoke-static {v4}, Landroid/support/v4/view/x;->c(Landroid/view/MenuItem;)Z

    move-result v1

    if-eqz v1, :cond_34

    .line 344
    const-string v1, "android:menu:expandedactionview"

    invoke-interface {v4}, Landroid/view/MenuItem;->getItemId()I

    move-result v5

    invoke-virtual {p1, v1, v5}, Landroid/os/Bundle;->putInt(Ljava/lang/String;I)V

    :cond_34
    move-object v1, v0

    .line 347
    invoke-interface {v4}, Landroid/view/MenuItem;->hasSubMenu()Z

    move-result v0

    if-eqz v0, :cond_44

    .line 348
    invoke-interface {v4}, Landroid/view/MenuItem;->getSubMenu()Landroid/view/SubMenu;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/view/menu/ag;

    .line 349
    invoke-virtual {v0, p1}, Landroid/support/v7/internal/view/menu/ag;->a(Landroid/os/Bundle;)V

    .line 335
    :cond_44
    add-int/lit8 v0, v2, 0x1

    move v2, v0

    move-object v0, v1

    goto :goto_8

    .line 353
    :cond_49
    if-eqz v0, :cond_52

    .line 354
    invoke-virtual {p0}, Landroid/support/v7/internal/view/menu/n;->a()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v1, v0}, Landroid/os/Bundle;->putSparseParcelableArray(Ljava/lang/String;Landroid/util/SparseArray;)V

    .line 356
    :cond_52
    return-void
.end method

.method public final a(Landroid/support/v7/internal/view/menu/aa;)V
    .registers 4

    .prologue
    .line 220
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    new-instance v1, Ljava/lang/ref/WeakReference;

    invoke-direct {v1, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    invoke-virtual {v0, v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    .line 221
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->e:Landroid/content/Context;

    invoke-interface {p1, v0, p0}, Landroid/support/v7/internal/view/menu/aa;->a(Landroid/content/Context;Landroid/support/v7/internal/view/menu/n;)V

    .line 222
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v7/internal/view/menu/n;->o:Z

    .line 223
    return-void
.end method

.method public a(Landroid/support/v7/internal/view/menu/o;)V
    .registers 2

    .prologue
    .line 393
    iput-object p1, p0, Landroid/support/v7/internal/view/menu/n;->i:Landroid/support/v7/internal/view/menu/o;

    .line 394
    return-void
.end method

.method final a(Landroid/view/MenuItem;)V
    .registers 8

    .prologue
    const/4 v2, 0x0

    .line 556
    invoke-interface {p1}, Landroid/view/MenuItem;->getGroupId()I

    move-result v4

    .line 558
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v5

    move v3, v2

    .line 559
    :goto_c
    if-ge v3, v5, :cond_34

    .line 560
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/view/menu/r;

    .line 561
    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->getGroupId()I

    move-result v1

    if-ne v1, v4, :cond_2e

    .line 562
    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->f()Z

    move-result v1

    if-eqz v1, :cond_2e

    .line 563
    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->isCheckable()Z

    move-result v1

    if-eqz v1, :cond_2e

    .line 566
    if-ne v0, p1, :cond_32

    const/4 v1, 0x1

    :goto_2b
    invoke-virtual {v0, v1}, Landroid/support/v7/internal/view/menu/r;->b(Z)V

    .line 559
    :cond_2e
    add-int/lit8 v0, v3, 0x1

    move v3, v0

    goto :goto_c

    :cond_32
    move v1, v2

    .line 566
    goto :goto_2b

    .line 573
    :cond_34
    return-void
.end method

.method final a(Z)V
    .registers 5

    .prologue
    .line 964
    iget-boolean v0, p0, Landroid/support/v7/internal/view/menu/n;->u:Z

    if-eqz v0, :cond_5

    .line 978
    :goto_4
    return-void

    .line 968
    :cond_5
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v7/internal/view/menu/n;->u:Z

    .line 969
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_e
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_2c

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/ref/WeakReference;

    .line 970
    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v7/internal/view/menu/aa;

    .line 971
    if-nez v1, :cond_28

    .line 972
    iget-object v1, p0, Landroid/support/v7/internal/view/menu/n;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v1, v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    goto :goto_e

    .line 974
    :cond_28
    invoke-interface {v1, p0, p1}, Landroid/support/v7/internal/view/menu/aa;->a(Landroid/support/v7/internal/view/menu/n;Z)V

    goto :goto_e

    .line 977
    :cond_2c
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v7/internal/view/menu/n;->u:Z

    goto :goto_4
.end method

.method a(Landroid/support/v7/internal/view/menu/n;Landroid/view/MenuItem;)Z
    .registers 4

    .prologue
    .line 777
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->i:Landroid/support/v7/internal/view/menu/o;

    if-eqz v0, :cond_e

    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->i:Landroid/support/v7/internal/view/menu/o;

    invoke-interface {v0, p2}, Landroid/support/v7/internal/view/menu/o;->a(Landroid/view/MenuItem;)Z

    move-result v0

    if-eqz v0, :cond_e

    const/4 v0, 0x1

    :goto_d
    return v0

    :cond_e
    const/4 v0, 0x0

    goto :goto_d
.end method

.method public a(Landroid/support/v7/internal/view/menu/r;)Z
    .registers 6

    .prologue
    const/4 v0, 0x0

    .line 1284
    iget-object v1, p0, Landroid/support/v7/internal/view/menu/n;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_a

    .line 1304
    :cond_9
    :goto_9
    return v0

    .line 1290
    :cond_a
    invoke-virtual {p0}, Landroid/support/v7/internal/view/menu/n;->g()V

    .line 1291
    iget-object v1, p0, Landroid/support/v7/internal/view/menu/n;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v3

    move v2, v0

    :goto_14
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_3e

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/ref/WeakReference;

    .line 1292
    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v7/internal/view/menu/aa;

    .line 1293
    if-nez v1, :cond_2e

    .line 1294
    iget-object v1, p0, Landroid/support/v7/internal/view/menu/n;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v1, v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    goto :goto_14

    .line 1295
    :cond_2e
    invoke-interface {v1, p1}, Landroid/support/v7/internal/view/menu/aa;->b(Landroid/support/v7/internal/view/menu/r;)Z

    move-result v0

    if-eqz v0, :cond_3c

    .line 1296
    :goto_34
    invoke-virtual {p0}, Landroid/support/v7/internal/view/menu/n;->h()V

    .line 1301
    if-eqz v0, :cond_9

    .line 1302
    iput-object p1, p0, Landroid/support/v7/internal/view/menu/n;->x:Landroid/support/v7/internal/view/menu/r;

    goto :goto_9

    :cond_3c
    move v2, v0

    goto :goto_14

    :cond_3e
    move v0, v2

    goto :goto_34
.end method

.method public final a(Landroid/view/MenuItem;I)Z
    .registers 10

    .prologue
    const/4 v6, 0x1

    const/4 v1, 0x0

    .line 916
    check-cast p1, Landroid/support/v7/internal/view/menu/r;

    .line 918
    if-eqz p1, :cond_c

    invoke-virtual {p1}, Landroid/support/v7/internal/view/menu/r;->isEnabled()Z

    move-result v0

    if-nez v0, :cond_e

    :cond_c
    move v0, v1

    .line 952
    :cond_d
    :goto_d
    return v0

    .line 922
    :cond_e
    invoke-virtual {p1}, Landroid/support/v7/internal/view/menu/r;->a()Z

    move-result v4

    .line 924
    invoke-virtual {p1}, Landroid/support/v7/internal/view/menu/r;->l()Landroid/support/v4/view/l;

    .line 925
    invoke-virtual {p1}, Landroid/support/v7/internal/view/menu/r;->m()Z

    move-result v0

    if-eqz v0, :cond_26

    .line 927
    invoke-virtual {p1}, Landroid/support/v7/internal/view/menu/r;->expandActionView()Z

    move-result v0

    or-int/2addr v0, v4

    .line 928
    if-eqz v0, :cond_d

    .line 929
    invoke-virtual {p0, v6}, Landroid/support/v7/internal/view/menu/n;->a(Z)V

    goto :goto_d

    .line 931
    :cond_26
    invoke-virtual {p1}, Landroid/support/v7/internal/view/menu/r;->hasSubMenu()Z

    move-result v0

    if-eqz v0, :cond_80

    .line 932
    invoke-virtual {p0, v1}, Landroid/support/v7/internal/view/menu/n;->a(Z)V

    .line 934
    invoke-virtual {p1}, Landroid/support/v7/internal/view/menu/r;->hasSubMenu()Z

    move-result v0

    if-nez v0, :cond_3f

    .line 935
    new-instance v0, Landroid/support/v7/internal/view/menu/ag;

    iget-object v2, p0, Landroid/support/v7/internal/view/menu/n;->e:Landroid/content/Context;

    invoke-direct {v0, v2, p0, p1}, Landroid/support/v7/internal/view/menu/ag;-><init>(Landroid/content/Context;Landroid/support/v7/internal/view/menu/n;Landroid/support/v7/internal/view/menu/r;)V

    invoke-virtual {p1, v0}, Landroid/support/v7/internal/view/menu/r;->a(Landroid/support/v7/internal/view/menu/ag;)V

    .line 938
    :cond_3f
    invoke-virtual {p1}, Landroid/support/v7/internal/view/menu/r;->getSubMenu()Landroid/view/SubMenu;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/view/menu/ag;

    .line 939
    iget-object v2, p0, Landroid/support/v7/internal/view/menu/n;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v2}, Ljava/util/concurrent/CopyOnWriteArrayList;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_55

    :goto_4d
    or-int v0, v4, v1

    .line 943
    if-nez v0, :cond_d

    .line 944
    invoke-virtual {p0, v6}, Landroid/support/v7/internal/view/menu/n;->a(Z)V

    goto :goto_d

    .line 939
    :cond_55
    iget-object v2, p0, Landroid/support/v7/internal/view/menu/n;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v2}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v5

    move v3, v1

    :goto_5c
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_7e

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/ref/WeakReference;

    invoke-virtual {v1}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/v7/internal/view/menu/aa;

    if-nez v2, :cond_76

    iget-object v2, p0, Landroid/support/v7/internal/view/menu/n;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v2, v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    goto :goto_5c

    :cond_76
    if-nez v3, :cond_89

    invoke-interface {v2, v0}, Landroid/support/v7/internal/view/menu/aa;->a(Landroid/support/v7/internal/view/menu/ag;)Z

    move-result v1

    :goto_7c
    move v3, v1

    goto :goto_5c

    :cond_7e
    move v1, v3

    goto :goto_4d

    .line 947
    :cond_80
    and-int/lit8 v0, p2, 0x1

    if-nez v0, :cond_87

    .line 948
    invoke-virtual {p0, v6}, Landroid/support/v7/internal/view/menu/n;->a(Z)V

    :cond_87
    move v0, v4

    goto :goto_d

    :cond_89
    move v1, v3

    goto :goto_7c
.end method

.method public add(I)Landroid/view/MenuItem;
    .registers 4

    .prologue
    const/4 v1, 0x0

    .line 423
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->f:Landroid/content/res/Resources;

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v1, v1, v1, v0}, Landroid/support/v7/internal/view/menu/n;->a(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object v0

    return-object v0
.end method

.method public add(IIII)Landroid/view/MenuItem;
    .registers 6

    .prologue
    .line 433
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->f:Landroid/content/res/Resources;

    invoke-virtual {v0, p4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, p1, p2, p3, v0}, Landroid/support/v7/internal/view/menu/n;->a(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object v0

    return-object v0
.end method

.method public add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;
    .registers 6

    .prologue
    .line 428
    invoke-direct {p0, p1, p2, p3, p4}, Landroid/support/v7/internal/view/menu/n;->a(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object v0

    return-object v0
.end method

.method public add(Ljava/lang/CharSequence;)Landroid/view/MenuItem;
    .registers 3

    .prologue
    const/4 v0, 0x0

    .line 418
    invoke-direct {p0, v0, v0, v0, p1}, Landroid/support/v7/internal/view/menu/n;->a(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object v0

    return-object v0
.end method

.method public addIntentOptions(IIILandroid/content/ComponentName;[Landroid/content/Intent;Landroid/content/Intent;I[Landroid/view/MenuItem;)I
    .registers 18

    .prologue
    .line 463
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->e:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v4

    .line 464
    const/4 v0, 0x0

    invoke-virtual {v4, p4, p5, p6, v0}, Landroid/content/pm/PackageManager;->queryIntentActivityOptions(Landroid/content/ComponentName;[Landroid/content/Intent;Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v5

    .line 466
    if-eqz v5, :cond_61

    invoke-interface {v5}, Ljava/util/List;->size()I

    move-result v0

    move v3, v0

    .line 468
    :goto_12
    and-int/lit8 v0, p7, 0x1

    if-nez v0, :cond_19

    .line 469
    invoke-virtual {p0, p1}, Landroid/support/v7/internal/view/menu/n;->removeGroup(I)V

    .line 472
    :cond_19
    const/4 v0, 0x0

    move v2, v0

    :goto_1b
    if-ge v2, v3, :cond_69

    .line 473
    invoke-interface {v5, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/pm/ResolveInfo;

    .line 474
    new-instance v6, Landroid/content/Intent;

    iget v1, v0, Landroid/content/pm/ResolveInfo;->specificIndex:I

    if-gez v1, :cond_64

    move-object v1, p6

    :goto_2a
    invoke-direct {v6, v1}, Landroid/content/Intent;-><init>(Landroid/content/Intent;)V

    .line 476
    new-instance v1, Landroid/content/ComponentName;

    iget-object v7, v0, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v7, v7, Landroid/content/pm/ActivityInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    iget-object v7, v7, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    iget-object v8, v0, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v8, v8, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    invoke-direct {v1, v7, v8}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v6, v1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    .line 479
    invoke-virtual {v0, v4}, Landroid/content/pm/ResolveInfo;->loadLabel(Landroid/content/pm/PackageManager;)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {p0, p1, p2, p3, v1}, Landroid/support/v7/internal/view/menu/n;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object v1

    invoke-virtual {v0, v4}, Landroid/content/pm/ResolveInfo;->loadIcon(Landroid/content/pm/PackageManager;)Landroid/graphics/drawable/Drawable;

    move-result-object v7

    invoke-interface {v1, v7}, Landroid/view/MenuItem;->setIcon(Landroid/graphics/drawable/Drawable;)Landroid/view/MenuItem;

    move-result-object v1

    invoke-interface {v1, v6}, Landroid/view/MenuItem;->setIntent(Landroid/content/Intent;)Landroid/view/MenuItem;

    move-result-object v1

    .line 482
    if-eqz p8, :cond_5d

    iget v6, v0, Landroid/content/pm/ResolveInfo;->specificIndex:I

    if-ltz v6, :cond_5d

    .line 483
    iget v0, v0, Landroid/content/pm/ResolveInfo;->specificIndex:I

    aput-object v1, p8, v0

    .line 472
    :cond_5d
    add-int/lit8 v0, v2, 0x1

    move v2, v0

    goto :goto_1b

    .line 466
    :cond_61
    const/4 v0, 0x0

    move v3, v0

    goto :goto_12

    .line 474
    :cond_64
    iget v1, v0, Landroid/content/pm/ResolveInfo;->specificIndex:I

    aget-object v1, p5, v1

    goto :goto_2a

    .line 487
    :cond_69
    return v3
.end method

.method public addSubMenu(I)Landroid/view/SubMenu;
    .registers 4

    .prologue
    const/4 v1, 0x0

    .line 443
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->f:Landroid/content/res/Resources;

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v1, v1, v1, v0}, Landroid/support/v7/internal/view/menu/n;->addSubMenu(IIILjava/lang/CharSequence;)Landroid/view/SubMenu;

    move-result-object v0

    return-object v0
.end method

.method public addSubMenu(IIII)Landroid/view/SubMenu;
    .registers 6

    .prologue
    .line 457
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->f:Landroid/content/res/Resources;

    invoke-virtual {v0, p4}, Landroid/content/res/Resources;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, p1, p2, p3, v0}, Landroid/support/v7/internal/view/menu/n;->addSubMenu(IIILjava/lang/CharSequence;)Landroid/view/SubMenu;

    move-result-object v0

    return-object v0
.end method

.method public addSubMenu(IIILjava/lang/CharSequence;)Landroid/view/SubMenu;
    .registers 8

    .prologue
    .line 448
    invoke-direct {p0, p1, p2, p3, p4}, Landroid/support/v7/internal/view/menu/n;->a(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/view/menu/r;

    .line 449
    new-instance v1, Landroid/support/v7/internal/view/menu/ag;

    iget-object v2, p0, Landroid/support/v7/internal/view/menu/n;->e:Landroid/content/Context;

    invoke-direct {v1, v2, p0, v0}, Landroid/support/v7/internal/view/menu/ag;-><init>(Landroid/content/Context;Landroid/support/v7/internal/view/menu/n;Landroid/support/v7/internal/view/menu/r;)V

    .line 450
    invoke-virtual {v0, v1}, Landroid/support/v7/internal/view/menu/r;->a(Landroid/support/v7/internal/view/menu/ag;)V

    .line 452
    return-object v1
.end method

.method public addSubMenu(Ljava/lang/CharSequence;)Landroid/view/SubMenu;
    .registers 3

    .prologue
    const/4 v0, 0x0

    .line 438
    invoke-virtual {p0, v0, v0, v0, p1}, Landroid/support/v7/internal/view/menu/n;->addSubMenu(IIILjava/lang/CharSequence;)Landroid/view/SubMenu;

    move-result-object v0

    return-object v0
.end method

.method public final b(Landroid/os/Bundle;)V
    .registers 9

    .prologue
    .line 359
    if-nez p1, :cond_3

    .line 386
    :cond_2
    :goto_2
    return-void

    .line 363
    :cond_3
    invoke-virtual {p0}, Landroid/support/v7/internal/view/menu/n;->a()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getSparseParcelableArray(Ljava/lang/String;)Landroid/util/SparseArray;

    move-result-object v2

    .line 366
    invoke-virtual {p0}, Landroid/support/v7/internal/view/menu/n;->size()I

    move-result v3

    .line 367
    const/4 v0, 0x0

    move v1, v0

    :goto_11
    if-ge v1, v3, :cond_3a

    .line 368
    invoke-virtual {p0, v1}, Landroid/support/v7/internal/view/menu/n;->getItem(I)Landroid/view/MenuItem;

    move-result-object v0

    .line 369
    invoke-static {v0}, Landroid/support/v4/view/x;->a(Landroid/view/MenuItem;)Landroid/view/View;

    move-result-object v4

    .line 370
    if-eqz v4, :cond_27

    invoke-virtual {v4}, Landroid/view/View;->getId()I

    move-result v5

    const/4 v6, -0x1

    if-eq v5, v6, :cond_27

    .line 371
    invoke-virtual {v4, v2}, Landroid/view/View;->restoreHierarchyState(Landroid/util/SparseArray;)V

    .line 373
    :cond_27
    invoke-interface {v0}, Landroid/view/MenuItem;->hasSubMenu()Z

    move-result v4

    if-eqz v4, :cond_36

    .line 374
    invoke-interface {v0}, Landroid/view/MenuItem;->getSubMenu()Landroid/view/SubMenu;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/view/menu/ag;

    .line 375
    invoke-virtual {v0, p1}, Landroid/support/v7/internal/view/menu/ag;->b(Landroid/os/Bundle;)V

    .line 367
    :cond_36
    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_11

    .line 379
    :cond_3a
    const-string v0, "android:menu:expandedactionview"

    invoke-virtual {p1, v0}, Landroid/os/Bundle;->getInt(Ljava/lang/String;)I

    move-result v0

    .line 380
    if-lez v0, :cond_2

    .line 381
    invoke-virtual {p0, v0}, Landroid/support/v7/internal/view/menu/n;->findItem(I)Landroid/view/MenuItem;

    move-result-object v0

    .line 382
    if-eqz v0, :cond_2

    .line 383
    invoke-static {v0}, Landroid/support/v4/view/x;->b(Landroid/view/MenuItem;)Z

    goto :goto_2
.end method

.method public final b(Landroid/support/v7/internal/view/menu/aa;)V
    .registers 5

    .prologue
    .line 232
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_6
    :goto_6
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_22

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/ref/WeakReference;

    .line 233
    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v7/internal/view/menu/aa;

    .line 234
    if-eqz v1, :cond_1c

    if-ne v1, p1, :cond_6

    .line 235
    :cond_1c
    iget-object v1, p0, Landroid/support/v7/internal/view/menu/n;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v1, v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    goto :goto_6

    .line 238
    :cond_22
    return-void
.end method

.method final b(Z)V
    .registers 5

    .prologue
    const/4 v1, 0x1

    .line 993
    iget-boolean v0, p0, Landroid/support/v7/internal/view/menu/n;->r:Z

    if-nez v0, :cond_3e

    .line 994
    if-eqz p1, :cond_b

    .line 995
    iput-boolean v1, p0, Landroid/support/v7/internal/view/menu/n;->l:Z

    .line 996
    iput-boolean v1, p0, Landroid/support/v7/internal/view/menu/n;->o:Z

    .line 999
    :cond_b
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_3d

    invoke-virtual {p0}, Landroid/support/v7/internal/view/menu/n;->g()V

    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_1c
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_3a

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v7/internal/view/menu/aa;

    if-nez v1, :cond_36

    iget-object v1, p0, Landroid/support/v7/internal/view/menu/n;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v1, v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    goto :goto_1c

    :cond_36
    invoke-interface {v1, p1}, Landroid/support/v7/internal/view/menu/aa;->c(Z)V

    goto :goto_1c

    :cond_3a
    invoke-virtual {p0}, Landroid/support/v7/internal/view/menu/n;->h()V

    .line 1003
    :cond_3d
    :goto_3d
    return-void

    .line 1001
    :cond_3e
    iput-boolean v1, p0, Landroid/support/v7/internal/view/menu/n;->s:Z

    goto :goto_3d
.end method

.method b()Z
    .registers 2

    .prologue
    .line 736
    iget-boolean v0, p0, Landroid/support/v7/internal/view/menu/n;->g:Z

    return v0
.end method

.method public b(Landroid/support/v7/internal/view/menu/r;)Z
    .registers 6

    .prologue
    const/4 v0, 0x0

    .line 1308
    iget-object v1, p0, Landroid/support/v7/internal/view/menu/n;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_d

    iget-object v1, p0, Landroid/support/v7/internal/view/menu/n;->x:Landroid/support/v7/internal/view/menu/r;

    if-eq v1, p1, :cond_e

    .line 1328
    :cond_d
    :goto_d
    return v0

    .line 1314
    :cond_e
    invoke-virtual {p0}, Landroid/support/v7/internal/view/menu/n;->g()V

    .line 1315
    iget-object v1, p0, Landroid/support/v7/internal/view/menu/n;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v1}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v3

    move v2, v0

    :goto_18
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_43

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/ref/WeakReference;

    .line 1316
    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v7/internal/view/menu/aa;

    .line 1317
    if-nez v1, :cond_32

    .line 1318
    iget-object v1, p0, Landroid/support/v7/internal/view/menu/n;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v1, v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    goto :goto_18

    .line 1319
    :cond_32
    invoke-interface {v1, p1}, Landroid/support/v7/internal/view/menu/aa;->c(Landroid/support/v7/internal/view/menu/r;)Z

    move-result v0

    if-eqz v0, :cond_41

    .line 1320
    :goto_38
    invoke-virtual {p0}, Landroid/support/v7/internal/view/menu/n;->h()V

    .line 1325
    if-eqz v0, :cond_d

    .line 1326
    const/4 v1, 0x0

    iput-object v1, p0, Landroid/support/v7/internal/view/menu/n;->x:Landroid/support/v7/internal/view/menu/r;

    goto :goto_d

    :cond_41
    move v2, v0

    goto :goto_18

    :cond_43
    move v0, v2

    goto :goto_38
.end method

.method public c()Z
    .registers 2

    .prologue
    .line 765
    iget-boolean v0, p0, Landroid/support/v7/internal/view/menu/n;->h:Z

    return v0
.end method

.method public clear()V
    .registers 2

    .prologue
    .line 547
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->x:Landroid/support/v7/internal/view/menu/r;

    if-eqz v0, :cond_9

    .line 548
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->x:Landroid/support/v7/internal/view/menu/r;

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/view/menu/n;->b(Landroid/support/v7/internal/view/menu/r;)Z

    .line 550
    :cond_9
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 552
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/view/menu/n;->b(Z)V

    .line 553
    return-void
.end method

.method public clearHeader()V
    .registers 2

    .prologue
    const/4 v0, 0x0

    .line 1145
    iput-object v0, p0, Landroid/support/v7/internal/view/menu/n;->b:Landroid/graphics/drawable/Drawable;

    .line 1146
    iput-object v0, p0, Landroid/support/v7/internal/view/menu/n;->a:Ljava/lang/CharSequence;

    .line 1147
    iput-object v0, p0, Landroid/support/v7/internal/view/menu/n;->c:Landroid/view/View;

    .line 1149
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/view/menu/n;->b(Z)V

    .line 1150
    return-void
.end method

.method public close()V
    .registers 2

    .prologue
    .line 982
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/view/menu/n;->a(Z)V

    .line 983
    return-void
.end method

.method final d()Landroid/content/res/Resources;
    .registers 2

    .prologue
    .line 769
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->f:Landroid/content/res/Resources;

    return-object v0
.end method

.method public final e()Landroid/content/Context;
    .registers 2

    .prologue
    .line 773
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->e:Landroid/content/Context;

    return-object v0
.end method

.method public final f()V
    .registers 2

    .prologue
    .line 784
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->i:Landroid/support/v7/internal/view/menu/o;

    if-eqz v0, :cond_9

    .line 785
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->i:Landroid/support/v7/internal/view/menu/o;

    invoke-interface {v0, p0}, Landroid/support/v7/internal/view/menu/o;->a(Landroid/support/v7/internal/view/menu/n;)V

    .line 787
    :cond_9
    return-void
.end method

.method public findItem(I)Landroid/view/MenuItem;
    .registers 6

    .prologue
    .line 638
    invoke-virtual {p0}, Landroid/support/v7/internal/view/menu/n;->size()I

    move-result v2

    .line 639
    const/4 v0, 0x0

    move v1, v0

    :goto_6
    if-ge v1, v2, :cond_2b

    .line 640
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/view/menu/r;

    .line 641
    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->getItemId()I

    move-result v3

    if-ne v3, p1, :cond_17

    .line 652
    :cond_16
    :goto_16
    return-object v0

    .line 643
    :cond_17
    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->hasSubMenu()Z

    move-result v3

    if-eqz v3, :cond_27

    .line 644
    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->getSubMenu()Landroid/view/SubMenu;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/view/SubMenu;->findItem(I)Landroid/view/MenuItem;

    move-result-object v0

    .line 646
    if-nez v0, :cond_16

    .line 639
    :cond_27
    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_6

    .line 652
    :cond_2b
    const/4 v0, 0x0

    goto :goto_16
.end method

.method public final g()V
    .registers 2

    .prologue
    .line 1011
    iget-boolean v0, p0, Landroid/support/v7/internal/view/menu/n;->r:Z

    if-nez v0, :cond_a

    .line 1012
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v7/internal/view/menu/n;->r:Z

    .line 1013
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v7/internal/view/menu/n;->s:Z

    .line 1015
    :cond_a
    return-void
.end method

.method public getItem(I)Landroid/view/MenuItem;
    .registers 3

    .prologue
    .line 697
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/MenuItem;

    return-object v0
.end method

.method public final h()V
    .registers 3

    .prologue
    const/4 v1, 0x0

    .line 1018
    iput-boolean v1, p0, Landroid/support/v7/internal/view/menu/n;->r:Z

    .line 1020
    iget-boolean v0, p0, Landroid/support/v7/internal/view/menu/n;->s:Z

    if-eqz v0, :cond_d

    .line 1021
    iput-boolean v1, p0, Landroid/support/v7/internal/view/menu/n;->s:Z

    .line 1022
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/view/menu/n;->b(Z)V

    .line 1024
    :cond_d
    return-void
.end method

.method public hasVisibleItems()Z
    .registers 5

    .prologue
    const/4 v1, 0x0

    .line 624
    invoke-virtual {p0}, Landroid/support/v7/internal/view/menu/n;->size()I

    move-result v3

    move v2, v1

    .line 626
    :goto_6
    if-ge v2, v3, :cond_1c

    .line 627
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/view/menu/r;

    .line 628
    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->isVisible()Z

    move-result v0

    if-eqz v0, :cond_18

    .line 629
    const/4 v0, 0x1

    .line 633
    :goto_17
    return v0

    .line 626
    :cond_18
    add-int/lit8 v0, v2, 0x1

    move v2, v0

    goto :goto_6

    :cond_1c
    move v0, v1

    .line 633
    goto :goto_17
.end method

.method final i()V
    .registers 2

    .prologue
    const/4 v0, 0x1

    .line 1033
    iput-boolean v0, p0, Landroid/support/v7/internal/view/menu/n;->l:Z

    .line 1034
    invoke-virtual {p0, v0}, Landroid/support/v7/internal/view/menu/n;->b(Z)V

    .line 1035
    return-void
.end method

.method public isShortcutKey(ILandroid/view/KeyEvent;)Z
    .registers 4

    .prologue
    .line 702
    invoke-direct {p0, p1, p2}, Landroid/support/v7/internal/view/menu/n;->a(ILandroid/view/KeyEvent;)Landroid/support/v7/internal/view/menu/r;

    move-result-object v0

    if-eqz v0, :cond_8

    const/4 v0, 0x1

    :goto_7
    return v0

    :cond_8
    const/4 v0, 0x0

    goto :goto_7
.end method

.method final j()V
    .registers 2

    .prologue
    const/4 v0, 0x1

    .line 1044
    iput-boolean v0, p0, Landroid/support/v7/internal/view/menu/n;->o:Z

    .line 1045
    invoke-virtual {p0, v0}, Landroid/support/v7/internal/view/menu/n;->b(Z)V

    .line 1046
    return-void
.end method

.method final k()Ljava/util/ArrayList;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList",
            "<",
            "Landroid/support/v7/internal/view/menu/r;",
            ">;"
        }
    .end annotation

    .prologue
    const/4 v2, 0x0

    .line 1049
    iget-boolean v0, p0, Landroid/support/v7/internal/view/menu/n;->l:Z

    if-nez v0, :cond_8

    .line 1050
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->k:Ljava/util/ArrayList;

    .line 1068
    :goto_7
    return-object v0

    .line 1054
    :cond_8
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->k:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 1056
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v3

    move v1, v2

    .line 1058
    :goto_14
    if-ge v1, v3, :cond_2d

    .line 1059
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/view/menu/r;

    .line 1060
    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->isVisible()Z

    move-result v4

    if-eqz v4, :cond_29

    .line 1061
    iget-object v4, p0, Landroid/support/v7/internal/view/menu/n;->k:Ljava/util/ArrayList;

    invoke-virtual {v4, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1058
    :cond_29
    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_14

    .line 1065
    :cond_2d
    iput-boolean v2, p0, Landroid/support/v7/internal/view/menu/n;->l:Z

    .line 1066
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v7/internal/view/menu/n;->o:Z

    .line 1068
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->k:Ljava/util/ArrayList;

    goto :goto_7
.end method

.method public final l()V
    .registers 7

    .prologue
    const/4 v3, 0x0

    .line 1096
    iget-boolean v0, p0, Landroid/support/v7/internal/view/menu/n;->o:Z

    if-nez v0, :cond_6

    .line 1132
    :goto_5
    return-void

    .line 1102
    :cond_6
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v4

    move v2, v3

    :goto_d
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_2e

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/ref/WeakReference;

    .line 1103
    invoke-virtual {v0}, Ljava/lang/ref/WeakReference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v7/internal/view/menu/aa;

    .line 1104
    if-nez v1, :cond_27

    .line 1105
    iget-object v1, p0, Landroid/support/v7/internal/view/menu/n;->w:Ljava/util/concurrent/CopyOnWriteArrayList;

    invoke-virtual {v1, v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(Ljava/lang/Object;)Z

    goto :goto_d

    .line 1107
    :cond_27
    invoke-interface {v1}, Landroid/support/v7/internal/view/menu/aa;->i()Z

    move-result v0

    or-int/2addr v0, v2

    move v2, v0

    .line 1109
    goto :goto_d

    .line 1111
    :cond_2e
    if-eqz v2, :cond_60

    .line 1112
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->m:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 1113
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->n:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 1114
    invoke-virtual {p0}, Landroid/support/v7/internal/view/menu/n;->k()Ljava/util/ArrayList;

    move-result-object v2

    .line 1115
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v4

    move v1, v3

    .line 1116
    :goto_43
    if-ge v1, v4, :cond_73

    .line 1117
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/view/menu/r;

    .line 1118
    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->h()Z

    move-result v5

    if-eqz v5, :cond_5a

    .line 1119
    iget-object v5, p0, Landroid/support/v7/internal/view/menu/n;->m:Ljava/util/ArrayList;

    invoke-virtual {v5, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1116
    :goto_56
    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_43

    .line 1121
    :cond_5a
    iget-object v5, p0, Landroid/support/v7/internal/view/menu/n;->n:Ljava/util/ArrayList;

    invoke-virtual {v5, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_56

    .line 1127
    :cond_60
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->m:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 1128
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->n:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 1129
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->n:Ljava/util/ArrayList;

    invoke-virtual {p0}, Landroid/support/v7/internal/view/menu/n;->k()Ljava/util/ArrayList;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    .line 1131
    :cond_73
    iput-boolean v3, p0, Landroid/support/v7/internal/view/menu/n;->o:Z

    goto :goto_5
.end method

.method final m()Ljava/util/ArrayList;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList",
            "<",
            "Landroid/support/v7/internal/view/menu/r;",
            ">;"
        }
    .end annotation

    .prologue
    .line 1135
    invoke-virtual {p0}, Landroid/support/v7/internal/view/menu/n;->l()V

    .line 1136
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->m:Ljava/util/ArrayList;

    return-object v0
.end method

.method final n()Ljava/util/ArrayList;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/ArrayList",
            "<",
            "Landroid/support/v7/internal/view/menu/r;",
            ">;"
        }
    .end annotation

    .prologue
    .line 1140
    invoke-virtual {p0}, Landroid/support/v7/internal/view/menu/n;->l()V

    .line 1141
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->n:Ljava/util/ArrayList;

    return-object v0
.end method

.method public o()Landroid/support/v7/internal/view/menu/n;
    .registers 1

    .prologue
    .line 1261
    return-object p0
.end method

.method final p()Z
    .registers 2

    .prologue
    .line 1280
    iget-boolean v0, p0, Landroid/support/v7/internal/view/menu/n;->t:Z

    return v0
.end method

.method public performIdentifierAction(II)Z
    .registers 4

    .prologue
    .line 912
    invoke-virtual {p0, p1}, Landroid/support/v7/internal/view/menu/n;->findItem(I)Landroid/view/MenuItem;

    move-result-object v0

    invoke-virtual {p0, v0, p2}, Landroid/support/v7/internal/view/menu/n;->a(Landroid/view/MenuItem;I)Z

    move-result v0

    return v0
.end method

.method public performShortcut(ILandroid/view/KeyEvent;I)Z
    .registers 6

    .prologue
    .line 802
    invoke-direct {p0, p1, p2}, Landroid/support/v7/internal/view/menu/n;->a(ILandroid/view/KeyEvent;)Landroid/support/v7/internal/view/menu/r;

    move-result-object v1

    .line 804
    const/4 v0, 0x0

    .line 806
    if-eqz v1, :cond_b

    .line 807
    invoke-virtual {p0, v1, p3}, Landroid/support/v7/internal/view/menu/n;->a(Landroid/view/MenuItem;I)Z

    move-result v0

    .line 810
    :cond_b
    and-int/lit8 v1, p3, 0x2

    if-eqz v1, :cond_13

    .line 811
    const/4 v1, 0x1

    invoke-virtual {p0, v1}, Landroid/support/v7/internal/view/menu/n;->a(Z)V

    .line 814
    :cond_13
    return v0
.end method

.method public final q()Landroid/support/v7/internal/view/menu/r;
    .registers 2

    .prologue
    .line 1332
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->x:Landroid/support/v7/internal/view/menu/r;

    return-object v0
.end method

.method public removeGroup(I)V
    .registers 7

    .prologue
    const/4 v1, 0x0

    .line 497
    invoke-virtual {p0}, Landroid/support/v7/internal/view/menu/n;->size()I

    move-result v3

    move v2, v1

    :goto_6
    if-ge v2, v3, :cond_3c

    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/view/menu/r;

    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->getGroupId()I

    move-result v0

    if-ne v0, p1, :cond_39

    move v3, v2

    .line 499
    :goto_17
    if-ltz v3, :cond_43

    .line 500
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    sub-int v4, v0, v3

    move v0, v1

    .line 502
    :goto_22
    add-int/lit8 v2, v0, 0x1

    if-ge v0, v4, :cond_3f

    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/view/menu/r;

    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->getGroupId()I

    move-result v0

    if-ne v0, p1, :cond_3f

    .line 504
    invoke-direct {p0, v3, v1}, Landroid/support/v7/internal/view/menu/n;->a(IZ)V

    move v0, v2

    goto :goto_22

    .line 497
    :cond_39
    add-int/lit8 v2, v2, 0x1

    goto :goto_6

    :cond_3c
    const/4 v0, -0x1

    move v3, v0

    goto :goto_17

    .line 508
    :cond_3f
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/view/menu/n;->b(Z)V

    .line 510
    :cond_43
    return-void
.end method

.method public removeItem(I)V
    .registers 5

    .prologue
    .line 492
    invoke-virtual {p0}, Landroid/support/v7/internal/view/menu/n;->size()I

    move-result v2

    const/4 v1, 0x0

    :goto_5
    if-ge v1, v2, :cond_1e

    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/view/menu/r;

    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->getItemId()I

    move-result v0

    if-ne v0, p1, :cond_1b

    move v0, v1

    :goto_16
    const/4 v1, 0x1

    invoke-direct {p0, v0, v1}, Landroid/support/v7/internal/view/menu/n;->a(IZ)V

    .line 493
    return-void

    .line 492
    :cond_1b
    add-int/lit8 v1, v1, 0x1

    goto :goto_5

    :cond_1e
    const/4 v0, -0x1

    goto :goto_16
.end method

.method public setGroupCheckable(IZZ)V
    .registers 8

    .prologue
    .line 577
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    .line 579
    const/4 v0, 0x0

    move v1, v0

    :goto_8
    if-ge v1, v2, :cond_22

    .line 580
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/view/menu/r;

    .line 581
    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->getGroupId()I

    move-result v3

    if-ne v3, p1, :cond_1e

    .line 582
    invoke-virtual {v0, p3}, Landroid/support/v7/internal/view/menu/r;->a(Z)V

    .line 583
    invoke-virtual {v0, p2}, Landroid/support/v7/internal/view/menu/r;->setCheckable(Z)Landroid/view/MenuItem;

    .line 579
    :cond_1e
    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_8

    .line 586
    :cond_22
    return-void
.end method

.method public setGroupEnabled(IZ)V
    .registers 7

    .prologue
    .line 612
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    .line 614
    const/4 v0, 0x0

    move v1, v0

    :goto_8
    if-ge v1, v2, :cond_1f

    .line 615
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/view/menu/r;

    .line 616
    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->getGroupId()I

    move-result v3

    if-ne v3, p1, :cond_1b

    .line 617
    invoke-virtual {v0, p2}, Landroid/support/v7/internal/view/menu/r;->setEnabled(Z)Landroid/view/MenuItem;

    .line 614
    :cond_1b
    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_8

    .line 620
    :cond_1f
    return-void
.end method

.method public setGroupVisible(IZ)V
    .registers 9

    .prologue
    const/4 v1, 0x1

    const/4 v0, 0x0

    .line 590
    iget-object v2, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v4

    move v3, v0

    move v2, v0

    .line 596
    :goto_a
    if-ge v3, v4, :cond_26

    .line 597
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/view/menu/r;

    .line 598
    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->getGroupId()I

    move-result v5

    if-ne v5, p1, :cond_2c

    .line 599
    invoke-virtual {v0, p2}, Landroid/support/v7/internal/view/menu/r;->c(Z)Z

    move-result v0

    if-eqz v0, :cond_2c

    move v0, v1

    .line 596
    :goto_21
    add-int/lit8 v2, v3, 0x1

    move v3, v2

    move v2, v0

    goto :goto_a

    .line 605
    :cond_26
    if-eqz v2, :cond_2b

    .line 606
    invoke-virtual {p0, v1}, Landroid/support/v7/internal/view/menu/n;->b(Z)V

    .line 608
    :cond_2b
    return-void

    :cond_2c
    move v0, v2

    goto :goto_21
.end method

.method public setQwertyMode(Z)V
    .registers 3

    .prologue
    .line 707
    iput-boolean p1, p0, Landroid/support/v7/internal/view/menu/n;->g:Z

    .line 709
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/view/menu/n;->b(Z)V

    .line 710
    return-void
.end method

.method public size()I
    .registers 2

    .prologue
    .line 692
    iget-object v0, p0, Landroid/support/v7/internal/view/menu/n;->j:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    return v0
.end method
