###### Class android.support.v7.internal.view.f (android.support.v7.internal.view.f)
.class final Landroid/support/v7/internal/view/f;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field final synthetic a:Landroid/support/v7/internal/view/d;

.field private b:Landroid/view/Menu;

.field private c:I

.field private d:I

.field private e:I

.field private f:I

.field private g:Z

.field private h:Z

.field private i:Z

.field private j:I

.field private k:I

.field private l:Ljava/lang/CharSequence;

.field private m:Ljava/lang/CharSequence;

.field private n:I

.field private o:C

.field private p:C

.field private q:I

.field private r:Z

.field private s:Z

.field private t:Z

.field private u:I

.field private v:I

.field private w:Ljava/lang/String;

.field private x:Ljava/lang/String;

.field private y:Ljava/lang/String;

.field private z:Landroid/support/v4/view/l;


# direct methods
.method public constructor <init>(Landroid/support/v7/internal/view/d;Landroid/view/Menu;)V
    .registers 3

    .prologue
    .line 312
    iput-object p1, p0, Landroid/support/v7/internal/view/f;->a:Landroid/support/v7/internal/view/d;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 313
    iput-object p2, p0, Landroid/support/v7/internal/view/f;->b:Landroid/view/Menu;

    .line 315
    invoke-virtual {p0}, Landroid/support/v7/internal/view/f;->a()V

    .line 316
    return-void
.end method

.method private static a(Ljava/lang/String;)C
    .registers 2

    .prologue
    const/4 v0, 0x0

    .line 400
    if-nez p0, :cond_4

    .line 403
    :goto_3
    return v0

    :cond_4
    invoke-virtual {p0, v0}, Ljava/lang/String;->charAt(I)C

    move-result v0

    goto :goto_3
.end method

.method static synthetic a(Landroid/support/v7/internal/view/f;)Landroid/support/v4/view/l;
    .registers 2

    .prologue
    .line 253
    iget-object v0, p0, Landroid/support/v7/internal/view/f;->z:Landroid/support/v4/view/l;

    return-object v0
.end method

.method private a(Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/String;",
            "[",
            "Ljava/lang/Class",
            "<*>;[",
            "Ljava/lang/Object;",
            ")TT;"
        }
    .end annotation

    .prologue
    .line 480
    :try_start_0
    iget-object v0, p0, Landroid/support/v7/internal/view/f;->a:Landroid/support/v7/internal/view/d;

    invoke-static {v0}, Landroid/support/v7/internal/view/d;->a(Landroid/support/v7/internal/view/d;)Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    .line 481
    invoke-virtual {v0, p2}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v0

    .line 482
    invoke-virtual {v0, p3}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_15
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_15} :catch_17

    move-result-object v0

    .line 486
    :goto_16
    return-object v0

    .line 483
    :catch_17
    move-exception v0

    .line 484
    const-string v1, "SupportMenuInflater"

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Cannot instantiate class: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 486
    const/4 v0, 0x0

    goto :goto_16
.end method

.method private a(Landroid/view/MenuItem;)V
    .registers 7

    .prologue
    const/4 v2, 0x0

    const/4 v1, 0x1

    .line 408
    iget-boolean v0, p0, Landroid/support/v7/internal/view/f;->r:Z

    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setChecked(Z)Landroid/view/MenuItem;

    move-result-object v0

    iget-boolean v3, p0, Landroid/support/v7/internal/view/f;->s:Z

    invoke-interface {v0, v3}, Landroid/view/MenuItem;->setVisible(Z)Landroid/view/MenuItem;

    move-result-object v0

    iget-boolean v3, p0, Landroid/support/v7/internal/view/f;->t:Z

    invoke-interface {v0, v3}, Landroid/view/MenuItem;->setEnabled(Z)Landroid/view/MenuItem;

    move-result-object v3

    iget v0, p0, Landroid/support/v7/internal/view/f;->q:I

    if-lez v0, :cond_55

    move v0, v1

    :goto_19
    invoke-interface {v3, v0}, Landroid/view/MenuItem;->setCheckable(Z)Landroid/view/MenuItem;

    move-result-object v0

    iget-object v3, p0, Landroid/support/v7/internal/view/f;->m:Ljava/lang/CharSequence;

    invoke-interface {v0, v3}, Landroid/view/MenuItem;->setTitleCondensed(Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object v0

    iget v3, p0, Landroid/support/v7/internal/view/f;->n:I

    invoke-interface {v0, v3}, Landroid/view/MenuItem;->setIcon(I)Landroid/view/MenuItem;

    move-result-object v0

    iget-char v3, p0, Landroid/support/v7/internal/view/f;->o:C

    invoke-interface {v0, v3}, Landroid/view/MenuItem;->setAlphabeticShortcut(C)Landroid/view/MenuItem;

    move-result-object v0

    iget-char v3, p0, Landroid/support/v7/internal/view/f;->p:C

    invoke-interface {v0, v3}, Landroid/view/MenuItem;->setNumericShortcut(C)Landroid/view/MenuItem;

    .line 417
    iget v0, p0, Landroid/support/v7/internal/view/f;->u:I

    if-ltz v0, :cond_3d

    .line 418
    iget v0, p0, Landroid/support/v7/internal/view/f;->u:I

    invoke-static {p1, v0}, Landroid/support/v4/view/x;->a(Landroid/view/MenuItem;I)V

    .line 421
    :cond_3d
    iget-object v0, p0, Landroid/support/v7/internal/view/f;->y:Ljava/lang/String;

    if-eqz v0, :cond_67

    .line 422
    iget-object v0, p0, Landroid/support/v7/internal/view/f;->a:Landroid/support/v7/internal/view/d;

    invoke-static {v0}, Landroid/support/v7/internal/view/d;->a(Landroid/support/v7/internal/view/d;)Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/Context;->isRestricted()Z

    move-result v0

    if-eqz v0, :cond_57

    .line 423
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "The android:onClick attribute cannot be used within a restricted context"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_55
    move v0, v2

    .line 408
    goto :goto_19

    .line 426
    :cond_57
    new-instance v0, Landroid/support/v7/internal/view/e;

    iget-object v3, p0, Landroid/support/v7/internal/view/f;->a:Landroid/support/v7/internal/view/d;

    invoke-static {v3}, Landroid/support/v7/internal/view/d;->c(Landroid/support/v7/internal/view/d;)Ljava/lang/Object;

    move-result-object v3

    iget-object v4, p0, Landroid/support/v7/internal/view/f;->y:Ljava/lang/String;

    invoke-direct {v0, v3, v4}, Landroid/support/v7/internal/view/e;-><init>(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {p1, v0}, Landroid/view/MenuItem;->setOnMenuItemClickListener(Landroid/view/MenuItem$OnMenuItemClickListener;)Landroid/view/MenuItem;

    .line 430
    :cond_67
    iget v0, p0, Landroid/support/v7/internal/view/f;->q:I

    const/4 v3, 0x2

    if-lt v0, v3, :cond_76

    .line 432
    instance-of v0, p1, Landroid/support/v7/internal/view/menu/r;

    if-eqz v0, :cond_a4

    move-object v0, p1

    .line 433
    check-cast v0, Landroid/support/v7/internal/view/menu/r;

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/view/menu/r;->a(Z)V

    .line 440
    :cond_76
    :goto_76
    iget-object v0, p0, Landroid/support/v7/internal/view/f;->w:Ljava/lang/String;

    if-eqz v0, :cond_b7

    .line 441
    iget-object v0, p0, Landroid/support/v7/internal/view/f;->w:Ljava/lang/String;

    invoke-static {}, Landroid/support/v7/internal/view/d;->b()[Ljava/lang/Class;

    move-result-object v2

    iget-object v3, p0, Landroid/support/v7/internal/view/f;->a:Landroid/support/v7/internal/view/d;

    invoke-static {v3}, Landroid/support/v7/internal/view/d;->d(Landroid/support/v7/internal/view/d;)[Ljava/lang/Object;

    move-result-object v3

    invoke-direct {p0, v0, v2, v3}, Landroid/support/v7/internal/view/f;->a(Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    .line 443
    invoke-static {p1, v0}, Landroid/support/v4/view/x;->a(Landroid/view/MenuItem;Landroid/view/View;)Landroid/view/MenuItem;

    .line 446
    :goto_8f
    iget v0, p0, Landroid/support/v7/internal/view/f;->v:I

    if-lez v0, :cond_9a

    .line 447
    if-nez v1, :cond_af

    .line 448
    iget v0, p0, Landroid/support/v7/internal/view/f;->v:I

    invoke-static {p1, v0}, Landroid/support/v4/view/x;->b(Landroid/view/MenuItem;I)Landroid/view/MenuItem;

    .line 455
    :cond_9a
    :goto_9a
    iget-object v0, p0, Landroid/support/v7/internal/view/f;->z:Landroid/support/v4/view/l;

    if-eqz v0, :cond_a3

    .line 456
    iget-object v0, p0, Landroid/support/v7/internal/view/f;->z:Landroid/support/v4/view/l;

    invoke-static {p1, v0}, Landroid/support/v4/view/x;->a(Landroid/view/MenuItem;Landroid/support/v4/view/l;)Landroid/view/MenuItem;

    .line 458
    :cond_a3
    return-void

    .line 434
    :cond_a4
    instance-of v0, p1, Landroid/support/v7/internal/view/menu/s;

    if-eqz v0, :cond_76

    move-object v0, p1

    .line 435
    check-cast v0, Landroid/support/v7/internal/view/menu/s;

    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/s;->b()V

    goto :goto_76

    .line 451
    :cond_af
    const-string v0, "SupportMenuInflater"

    const-string v1, "Ignoring attribute \'itemActionViewLayout\'. Action view already specified."

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_9a

    :cond_b7
    move v1, v2

    goto :goto_8f
.end method


# virtual methods
.method public final a()V
    .registers 3

    .prologue
    const/4 v1, 0x1

    const/4 v0, 0x0

    .line 319
    iput v0, p0, Landroid/support/v7/internal/view/f;->c:I

    .line 320
    iput v0, p0, Landroid/support/v7/internal/view/f;->d:I

    .line 321
    iput v0, p0, Landroid/support/v7/internal/view/f;->e:I

    .line 322
    iput v0, p0, Landroid/support/v7/internal/view/f;->f:I

    .line 323
    iput-boolean v1, p0, Landroid/support/v7/internal/view/f;->g:Z

    .line 324
    iput-boolean v1, p0, Landroid/support/v7/internal/view/f;->h:Z

    .line 325
    return-void
.end method

.method public final a(Landroid/util/AttributeSet;)V
    .registers 6

    .prologue
    const/4 v3, 0x1

    const/4 v2, 0x0

    .line 331
    iget-object v0, p0, Landroid/support/v7/internal/view/f;->a:Landroid/support/v7/internal/view/d;

    invoke-static {v0}, Landroid/support/v7/internal/view/d;->a(Landroid/support/v7/internal/view/d;)Landroid/content/Context;

    move-result-object v0

    sget-object v1, Landroid/support/v7/a/k;->j:[I

    invoke-virtual {v0, p1, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v0

    .line 333
    invoke-virtual {v0, v3, v2}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v1

    iput v1, p0, Landroid/support/v7/internal/view/f;->c:I

    .line 334
    const/4 v1, 0x3

    invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v1

    iput v1, p0, Landroid/support/v7/internal/view/f;->d:I

    .line 336
    const/4 v1, 0x4

    invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v1

    iput v1, p0, Landroid/support/v7/internal/view/f;->e:I

    .line 337
    const/4 v1, 0x5

    invoke-virtual {v0, v1, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v1

    iput v1, p0, Landroid/support/v7/internal/view/f;->f:I

    .line 339
    const/4 v1, 0x2

    invoke-virtual {v0, v1, v3}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    iput-boolean v1, p0, Landroid/support/v7/internal/view/f;->g:Z

    .line 340
    invoke-virtual {v0, v2, v3}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    iput-boolean v1, p0, Landroid/support/v7/internal/view/f;->h:Z

    .line 342
    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    .line 343
    return-void
.end method

.method public final b()V
    .registers 6

    .prologue
    .line 461
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v7/internal/view/f;->i:Z

    .line 462
    iget-object v0, p0, Landroid/support/v7/internal/view/f;->b:Landroid/view/Menu;

    iget v1, p0, Landroid/support/v7/internal/view/f;->c:I

    iget v2, p0, Landroid/support/v7/internal/view/f;->j:I

    iget v3, p0, Landroid/support/v7/internal/view/f;->k:I

    iget-object v4, p0, Landroid/support/v7/internal/view/f;->l:Ljava/lang/CharSequence;

    invoke-interface {v0, v1, v2, v3, v4}, Landroid/view/Menu;->add(IIILjava/lang/CharSequence;)Landroid/view/MenuItem;

    move-result-object v0

    invoke-direct {p0, v0}, Landroid/support/v7/internal/view/f;->a(Landroid/view/MenuItem;)V

    .line 463
    return-void
.end method

.method public final b(Landroid/util/AttributeSet;)V
    .registers 9

    .prologue
    const/16 v6, 0xb

    const/4 v1, 0x1

    const/4 v2, 0x0

    .line 349
    iget-object v0, p0, Landroid/support/v7/internal/view/f;->a:Landroid/support/v7/internal/view/d;

    invoke-static {v0}, Landroid/support/v7/internal/view/d;->a(Landroid/support/v7/internal/view/d;)Landroid/content/Context;

    move-result-object v0

    sget-object v3, Landroid/support/v7/a/k;->k:[I

    invoke-virtual {v0, p1, v3}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v3

    .line 352
    const/4 v0, 0x2

    invoke-virtual {v3, v0, v2}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v0

    iput v0, p0, Landroid/support/v7/internal/view/f;->j:I

    .line 353
    const/4 v0, 0x5

    iget v4, p0, Landroid/support/v7/internal/view/f;->d:I

    invoke-virtual {v3, v0, v4}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v0

    .line 354
    const/4 v4, 0x6

    iget v5, p0, Landroid/support/v7/internal/view/f;->e:I

    invoke-virtual {v3, v4, v5}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    .line 355
    const/high16 v5, -0x10000

    and-int/2addr v0, v5

    const v5, 0xffff

    and-int/2addr v4, v5

    or-int/2addr v0, v4

    iput v0, p0, Landroid/support/v7/internal/view/f;->k:I

    .line 357
    const/4 v0, 0x7

    invoke-virtual {v3, v0}, Landroid/content/res/TypedArray;->getText(I)Ljava/lang/CharSequence;

    move-result-object v0

    iput-object v0, p0, Landroid/support/v7/internal/view/f;->l:Ljava/lang/CharSequence;

    .line 358
    const/16 v0, 0x8

    invoke-virtual {v3, v0}, Landroid/content/res/TypedArray;->getText(I)Ljava/lang/CharSequence;

    move-result-object v0

    iput-object v0, p0, Landroid/support/v7/internal/view/f;->m:Ljava/lang/CharSequence;

    .line 359
    invoke-virtual {v3, v2, v2}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v0

    iput v0, p0, Landroid/support/v7/internal/view/f;->n:I

    .line 360
    const/16 v0, 0x9

    invoke-virtual {v3, v0}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/support/v7/internal/view/f;->a(Ljava/lang/String;)C

    move-result v0

    iput-char v0, p0, Landroid/support/v7/internal/view/f;->o:C

    .line 362
    const/16 v0, 0xa

    invoke-virtual {v3, v0}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/support/v7/internal/view/f;->a(Ljava/lang/String;)C

    move-result v0

    iput-char v0, p0, Landroid/support/v7/internal/view/f;->p:C

    .line 364
    invoke-virtual {v3, v6}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v0

    if-eqz v0, :cond_d6

    .line 366
    invoke-virtual {v3, v6, v2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v0

    if-eqz v0, :cond_d4

    move v0, v1

    :goto_69
    iput v0, p0, Landroid/support/v7/internal/view/f;->q:I

    .line 372
    :goto_6b
    const/4 v0, 0x3

    invoke-virtual {v3, v0, v2}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v0

    iput-boolean v0, p0, Landroid/support/v7/internal/view/f;->r:Z

    .line 373
    const/4 v0, 0x4

    iget-boolean v4, p0, Landroid/support/v7/internal/view/f;->g:Z

    invoke-virtual {v3, v0, v4}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v0

    iput-boolean v0, p0, Landroid/support/v7/internal/view/f;->s:Z

    .line 374
    iget-boolean v0, p0, Landroid/support/v7/internal/view/f;->h:Z

    invoke-virtual {v3, v1, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v0

    iput-boolean v0, p0, Landroid/support/v7/internal/view/f;->t:Z

    .line 375
    const/16 v0, 0xd

    const/4 v4, -0x1

    invoke-virtual {v3, v0, v4}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v0

    iput v0, p0, Landroid/support/v7/internal/view/f;->u:I

    .line 376
    const/16 v0, 0xc

    invoke-virtual {v3, v0}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Landroid/support/v7/internal/view/f;->y:Ljava/lang/String;

    .line 377
    const/16 v0, 0xe

    invoke-virtual {v3, v0, v2}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v0

    iput v0, p0, Landroid/support/v7/internal/view/f;->v:I

    .line 378
    const/16 v0, 0xf

    invoke-virtual {v3, v0}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Landroid/support/v7/internal/view/f;->w:Ljava/lang/String;

    .line 379
    const/16 v0, 0x10

    invoke-virtual {v3, v0}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Landroid/support/v7/internal/view/f;->x:Ljava/lang/String;

    .line 381
    iget-object v0, p0, Landroid/support/v7/internal/view/f;->x:Ljava/lang/String;

    if-eqz v0, :cond_db

    .line 382
    :goto_b0
    if-eqz v1, :cond_dd

    iget v0, p0, Landroid/support/v7/internal/view/f;->v:I

    if-nez v0, :cond_dd

    iget-object v0, p0, Landroid/support/v7/internal/view/f;->w:Ljava/lang/String;

    if-nez v0, :cond_dd

    .line 383
    iget-object v0, p0, Landroid/support/v7/internal/view/f;->x:Ljava/lang/String;

    invoke-static {}, Landroid/support/v7/internal/view/d;->a()[Ljava/lang/Class;

    move-result-object v1

    iget-object v4, p0, Landroid/support/v7/internal/view/f;->a:Landroid/support/v7/internal/view/d;

    invoke-static {v4}, Landroid/support/v7/internal/view/d;->b(Landroid/support/v7/internal/view/d;)[Ljava/lang/Object;

    move-result-object v4

    invoke-direct {p0, v0, v1, v4}, Landroid/support/v7/internal/view/f;->a(Ljava/lang/String;[Ljava/lang/Class;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/view/l;

    iput-object v0, p0, Landroid/support/v7/internal/view/f;->z:Landroid/support/v4/view/l;

    .line 394
    :goto_ce
    invoke-virtual {v3}, Landroid/content/res/TypedArray;->recycle()V

    .line 396
    iput-boolean v2, p0, Landroid/support/v7/internal/view/f;->i:Z

    .line 397
    return-void

    :cond_d4
    move v0, v2

    .line 366
    goto :goto_69

    .line 370
    :cond_d6
    iget v0, p0, Landroid/support/v7/internal/view/f;->f:I

    iput v0, p0, Landroid/support/v7/internal/view/f;->q:I

    goto :goto_6b

    :cond_db
    move v1, v2

    .line 381
    goto :goto_b0

    .line 387
    :cond_dd
    if-eqz v1, :cond_e6

    .line 388
    const-string v0, "SupportMenuInflater"

    const-string v1, "Ignoring attribute \'actionProviderClass\'. Action view already specified."

    invoke-static {v0, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 391
    :cond_e6
    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v7/internal/view/f;->z:Landroid/support/v4/view/l;

    goto :goto_ce
.end method

.method public final c()Landroid/view/SubMenu;
    .registers 6

    .prologue
    .line 466
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v7/internal/view/f;->i:Z

    .line 467
    iget-object v0, p0, Landroid/support/v7/internal/view/f;->b:Landroid/view/Menu;

    iget v1, p0, Landroid/support/v7/internal/view/f;->c:I

    iget v2, p0, Landroid/support/v7/internal/view/f;->j:I

    iget v3, p0, Landroid/support/v7/internal/view/f;->k:I

    iget-object v4, p0, Landroid/support/v7/internal/view/f;->l:Ljava/lang/CharSequence;

    invoke-interface {v0, v1, v2, v3, v4}, Landroid/view/Menu;->addSubMenu(IIILjava/lang/CharSequence;)Landroid/view/SubMenu;

    move-result-object v0

    .line 468
    invoke-interface {v0}, Landroid/view/SubMenu;->getItem()Landroid/view/MenuItem;

    move-result-object v1

    invoke-direct {p0, v1}, Landroid/support/v7/internal/view/f;->a(Landroid/view/MenuItem;)V

    .line 469
    return-object v0
.end method

.method public final d()Z
    .registers 2

    .prologue
    .line 473
    iget-boolean v0, p0, Landroid/support/v7/internal/view/f;->i:Z

    return v0
.end method
