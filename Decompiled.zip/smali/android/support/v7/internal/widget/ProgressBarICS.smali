###### Class android.support.v7.internal.widget.ProgressBarICS (android.support.v7.internal.widget.ProgressBarICS)
.class public final Landroid/support/v7/internal/widget/ProgressBarICS;
.super Landroid/view/View;
.source "SourceFile"


# static fields
.field private static final f:[I


# instance fields
.field a:I

.field b:I

.field c:I

.field d:I

.field e:Landroid/graphics/Bitmap;

.field private g:I

.field private h:I

.field private i:I

.field private j:I

.field private k:I

.field private l:Z

.field private m:Z

.field private n:Landroid/view/animation/Transformation;

.field private o:Landroid/view/animation/AlphaAnimation;

.field private p:Landroid/graphics/drawable/Drawable;

.field private q:Landroid/graphics/drawable/Drawable;

.field private r:Landroid/graphics/drawable/Drawable;

.field private s:Z

.field private t:Landroid/view/animation/Interpolator;

.field private u:Landroid/support/v7/internal/widget/z;

.field private v:J

.field private w:Z

.field private x:J

.field private y:Z


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .prologue
    .line 60
    const/16 v0, 0xe

    new-array v0, v0, [I

    fill-array-data v0, :array_a

    sput-object v0, Landroid/support/v7/internal/widget/ProgressBarICS;->f:[I

    return-void

    :array_a
    .array-data 4
        0x1010136
        0x1010137
        0x1010138
        0x1010139
        0x101013a
        0x101013b
        0x101013c
        0x101013d
        0x101013e
        0x101013f
        0x101011f
        0x1010140
        0x1010120
        0x1010141
    .end array-data
.end method

.method public constructor <init>(Landroid/content/Context;I)V
    .registers 11

    .prologue
    const/16 v5, 0x30

    const/16 v4, 0x18

    const/4 v6, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x0

    .line 109
    invoke-direct {p0, p1, v6, v0}, Landroid/view/View;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 110
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Thread;->getId()J

    move-result-wide v2

    iput-wide v2, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->v:J

    .line 111
    const/16 v2, 0x64

    iput v2, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->i:I

    iput v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->g:I

    iput v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->h:I

    iput-boolean v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->l:Z

    iput-boolean v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->m:Z

    const/16 v2, 0xfa0

    iput v2, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->k:I

    iput v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->j:I

    iput v4, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->a:I

    iput v5, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->b:I

    iput v4, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->c:I

    iput v5, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->d:I

    .line 113
    sget-object v2, Landroid/support/v7/internal/widget/ProgressBarICS;->f:[I

    invoke-virtual {p1, v6, v2, v0, p2}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object v3

    .line 116
    iput-boolean v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->s:Z

    .line 118
    iget v2, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->i:I

    invoke-virtual {v3, v0, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v2

    invoke-virtual {p0, v2}, Landroid/support/v7/internal/widget/ProgressBarICS;->a(I)V

    .line 119
    iget v2, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->g:I

    invoke-virtual {v3, v1, v2}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v2

    invoke-direct {p0, v2}, Landroid/support/v7/internal/widget/ProgressBarICS;->b(I)V

    .line 120
    const/4 v2, 0x2

    iget v4, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->h:I

    invoke-virtual {v3, v2, v4}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v2

    invoke-direct {p0, v2}, Landroid/support/v7/internal/widget/ProgressBarICS;->d(I)V

    .line 122
    const/4 v2, 0x3

    iget-boolean v4, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->l:Z

    invoke-virtual {v3, v2, v4}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v4

    .line 123
    const/4 v2, 0x4

    iget-boolean v5, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->m:Z

    invoke-virtual {v3, v2, v5}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v2

    iput-boolean v2, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->m:Z

    .line 125
    const/4 v2, 0x5

    invoke-virtual {v3, v2}, Landroid/content/res/TypedArray;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    .line 126
    if-eqz v2, :cond_7d

    .line 127
    invoke-direct {p0, v2}, Landroid/support/v7/internal/widget/ProgressBarICS;->a(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    .line 128
    if-eqz v2, :cond_72

    invoke-virtual {v2, p0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    :cond_72
    iput-object v2, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->p:Landroid/graphics/drawable/Drawable;

    iget-boolean v5, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->l:Z

    if-eqz v5, :cond_7d

    iput-object v2, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->r:Landroid/graphics/drawable/Drawable;

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->postInvalidate()V

    .line 131
    :cond_7d
    const/4 v2, 0x6

    invoke-virtual {v3, v2}, Landroid/content/res/TypedArray;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    .line 132
    if-eqz v2, :cond_d3

    .line 133
    invoke-direct {p0, v2, v0}, Landroid/support/v7/internal/widget/ProgressBarICS;->a(Landroid/graphics/drawable/Drawable;Z)Landroid/graphics/drawable/Drawable;

    move-result-object v5

    .line 136
    iget-object v2, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->q:Landroid/graphics/drawable/Drawable;

    if-eqz v2, :cond_12f

    iget-object v2, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->q:Landroid/graphics/drawable/Drawable;

    if-eq v5, v2, :cond_12f

    iget-object v2, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->q:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v2, v6}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    move v2, v1

    :goto_96
    if-eqz v5, :cond_a8

    invoke-virtual {v5, p0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    invoke-virtual {v5}, Landroid/graphics/drawable/Drawable;->getMinimumHeight()I

    move-result v6

    iget v7, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->d:I

    if-ge v7, v6, :cond_a8

    iput v6, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->d:I

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->requestLayout()V

    :cond_a8
    iput-object v5, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->q:Landroid/graphics/drawable/Drawable;

    iget-boolean v6, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->l:Z

    if-nez v6, :cond_b3

    iput-object v5, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->r:Landroid/graphics/drawable/Drawable;

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->postInvalidate()V

    :cond_b3
    if-eqz v2, :cond_d3

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->getWidth()I

    move-result v2

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->getHeight()I

    move-result v5

    invoke-direct {p0, v2, v5}, Landroid/support/v7/internal/widget/ProgressBarICS;->c(II)V

    invoke-direct {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->c()V

    const v2, 0x102000d

    iget v5, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->g:I

    invoke-direct {p0, v2, v5}, Landroid/support/v7/internal/widget/ProgressBarICS;->a(II)V

    const v2, 0x102000f

    iget v5, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->h:I

    invoke-direct {p0, v2, v5}, Landroid/support/v7/internal/widget/ProgressBarICS;->a(II)V

    .line 139
    :cond_d3
    const/4 v2, 0x7

    iget v5, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->k:I

    invoke-virtual {v3, v2, v5}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v2

    iput v2, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->k:I

    .line 140
    const/16 v2, 0x8

    iget v5, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->j:I

    invoke-virtual {v3, v2, v5}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v2

    iput v2, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->j:I

    .line 141
    const/16 v2, 0x9

    iget v5, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->a:I

    invoke-virtual {v3, v2, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v2

    iput v2, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->a:I

    .line 142
    const/16 v2, 0xa

    iget v5, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->b:I

    invoke-virtual {v3, v2, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v2

    iput v2, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->b:I

    .line 143
    const/16 v2, 0xb

    iget v5, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->c:I

    invoke-virtual {v3, v2, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v2

    iput v2, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->c:I

    .line 144
    const/16 v2, 0xc

    iget v5, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->d:I

    invoke-virtual {v3, v2, v5}, Landroid/content/res/TypedArray;->getDimensionPixelSize(II)I

    move-result v2

    iput v2, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->d:I

    .line 146
    const/16 v2, 0xd

    const v5, 0x10a000b

    invoke-virtual {v3, v2, v5}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v2

    .line 147
    if-lez v2, :cond_11f

    .line 148
    invoke-static {p1, v2}, Landroid/view/animation/AnimationUtils;->loadInterpolator(Landroid/content/Context;I)Landroid/view/animation/Interpolator;

    move-result-object v2

    iput-object v2, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->t:Landroid/view/animation/Interpolator;

    .line 151
    :cond_11f
    invoke-virtual {v3}, Landroid/content/res/TypedArray;->recycle()V

    .line 153
    iput-boolean v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->s:Z

    .line 154
    iget-boolean v2, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->m:Z

    if-nez v2, :cond_12a

    if-eqz v4, :cond_12b

    :cond_12a
    move v0, v1

    :cond_12b
    invoke-direct {p0, v0}, Landroid/support/v7/internal/widget/ProgressBarICS;->a(Z)V

    .line 155
    return-void

    :cond_12f
    move v2, v0

    .line 136
    goto/16 :goto_96
.end method

.method private a(Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
    .registers 8

    .prologue
    const/16 v5, 0x2710

    .line 212
    instance-of v0, p1, Landroid/graphics/drawable/AnimationDrawable;

    if-eqz v0, :cond_35

    .line 213
    check-cast p1, Landroid/graphics/drawable/AnimationDrawable;

    .line 214
    invoke-virtual {p1}, Landroid/graphics/drawable/AnimationDrawable;->getNumberOfFrames()I

    move-result v2

    .line 215
    new-instance v0, Landroid/graphics/drawable/AnimationDrawable;

    invoke-direct {v0}, Landroid/graphics/drawable/AnimationDrawable;-><init>()V

    .line 216
    invoke-virtual {p1}, Landroid/graphics/drawable/AnimationDrawable;->isOneShot()Z

    move-result v1

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/AnimationDrawable;->setOneShot(Z)V

    .line 218
    const/4 v1, 0x0

    :goto_19
    if-ge v1, v2, :cond_31

    .line 219
    invoke-virtual {p1, v1}, Landroid/graphics/drawable/AnimationDrawable;->getFrame(I)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    const/4 v4, 0x1

    invoke-direct {p0, v3, v4}, Landroid/support/v7/internal/widget/ProgressBarICS;->a(Landroid/graphics/drawable/Drawable;Z)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    .line 220
    invoke-virtual {v3, v5}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    .line 221
    invoke-virtual {p1, v1}, Landroid/graphics/drawable/AnimationDrawable;->getDuration(I)I

    move-result v4

    invoke-virtual {v0, v3, v4}, Landroid/graphics/drawable/AnimationDrawable;->addFrame(Landroid/graphics/drawable/Drawable;I)V

    .line 218
    add-int/lit8 v1, v1, 0x1

    goto :goto_19

    .line 223
    :cond_31
    invoke-virtual {v0, v5}, Landroid/graphics/drawable/AnimationDrawable;->setLevel(I)Z

    move-object p1, v0

    .line 226
    :cond_35
    return-object p1
.end method

.method private a(Landroid/graphics/drawable/Drawable;Z)Landroid/graphics/drawable/Drawable;
    .registers 11

    .prologue
    const/4 v5, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x0

    .line 163
    instance-of v0, p1, Landroid/graphics/drawable/LayerDrawable;

    if-eqz v0, :cond_44

    .line 164
    check-cast p1, Landroid/graphics/drawable/LayerDrawable;

    .line 165
    invoke-virtual {p1}, Landroid/graphics/drawable/LayerDrawable;->getNumberOfLayers()I

    move-result v4

    .line 166
    new-array v5, v4, [Landroid/graphics/drawable/Drawable;

    move v3, v1

    .line 168
    :goto_10
    if-ge v3, v4, :cond_31

    .line 169
    invoke-virtual {p1, v3}, Landroid/graphics/drawable/LayerDrawable;->getId(I)I

    move-result v0

    .line 170
    invoke-virtual {p1, v3}, Landroid/graphics/drawable/LayerDrawable;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v6

    const v7, 0x102000d

    if-eq v0, v7, :cond_24

    const v7, 0x102000f

    if-ne v0, v7, :cond_2f

    :cond_24
    move v0, v2

    :goto_25
    invoke-direct {p0, v6, v0}, Landroid/support/v7/internal/widget/ProgressBarICS;->a(Landroid/graphics/drawable/Drawable;Z)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    aput-object v0, v5, v3

    .line 168
    add-int/lit8 v0, v3, 0x1

    move v3, v0

    goto :goto_10

    :cond_2f
    move v0, v1

    .line 170
    goto :goto_25

    .line 174
    :cond_31
    new-instance v0, Landroid/graphics/drawable/LayerDrawable;

    invoke-direct {v0, v5}, Landroid/graphics/drawable/LayerDrawable;-><init>([Landroid/graphics/drawable/Drawable;)V

    .line 176
    :goto_36
    if-ge v1, v4, :cond_42

    .line 177
    invoke-virtual {p1, v1}, Landroid/graphics/drawable/LayerDrawable;->getId(I)I

    move-result v2

    invoke-virtual {v0, v1, v2}, Landroid/graphics/drawable/LayerDrawable;->setId(II)V

    .line 176
    add-int/lit8 v1, v1, 0x1

    goto :goto_36

    :cond_42
    move-object p1, v0

    .line 198
    :cond_43
    :goto_43
    return-object p1

    .line 182
    :cond_44
    instance-of v0, p1, Landroid/graphics/drawable/BitmapDrawable;

    if-eqz v0, :cond_43

    .line 183
    check-cast p1, Landroid/graphics/drawable/BitmapDrawable;

    invoke-virtual {p1}, Landroid/graphics/drawable/BitmapDrawable;->getBitmap()Landroid/graphics/Bitmap;

    move-result-object v1

    .line 184
    iget-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->e:Landroid/graphics/Bitmap;

    if-nez v0, :cond_54

    .line 185
    iput-object v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->e:Landroid/graphics/Bitmap;

    .line 188
    :cond_54
    new-instance v0, Landroid/graphics/drawable/ShapeDrawable;

    const/16 v3, 0x8

    new-array v3, v3, [F

    fill-array-data v3, :array_80

    new-instance v4, Landroid/graphics/drawable/shapes/RoundRectShape;

    invoke-direct {v4, v3, v5, v5}, Landroid/graphics/drawable/shapes/RoundRectShape;-><init>([FLandroid/graphics/RectF;[F)V

    invoke-direct {v0, v4}, Landroid/graphics/drawable/ShapeDrawable;-><init>(Landroid/graphics/drawable/shapes/Shape;)V

    .line 190
    new-instance v3, Landroid/graphics/BitmapShader;

    sget-object v4, Landroid/graphics/Shader$TileMode;->REPEAT:Landroid/graphics/Shader$TileMode;

    sget-object v5, Landroid/graphics/Shader$TileMode;->CLAMP:Landroid/graphics/Shader$TileMode;

    invoke-direct {v3, v1, v4, v5}, Landroid/graphics/BitmapShader;-><init>(Landroid/graphics/Bitmap;Landroid/graphics/Shader$TileMode;Landroid/graphics/Shader$TileMode;)V

    .line 192
    invoke-virtual {v0}, Landroid/graphics/drawable/ShapeDrawable;->getPaint()Landroid/graphics/Paint;

    move-result-object v1

    invoke-virtual {v1, v3}, Landroid/graphics/Paint;->setShader(Landroid/graphics/Shader;)Landroid/graphics/Shader;

    .line 194
    if-eqz p2, :cond_7e

    new-instance p1, Landroid/graphics/drawable/ClipDrawable;

    const/4 v1, 0x3

    invoke-direct {p1, v0, v1, v2}, Landroid/graphics/drawable/ClipDrawable;-><init>(Landroid/graphics/drawable/Drawable;II)V

    goto :goto_43

    :cond_7e
    move-object p1, v0

    goto :goto_43

    .line 188
    :array_80
    .array-data 4
        0x40a00000    # 5.0f
        0x40a00000    # 5.0f
        0x40a00000    # 5.0f
        0x40a00000    # 5.0f
        0x40a00000    # 5.0f
        0x40a00000    # 5.0f
        0x40a00000    # 5.0f
        0x40a00000    # 5.0f
    .end array-data
.end method

.method static synthetic a(Landroid/support/v7/internal/widget/ProgressBarICS;Landroid/support/v7/internal/widget/z;)Landroid/support/v7/internal/widget/z;
    .registers 2

    .prologue
    .line 52
    iput-object p1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->u:Landroid/support/v7/internal/widget/z;

    return-object p1
.end method

.method private a()V
    .registers 4

    .prologue
    .line 613
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->getVisibility()I

    move-result v0

    if-eqz v0, :cond_7

    .line 634
    :goto_6
    return-void

    .line 617
    :cond_7
    iget-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->p:Landroid/graphics/drawable/Drawable;

    instance-of v0, v0, Landroid/graphics/drawable/Animatable;

    if-eqz v0, :cond_17

    .line 618
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->w:Z

    .line 619
    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->o:Landroid/view/animation/AlphaAnimation;

    .line 633
    :goto_13
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->postInvalidate()V

    goto :goto_6

    .line 621
    :cond_17
    iget-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->t:Landroid/view/animation/Interpolator;

    if-nez v0, :cond_22

    .line 622
    new-instance v0, Landroid/view/animation/LinearInterpolator;

    invoke-direct {v0}, Landroid/view/animation/LinearInterpolator;-><init>()V

    iput-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->t:Landroid/view/animation/Interpolator;

    .line 625
    :cond_22
    new-instance v0, Landroid/view/animation/Transformation;

    invoke-direct {v0}, Landroid/view/animation/Transformation;-><init>()V

    iput-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->n:Landroid/view/animation/Transformation;

    .line 626
    new-instance v0, Landroid/view/animation/AlphaAnimation;

    const/4 v1, 0x0

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-direct {v0, v1, v2}, Landroid/view/animation/AlphaAnimation;-><init>(FF)V

    iput-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->o:Landroid/view/animation/AlphaAnimation;

    .line 627
    iget-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->o:Landroid/view/animation/AlphaAnimation;

    iget v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->j:I

    invoke-virtual {v0, v1}, Landroid/view/animation/AlphaAnimation;->setRepeatMode(I)V

    .line 628
    iget-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->o:Landroid/view/animation/AlphaAnimation;

    const/4 v1, -0x1

    invoke-virtual {v0, v1}, Landroid/view/animation/AlphaAnimation;->setRepeatCount(I)V

    .line 629
    iget-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->o:Landroid/view/animation/AlphaAnimation;

    iget v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->k:I

    int-to-long v1, v1

    invoke-virtual {v0, v1, v2}, Landroid/view/animation/AlphaAnimation;->setDuration(J)V

    .line 630
    iget-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->o:Landroid/view/animation/AlphaAnimation;

    iget-object v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->t:Landroid/view/animation/Interpolator;

    invoke-virtual {v0, v1}, Landroid/view/animation/AlphaAnimation;->setInterpolator(Landroid/view/animation/Interpolator;)V

    .line 631
    iget-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->o:Landroid/view/animation/AlphaAnimation;

    const-wide/16 v1, -0x1

    invoke-virtual {v0, v1, v2}, Landroid/view/animation/AlphaAnimation;->setStartTime(J)V

    goto :goto_13
.end method

.method private declared-synchronized a(II)V
    .registers 8

    .prologue
    .line 418
    monitor-enter p0

    :try_start_1
    iget v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->i:I

    if-lez v1, :cond_29

    int-to-float v1, p2

    iget v2, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->i:I

    int-to-float v2, v2

    div-float/2addr v1, v2

    move v3, v1

    .line 419
    :goto_b
    iget-object v2, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->r:Landroid/graphics/drawable/Drawable;

    .line 420
    if-eqz v2, :cond_2c

    .line 421
    const/4 v1, 0x0

    .line 423
    instance-of v4, v2, Landroid/graphics/drawable/LayerDrawable;

    if-eqz v4, :cond_1c

    .line 424
    move-object v0, v2

    check-cast v0, Landroid/graphics/drawable/LayerDrawable;

    move-object v1, v0

    invoke-virtual {v1, p1}, Landroid/graphics/drawable/LayerDrawable;->findDrawableByLayerId(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    .line 427
    :cond_1c
    const v4, 0x461c4000    # 10000.0f

    mul-float/2addr v3, v4

    float-to-int v3, v3

    .line 428
    if-eqz v1, :cond_24

    move-object v2, v1

    :cond_24
    invoke-virtual {v2, v3}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z
    :try_end_27
    .catchall {:try_start_1 .. :try_end_27} :catchall_30

    .line 432
    :goto_27
    monitor-exit p0

    return-void

    .line 418
    :cond_29
    const/4 v1, 0x0

    move v3, v1

    goto :goto_b

    .line 430
    :cond_2c
    :try_start_2c
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->invalidate()V
    :try_end_2f
    .catchall {:try_start_2c .. :try_end_2f} :catchall_30

    goto :goto_27

    .line 418
    :catchall_30
    move-exception v1

    monitor-exit p0

    throw v1
.end method

.method static synthetic a(Landroid/support/v7/internal/widget/ProgressBarICS;II)V
    .registers 3

    .prologue
    .line 52
    invoke-direct {p0, p1, p2}, Landroid/support/v7/internal/widget/ProgressBarICS;->a(II)V

    return-void
.end method

.method private declared-synchronized a(Z)V
    .registers 3

    .prologue
    .line 275
    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->m:Z

    if-eqz v0, :cond_9

    iget-boolean v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->l:Z

    if-nez v0, :cond_18

    :cond_9
    iget-boolean v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->l:Z

    if-eq p1, v0, :cond_18

    .line 276
    iput-boolean p1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->l:Z

    .line 278
    if-eqz p1, :cond_1a

    .line 280
    iget-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->p:Landroid/graphics/drawable/Drawable;

    iput-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->r:Landroid/graphics/drawable/Drawable;

    .line 281
    invoke-direct {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->a()V
    :try_end_18
    .catchall {:try_start_1 .. :try_end_18} :catchall_22

    .line 287
    :cond_18
    :goto_18
    monitor-exit p0

    return-void

    .line 283
    :cond_1a
    :try_start_1a
    iget-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->q:Landroid/graphics/drawable/Drawable;

    iput-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->r:Landroid/graphics/drawable/Drawable;

    .line 284
    invoke-direct {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->b()V
    :try_end_21
    .catchall {:try_start_1a .. :try_end_21} :catchall_22

    goto :goto_18

    .line 275
    :catchall_22
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method private b()V
    .registers 2

    .prologue
    const/4 v0, 0x0

    .line 640
    iput-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->o:Landroid/view/animation/AlphaAnimation;

    .line 641
    iput-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->n:Landroid/view/animation/Transformation;

    .line 642
    iget-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->p:Landroid/graphics/drawable/Drawable;

    instance-of v0, v0, Landroid/graphics/drawable/Animatable;

    if-eqz v0, :cond_15

    .line 643
    iget-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->p:Landroid/graphics/drawable/Drawable;

    check-cast v0, Landroid/graphics/drawable/Animatable;

    invoke-interface {v0}, Landroid/graphics/drawable/Animatable;->stop()V

    .line 644
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->w:Z

    .line 646
    :cond_15
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->postInvalidate()V

    .line 647
    return-void
.end method

.method private declared-synchronized b(I)V
    .registers 3

    .prologue
    .line 465
    monitor-enter p0

    :try_start_1
    invoke-direct {p0, p1}, Landroid/support/v7/internal/widget/ProgressBarICS;->c(I)V
    :try_end_4
    .catchall {:try_start_1 .. :try_end_4} :catchall_6

    .line 466
    monitor-exit p0

    return-void

    .line 465
    :catchall_6
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method private declared-synchronized b(II)V
    .registers 7

    .prologue
    .line 435
    monitor-enter p0

    :try_start_1
    iget-wide v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->v:J

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Thread;->getId()J

    move-result-wide v2

    cmp-long v0, v0, v2

    if-nez v0, :cond_14

    .line 436
    invoke-direct {p0, p1, p2}, Landroid/support/v7/internal/widget/ProgressBarICS;->a(II)V
    :try_end_12
    .catchall {:try_start_1 .. :try_end_12} :catchall_24

    .line 451
    :goto_12
    monitor-exit p0

    return-void

    .line 439
    :cond_14
    :try_start_14
    iget-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->u:Landroid/support/v7/internal/widget/z;

    if-eqz v0, :cond_27

    .line 441
    iget-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->u:Landroid/support/v7/internal/widget/z;

    .line 443
    const/4 v1, 0x0

    iput-object v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->u:Landroid/support/v7/internal/widget/z;

    .line 444
    invoke-virtual {v0, p1, p2}, Landroid/support/v7/internal/widget/z;->a(II)V

    .line 449
    :goto_20
    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/ProgressBarICS;->post(Ljava/lang/Runnable;)Z
    :try_end_23
    .catchall {:try_start_14 .. :try_end_23} :catchall_24

    goto :goto_12

    .line 435
    :catchall_24
    move-exception v0

    monitor-exit p0

    throw v0

    .line 447
    :cond_27
    :try_start_27
    new-instance v0, Landroid/support/v7/internal/widget/z;

    invoke-direct {v0, p0, p1, p2}, Landroid/support/v7/internal/widget/z;-><init>(Landroid/support/v7/internal/widget/ProgressBarICS;II)V
    :try_end_2c
    .catchall {:try_start_27 .. :try_end_2c} :catchall_24

    goto :goto_20
.end method

.method private c()V
    .registers 3

    .prologue
    .line 827
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->getDrawableState()[I

    move-result-object v0

    .line 829
    iget-object v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->q:Landroid/graphics/drawable/Drawable;

    if-eqz v1, :cond_15

    iget-object v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->q:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    move-result v1

    if-eqz v1, :cond_15

    .line 830
    iget-object v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->q:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v1, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    .line 833
    :cond_15
    iget-object v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->p:Landroid/graphics/drawable/Drawable;

    if-eqz v1, :cond_26

    iget-object v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->p:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->isStateful()Z

    move-result v1

    if-eqz v1, :cond_26

    .line 834
    iget-object v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->p:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v1, v0}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    .line 836
    :cond_26
    return-void
.end method

.method private declared-synchronized c(I)V
    .registers 4

    .prologue
    .line 469
    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->l:Z
    :try_end_3
    .catchall {:try_start_1 .. :try_end_3} :catchall_1f

    if-eqz v0, :cond_7

    .line 485
    :cond_5
    :goto_5
    monitor-exit p0

    return-void

    .line 473
    :cond_7
    if-gez p1, :cond_22

    .line 474
    const/4 v0, 0x0

    .line 477
    :goto_a
    :try_start_a
    iget v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->i:I

    if-le v0, v1, :cond_10

    .line 478
    iget v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->i:I

    .line 481
    :cond_10
    iget v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->g:I

    if-eq v0, v1, :cond_5

    .line 482
    iput v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->g:I

    .line 483
    const v0, 0x102000d

    iget v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->g:I

    invoke-direct {p0, v0, v1}, Landroid/support/v7/internal/widget/ProgressBarICS;->b(II)V
    :try_end_1e
    .catchall {:try_start_a .. :try_end_1e} :catchall_1f

    goto :goto_5

    .line 469
    :catchall_1f
    move-exception v0

    monitor-exit p0

    throw v0

    :cond_22
    move v0, p1

    goto :goto_a
.end method

.method private c(II)V
    .registers 9

    .prologue
    const/4 v1, 0x0

    .line 732
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->getPaddingRight()I

    move-result v0

    sub-int v0, p1, v0

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->getPaddingLeft()I

    move-result v2

    sub-int v3, v0, v2

    .line 733
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->getPaddingBottom()I

    move-result v0

    sub-int v0, p2, v0

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->getPaddingTop()I

    move-result v2

    sub-int v2, v0, v2

    .line 737
    iget-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->p:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_71

    .line 739
    iget-boolean v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->m:Z

    if-eqz v0, :cond_6c

    iget-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->p:Landroid/graphics/drawable/Drawable;

    instance-of v0, v0, Landroid/graphics/drawable/AnimationDrawable;

    if-nez v0, :cond_6c

    .line 742
    iget-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->p:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v0

    .line 743
    iget-object v4, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->p:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v4}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v4

    .line 744
    int-to-float v0, v0

    int-to-float v4, v4

    div-float/2addr v0, v4

    .line 745
    int-to-float v4, p1

    int-to-float v5, p2

    div-float/2addr v4, v5

    .line 746
    cmpl-float v5, v0, v4

    if-eqz v5, :cond_6c

    .line 747
    cmpl-float v4, v4, v0

    if-lez v4, :cond_5b

    .line 749
    int-to-float v3, p2

    mul-float/2addr v0, v3

    float-to-int v3, v0

    .line 750
    sub-int v0, p1, v3

    div-int/lit8 v0, v0, 0x2

    .line 751
    add-int/2addr v3, v0

    move v4, v3

    move v3, v2

    move v2, v1

    .line 760
    :goto_4c
    iget-object v5, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->p:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v5, v0, v2, v4, v3}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 763
    :goto_51
    iget-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->q:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_5a

    .line 764
    iget-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->q:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0, v1, v1, v4, v3}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 766
    :cond_5a
    return-void

    .line 754
    :cond_5b
    int-to-float v2, p1

    const/high16 v4, 0x3f800000    # 1.0f

    div-float v0, v4, v0

    mul-float/2addr v0, v2

    float-to-int v2, v0

    .line 755
    sub-int v0, p2, v2

    div-int/lit8 v0, v0, 0x2

    .line 756
    add-int/2addr v2, v0

    move v4, v3

    move v3, v2

    move v2, v0

    move v0, v1

    goto :goto_4c

    :cond_6c
    move v0, v1

    move v4, v3

    move v3, v2

    move v2, v1

    goto :goto_4c

    :cond_71
    move v4, v3

    move v3, v2

    goto :goto_51
.end method

.method private declared-synchronized d(I)V
    .registers 4

    .prologue
    .line 500
    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->l:Z
    :try_end_3
    .catchall {:try_start_1 .. :try_end_3} :catchall_1f

    if-eqz v0, :cond_7

    .line 516
    :cond_5
    :goto_5
    monitor-exit p0

    return-void

    .line 504
    :cond_7
    if-gez p1, :cond_22

    .line 505
    const/4 v0, 0x0

    .line 508
    :goto_a
    :try_start_a
    iget v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->i:I

    if-le v0, v1, :cond_10

    .line 509
    iget v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->i:I

    .line 512
    :cond_10
    iget v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->h:I

    if-eq v0, v1, :cond_5

    .line 513
    iput v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->h:I

    .line 514
    const v0, 0x102000f

    iget v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->h:I

    invoke-direct {p0, v0, v1}, Landroid/support/v7/internal/widget/ProgressBarICS;->b(II)V
    :try_end_1e
    .catchall {:try_start_a .. :try_end_1e} :catchall_1f

    goto :goto_5

    .line 500
    :catchall_1f
    move-exception v0

    monitor-exit p0

    throw v0

    :cond_22
    move v0, p1

    goto :goto_a
.end method


# virtual methods
.method public final declared-synchronized a(I)V
    .registers 4

    .prologue
    .line 573
    monitor-enter p0

    if-gez p1, :cond_4

    .line 574
    const/4 p1, 0x0

    .line 576
    :cond_4
    :try_start_4
    iget v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->i:I

    if-eq p1, v0, :cond_1b

    .line 577
    iput p1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->i:I

    .line 578
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->postInvalidate()V

    .line 580
    iget v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->g:I

    if-le v0, p1, :cond_13

    .line 581
    iput p1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->g:I

    .line 583
    :cond_13
    const v0, 0x102000d

    iget v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->g:I

    invoke-direct {p0, v0, v1}, Landroid/support/v7/internal/widget/ProgressBarICS;->b(II)V
    :try_end_1b
    .catchall {:try_start_4 .. :try_end_1b} :catchall_1d

    .line 585
    :cond_1b
    monitor-exit p0

    return-void

    .line 573
    :catchall_1d
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method protected final drawableStateChanged()V
    .registers 1

    .prologue
    .line 822
    invoke-super {p0}, Landroid/view/View;->drawableStateChanged()V

    .line 823
    invoke-direct {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->c()V

    .line 824
    return-void
.end method

.method public final invalidateDrawable(Landroid/graphics/drawable/Drawable;)V
    .registers 8

    .prologue
    .line 711
    iget-boolean v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->y:Z

    if-nez v0, :cond_2f

    .line 712
    invoke-virtual {p0, p1}, Landroid/support/v7/internal/widget/ProgressBarICS;->verifyDrawable(Landroid/graphics/drawable/Drawable;)Z

    move-result v0

    if-eqz v0, :cond_30

    .line 713
    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getBounds()Landroid/graphics/Rect;

    move-result-object v0

    .line 714
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->getScrollX()I

    move-result v1

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->getPaddingLeft()I

    move-result v2

    add-int/2addr v1, v2

    .line 715
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->getScrollY()I

    move-result v2

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->getPaddingTop()I

    move-result v3

    add-int/2addr v2, v3

    .line 717
    iget v3, v0, Landroid/graphics/Rect;->left:I

    add-int/2addr v3, v1

    iget v4, v0, Landroid/graphics/Rect;->top:I

    add-int/2addr v4, v2

    iget v5, v0, Landroid/graphics/Rect;->right:I

    add-int/2addr v1, v5

    iget v0, v0, Landroid/graphics/Rect;->bottom:I

    add-int/2addr v0, v2

    invoke-virtual {p0, v3, v4, v1, v0}, Landroid/support/v7/internal/widget/ProgressBarICS;->invalidate(IIII)V

    .line 723
    :cond_2f
    :goto_2f
    return-void

    .line 720
    :cond_30
    invoke-super {p0, p1}, Landroid/view/View;->invalidateDrawable(Landroid/graphics/drawable/Drawable;)V

    goto :goto_2f
.end method

.method protected final onAttachedToWindow()V
    .registers 2

    .prologue
    .line 900
    invoke-super {p0}, Landroid/view/View;->onAttachedToWindow()V

    .line 901
    iget-boolean v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->l:Z

    if-eqz v0, :cond_a

    .line 902
    invoke-direct {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->a()V

    .line 904
    :cond_a
    return-void
.end method

.method protected final onDetachedFromWindow()V
    .registers 2

    .prologue
    .line 908
    iget-boolean v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->l:Z

    if-eqz v0, :cond_7

    .line 909
    invoke-direct {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->b()V

    .line 911
    :cond_7
    iget-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->u:Landroid/support/v7/internal/widget/z;

    if-eqz v0, :cond_10

    .line 912
    iget-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->u:Landroid/support/v7/internal/widget/z;

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/ProgressBarICS;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 917
    :cond_10
    invoke-super {p0}, Landroid/view/View;->onDetachedFromWindow()V

    .line 918
    return-void
.end method

.method protected final declared-synchronized onDraw(Landroid/graphics/Canvas;)V
    .registers 9

    .prologue
    const-wide/16 v5, 0xc8

    .line 770
    monitor-enter p0

    :try_start_3
    invoke-super {p0, p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    .line 772
    iget-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->r:Landroid/graphics/drawable/Drawable;

    .line 773
    if-eqz v0, :cond_69

    .line 776
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 777
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->getPaddingLeft()I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->getPaddingTop()I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {p1, v1, v2}, Landroid/graphics/Canvas;->translate(FF)V

    .line 778
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->getDrawingTime()J

    move-result-wide v1

    .line 779
    iget-object v3, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->o:Landroid/view/animation/AlphaAnimation;

    if-eqz v3, :cond_53

    .line 780
    iget-object v3, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->o:Landroid/view/animation/AlphaAnimation;

    iget-object v4, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->n:Landroid/view/animation/Transformation;

    invoke-virtual {v3, v1, v2, v4}, Landroid/view/animation/AlphaAnimation;->getTransformation(JLandroid/view/animation/Transformation;)Z

    .line 781
    iget-object v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->n:Landroid/view/animation/Transformation;

    invoke-virtual {v1}, Landroid/view/animation/Transformation;->getAlpha()F
    :try_end_2e
    .catchall {:try_start_3 .. :try_end_2e} :catchall_70

    move-result v1

    .line 783
    const/4 v2, 0x1

    :try_start_30
    iput-boolean v2, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->y:Z

    .line 784
    const v2, 0x461c4000    # 10000.0f

    mul-float/2addr v1, v2

    float-to-int v1, v1

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z
    :try_end_3a
    .catchall {:try_start_30 .. :try_end_3a} :catchall_6b

    .line 786
    const/4 v1, 0x0

    :try_start_3b
    iput-boolean v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->y:Z

    .line 788
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v1

    iget-wide v3, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->x:J

    sub-long/2addr v1, v3

    cmp-long v1, v1, v5

    if-ltz v1, :cond_53

    .line 789
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v1

    iput-wide v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->x:J

    .line 790
    const-wide/16 v1, 0xc8

    invoke-virtual {p0, v1, v2}, Landroid/support/v7/internal/widget/ProgressBarICS;->postInvalidateDelayed(J)V

    .line 793
    :cond_53
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    .line 794
    invoke-virtual {p1}, Landroid/graphics/Canvas;->restore()V

    .line 795
    iget-boolean v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->w:Z

    if-eqz v1, :cond_69

    instance-of v1, v0, Landroid/graphics/drawable/Animatable;

    if-eqz v1, :cond_69

    .line 796
    check-cast v0, Landroid/graphics/drawable/Animatable;

    invoke-interface {v0}, Landroid/graphics/drawable/Animatable;->start()V

    .line 797
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->w:Z
    :try_end_69
    .catchall {:try_start_3b .. :try_end_69} :catchall_70

    .line 800
    :cond_69
    monitor-exit p0

    return-void

    .line 786
    :catchall_6b
    move-exception v0

    const/4 v1, 0x0

    :try_start_6d
    iput-boolean v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->y:Z

    throw v0
    :try_end_70
    .catchall {:try_start_6d .. :try_end_70} :catchall_70

    .line 770
    :catchall_70
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method protected final declared-synchronized onMeasure(II)V
    .registers 7

    .prologue
    const/4 v0, 0x0

    .line 804
    monitor-enter p0

    :try_start_2
    iget-object v2, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->r:Landroid/graphics/drawable/Drawable;

    .line 808
    if-eqz v2, :cond_4d

    .line 809
    iget v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->a:I

    iget v1, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->b:I

    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->getIntrinsicWidth()I

    move-result v3

    invoke-static {v1, v3}, Ljava/lang/Math;->min(II)I

    move-result v1

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    .line 810
    iget v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->c:I

    iget v3, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->d:I

    invoke-virtual {v2}, Landroid/graphics/drawable/Drawable;->getIntrinsicHeight()I

    move-result v2

    invoke-static {v3, v2}, Ljava/lang/Math;->min(II)I

    move-result v2

    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 812
    :goto_26
    invoke-direct {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->c()V

    .line 813
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->getPaddingLeft()I

    move-result v2

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->getPaddingRight()I

    move-result v3

    add-int/2addr v2, v3

    add-int/2addr v1, v2

    .line 814
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->getPaddingTop()I

    move-result v2

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->getPaddingBottom()I

    move-result v3

    add-int/2addr v2, v3

    add-int/2addr v0, v2

    .line 816
    invoke-static {v1, p1}, Landroid/support/v7/internal/widget/ProgressBarICS;->resolveSize(II)I

    move-result v1

    invoke-static {v0, p2}, Landroid/support/v7/internal/widget/ProgressBarICS;->resolveSize(II)I

    move-result v0

    invoke-virtual {p0, v1, v0}, Landroid/support/v7/internal/widget/ProgressBarICS;->setMeasuredDimension(II)V
    :try_end_48
    .catchall {:try_start_2 .. :try_end_48} :catchall_4a

    .line 818
    monitor-exit p0

    return-void

    .line 804
    :catchall_4a
    move-exception v0

    monitor-exit p0

    throw v0

    :cond_4d
    move v1, v0

    goto :goto_26
.end method

.method public final onRestoreInstanceState(Landroid/os/Parcelable;)V
    .registers 3

    .prologue
    .line 891
    check-cast p1, Landroid/support/v7/internal/widget/ProgressBarICS$SavedState;

    .line 892
    invoke-virtual {p1}, Landroid/support/v7/internal/widget/ProgressBarICS$SavedState;->getSuperState()Landroid/os/Parcelable;

    move-result-object v0

    invoke-super {p0, v0}, Landroid/view/View;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    .line 894
    iget v0, p1, Landroid/support/v7/internal/widget/ProgressBarICS$SavedState;->a:I

    invoke-direct {p0, v0}, Landroid/support/v7/internal/widget/ProgressBarICS;->b(I)V

    .line 895
    iget v0, p1, Landroid/support/v7/internal/widget/ProgressBarICS$SavedState;->b:I

    invoke-direct {p0, v0}, Landroid/support/v7/internal/widget/ProgressBarICS;->d(I)V

    .line 896
    return-void
.end method

.method public final onSaveInstanceState()Landroid/os/Parcelable;
    .registers 3

    .prologue
    .line 880
    invoke-super {p0}, Landroid/view/View;->onSaveInstanceState()Landroid/os/Parcelable;

    move-result-object v0

    .line 881
    new-instance v1, Landroid/support/v7/internal/widget/ProgressBarICS$SavedState;

    invoke-direct {v1, v0}, Landroid/support/v7/internal/widget/ProgressBarICS$SavedState;-><init>(Landroid/os/Parcelable;)V

    .line 883
    iget v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->g:I

    iput v0, v1, Landroid/support/v7/internal/widget/ProgressBarICS$SavedState;->a:I

    .line 884
    iget v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->h:I

    iput v0, v1, Landroid/support/v7/internal/widget/ProgressBarICS$SavedState;->b:I

    .line 886
    return-object v1
.end method

.method protected final onSizeChanged(IIII)V
    .registers 5

    .prologue
    .line 727
    invoke-direct {p0, p1, p2}, Landroid/support/v7/internal/widget/ProgressBarICS;->c(II)V

    .line 728
    return-void
.end method

.method protected final onVisibilityChanged(Landroid/view/View;I)V
    .registers 4

    .prologue
    .line 697
    invoke-super {p0, p1, p2}, Landroid/view/View;->onVisibilityChanged(Landroid/view/View;I)V

    .line 699
    iget-boolean v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->l:Z

    if-eqz v0, :cond_11

    .line 701
    const/16 v0, 0x8

    if-eq p2, v0, :cond_e

    const/4 v0, 0x4

    if-ne p2, v0, :cond_12

    .line 702
    :cond_e
    invoke-direct {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->b()V

    .line 707
    :cond_11
    :goto_11
    return-void

    .line 704
    :cond_12
    invoke-direct {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->a()V

    goto :goto_11
.end method

.method public final postInvalidate()V
    .registers 2

    .prologue
    .line 385
    iget-boolean v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->s:Z

    if-nez v0, :cond_7

    .line 386
    invoke-super {p0}, Landroid/view/View;->postInvalidate()V

    .line 388
    :cond_7
    return-void
.end method

.method public final setVisibility(I)V
    .registers 3

    .prologue
    .line 681
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->getVisibility()I

    move-result v0

    if-eq v0, p1, :cond_17

    .line 682
    invoke-super {p0, p1}, Landroid/view/View;->setVisibility(I)V

    .line 684
    iget-boolean v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->l:Z

    if-eqz v0, :cond_17

    .line 686
    const/16 v0, 0x8

    if-eq p1, v0, :cond_14

    const/4 v0, 0x4

    if-ne p1, v0, :cond_18

    .line 687
    :cond_14
    invoke-direct {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->b()V

    .line 693
    :cond_17
    :goto_17
    return-void

    .line 689
    :cond_18
    invoke-direct {p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->a()V

    goto :goto_17
.end method

.method protected final verifyDrawable(Landroid/graphics/drawable/Drawable;)Z
    .registers 3

    .prologue
    .line 379
    iget-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->q:Landroid/graphics/drawable/Drawable;

    if-eq p1, v0, :cond_e

    iget-object v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS;->p:Landroid/graphics/drawable/Drawable;

    if-eq p1, v0, :cond_e

    invoke-super {p0, p1}, Landroid/view/View;->verifyDrawable(Landroid/graphics/drawable/Drawable;)Z

    move-result v0

    if-eqz v0, :cond_10

    :cond_e
    const/4 v0, 0x1

    :goto_f
    return v0

    :cond_10
    const/4 v0, 0x0

    goto :goto_f
.end method

###### Class android.support.v7.internal.widget.ProgressBarICS.SavedState (android.support.v7.internal.widget.ProgressBarICS$SavedState)
.class Landroid/support/v7/internal/widget/ProgressBarICS$SavedState;
.super Landroid/view/View$BaseSavedState;
.source "SourceFile"


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator",
            "<",
            "Landroid/support/v7/internal/widget/ProgressBarICS$SavedState;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field a:I

.field b:I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .prologue
    .line 865
    new-instance v0, Landroid/support/v7/internal/widget/ProgressBarICS$SavedState$1;

    invoke-direct {v0}, Landroid/support/v7/internal/widget/ProgressBarICS$SavedState$1;-><init>()V

    sput-object v0, Landroid/support/v7/internal/widget/ProgressBarICS$SavedState;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method private constructor <init>(Landroid/os/Parcel;)V
    .registers 3

    .prologue
    .line 853
    invoke-direct {p0, p1}, Landroid/view/View$BaseSavedState;-><init>(Landroid/os/Parcel;)V

    .line 854
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS$SavedState;->a:I

    .line 855
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS$SavedState;->b:I

    .line 856
    return-void
.end method

.method synthetic constructor <init>(Landroid/os/Parcel;B)V
    .registers 3

    .prologue
    .line 838
    invoke-direct {p0, p1}, Landroid/support/v7/internal/widget/ProgressBarICS$SavedState;-><init>(Landroid/os/Parcel;)V

    return-void
.end method

.method constructor <init>(Landroid/os/Parcelable;)V
    .registers 2

    .prologue
    .line 846
    invoke-direct {p0, p1}, Landroid/view/View$BaseSavedState;-><init>(Landroid/os/Parcelable;)V

    .line 847
    return-void
.end method


# virtual methods
.method public writeToParcel(Landroid/os/Parcel;I)V
    .registers 4

    .prologue
    .line 860
    invoke-super {p0, p1, p2}, Landroid/view/View$BaseSavedState;->writeToParcel(Landroid/os/Parcel;I)V

    .line 861
    iget v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS$SavedState;->a:I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 862
    iget v0, p0, Landroid/support/v7/internal/widget/ProgressBarICS$SavedState;->b:I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 863
    return-void
.end method

###### Class android.support.v7.internal.widget.ProgressBarICS.SavedState.AnonymousClass1 (android.support.v7.internal.widget.ProgressBarICS$SavedState$1)
.class final Landroid/support/v7/internal/widget/ProgressBarICS$SavedState$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/v7/internal/widget/ProgressBarICS$SavedState;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$Creator",
        "<",
        "Landroid/support/v7/internal/widget/ProgressBarICS$SavedState;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 866
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .registers 4

    .prologue
    .line 866
    new-instance v0, Landroid/support/v7/internal/widget/ProgressBarICS$SavedState;

    const/4 v1, 0x0

    invoke-direct {v0, p1, v1}, Landroid/support/v7/internal/widget/ProgressBarICS$SavedState;-><init>(Landroid/os/Parcel;B)V

    return-object v0
.end method

.method public final bridge synthetic newArray(I)[Ljava/lang/Object;
    .registers 3

    .prologue
    .line 866
    new-array v0, p1, [Landroid/support/v7/internal/widget/ProgressBarICS$SavedState;

    return-object v0
.end method
