###### Class android.support.v7.internal.widget.n (android.support.v7.internal.widget.n)
.class public interface abstract Landroid/support/v7/internal/widget/n;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Landroid/view/View;I)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/view/View;",
            "I)V"
        }
    .end annotation
.end method
