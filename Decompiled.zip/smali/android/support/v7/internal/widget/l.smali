###### Class android.support.v7.internal.widget.l (android.support.v7.internal.widget.l)
.class abstract Landroid/support/v7/internal/widget/l;
.super Landroid/view/ViewGroup;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T::",
        "Landroid/widget/Adapter;",
        ">",
        "Landroid/view/ViewGroup;"
    }
.end annotation


# instance fields
.field A:I

.field B:I

.field C:J

.field D:Z

.field private a:I

.field private b:Landroid/view/View;

.field private c:Z

.field private d:Z

.field private e:Landroid/support/v7/internal/widget/q;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/support/v7/internal/widget/l",
            "<TT;>.android/support/v7/internal/widget/q;"
        }
    .end annotation
.end field

.field k:I
    .annotation runtime Landroid/view/ViewDebug$ExportedProperty;
        category = "scrolling"
    .end annotation
.end field

.field l:I

.field m:I

.field n:J

.field o:J

.field p:Z

.field q:I

.field r:Z

.field s:Landroid/support/v7/internal/widget/p;

.field t:Landroid/support/v7/internal/widget/n;

.field u:Z

.field v:I
    .annotation runtime Landroid/view/ViewDebug$ExportedProperty;
        category = "list"
    .end annotation
.end field

.field w:J

.field x:I
    .annotation runtime Landroid/view/ViewDebug$ExportedProperty;
        category = "list"
    .end annotation
.end field

.field y:J

.field z:I
    .annotation runtime Landroid/view/ViewDebug$ExportedProperty;
        category = "list"
    .end annotation
.end field


# direct methods
.method constructor <init>(Landroid/content/Context;I)V
    .registers 8

    .prologue
    const/4 v4, -0x1

    const-wide/high16 v2, -0x8000000000000000L

    const/4 v1, 0x0

    .line 236
    const/4 v0, 0x0

    invoke-direct {p0, p1, v0, p2}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 67
    iput v1, p0, Landroid/support/v7/internal/widget/l;->k:I

    .line 84
    iput-wide v2, p0, Landroid/support/v7/internal/widget/l;->n:J

    .line 94
    iput-boolean v1, p0, Landroid/support/v7/internal/widget/l;->p:Z

    .line 126
    iput-boolean v1, p0, Landroid/support/v7/internal/widget/l;->r:Z

    .line 152
    iput v4, p0, Landroid/support/v7/internal/widget/l;->v:I

    .line 158
    iput-wide v2, p0, Landroid/support/v7/internal/widget/l;->w:J

    .line 163
    iput v4, p0, Landroid/support/v7/internal/widget/l;->x:I

    .line 169
    iput-wide v2, p0, Landroid/support/v7/internal/widget/l;->y:J

    .line 201
    iput v4, p0, Landroid/support/v7/internal/widget/l;->B:I

    .line 206
    iput-wide v2, p0, Landroid/support/v7/internal/widget/l;->C:J

    .line 225
    iput-boolean v1, p0, Landroid/support/v7/internal/widget/l;->D:Z

    .line 237
    return-void
.end method

.method private a(I)J
    .registers 4

    .prologue
    .line 770
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/l;->c()Landroid/widget/Adapter;

    move-result-object v0

    .line 771
    if-eqz v0, :cond_8

    if-gez p1, :cond_b

    :cond_8
    const-wide/high16 v0, -0x8000000000000000L

    :goto_a
    return-wide v0

    :cond_b
    invoke-interface {v0, p1}, Landroid/widget/Adapter;->getItemId(I)J

    move-result-wide v0

    goto :goto_a
.end method

.method static synthetic a(Landroid/support/v7/internal/widget/l;)Landroid/os/Parcelable;
    .registers 2

    .prologue
    .line 50
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/l;->onSaveInstanceState()Landroid/os/Parcelable;

    move-result-object v0

    return-object v0
.end method

.method private a()V
    .registers 4

    .prologue
    .line 891
    iget-object v0, p0, Landroid/support/v7/internal/widget/l;->s:Landroid/support/v7/internal/widget/p;

    if-nez v0, :cond_5

    .line 902
    :goto_4
    return-void

    .line 894
    :cond_5
    iget v0, p0, Landroid/support/v7/internal/widget/l;->v:I

    .line 895
    if-ltz v0, :cond_19

    .line 896
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/l;->b()Landroid/view/View;

    .line 897
    iget-object v1, p0, Landroid/support/v7/internal/widget/l;->s:Landroid/support/v7/internal/widget/p;

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/l;->c()Landroid/widget/Adapter;

    move-result-object v2

    invoke-interface {v2, v0}, Landroid/widget/Adapter;->getItemId(I)J

    invoke-interface {v1, v0}, Landroid/support/v7/internal/widget/p;->a(I)V

    goto :goto_4

    .line 900
    :cond_19
    iget-object v0, p0, Landroid/support/v7/internal/widget/l;->s:Landroid/support/v7/internal/widget/p;

    goto :goto_4
.end method

.method static synthetic a(Landroid/support/v7/internal/widget/l;Landroid/os/Parcelable;)V
    .registers 2

    .prologue
    .line 50
    invoke-virtual {p0, p1}, Landroid/support/v7/internal/widget/l;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    return-void
.end method

.method static synthetic b(Landroid/support/v7/internal/widget/l;)V
    .registers 1

    .prologue
    .line 50
    invoke-direct {p0}, Landroid/support/v7/internal/widget/l;->a()V

    return-void
.end method


# virtual methods
.method public a(Landroid/support/v7/internal/widget/n;)V
    .registers 2

    .prologue
    .line 282
    iput-object p1, p0, Landroid/support/v7/internal/widget/l;->t:Landroid/support/v7/internal/widget/n;

    .line 283
    return-void
.end method

.method public final a(Landroid/view/View;I)Z
    .registers 6

    .prologue
    const/4 v0, 0x1

    const/4 v1, 0x0

    .line 303
    iget-object v2, p0, Landroid/support/v7/internal/widget/l;->t:Landroid/support/v7/internal/widget/n;

    if-eqz v2, :cond_14

    .line 304
    invoke-virtual {p0, v1}, Landroid/support/v7/internal/widget/l;->playSoundEffect(I)V

    .line 305
    if-eqz p1, :cond_e

    .line 306
    invoke-virtual {p1, v0}, Landroid/view/View;->sendAccessibilityEvent(I)V

    .line 308
    :cond_e
    iget-object v1, p0, Landroid/support/v7/internal/widget/l;->t:Landroid/support/v7/internal/widget/n;

    invoke-interface {v1, p1, p2}, Landroid/support/v7/internal/widget/n;->a(Landroid/view/View;I)V

    .line 312
    :goto_13
    return v0

    :cond_14
    move v0, v1

    goto :goto_13
.end method

.method public addView(Landroid/view/View;)V
    .registers 4

    .prologue
    .line 461
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const-string v1, "addView(View) is not supported in AdapterView"

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public addView(Landroid/view/View;I)V
    .registers 5

    .prologue
    .line 474
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const-string v1, "addView(View, int) is not supported in AdapterView"

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V
    .registers 6

    .prologue
    .line 502
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const-string v1, "addView(View, int, LayoutParams) is not supported in AdapterView"

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .registers 5

    .prologue
    .line 487
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const-string v1, "addView(View, LayoutParams) is not supported in AdapterView"

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public abstract b()Landroid/view/View;
.end method

.method final b(I)V
    .registers 4

    .prologue
    .line 1094
    iput p1, p0, Landroid/support/v7/internal/widget/l;->x:I

    .line 1095
    invoke-direct {p0, p1}, Landroid/support/v7/internal/widget/l;->a(I)J

    move-result-wide v0

    iput-wide v0, p0, Landroid/support/v7/internal/widget/l;->y:J

    .line 1096
    return-void
.end method

.method public abstract c()Landroid/widget/Adapter;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation
.end method

.method final c(I)V
    .registers 4

    .prologue
    .line 1104
    iput p1, p0, Landroid/support/v7/internal/widget/l;->v:I

    .line 1105
    invoke-direct {p0, p1}, Landroid/support/v7/internal/widget/l;->a(I)J

    move-result-wide v0

    iput-wide v0, p0, Landroid/support/v7/internal/widget/l;->w:J

    .line 1107
    iget-boolean v0, p0, Landroid/support/v7/internal/widget/l;->p:Z

    if-eqz v0, :cond_18

    iget v0, p0, Landroid/support/v7/internal/widget/l;->q:I

    if-nez v0, :cond_18

    if-ltz p1, :cond_18

    .line 1108
    iput p1, p0, Landroid/support/v7/internal/widget/l;->m:I

    .line 1109
    iget-wide v0, p0, Landroid/support/v7/internal/widget/l;->w:J

    iput-wide v0, p0, Landroid/support/v7/internal/widget/l;->n:J

    .line 1111
    :cond_18
    return-void
.end method

.method protected canAnimate()Z
    .registers 2

    .prologue
    .line 916
    invoke-super {p0}, Landroid/view/ViewGroup;->canAnimate()Z

    move-result v0

    if-eqz v0, :cond_c

    iget v0, p0, Landroid/support/v7/internal/widget/l;->z:I

    if-lez v0, :cond_c

    const/4 v0, 0x1

    :goto_b
    return v0

    :cond_c
    const/4 v0, 0x0

    goto :goto_b
.end method

.method final d()V
    .registers 7

    .prologue
    const/16 v5, 0x8

    const/4 v2, 0x1

    const/4 v1, 0x0

    .line 714
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/l;->c()Landroid/widget/Adapter;

    move-result-object v4

    .line 715
    if-eqz v4, :cond_10

    invoke-interface {v4}, Landroid/widget/Adapter;->getCount()I

    move-result v0

    if-nez v0, :cond_5b

    :cond_10
    move v0, v2

    .line 716
    :goto_11
    if-nez v0, :cond_5d

    move v3, v2

    .line 720
    :goto_14
    if-eqz v3, :cond_5f

    iget-boolean v0, p0, Landroid/support/v7/internal/widget/l;->d:Z

    if-eqz v0, :cond_5f

    move v0, v2

    :goto_1b
    invoke-super {p0, v0}, Landroid/view/ViewGroup;->setFocusableInTouchMode(Z)V

    .line 721
    if-eqz v3, :cond_61

    iget-boolean v0, p0, Landroid/support/v7/internal/widget/l;->c:Z

    if-eqz v0, :cond_61

    move v0, v2

    :goto_25
    invoke-super {p0, v0}, Landroid/view/ViewGroup;->setFocusable(Z)V

    .line 722
    iget-object v0, p0, Landroid/support/v7/internal/widget/l;->b:Landroid/view/View;

    if-eqz v0, :cond_5a

    .line 723
    if-eqz v4, :cond_34

    invoke-interface {v4}, Landroid/widget/Adapter;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_63

    :cond_34
    :goto_34
    if-eqz v2, :cond_69

    iget-object v0, p0, Landroid/support/v7/internal/widget/l;->b:Landroid/view/View;

    if-eqz v0, :cond_65

    iget-object v0, p0, Landroid/support/v7/internal/widget/l;->b:Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/view/View;->setVisibility(I)V

    invoke-virtual {p0, v5}, Landroid/support/v7/internal/widget/l;->setVisibility(I)V

    :goto_42
    iget-boolean v0, p0, Landroid/support/v7/internal/widget/l;->u:Z

    if-eqz v0, :cond_5a

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/l;->getLeft()I

    move-result v2

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/l;->getTop()I

    move-result v3

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/l;->getRight()I

    move-result v4

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/l;->getBottom()I

    move-result v5

    move-object v0, p0

    invoke-virtual/range {v0 .. v5}, Landroid/support/v7/internal/widget/l;->onLayout(ZIIII)V

    .line 725
    :cond_5a
    :goto_5a
    return-void

    :cond_5b
    move v0, v1

    .line 715
    goto :goto_11

    :cond_5d
    move v3, v1

    .line 716
    goto :goto_14

    :cond_5f
    move v0, v1

    .line 720
    goto :goto_1b

    :cond_61
    move v0, v1

    .line 721
    goto :goto_25

    :cond_63
    move v2, v1

    .line 723
    goto :goto_34

    :cond_65
    invoke-virtual {p0, v1}, Landroid/support/v7/internal/widget/l;->setVisibility(I)V

    goto :goto_42

    :cond_69
    iget-object v0, p0, Landroid/support/v7/internal/widget/l;->b:Landroid/view/View;

    if-eqz v0, :cond_72

    iget-object v0, p0, Landroid/support/v7/internal/widget/l;->b:Landroid/view/View;

    invoke-virtual {v0, v5}, Landroid/view/View;->setVisibility(I)V

    :cond_72
    invoke-virtual {p0, v1}, Landroid/support/v7/internal/widget/l;->setVisibility(I)V

    goto :goto_5a
.end method

.method public dispatchPopulateAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)Z
    .registers 4

    .prologue
    .line 906
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/l;->b()Landroid/view/View;

    move-result-object v0

    .line 907
    if-eqz v0, :cond_14

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v1

    if-nez v1, :cond_14

    invoke-virtual {v0, p1}, Landroid/view/View;->dispatchPopulateAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)Z

    move-result v0

    if-eqz v0, :cond_14

    .line 909
    const/4 v0, 0x1

    .line 911
    :goto_13
    return v0

    :cond_14
    const/4 v0, 0x0

    goto :goto_13
.end method

.method protected dispatchRestoreInstanceState(Landroid/util/SparseArray;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/util/SparseArray",
            "<",
            "Landroid/os/Parcelable;",
            ">;)V"
        }
    .end annotation

    .prologue
    .line 793
    invoke-virtual {p0, p1}, Landroid/support/v7/internal/widget/l;->dispatchThawSelfOnly(Landroid/util/SparseArray;)V

    .line 794
    return-void
.end method

.method protected dispatchSaveInstanceState(Landroid/util/SparseArray;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/util/SparseArray",
            "<",
            "Landroid/os/Parcelable;",
            ">;)V"
        }
    .end annotation

    .prologue
    .line 785
    invoke-virtual {p0, p1}, Landroid/support/v7/internal/widget/l;->dispatchFreezeSelfOnly(Landroid/util/SparseArray;)V

    .line 786
    return-void
.end method

.method final e()V
    .registers 15

    .prologue
    .line 920
    iget v7, p0, Landroid/support/v7/internal/widget/l;->z:I

    .line 921
    const/4 v4, 0x0

    .line 923
    if-lez v7, :cond_a8

    .line 928
    iget-boolean v0, p0, Landroid/support/v7/internal/widget/l;->p:Z

    if-eqz v0, :cond_a6

    .line 931
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v7/internal/widget/l;->p:Z

    .line 935
    iget v8, p0, Landroid/support/v7/internal/widget/l;->z:I

    if-eqz v8, :cond_a4

    iget-wide v9, p0, Landroid/support/v7/internal/widget/l;->n:J

    iget v0, p0, Landroid/support/v7/internal/widget/l;->m:I

    const-wide/high16 v1, -0x8000000000000000L

    cmp-long v1, v9, v1

    if-eqz v1, :cond_a4

    const/4 v1, 0x0

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    add-int/lit8 v1, v8, -0x1

    invoke-static {v1, v0}, Ljava/lang/Math;->min(II)I

    move-result v1

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    const-wide/16 v5, 0x64

    add-long v11, v2, v5

    const/4 v0, 0x0

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/l;->c()Landroid/widget/Adapter;

    move-result-object v13

    if-eqz v13, :cond_a4

    move v2, v1

    move v3, v1

    :cond_36
    :goto_36
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v5

    cmp-long v5, v5, v11

    if-gtz v5, :cond_a4

    invoke-interface {v13, v3}, Landroid/widget/Adapter;->getItemId(I)J

    move-result-wide v5

    cmp-long v5, v5, v9

    if-nez v5, :cond_7c

    .line 936
    :goto_46
    if-ltz v3, :cond_a6

    .line 939
    if-ne v3, v3, :cond_a6

    .line 941
    invoke-virtual {p0, v3}, Landroid/support/v7/internal/widget/l;->c(I)V

    .line 942
    const/4 v4, 0x1

    move v0, v4

    .line 946
    :goto_4f
    if-nez v0, :cond_65

    .line 948
    iget v1, p0, Landroid/support/v7/internal/widget/l;->v:I

    .line 951
    if-lt v1, v7, :cond_57

    .line 952
    add-int/lit8 v1, v7, -0x1

    .line 954
    :cond_57
    if-gez v1, :cond_5a

    .line 955
    const/4 v1, 0x0

    .line 960
    :cond_5a
    if-gez v1, :cond_5c

    .line 964
    :cond_5c
    if-ltz v1, :cond_65

    .line 965
    invoke-virtual {p0, v1}, Landroid/support/v7/internal/widget/l;->c(I)V

    .line 966
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/l;->f()V

    .line 967
    const/4 v0, 0x1

    .line 971
    :cond_65
    :goto_65
    if-nez v0, :cond_7b

    .line 973
    const/4 v0, -0x1

    iput v0, p0, Landroid/support/v7/internal/widget/l;->x:I

    .line 974
    const-wide/high16 v0, -0x8000000000000000L

    iput-wide v0, p0, Landroid/support/v7/internal/widget/l;->y:J

    .line 975
    const/4 v0, -0x1

    iput v0, p0, Landroid/support/v7/internal/widget/l;->v:I

    .line 976
    const-wide/high16 v0, -0x8000000000000000L

    iput-wide v0, p0, Landroid/support/v7/internal/widget/l;->w:J

    .line 977
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v7/internal/widget/l;->p:Z

    .line 978
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/l;->f()V

    .line 980
    :cond_7b
    return-void

    .line 935
    :cond_7c
    add-int/lit8 v5, v8, -0x1

    if-ne v1, v5, :cond_94

    const/4 v5, 0x1

    move v6, v5

    :goto_82
    if-nez v2, :cond_97

    const/4 v5, 0x1

    :goto_85
    if-eqz v6, :cond_89

    if-nez v5, :cond_a4

    :cond_89
    if-nez v5, :cond_8f

    if-eqz v0, :cond_99

    if-nez v6, :cond_99

    :cond_8f
    add-int/lit8 v1, v1, 0x1

    const/4 v0, 0x0

    move v3, v1

    goto :goto_36

    :cond_94
    const/4 v5, 0x0

    move v6, v5

    goto :goto_82

    :cond_97
    const/4 v5, 0x0

    goto :goto_85

    :cond_99
    if-nez v6, :cond_9f

    if-nez v0, :cond_36

    if-nez v5, :cond_36

    :cond_9f
    add-int/lit8 v2, v2, -0x1

    const/4 v0, 0x1

    move v3, v2

    goto :goto_36

    :cond_a4
    const/4 v3, -0x1

    goto :goto_46

    :cond_a6
    move v0, v4

    goto :goto_4f

    :cond_a8
    move v0, v4

    goto :goto_65
.end method

.method final f()V
    .registers 5

    .prologue
    .line 983
    iget v0, p0, Landroid/support/v7/internal/widget/l;->x:I

    iget v1, p0, Landroid/support/v7/internal/widget/l;->B:I

    if-ne v0, v1, :cond_e

    iget-wide v0, p0, Landroid/support/v7/internal/widget/l;->y:J

    iget-wide v2, p0, Landroid/support/v7/internal/widget/l;->C:J

    cmp-long v0, v0, v2

    if-eqz v0, :cond_48

    .line 984
    :cond_e
    iget-object v0, p0, Landroid/support/v7/internal/widget/l;->s:Landroid/support/v7/internal/widget/p;

    if-eqz v0, :cond_2b

    iget-boolean v0, p0, Landroid/support/v7/internal/widget/l;->r:Z

    if-nez v0, :cond_1a

    iget-boolean v0, p0, Landroid/support/v7/internal/widget/l;->D:Z

    if-eqz v0, :cond_49

    :cond_1a
    iget-object v0, p0, Landroid/support/v7/internal/widget/l;->e:Landroid/support/v7/internal/widget/q;

    if-nez v0, :cond_26

    new-instance v0, Landroid/support/v7/internal/widget/q;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Landroid/support/v7/internal/widget/q;-><init>(Landroid/support/v7/internal/widget/l;B)V

    iput-object v0, p0, Landroid/support/v7/internal/widget/l;->e:Landroid/support/v7/internal/widget/q;

    :cond_26
    iget-object v0, p0, Landroid/support/v7/internal/widget/l;->e:Landroid/support/v7/internal/widget/q;

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/l;->post(Ljava/lang/Runnable;)Z

    :cond_2b
    :goto_2b
    iget v0, p0, Landroid/support/v7/internal/widget/l;->x:I

    const/4 v1, -0x1

    if-eq v0, v1, :cond_40

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/l;->isShown()Z

    move-result v0

    if-eqz v0, :cond_40

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/l;->isInTouchMode()Z

    move-result v0

    if-nez v0, :cond_40

    const/4 v0, 0x4

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/l;->sendAccessibilityEvent(I)V

    .line 985
    :cond_40
    iget v0, p0, Landroid/support/v7/internal/widget/l;->x:I

    iput v0, p0, Landroid/support/v7/internal/widget/l;->B:I

    .line 986
    iget-wide v0, p0, Landroid/support/v7/internal/widget/l;->y:J

    iput-wide v0, p0, Landroid/support/v7/internal/widget/l;->C:J

    .line 988
    :cond_48
    return-void

    .line 984
    :cond_49
    invoke-direct {p0}, Landroid/support/v7/internal/widget/l;->a()V

    goto :goto_2b
.end method

.method final g()V
    .registers 6

    .prologue
    const/4 v4, 0x1

    const/4 v3, 0x0

    .line 1119
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/l;->getChildCount()I

    move-result v0

    if-lez v0, :cond_2e

    .line 1120
    iput-boolean v4, p0, Landroid/support/v7/internal/widget/l;->p:Z

    .line 1121
    iget v0, p0, Landroid/support/v7/internal/widget/l;->a:I

    int-to-long v0, v0

    iput-wide v0, p0, Landroid/support/v7/internal/widget/l;->o:J

    .line 1122
    iget v0, p0, Landroid/support/v7/internal/widget/l;->x:I

    if-ltz v0, :cond_2f

    .line 1124
    iget v0, p0, Landroid/support/v7/internal/widget/l;->x:I

    iget v1, p0, Landroid/support/v7/internal/widget/l;->k:I

    sub-int/2addr v0, v1

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/l;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    .line 1125
    iget-wide v1, p0, Landroid/support/v7/internal/widget/l;->w:J

    iput-wide v1, p0, Landroid/support/v7/internal/widget/l;->n:J

    .line 1126
    iget v1, p0, Landroid/support/v7/internal/widget/l;->v:I

    iput v1, p0, Landroid/support/v7/internal/widget/l;->m:I

    .line 1127
    if-eqz v0, :cond_2c

    .line 1128
    invoke-virtual {v0}, Landroid/view/View;->getTop()I

    move-result v0

    iput v0, p0, Landroid/support/v7/internal/widget/l;->l:I

    .line 1130
    :cond_2c
    iput v3, p0, Landroid/support/v7/internal/widget/l;->q:I

    .line 1147
    :cond_2e
    :goto_2e
    return-void

    .line 1133
    :cond_2f
    invoke-virtual {p0, v3}, Landroid/support/v7/internal/widget/l;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    .line 1134
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/l;->c()Landroid/widget/Adapter;

    move-result-object v1

    .line 1135
    iget v2, p0, Landroid/support/v7/internal/widget/l;->k:I

    if-ltz v2, :cond_5a

    iget v2, p0, Landroid/support/v7/internal/widget/l;->k:I

    invoke-interface {v1}, Landroid/widget/Adapter;->getCount()I

    move-result v3

    if-ge v2, v3, :cond_5a

    .line 1136
    iget v2, p0, Landroid/support/v7/internal/widget/l;->k:I

    invoke-interface {v1, v2}, Landroid/widget/Adapter;->getItemId(I)J

    move-result-wide v1

    iput-wide v1, p0, Landroid/support/v7/internal/widget/l;->n:J

    .line 1140
    :goto_4b
    iget v1, p0, Landroid/support/v7/internal/widget/l;->k:I

    iput v1, p0, Landroid/support/v7/internal/widget/l;->m:I

    .line 1141
    if-eqz v0, :cond_57

    .line 1142
    invoke-virtual {v0}, Landroid/view/View;->getTop()I

    move-result v0

    iput v0, p0, Landroid/support/v7/internal/widget/l;->l:I

    .line 1144
    :cond_57
    iput v4, p0, Landroid/support/v7/internal/widget/l;->q:I

    goto :goto_2e

    .line 1138
    :cond_5a
    const-wide/16 v1, -0x1

    iput-wide v1, p0, Landroid/support/v7/internal/widget/l;->n:J

    goto :goto_4b
.end method

.method protected onDetachedFromWindow()V
    .registers 2

    .prologue
    .line 849
    invoke-super {p0}, Landroid/view/ViewGroup;->onDetachedFromWindow()V

    .line 850
    iget-object v0, p0, Landroid/support/v7/internal/widget/l;->e:Landroid/support/v7/internal/widget/q;

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/l;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 851
    return-void
.end method

.method protected onLayout(ZIIII)V
    .registers 7

    .prologue
    .line 542
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/l;->getHeight()I

    move-result v0

    iput v0, p0, Landroid/support/v7/internal/widget/l;->a:I

    .line 543
    return-void
.end method

.method public removeAllViews()V
    .registers 3

    .prologue
    .line 537
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const-string v1, "removeAllViews() is not supported in AdapterView"

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public removeView(Landroid/view/View;)V
    .registers 4

    .prologue
    .line 515
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const-string v1, "removeView(View) is not supported in AdapterView"

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public removeViewAt(I)V
    .registers 4

    .prologue
    .line 527
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    const-string v1, "removeViewAt(int) is not supported in AdapterView"

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public setFocusable(Z)V
    .registers 5

    .prologue
    const/4 v2, 0x1

    const/4 v1, 0x0

    .line 689
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/l;->c()Landroid/widget/Adapter;

    move-result-object v0

    .line 690
    if-eqz v0, :cond_e

    invoke-interface {v0}, Landroid/widget/Adapter;->getCount()I

    move-result v0

    if-nez v0, :cond_1d

    :cond_e
    move v0, v2

    .line 692
    :goto_f
    iput-boolean p1, p0, Landroid/support/v7/internal/widget/l;->c:Z

    .line 693
    if-nez p1, :cond_15

    .line 694
    iput-boolean v1, p0, Landroid/support/v7/internal/widget/l;->d:Z

    .line 697
    :cond_15
    if-eqz p1, :cond_1f

    if-nez v0, :cond_1f

    :goto_19
    invoke-super {p0, v2}, Landroid/view/ViewGroup;->setFocusable(Z)V

    .line 698
    return-void

    :cond_1d
    move v0, v1

    .line 690
    goto :goto_f

    :cond_1f
    move v2, v1

    .line 697
    goto :goto_19
.end method

.method public setFocusableInTouchMode(Z)V
    .registers 5

    .prologue
    const/4 v1, 0x0

    const/4 v2, 0x1

    .line 702
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/l;->c()Landroid/widget/Adapter;

    move-result-object v0

    .line 703
    if-eqz v0, :cond_e

    invoke-interface {v0}, Landroid/widget/Adapter;->getCount()I

    move-result v0

    if-nez v0, :cond_1d

    :cond_e
    move v0, v2

    .line 705
    :goto_f
    iput-boolean p1, p0, Landroid/support/v7/internal/widget/l;->d:Z

    .line 706
    if-eqz p1, :cond_15

    .line 707
    iput-boolean v2, p0, Landroid/support/v7/internal/widget/l;->c:Z

    .line 710
    :cond_15
    if-eqz p1, :cond_1f

    if-nez v0, :cond_1f

    :goto_19
    invoke-super {p0, v2}, Landroid/view/ViewGroup;->setFocusableInTouchMode(Z)V

    .line 711
    return-void

    :cond_1d
    move v0, v1

    .line 703
    goto :goto_f

    :cond_1f
    move v2, v1

    .line 710
    goto :goto_19
.end method

.method public setOnClickListener(Landroid/view/View$OnClickListener;)V
    .registers 4

    .prologue
    .line 776
    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "Don\'t call setOnClickListener for an AdapterView. You probably want setOnItemClickListener instead"

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

###### Class android.support.v7.internal.widget.q (android.support.v7.internal.widget.q)
.class final Landroid/support/v7/internal/widget/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Landroid/support/v7/internal/widget/l;


# direct methods
.method private constructor <init>(Landroid/support/v7/internal/widget/l;)V
    .registers 2

    .prologue
    .line 853
    iput-object p1, p0, Landroid/support/v7/internal/widget/q;->a:Landroid/support/v7/internal/widget/l;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Landroid/support/v7/internal/widget/l;B)V
    .registers 3

    .prologue
    .line 853
    invoke-direct {p0, p1}, Landroid/support/v7/internal/widget/q;-><init>(Landroid/support/v7/internal/widget/l;)V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .prologue
    .line 855
    iget-object v0, p0, Landroid/support/v7/internal/widget/q;->a:Landroid/support/v7/internal/widget/l;

    iget-boolean v0, v0, Landroid/support/v7/internal/widget/l;->u:Z

    if-eqz v0, :cond_14

    .line 859
    iget-object v0, p0, Landroid/support/v7/internal/widget/q;->a:Landroid/support/v7/internal/widget/l;

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/l;->c()Landroid/widget/Adapter;

    move-result-object v0

    if-eqz v0, :cond_13

    .line 860
    iget-object v0, p0, Landroid/support/v7/internal/widget/q;->a:Landroid/support/v7/internal/widget/l;

    invoke-virtual {v0, p0}, Landroid/support/v7/internal/widget/l;->post(Ljava/lang/Runnable;)Z

    .line 865
    :cond_13
    :goto_13
    return-void

    .line 863
    :cond_14
    iget-object v0, p0, Landroid/support/v7/internal/widget/q;->a:Landroid/support/v7/internal/widget/l;

    invoke-static {v0}, Landroid/support/v7/internal/widget/l;->b(Landroid/support/v7/internal/widget/l;)V

    goto :goto_13
.end method
