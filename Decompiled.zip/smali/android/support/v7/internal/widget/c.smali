###### Class android.support.v7.internal.widget.c (android.support.v7.internal.widget.c)
.class final Landroid/support/v7/internal/widget/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/support/v7/internal/view/menu/aa;


# instance fields
.field a:Landroid/support/v7/internal/view/menu/n;

.field b:Landroid/support/v7/internal/view/menu/r;

.field final synthetic c:Landroid/support/v7/internal/widget/ActionBarView;


# direct methods
.method private constructor <init>(Landroid/support/v7/internal/widget/ActionBarView;)V
    .registers 2

    .prologue
    .line 1377
    iput-object p1, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Landroid/support/v7/internal/widget/ActionBarView;B)V
    .registers 3

    .prologue
    .line 1377
    invoke-direct {p0, p1}, Landroid/support/v7/internal/widget/c;-><init>(Landroid/support/v7/internal/widget/ActionBarView;)V

    return-void
.end method


# virtual methods
.method public final a(Landroid/content/Context;Landroid/support/v7/internal/view/menu/n;)V
    .registers 5

    .prologue
    .line 1385
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->a:Landroid/support/v7/internal/view/menu/n;

    if-eqz v0, :cond_f

    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->b:Landroid/support/v7/internal/view/menu/r;

    if-eqz v0, :cond_f

    .line 1386
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->a:Landroid/support/v7/internal/view/menu/n;

    iget-object v1, p0, Landroid/support/v7/internal/widget/c;->b:Landroid/support/v7/internal/view/menu/r;

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/view/menu/n;->b(Landroid/support/v7/internal/view/menu/r;)Z

    .line 1388
    :cond_f
    iput-object p2, p0, Landroid/support/v7/internal/widget/c;->a:Landroid/support/v7/internal/view/menu/n;

    .line 1389
    return-void
.end method

.method public final a(Landroid/support/v7/internal/view/menu/n;Z)V
    .registers 3

    .prologue
    .line 1431
    return-void
.end method

.method public final a(Landroid/support/v7/internal/view/menu/ag;)Z
    .registers 3

    .prologue
    .line 1426
    const/4 v0, 0x0

    return v0
.end method

.method public final b(Landroid/support/v7/internal/view/menu/r;)Z
    .registers 7

    .prologue
    const/4 v4, 0x1

    const/16 v3, 0x8

    .line 1440
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-virtual {p1}, Landroid/support/v7/internal/view/menu/r;->getActionView()Landroid/view/View;

    move-result-object v1

    iput-object v1, v0, Landroid/support/v7/internal/widget/ActionBarView;->g:Landroid/view/View;

    .line 1441
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->e(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    move-result-object v0

    iget-object v1, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v1}, Landroid/support/v7/internal/widget/ActionBarView;->d(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object v1

    iget-object v2, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-virtual {v2}, Landroid/support/v7/internal/widget/ActionBarView;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->a(Landroid/graphics/drawable/Drawable;)V

    .line 1442
    iput-object p1, p0, Landroid/support/v7/internal/widget/c;->b:Landroid/support/v7/internal/view/menu/r;

    .line 1443
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    iget-object v0, v0, Landroid/support/v7/internal/widget/ActionBarView;->g:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    iget-object v1, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    if-eq v0, v1, :cond_3f

    .line 1444
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    iget-object v1, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    iget-object v1, v1, Landroid/support/v7/internal/widget/ActionBarView;->g:Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/widget/ActionBarView;->addView(Landroid/view/View;)V

    .line 1446
    :cond_3f
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->e(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    iget-object v1, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    if-eq v0, v1, :cond_58

    .line 1447
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    iget-object v1, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v1}, Landroid/support/v7/internal/widget/ActionBarView;->e(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/widget/ActionBarView;->addView(Landroid/view/View;)V

    .line 1449
    :cond_58
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->f(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    move-result-object v0

    invoke-virtual {v0, v3}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->setVisibility(I)V

    .line 1450
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->g(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/widget/LinearLayout;

    move-result-object v0

    if-eqz v0, :cond_72

    .line 1451
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->g(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/widget/LinearLayout;

    move-result-object v0

    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 1453
    :cond_72
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->h(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/internal/widget/ScrollingTabContainerView;

    move-result-object v0

    if-eqz v0, :cond_83

    .line 1454
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->h(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/internal/widget/ScrollingTabContainerView;

    move-result-object v0

    invoke-virtual {v0, v3}, Landroid/support/v7/internal/widget/ScrollingTabContainerView;->setVisibility(I)V

    .line 1456
    :cond_83
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->i(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/internal/widget/ab;

    move-result-object v0

    if-eqz v0, :cond_94

    .line 1457
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->i(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/internal/widget/ab;

    move-result-object v0

    invoke-virtual {v0, v3}, Landroid/support/v7/internal/widget/ab;->setVisibility(I)V

    .line 1459
    :cond_94
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->j(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_a5

    .line 1460
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->j(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0, v3}, Landroid/view/View;->setVisibility(I)V

    .line 1462
    :cond_a5
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/ActionBarView;->requestLayout()V

    .line 1463
    invoke-virtual {p1, v4}, Landroid/support/v7/internal/view/menu/r;->e(Z)V

    .line 1465
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    iget-object v0, v0, Landroid/support/v7/internal/widget/ActionBarView;->g:Landroid/view/View;

    instance-of v0, v0, Landroid/support/v7/b/b;

    if-eqz v0, :cond_be

    .line 1466
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    iget-object v0, v0, Landroid/support/v7/internal/widget/ActionBarView;->g:Landroid/view/View;

    check-cast v0, Landroid/support/v7/b/b;

    invoke-interface {v0}, Landroid/support/v7/b/b;->a()V

    .line 1469
    :cond_be
    return v4
.end method

.method public final c(Z)V
    .registers 7

    .prologue
    const/4 v1, 0x0

    .line 1399
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->b:Landroid/support/v7/internal/view/menu/r;

    if-eqz v0, :cond_28

    .line 1402
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->a:Landroid/support/v7/internal/view/menu/n;

    if-eqz v0, :cond_2d

    .line 1403
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->a:Landroid/support/v7/internal/view/menu/n;

    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/n;->size()I

    move-result v3

    move v2, v1

    .line 1404
    :goto_10
    if-ge v2, v3, :cond_2d

    .line 1405
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->a:Landroid/support/v7/internal/view/menu/n;

    invoke-virtual {v0, v2}, Landroid/support/v7/internal/view/menu/n;->getItem(I)Landroid/view/MenuItem;

    move-result-object v0

    check-cast v0, Landroid/support/v4/a/a/b;

    .line 1406
    iget-object v4, p0, Landroid/support/v7/internal/widget/c;->b:Landroid/support/v7/internal/view/menu/r;

    if-ne v0, v4, :cond_29

    .line 1407
    const/4 v0, 0x1

    .line 1413
    :goto_1f
    if-nez v0, :cond_28

    .line 1415
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->a:Landroid/support/v7/internal/view/menu/n;

    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->b:Landroid/support/v7/internal/view/menu/r;

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/c;->c(Landroid/support/v7/internal/view/menu/r;)Z

    .line 1418
    :cond_28
    return-void

    .line 1404
    :cond_29
    add-int/lit8 v0, v2, 0x1

    move v2, v0

    goto :goto_10

    :cond_2d
    move v0, v1

    goto :goto_1f
.end method

.method public final c(Landroid/support/v7/internal/view/menu/r;)Z
    .registers 7

    .prologue
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x0

    .line 1476
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    iget-object v0, v0, Landroid/support/v7/internal/widget/ActionBarView;->g:Landroid/view/View;

    instance-of v0, v0, Landroid/support/v7/b/b;

    if-eqz v0, :cond_14

    .line 1477
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    iget-object v0, v0, Landroid/support/v7/internal/widget/ActionBarView;->g:Landroid/view/View;

    check-cast v0, Landroid/support/v7/b/b;

    invoke-interface {v0}, Landroid/support/v7/b/b;->b()V

    .line 1480
    :cond_14
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    iget-object v1, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    iget-object v1, v1, Landroid/support/v7/internal/widget/ActionBarView;->g:Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/widget/ActionBarView;->removeView(Landroid/view/View;)V

    .line 1481
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    iget-object v1, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v1}, Landroid/support/v7/internal/widget/ActionBarView;->e(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/widget/ActionBarView;->removeView(Landroid/view/View;)V

    .line 1482
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    iput-object v3, v0, Landroid/support/v7/internal/widget/ActionBarView;->g:Landroid/view/View;

    .line 1483
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->k(Landroid/support/v7/internal/widget/ActionBarView;)I

    move-result v0

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_3f

    .line 1484
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->f(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    move-result-object v0

    invoke-virtual {v0, v2}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->setVisibility(I)V

    .line 1486
    :cond_3f
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->k(Landroid/support/v7/internal/widget/ActionBarView;)I

    move-result v0

    and-int/lit8 v0, v0, 0x8

    if-eqz v0, :cond_56

    .line 1487
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->g(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/widget/LinearLayout;

    move-result-object v0

    if-nez v0, :cond_b8

    .line 1488
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->l(Landroid/support/v7/internal/widget/ActionBarView;)V

    .line 1493
    :cond_56
    :goto_56
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->h(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/internal/widget/ScrollingTabContainerView;

    move-result-object v0

    if-eqz v0, :cond_70

    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->m(Landroid/support/v7/internal/widget/ActionBarView;)I

    move-result v0

    const/4 v1, 0x2

    if-ne v0, v1, :cond_70

    .line 1494
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->h(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/internal/widget/ScrollingTabContainerView;

    move-result-object v0

    invoke-virtual {v0, v2}, Landroid/support/v7/internal/widget/ScrollingTabContainerView;->setVisibility(I)V

    .line 1496
    :cond_70
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->i(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/internal/widget/ab;

    move-result-object v0

    if-eqz v0, :cond_89

    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->m(Landroid/support/v7/internal/widget/ActionBarView;)I

    move-result v0

    if-ne v0, v4, :cond_89

    .line 1497
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->i(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/internal/widget/ab;

    move-result-object v0

    invoke-virtual {v0, v2}, Landroid/support/v7/internal/widget/ab;->setVisibility(I)V

    .line 1499
    :cond_89
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->j(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_a4

    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->k(Landroid/support/v7/internal/widget/ActionBarView;)I

    move-result v0

    and-int/lit8 v0, v0, 0x10

    if-eqz v0, :cond_a4

    .line 1500
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->j(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1502
    :cond_a4
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->e(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    move-result-object v0

    invoke-virtual {v0, v3}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->a(Landroid/graphics/drawable/Drawable;)V

    .line 1503
    iput-object v3, p0, Landroid/support/v7/internal/widget/c;->b:Landroid/support/v7/internal/view/menu/r;

    .line 1504
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/ActionBarView;->requestLayout()V

    .line 1505
    invoke-virtual {p1, v2}, Landroid/support/v7/internal/view/menu/r;->e(Z)V

    .line 1507
    return v4

    .line 1490
    :cond_b8
    iget-object v0, p0, Landroid/support/v7/internal/widget/c;->c:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->g(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/widget/LinearLayout;

    move-result-object v0

    invoke-virtual {v0, v2}, Landroid/widget/LinearLayout;->setVisibility(I)V

    goto :goto_56
.end method

.method public final i()Z
    .registers 2

    .prologue
    .line 1435
    const/4 v0, 0x0

    return v0
.end method
