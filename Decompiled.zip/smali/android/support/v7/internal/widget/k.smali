###### Class android.support.v7.internal.widget.k (android.support.v7.internal.widget.k)
.class final Landroid/support/v7/internal/widget/k;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;
.implements Landroid/view/View$OnLongClickListener;
.implements Landroid/widget/AdapterView$OnItemClickListener;
.implements Landroid/widget/PopupWindow$OnDismissListener;


# instance fields
.field final synthetic a:Landroid/support/v7/internal/widget/ActivityChooserView;


# direct methods
.method private constructor <init>(Landroid/support/v7/internal/widget/ActivityChooserView;)V
    .registers 2

    .prologue
    .line 531
    iput-object p1, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Landroid/support/v7/internal/widget/ActivityChooserView;B)V
    .registers 3

    .prologue
    .line 531
    invoke-direct {p0, p1}, Landroid/support/v7/internal/widget/k;-><init>(Landroid/support/v7/internal/widget/ActivityChooserView;)V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 4

    .prologue
    .line 567
    iget-object v0, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActivityChooserView;->e(Landroid/support/v7/internal/widget/ActivityChooserView;)Landroid/widget/FrameLayout;

    move-result-object v0

    if-ne p1, v0, :cond_44

    .line 568
    iget-object v0, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/ActivityChooserView;->a()Z

    .line 569
    iget-object v0, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActivityChooserView;->a(Landroid/support/v7/internal/widget/ActivityChooserView;)Landroid/support/v7/internal/widget/j;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/j;->b()Landroid/content/pm/ResolveInfo;

    move-result-object v0

    .line 570
    iget-object v1, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    invoke-static {v1}, Landroid/support/v7/internal/widget/ActivityChooserView;->a(Landroid/support/v7/internal/widget/ActivityChooserView;)Landroid/support/v7/internal/widget/j;

    move-result-object v1

    invoke-virtual {v1}, Landroid/support/v7/internal/widget/j;->e()Landroid/support/v7/internal/widget/d;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/support/v7/internal/widget/d;->a(Landroid/content/pm/ResolveInfo;)I

    move-result v0

    .line 571
    iget-object v1, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    invoke-static {v1}, Landroid/support/v7/internal/widget/ActivityChooserView;->a(Landroid/support/v7/internal/widget/ActivityChooserView;)Landroid/support/v7/internal/widget/j;

    move-result-object v1

    invoke-virtual {v1}, Landroid/support/v7/internal/widget/j;->e()Landroid/support/v7/internal/widget/d;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/support/v7/internal/widget/d;->b(I)Landroid/content/Intent;

    move-result-object v0

    .line 572
    if-eqz v0, :cond_43

    .line 573
    const/high16 v1, 0x80000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 574
    iget-object v1, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    invoke-virtual {v1}, Landroid/support/v7/internal/widget/ActivityChooserView;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    .line 578
    :cond_43
    :goto_43
    return-void

    .line 576
    :cond_44
    iget-object v0, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActivityChooserView;->f(Landroid/support/v7/internal/widget/ActivityChooserView;)Landroid/widget/FrameLayout;

    move-result-object v0

    if-ne p1, v0, :cond_5e

    .line 577
    iget-object v0, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Landroid/support/v7/internal/widget/ActivityChooserView;->a(Landroid/support/v7/internal/widget/ActivityChooserView;Z)Z

    .line 578
    iget-object v0, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    iget-object v1, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    invoke-static {v1}, Landroid/support/v7/internal/widget/ActivityChooserView;->g(Landroid/support/v7/internal/widget/ActivityChooserView;)I

    move-result v1

    invoke-static {v0, v1}, Landroid/support/v7/internal/widget/ActivityChooserView;->a(Landroid/support/v7/internal/widget/ActivityChooserView;I)V

    goto :goto_43

    .line 580
    :cond_5e
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw v0
.end method

.method public final onDismiss()V
    .registers 3

    .prologue
    .line 600
    iget-object v0, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActivityChooserView;->h(Landroid/support/v7/internal/widget/ActivityChooserView;)Landroid/widget/PopupWindow$OnDismissListener;

    move-result-object v0

    if-eqz v0, :cond_11

    iget-object v0, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActivityChooserView;->h(Landroid/support/v7/internal/widget/ActivityChooserView;)Landroid/widget/PopupWindow$OnDismissListener;

    move-result-object v0

    invoke-interface {v0}, Landroid/widget/PopupWindow$OnDismissListener;->onDismiss()V

    .line 601
    :cond_11
    iget-object v0, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    iget-object v0, v0, Landroid/support/v7/internal/widget/ActivityChooserView;->a:Landroid/support/v4/view/l;

    if-eqz v0, :cond_1f

    .line 602
    iget-object v0, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    iget-object v0, v0, Landroid/support/v7/internal/widget/ActivityChooserView;->a:Landroid/support/v4/view/l;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/support/v4/view/l;->a(Z)V

    .line 604
    :cond_1f
    return-void
.end method

.method public final onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/widget/AdapterView",
            "<*>;",
            "Landroid/view/View;",
            "IJ)V"
        }
    .end annotation

    .prologue
    .line 536
    invoke-virtual {p1}, Landroid/widget/AdapterView;->getAdapter()Landroid/widget/Adapter;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/widget/j;

    .line 537
    invoke-virtual {v0, p3}, Landroid/support/v7/internal/widget/j;->getItemViewType(I)I

    move-result v0

    .line 538
    packed-switch v0, :pswitch_data_68

    .line 561
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw v0

    .line 540
    :pswitch_13
    iget-object v0, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    const v1, 0x7fffffff

    invoke-static {v0, v1}, Landroid/support/v7/internal/widget/ActivityChooserView;->a(Landroid/support/v7/internal/widget/ActivityChooserView;I)V

    .line 563
    :cond_1b
    :goto_1b
    return-void

    .line 543
    :pswitch_1c
    iget-object v0, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/ActivityChooserView;->a()Z

    .line 544
    iget-object v0, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActivityChooserView;->d(Landroid/support/v7/internal/widget/ActivityChooserView;)Z

    move-result v0

    if-eqz v0, :cond_39

    .line 546
    if-lez p3, :cond_1b

    .line 547
    iget-object v0, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActivityChooserView;->a(Landroid/support/v7/internal/widget/ActivityChooserView;)Landroid/support/v7/internal/widget/j;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/j;->e()Landroid/support/v7/internal/widget/d;

    move-result-object v0

    invoke-virtual {v0, p3}, Landroid/support/v7/internal/widget/d;->c(I)V

    goto :goto_1b

    .line 552
    :cond_39
    iget-object v0, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActivityChooserView;->a(Landroid/support/v7/internal/widget/ActivityChooserView;)Landroid/support/v7/internal/widget/j;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/j;->f()Z

    move-result v0

    if-eqz v0, :cond_64

    .line 553
    :goto_45
    iget-object v0, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActivityChooserView;->a(Landroid/support/v7/internal/widget/ActivityChooserView;)Landroid/support/v7/internal/widget/j;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/j;->e()Landroid/support/v7/internal/widget/d;

    move-result-object v0

    invoke-virtual {v0, p3}, Landroid/support/v7/internal/widget/d;->b(I)Landroid/content/Intent;

    move-result-object v0

    .line 554
    if-eqz v0, :cond_1b

    .line 555
    const/high16 v1, 0x80000

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    .line 556
    iget-object v1, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    invoke-virtual {v1}, Landroid/support/v7/internal/widget/ActivityChooserView;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    goto :goto_1b

    .line 552
    :cond_64
    add-int/lit8 p3, p3, 0x1

    goto :goto_45

    .line 538
    nop

    :pswitch_data_68
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_13
    .end packed-switch
.end method

.method public final onLongClick(Landroid/view/View;)Z
    .registers 5

    .prologue
    const/4 v2, 0x1

    .line 587
    iget-object v0, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActivityChooserView;->e(Landroid/support/v7/internal/widget/ActivityChooserView;)Landroid/widget/FrameLayout;

    move-result-object v0

    if-ne p1, v0, :cond_26

    .line 588
    iget-object v0, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActivityChooserView;->a(Landroid/support/v7/internal/widget/ActivityChooserView;)Landroid/support/v7/internal/widget/j;

    move-result-object v0

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/j;->getCount()I

    move-result v0

    if-lez v0, :cond_25

    .line 589
    iget-object v0, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    invoke-static {v0, v2}, Landroid/support/v7/internal/widget/ActivityChooserView;->a(Landroid/support/v7/internal/widget/ActivityChooserView;Z)Z

    .line 590
    iget-object v0, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    iget-object v1, p0, Landroid/support/v7/internal/widget/k;->a:Landroid/support/v7/internal/widget/ActivityChooserView;

    invoke-static {v1}, Landroid/support/v7/internal/widget/ActivityChooserView;->g(Landroid/support/v7/internal/widget/ActivityChooserView;)I

    move-result v1

    invoke-static {v0, v1}, Landroid/support/v7/internal/widget/ActivityChooserView;->a(Landroid/support/v7/internal/widget/ActivityChooserView;I)V

    .line 595
    :cond_25
    return v2

    .line 593
    :cond_26
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw v0
.end method
