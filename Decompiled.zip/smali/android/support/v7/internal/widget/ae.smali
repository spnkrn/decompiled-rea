###### Class android.support.v7.internal.widget.ae (android.support.v7.internal.widget.ae)
.class final Landroid/support/v7/internal/widget/ae;
.super Landroid/support/v7/internal/widget/ListPopupWindow;
.source "SourceFile"

# interfaces
.implements Landroid/support/v7/internal/widget/af;


# instance fields
.field final synthetic b:Landroid/support/v7/internal/widget/ab;

.field private c:Ljava/lang/CharSequence;

.field private d:Landroid/widget/ListAdapter;


# direct methods
.method public constructor <init>(Landroid/support/v7/internal/widget/ab;Landroid/content/Context;I)V
    .registers 6

    .prologue
    .line 698
    iput-object p1, p0, Landroid/support/v7/internal/widget/ae;->b:Landroid/support/v7/internal/widget/ab;

    .line 699
    const/4 v0, 0x0

    invoke-direct {p0, p2, v0, p3}, Landroid/support/v7/internal/widget/ListPopupWindow;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 701
    invoke-virtual {p0, p1}, Landroid/support/v7/internal/widget/ae;->a(Landroid/view/View;)V

    .line 702
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ae;->b()V

    .line 703
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ae;->a()V

    .line 705
    new-instance v0, Landroid/support/v7/internal/widget/o;

    new-instance v1, Landroid/support/v7/internal/widget/ae$1;

    invoke-direct {v1, p0, p1}, Landroid/support/v7/internal/widget/ae$1;-><init>(Landroid/support/v7/internal/widget/ae;Landroid/support/v7/internal/widget/ab;)V

    invoke-direct {v0, p1, v1}, Landroid/support/v7/internal/widget/o;-><init>(Landroid/support/v7/internal/widget/l;Landroid/support/v7/internal/widget/n;)V

    .line 716
    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/ae;->a(Landroid/widget/AdapterView$OnItemClickListener;)V

    .line 717
    return-void
.end method

.method static synthetic a(Landroid/support/v7/internal/widget/ae;)Landroid/widget/ListAdapter;
    .registers 2

    .prologue
    .line 693
    iget-object v0, p0, Landroid/support/v7/internal/widget/ae;->d:Landroid/widget/ListAdapter;

    return-object v0
.end method


# virtual methods
.method public final a(Landroid/widget/ListAdapter;)V
    .registers 2

    .prologue
    .line 721
    invoke-super {p0, p1}, Landroid/support/v7/internal/widget/ListPopupWindow;->a(Landroid/widget/ListAdapter;)V

    .line 722
    iput-object p1, p0, Landroid/support/v7/internal/widget/ae;->d:Landroid/widget/ListAdapter;

    .line 723
    return-void
.end method

.method public final a(Ljava/lang/CharSequence;)V
    .registers 2

    .prologue
    .line 731
    iput-object p1, p0, Landroid/support/v7/internal/widget/ae;->c:Ljava/lang/CharSequence;

    .line 732
    return-void
.end method

.method public final e()V
    .registers 7

    .prologue
    .line 736
    iget-object v0, p0, Landroid/support/v7/internal/widget/ae;->b:Landroid/support/v7/internal/widget/ab;

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/ab;->getPaddingLeft()I

    move-result v1

    .line 737
    iget-object v0, p0, Landroid/support/v7/internal/widget/ae;->b:Landroid/support/v7/internal/widget/ab;

    iget v0, v0, Landroid/support/v7/internal/widget/ab;->E:I

    const/4 v2, -0x2

    if-ne v0, v2, :cond_63

    .line 738
    iget-object v0, p0, Landroid/support/v7/internal/widget/ae;->b:Landroid/support/v7/internal/widget/ab;

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/ab;->getWidth()I

    move-result v2

    .line 739
    iget-object v0, p0, Landroid/support/v7/internal/widget/ae;->b:Landroid/support/v7/internal/widget/ab;

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/ab;->getPaddingRight()I

    move-result v3

    .line 740
    iget-object v4, p0, Landroid/support/v7/internal/widget/ae;->b:Landroid/support/v7/internal/widget/ab;

    iget-object v0, p0, Landroid/support/v7/internal/widget/ae;->d:Landroid/widget/ListAdapter;

    check-cast v0, Landroid/widget/SpinnerAdapter;

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ae;->c()Landroid/graphics/drawable/Drawable;

    move-result-object v5

    invoke-virtual {v4, v0, v5}, Landroid/support/v7/internal/widget/ab;->a(Landroid/widget/SpinnerAdapter;Landroid/graphics/drawable/Drawable;)I

    move-result v0

    sub-int/2addr v2, v1

    sub-int/2addr v2, v3

    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    move-result v0

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/ae;->c(I)V

    .line 750
    :goto_30
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ae;->c()Landroid/graphics/drawable/Drawable;

    move-result-object v2

    .line 751
    const/4 v0, 0x0

    .line 752
    if-eqz v2, :cond_49

    .line 753
    iget-object v0, p0, Landroid/support/v7/internal/widget/ae;->b:Landroid/support/v7/internal/widget/ab;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ab;->a(Landroid/support/v7/internal/widget/ab;)Landroid/graphics/Rect;

    move-result-object v0

    invoke-virtual {v2, v0}, Landroid/graphics/drawable/Drawable;->getPadding(Landroid/graphics/Rect;)Z

    .line 754
    iget-object v0, p0, Landroid/support/v7/internal/widget/ae;->b:Landroid/support/v7/internal/widget/ab;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ab;->a(Landroid/support/v7/internal/widget/ab;)Landroid/graphics/Rect;

    move-result-object v0

    iget v0, v0, Landroid/graphics/Rect;->left:I

    neg-int v0, v0

    .line 756
    :cond_49
    add-int/2addr v0, v1

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/ae;->a(I)V

    .line 757
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ae;->g()V

    .line 758
    invoke-super {p0}, Landroid/support/v7/internal/widget/ListPopupWindow;->e()V

    .line 759
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ae;->k()Landroid/widget/ListView;

    move-result-object v0

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/widget/ListView;->setChoiceMode(I)V

    .line 760
    iget-object v0, p0, Landroid/support/v7/internal/widget/ae;->b:Landroid/support/v7/internal/widget/ab;

    iget v0, v0, Landroid/support/v7/internal/widget/l;->v:I

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/ae;->d(I)V

    .line 761
    return-void

    .line 743
    :cond_63
    iget-object v0, p0, Landroid/support/v7/internal/widget/ae;->b:Landroid/support/v7/internal/widget/ab;

    iget v0, v0, Landroid/support/v7/internal/widget/ab;->E:I

    const/4 v2, -0x1

    if-ne v0, v2, :cond_7c

    .line 744
    iget-object v0, p0, Landroid/support/v7/internal/widget/ae;->b:Landroid/support/v7/internal/widget/ab;

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/ab;->getWidth()I

    move-result v0

    .line 745
    iget-object v2, p0, Landroid/support/v7/internal/widget/ae;->b:Landroid/support/v7/internal/widget/ab;

    invoke-virtual {v2}, Landroid/support/v7/internal/widget/ab;->getPaddingRight()I

    move-result v2

    .line 746
    sub-int/2addr v0, v1

    sub-int/2addr v0, v2

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/ae;->c(I)V

    goto :goto_30

    .line 748
    :cond_7c
    iget-object v0, p0, Landroid/support/v7/internal/widget/ae;->b:Landroid/support/v7/internal/widget/ab;

    iget v0, v0, Landroid/support/v7/internal/widget/ab;->E:I

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/ae;->c(I)V

    goto :goto_30
.end method

###### Class android.support.v7.internal.widget.ae.AnonymousClass1 (android.support.v7.internal.widget.ae$1)
.class final Landroid/support/v7/internal/widget/ae$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/support/v7/internal/widget/n;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroid/support/v7/internal/widget/ae;-><init>(Landroid/support/v7/internal/widget/ab;Landroid/content/Context;I)V
.end annotation


# instance fields
.field final synthetic a:Landroid/support/v7/internal/widget/ab;

.field final synthetic b:Landroid/support/v7/internal/widget/ae;


# direct methods
.method constructor <init>(Landroid/support/v7/internal/widget/ae;Landroid/support/v7/internal/widget/ab;)V
    .registers 3

    .prologue
    .line 706
    iput-object p1, p0, Landroid/support/v7/internal/widget/ae$1;->b:Landroid/support/v7/internal/widget/ae;

    iput-object p2, p0, Landroid/support/v7/internal/widget/ae$1;->a:Landroid/support/v7/internal/widget/ab;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/view/View;I)V
    .registers 5

    .prologue
    .line 708
    iget-object v0, p0, Landroid/support/v7/internal/widget/ae$1;->b:Landroid/support/v7/internal/widget/ae;

    iget-object v0, v0, Landroid/support/v7/internal/widget/ae;->b:Landroid/support/v7/internal/widget/ab;

    invoke-virtual {v0, p2}, Landroid/support/v7/internal/widget/ab;->a(I)V

    .line 709
    iget-object v0, p0, Landroid/support/v7/internal/widget/ae$1;->b:Landroid/support/v7/internal/widget/ae;

    iget-object v0, v0, Landroid/support/v7/internal/widget/ae;->b:Landroid/support/v7/internal/widget/ab;

    iget-object v0, v0, Landroid/support/v7/internal/widget/ab;->t:Landroid/support/v7/internal/widget/n;

    if-eqz v0, :cond_1f

    .line 710
    iget-object v0, p0, Landroid/support/v7/internal/widget/ae$1;->b:Landroid/support/v7/internal/widget/ae;

    iget-object v0, v0, Landroid/support/v7/internal/widget/ae;->b:Landroid/support/v7/internal/widget/ab;

    iget-object v1, p0, Landroid/support/v7/internal/widget/ae$1;->b:Landroid/support/v7/internal/widget/ae;

    invoke-static {v1}, Landroid/support/v7/internal/widget/ae;->a(Landroid/support/v7/internal/widget/ae;)Landroid/widget/ListAdapter;

    move-result-object v1

    invoke-interface {v1, p2}, Landroid/widget/ListAdapter;->getItemId(I)J

    invoke-virtual {v0, p1, p2}, Landroid/support/v7/internal/widget/ab;->a(Landroid/view/View;I)Z

    .line 712
    :cond_1f
    iget-object v0, p0, Landroid/support/v7/internal/widget/ae$1;->b:Landroid/support/v7/internal/widget/ae;

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/ae;->f()V

    .line 713
    return-void
.end method
