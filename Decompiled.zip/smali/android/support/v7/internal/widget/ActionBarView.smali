###### Class android.support.v7.internal.widget.ActionBarView (android.support.v7.internal.widget.ActionBarView)
.class public Landroid/support/v7/internal/widget/ActionBarView;
.super Landroid/support/v7/internal/widget/a;
.source "SourceFile"


# instance fields
.field private A:Landroid/support/v7/internal/widget/ProgressBarICS;

.field private B:I

.field private C:I

.field private D:I

.field private E:I

.field private F:I

.field private G:I

.field private H:Z

.field private I:Z

.field private J:Z

.field private K:Z

.field private L:Landroid/support/v7/internal/view/menu/n;

.field private M:Landroid/support/v7/internal/widget/ActionBarContextView;

.field private N:Landroid/support/v7/internal/view/menu/a;

.field private O:Landroid/support/v7/app/b;

.field private P:Ljava/lang/Runnable;

.field private Q:Landroid/support/v7/internal/widget/c;

.field private final R:Landroid/support/v7/internal/widget/p;

.field private final S:Landroid/view/View$OnClickListener;

.field private final T:Landroid/view/View$OnClickListener;

.field g:Landroid/view/View;

.field h:Landroid/view/Window$Callback;

.field private i:I

.field private j:I

.field private k:Ljava/lang/CharSequence;

.field private l:Ljava/lang/CharSequence;

.field private m:Landroid/graphics/drawable/Drawable;

.field private n:Landroid/graphics/drawable/Drawable;

.field private o:Landroid/content/Context;

.field private p:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

.field private q:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

.field private r:Landroid/widget/LinearLayout;

.field private s:Landroid/widget/TextView;

.field private t:Landroid/widget/TextView;

.field private u:Landroid/view/View;

.field private v:Landroid/support/v7/internal/widget/ab;

.field private w:Landroid/widget/LinearLayout;

.field private x:Landroid/support/v7/internal/widget/ScrollingTabContainerView;

.field private y:Landroid/view/View;

.field private z:Landroid/support/v7/internal/widget/ProgressBarICS;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 12

    .prologue
    const/4 v8, 0x1

    const/4 v7, 0x0

    .line 166
    invoke-direct {p0, p1, p2}, Landroid/support/v7/internal/widget/a;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 85
    const/4 v1, -0x1

    iput v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->j:I

    .line 135
    new-instance v1, Landroid/support/v7/internal/widget/ActionBarView$1;

    invoke-direct {v1, p0}, Landroid/support/v7/internal/widget/ActionBarView$1;-><init>(Landroid/support/v7/internal/widget/ActionBarView;)V

    iput-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->R:Landroid/support/v7/internal/widget/p;

    .line 149
    new-instance v1, Landroid/support/v7/internal/widget/ActionBarView$2;

    invoke-direct {v1, p0}, Landroid/support/v7/internal/widget/ActionBarView$2;-><init>(Landroid/support/v7/internal/widget/ActionBarView;)V

    iput-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->S:Landroid/view/View$OnClickListener;

    .line 159
    new-instance v1, Landroid/support/v7/internal/widget/ActionBarView$3;

    invoke-direct {v1, p0}, Landroid/support/v7/internal/widget/ActionBarView$3;-><init>(Landroid/support/v7/internal/widget/ActionBarView;)V

    iput-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->T:Landroid/view/View$OnClickListener;

    .line 167
    iput-object p1, p0, Landroid/support/v7/internal/widget/ActionBarView;->o:Landroid/content/Context;

    .line 170
    invoke-virtual {p0, v7}, Landroid/support/v7/internal/widget/ActionBarView;->setBackgroundResource(I)V

    .line 172
    sget-object v1, Landroid/support/v7/a/k;->a:[I

    sget v2, Landroid/support/v7/a/c;->b:I

    invoke-virtual {p1, p2, v1, v2, v7}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object v2

    .line 175
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v3

    .line 176
    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v4

    .line 177
    const/4 v1, 0x2

    invoke-virtual {v2, v1, v7}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v1

    iput v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->i:I

    .line 179
    invoke-virtual {v2, v8}, Landroid/content/res/TypedArray;->getText(I)Ljava/lang/CharSequence;

    move-result-object v1

    iput-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->k:Ljava/lang/CharSequence;

    .line 180
    const/4 v1, 0x4

    invoke-virtual {v2, v1}, Landroid/content/res/TypedArray;->getText(I)Ljava/lang/CharSequence;

    move-result-object v1

    iput-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->l:Ljava/lang/CharSequence;

    .line 181
    const/16 v1, 0x8

    invoke-virtual {v2, v1}, Landroid/content/res/TypedArray;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    iput-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->n:Landroid/graphics/drawable/Drawable;

    .line 182
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->n:Landroid/graphics/drawable/Drawable;

    if-nez v1, :cond_74

    .line 183
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v5, 0x9

    if-lt v1, v5, :cond_74

    .line 184
    instance-of v1, p1, Landroid/app/Activity;

    if-eqz v1, :cond_6a

    .line 186
    :try_start_5c
    move-object v0, p1

    check-cast v0, Landroid/app/Activity;

    move-object v1, v0

    invoke-virtual {v1}, Landroid/app/Activity;->getComponentName()Landroid/content/ComponentName;

    move-result-object v1

    invoke-virtual {v4, v1}, Landroid/content/pm/PackageManager;->getActivityLogo(Landroid/content/ComponentName;)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    iput-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->n:Landroid/graphics/drawable/Drawable;
    :try_end_6a
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_5c .. :try_end_6a} :catch_143

    .line 191
    :cond_6a
    :goto_6a
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->n:Landroid/graphics/drawable/Drawable;

    if-nez v1, :cond_74

    .line 192
    invoke-virtual {v3, v4}, Landroid/content/pm/ApplicationInfo;->loadLogo(Landroid/content/pm/PackageManager;)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    iput-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->n:Landroid/graphics/drawable/Drawable;

    .line 198
    :cond_74
    const/4 v1, 0x7

    invoke-virtual {v2, v1}, Landroid/content/res/TypedArray;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    iput-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->m:Landroid/graphics/drawable/Drawable;

    .line 199
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->m:Landroid/graphics/drawable/Drawable;

    if-nez v1, :cond_9b

    .line 200
    instance-of v1, p1, Landroid/app/Activity;

    if-eqz v1, :cond_91

    .line 202
    :try_start_83
    move-object v0, p1

    check-cast v0, Landroid/app/Activity;

    move-object v1, v0

    invoke-virtual {v1}, Landroid/app/Activity;->getComponentName()Landroid/content/ComponentName;

    move-result-object v1

    invoke-virtual {v4, v1}, Landroid/content/pm/PackageManager;->getActivityIcon(Landroid/content/ComponentName;)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    iput-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->m:Landroid/graphics/drawable/Drawable;
    :try_end_91
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_83 .. :try_end_91} :catch_14d

    .line 207
    :cond_91
    :goto_91
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->m:Landroid/graphics/drawable/Drawable;

    if-nez v1, :cond_9b

    .line 208
    invoke-virtual {v3, v4}, Landroid/content/pm/ApplicationInfo;->loadIcon(Landroid/content/pm/PackageManager;)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    iput-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->m:Landroid/graphics/drawable/Drawable;

    .line 212
    :cond_9b
    invoke-static {p1}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v3

    .line 214
    const/16 v1, 0xe

    sget v4, Landroid/support/v7/a/h;->c:I

    invoke-virtual {v2, v1, v4}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v4

    .line 218
    invoke-virtual {v3, v4, p0, v7}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    iput-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->p:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    .line 220
    invoke-virtual {v3, v4, p0, v7}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v1

    check-cast v1, Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    iput-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->q:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    .line 221
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->q:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    invoke-virtual {v1, v8}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->a(Z)V

    .line 222
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->q:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    iget-object v4, p0, Landroid/support/v7/internal/widget/ActionBarView;->S:Landroid/view/View$OnClickListener;

    invoke-virtual {v1, v4}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 223
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->q:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    sget v5, Landroid/support/v7/a/i;->b:I

    invoke-virtual {v4, v5}, Landroid/content/res/Resources;->getText(I)Ljava/lang/CharSequence;

    move-result-object v4

    invoke-virtual {v1, v4}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 226
    const/4 v1, 0x5

    invoke-virtual {v2, v1, v7}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v1

    iput v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->D:I

    .line 227
    const/4 v1, 0x6

    invoke-virtual {v2, v1, v7}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v1

    iput v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->E:I

    .line 228
    const/16 v1, 0xf

    invoke-virtual {v2, v1, v7}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v1

    iput v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->F:I

    .line 229
    const/16 v1, 0x10

    invoke-virtual {v2, v1, v7}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v1

    iput v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->G:I

    .line 232
    const/16 v1, 0x11

    invoke-virtual {v2, v1, v7}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v1

    iput v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->B:I

    .line 234
    const/16 v1, 0x12

    invoke-virtual {v2, v1, v7}, Landroid/content/res/TypedArray;->getDimensionPixelOffset(II)I

    move-result v1

    iput v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->C:I

    .line 236
    const/4 v1, 0x3

    invoke-virtual {v2, v1, v7}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v1

    invoke-virtual {p0, v1}, Landroid/support/v7/internal/widget/ActionBarView;->b(I)V

    .line 238
    const/16 v1, 0xd

    invoke-virtual {v2, v1, v7}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v1

    .line 239
    if-eqz v1, :cond_11f

    .line 240
    invoke-virtual {v3, v1, p0, v7}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v1

    iput-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->y:Landroid/view/View;

    .line 241
    iput v7, p0, Landroid/support/v7/internal/widget/ActionBarView;->i:I

    .line 242
    iget v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->j:I

    or-int/lit8 v1, v1, 0x10

    invoke-virtual {p0, v1}, Landroid/support/v7/internal/widget/ActionBarView;->b(I)V

    .line 245
    :cond_11f
    invoke-virtual {v2, v7, v7}, Landroid/content/res/TypedArray;->getLayoutDimension(II)I

    move-result v1

    iput v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->f:I

    .line 246
    invoke-virtual {v2}, Landroid/content/res/TypedArray;->recycle()V

    .line 247
    new-instance v1, Landroid/support/v7/internal/view/menu/a;

    iget-object v2, p0, Landroid/support/v7/internal/widget/ActionBarView;->k:Ljava/lang/CharSequence;

    invoke-direct {v1, p1, v2}, Landroid/support/v7/internal/view/menu/a;-><init>(Landroid/content/Context;Ljava/lang/CharSequence;)V

    iput-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->N:Landroid/support/v7/internal/view/menu/a;

    .line 248
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->p:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    iget-object v2, p0, Landroid/support/v7/internal/widget/ActionBarView;->T:Landroid/view/View$OnClickListener;

    invoke-virtual {v1, v2}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 249
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->p:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    invoke-virtual {v1, v8}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->setClickable(Z)V

    .line 250
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->p:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    invoke-virtual {v1, v8}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->setFocusable(Z)V

    .line 252
    return-void

    .line 187
    :catch_143
    move-exception v1

    .line 188
    const-string v5, "ActionBarView"

    const-string v6, "Activity component name not found!"

    invoke-static {v5, v6, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    goto/16 :goto_6a

    .line 203
    :catch_14d
    move-exception v1

    .line 204
    const-string v5, "ActionBarView"

    const-string v6, "Activity component name not found!"

    invoke-static {v5, v6, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    goto/16 :goto_91
.end method

.method static synthetic a(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/app/b;
    .registers 2

    .prologue
    .line 63
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->O:Landroid/support/v7/app/b;

    return-object v0
.end method

.method private a(Landroid/support/v7/internal/view/menu/n;)V
    .registers 6

    .prologue
    const/4 v3, 0x0

    const/4 v2, 0x1

    .line 462
    if-eqz p1, :cond_19

    .line 463
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->b:Landroid/support/v7/internal/view/menu/ActionMenuPresenter;

    invoke-virtual {p1, v0}, Landroid/support/v7/internal/view/menu/n;->a(Landroid/support/v7/internal/view/menu/aa;)V

    .line 464
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->Q:Landroid/support/v7/internal/widget/c;

    invoke-virtual {p1, v0}, Landroid/support/v7/internal/view/menu/n;->a(Landroid/support/v7/internal/view/menu/aa;)V

    .line 471
    :goto_e
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->b:Landroid/support/v7/internal/view/menu/ActionMenuPresenter;

    invoke-virtual {v0, v2}, Landroid/support/v7/internal/view/menu/ActionMenuPresenter;->c(Z)V

    .line 472
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->Q:Landroid/support/v7/internal/widget/c;

    invoke-virtual {v0, v2}, Landroid/support/v7/internal/widget/c;->c(Z)V

    .line 473
    return-void

    .line 466
    :cond_19
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->b:Landroid/support/v7/internal/view/menu/ActionMenuPresenter;

    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->o:Landroid/content/Context;

    invoke-virtual {v0, v1, v3}, Landroid/support/v7/internal/view/menu/ActionMenuPresenter;->a(Landroid/content/Context;Landroid/support/v7/internal/view/menu/n;)V

    .line 467
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->Q:Landroid/support/v7/internal/widget/c;

    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->o:Landroid/content/Context;

    invoke-virtual {v0, v1, v3}, Landroid/support/v7/internal/widget/c;->a(Landroid/content/Context;Landroid/support/v7/internal/view/menu/n;)V

    goto :goto_e
.end method

.method static synthetic b(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/internal/widget/c;
    .registers 2

    .prologue
    .line 63
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->Q:Landroid/support/v7/internal/widget/c;

    return-object v0
.end method

.method static synthetic c(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/internal/view/menu/a;
    .registers 2

    .prologue
    .line 63
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->N:Landroid/support/v7/internal/view/menu/a;

    return-object v0
.end method

.method private c(Ljava/lang/CharSequence;)V
    .registers 5

    .prologue
    const/4 v1, 0x0

    .line 527
    iput-object p1, p0, Landroid/support/v7/internal/widget/ActionBarView;->k:Ljava/lang/CharSequence;

    .line 528
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->s:Landroid/widget/TextView;

    if-eqz v0, :cond_2e

    .line 529
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->s:Landroid/widget/TextView;

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 530
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->g:Landroid/view/View;

    if-nez v0, :cond_38

    iget v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->j:I

    and-int/lit8 v0, v0, 0x8

    if-eqz v0, :cond_38

    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->k:Ljava/lang/CharSequence;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_26

    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->l:Ljava/lang/CharSequence;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_38

    :cond_26
    const/4 v0, 0x1

    .line 533
    :goto_27
    iget-object v2, p0, Landroid/support/v7/internal/widget/ActionBarView;->r:Landroid/widget/LinearLayout;

    if-eqz v0, :cond_3a

    :goto_2b
    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 535
    :cond_2e
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->N:Landroid/support/v7/internal/view/menu/a;

    if-eqz v0, :cond_37

    .line 536
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->N:Landroid/support/v7/internal/view/menu/a;

    invoke-virtual {v0, p1}, Landroid/support/v7/internal/view/menu/a;->setTitle(Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    .line 538
    :cond_37
    return-void

    :cond_38
    move v0, v1

    .line 530
    goto :goto_27

    .line 533
    :cond_3a
    const/16 v1, 0x8

    goto :goto_2b
.end method

.method static synthetic d(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/graphics/drawable/Drawable;
    .registers 2

    .prologue
    .line 63
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->m:Landroid/graphics/drawable/Drawable;

    return-object v0
.end method

.method static synthetic e(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/internal/widget/ActionBarView$HomeView;
    .registers 2

    .prologue
    .line 63
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->q:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    return-object v0
.end method

.method static synthetic f(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/internal/widget/ActionBarView$HomeView;
    .registers 2

    .prologue
    .line 63
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->p:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    return-object v0
.end method

.method static synthetic g(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/widget/LinearLayout;
    .registers 2

    .prologue
    .line 63
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->r:Landroid/widget/LinearLayout;

    return-object v0
.end method

.method static synthetic h(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/internal/widget/ScrollingTabContainerView;
    .registers 2

    .prologue
    .line 63
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->x:Landroid/support/v7/internal/widget/ScrollingTabContainerView;

    return-object v0
.end method

.method static synthetic i(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/internal/widget/ab;
    .registers 2

    .prologue
    .line 63
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->v:Landroid/support/v7/internal/widget/ab;

    return-object v0
.end method

.method static synthetic j(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/view/View;
    .registers 2

    .prologue
    .line 63
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->y:Landroid/view/View;

    return-object v0
.end method

.method static synthetic k(Landroid/support/v7/internal/widget/ActionBarView;)I
    .registers 2

    .prologue
    .line 63
    iget v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->j:I

    return v0
.end method

.method static synthetic l(Landroid/support/v7/internal/widget/ActionBarView;)V
    .registers 1

    .prologue
    .line 63
    invoke-direct {p0}, Landroid/support/v7/internal/widget/ActionBarView;->q()V

    return-void
.end method

.method static synthetic m(Landroid/support/v7/internal/widget/ActionBarView;)I
    .registers 2

    .prologue
    .line 63
    iget v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->i:I

    return v0
.end method

.method private q()V
    .registers 8

    .prologue
    const/16 v5, 0x8

    const/4 v1, 0x1

    const/4 v2, 0x0

    .line 765
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->r:Landroid/widget/LinearLayout;

    if-nez v0, :cond_99

    .line 766
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v0

    .line 767
    sget v3, Landroid/support/v7/a/h;->e:I

    invoke-virtual {v0, v3, p0, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/LinearLayout;

    iput-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->r:Landroid/widget/LinearLayout;

    .line 769
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->r:Landroid/widget/LinearLayout;

    sget v3, Landroid/support/v7/a/f;->g:I

    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->s:Landroid/widget/TextView;

    .line 770
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->r:Landroid/widget/LinearLayout;

    sget v3, Landroid/support/v7/a/f;->f:I

    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/TextView;

    iput-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->t:Landroid/widget/TextView;

    .line 771
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->r:Landroid/widget/LinearLayout;

    sget v3, Landroid/support/v7/a/f;->G:I

    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->findViewById(I)Landroid/view/View;

    move-result-object v0

    iput-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->u:Landroid/view/View;

    .line 773
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->r:Landroid/widget/LinearLayout;

    iget-object v3, p0, Landroid/support/v7/internal/widget/ActionBarView;->T:Landroid/view/View$OnClickListener;

    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    .line 775
    iget v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->D:I

    if-eqz v0, :cond_50

    .line 776
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->s:Landroid/widget/TextView;

    iget-object v3, p0, Landroid/support/v7/internal/widget/ActionBarView;->o:Landroid/content/Context;

    iget v4, p0, Landroid/support/v7/internal/widget/ActionBarView;->D:I

    invoke-virtual {v0, v3, v4}, Landroid/widget/TextView;->setTextAppearance(Landroid/content/Context;I)V

    .line 778
    :cond_50
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->k:Ljava/lang/CharSequence;

    if-eqz v0, :cond_5b

    .line 779
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->s:Landroid/widget/TextView;

    iget-object v3, p0, Landroid/support/v7/internal/widget/ActionBarView;->k:Ljava/lang/CharSequence;

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 782
    :cond_5b
    iget v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->E:I

    if-eqz v0, :cond_68

    .line 783
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->t:Landroid/widget/TextView;

    iget-object v3, p0, Landroid/support/v7/internal/widget/ActionBarView;->o:Landroid/content/Context;

    iget v4, p0, Landroid/support/v7/internal/widget/ActionBarView;->E:I

    invoke-virtual {v0, v3, v4}, Landroid/widget/TextView;->setTextAppearance(Landroid/content/Context;I)V

    .line 785
    :cond_68
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->l:Ljava/lang/CharSequence;

    if-eqz v0, :cond_78

    .line 786
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->t:Landroid/widget/TextView;

    iget-object v3, p0, Landroid/support/v7/internal/widget/ActionBarView;->l:Ljava/lang/CharSequence;

    invoke-virtual {v0, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 787
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->t:Landroid/widget/TextView;

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setVisibility(I)V

    .line 790
    :cond_78
    iget v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->j:I

    and-int/lit8 v0, v0, 0x4

    if-eqz v0, :cond_b8

    move v0, v1

    .line 791
    :goto_7f
    iget v3, p0, Landroid/support/v7/internal/widget/ActionBarView;->j:I

    and-int/lit8 v3, v3, 0x2

    if-eqz v3, :cond_ba

    move v3, v1

    .line 792
    :goto_86
    iget-object v6, p0, Landroid/support/v7/internal/widget/ActionBarView;->u:Landroid/view/View;

    if-nez v3, :cond_be

    if-eqz v0, :cond_bc

    move v4, v2

    :goto_8d
    invoke-virtual {v6, v4}, Landroid/view/View;->setVisibility(I)V

    .line 793
    iget-object v4, p0, Landroid/support/v7/internal/widget/ActionBarView;->r:Landroid/widget/LinearLayout;

    if-eqz v0, :cond_c0

    if-nez v3, :cond_c0

    :goto_96
    invoke-virtual {v4, v1}, Landroid/widget/LinearLayout;->setEnabled(Z)V

    .line 796
    :cond_99
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->r:Landroid/widget/LinearLayout;

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/ActionBarView;->addView(Landroid/view/View;)V

    .line 797
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->g:Landroid/view/View;

    if-nez v0, :cond_b2

    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->k:Ljava/lang/CharSequence;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_b7

    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->l:Ljava/lang/CharSequence;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_b7

    .line 800
    :cond_b2
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->r:Landroid/widget/LinearLayout;

    invoke-virtual {v0, v5}, Landroid/widget/LinearLayout;->setVisibility(I)V

    .line 802
    :cond_b7
    return-void

    :cond_b8
    move v0, v2

    .line 790
    goto :goto_7f

    :cond_ba
    move v3, v2

    .line 791
    goto :goto_86

    .line 792
    :cond_bc
    const/4 v4, 0x4

    goto :goto_8d

    :cond_be
    move v4, v5

    goto :goto_8d

    :cond_c0
    move v1, v2

    .line 793
    goto :goto_96
.end method


# virtual methods
.method public final bridge synthetic a()I
    .registers 2

    .prologue
    .line 63
    invoke-super {p0}, Landroid/support/v7/internal/widget/a;->a()I

    move-result v0

    return v0
.end method

.method public final bridge synthetic a(I)V
    .registers 2

    .prologue
    .line 63
    invoke-super {p0, p1}, Landroid/support/v7/internal/widget/a;->a(I)V

    return-void
.end method

.method public final a(Landroid/graphics/drawable/Drawable;)V
    .registers 5

    .prologue
    .line 640
    iput-object p1, p0, Landroid/support/v7/internal/widget/ActionBarView;->m:Landroid/graphics/drawable/Drawable;

    .line 641
    if-eqz p1, :cond_13

    iget v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->j:I

    and-int/lit8 v0, v0, 0x1

    if-eqz v0, :cond_e

    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->n:Landroid/graphics/drawable/Drawable;

    if-nez v0, :cond_13

    .line 643
    :cond_e
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->p:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    invoke-virtual {v0, p1}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->a(Landroid/graphics/drawable/Drawable;)V

    .line 645
    :cond_13
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->g:Landroid/view/View;

    if-eqz v0, :cond_2a

    .line 646
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->q:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->m:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v1}, Landroid/graphics/drawable/Drawable;->getConstantState()Landroid/graphics/drawable/Drawable$ConstantState;

    move-result-object v1

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/graphics/drawable/Drawable$ConstantState;->newDrawable(Landroid/content/res/Resources;)Landroid/graphics/drawable/Drawable;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->a(Landroid/graphics/drawable/Drawable;)V

    .line 648
    :cond_2a
    return-void
.end method

.method public final a(Landroid/support/v4/a/a/a;Landroid/support/v7/internal/view/menu/ab;)V
    .registers 8

    .prologue
    const/4 v4, 0x0

    const/4 v3, -0x1

    .line 396
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->L:Landroid/support/v7/internal/view/menu/n;

    if-ne p1, v0, :cond_7

    .line 459
    :goto_6
    return-void

    .line 400
    :cond_7
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->L:Landroid/support/v7/internal/view/menu/n;

    if-eqz v0, :cond_19

    .line 401
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->L:Landroid/support/v7/internal/view/menu/n;

    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->b:Landroid/support/v7/internal/view/menu/ActionMenuPresenter;

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/view/menu/n;->b(Landroid/support/v7/internal/view/menu/aa;)V

    .line 402
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->L:Landroid/support/v7/internal/view/menu/n;

    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->Q:Landroid/support/v7/internal/widget/c;

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/view/menu/n;->b(Landroid/support/v7/internal/view/menu/aa;)V

    .line 405
    :cond_19
    check-cast p1, Landroid/support/v7/internal/view/menu/n;

    .line 406
    iput-object p1, p0, Landroid/support/v7/internal/widget/ActionBarView;->L:Landroid/support/v7/internal/view/menu/n;

    .line 407
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->a:Landroid/support/v7/internal/view/menu/ActionMenuView;

    if-eqz v0, :cond_30

    .line 408
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->a:Landroid/support/v7/internal/view/menu/ActionMenuView;

    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/ActionMenuView;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    .line 409
    if-eqz v0, :cond_30

    .line 410
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->a:Landroid/support/v7/internal/view/menu/ActionMenuView;

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 413
    :cond_30
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->b:Landroid/support/v7/internal/view/menu/ActionMenuPresenter;

    if-nez v0, :cond_50

    .line 414
    new-instance v0, Landroid/support/v7/internal/view/menu/ActionMenuPresenter;

    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->o:Landroid/content/Context;

    invoke-direct {v0, v1}, Landroid/support/v7/internal/view/menu/ActionMenuPresenter;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->b:Landroid/support/v7/internal/view/menu/ActionMenuPresenter;

    .line 415
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->b:Landroid/support/v7/internal/view/menu/ActionMenuPresenter;

    invoke-virtual {v0, p2}, Landroid/support/v7/internal/view/menu/ActionMenuPresenter;->a(Landroid/support/v7/internal/view/menu/ab;)V

    .line 416
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->b:Landroid/support/v7/internal/view/menu/ActionMenuPresenter;

    sget v1, Landroid/support/v7/a/f;->i:I

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/view/menu/ActionMenuPresenter;->b(I)V

    .line 417
    new-instance v0, Landroid/support/v7/internal/widget/c;

    invoke-direct {v0, p0, v4}, Landroid/support/v7/internal/widget/c;-><init>(Landroid/support/v7/internal/widget/ActionBarView;B)V

    iput-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->Q:Landroid/support/v7/internal/widget/c;

    .line 421
    :cond_50
    new-instance v2, Landroid/view/ViewGroup$LayoutParams;

    const/4 v0, -0x2

    invoke-direct {v2, v0, v3}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    .line 423
    iget-boolean v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->d:Z

    if-nez v0, :cond_8b

    .line 424
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->b:Landroid/support/v7/internal/view/menu/ActionMenuPresenter;

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    sget v3, Landroid/support/v7/a/d;->b:I

    invoke-virtual {v1, v3}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result v1

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/view/menu/ActionMenuPresenter;->b(Z)V

    .line 427
    invoke-direct {p0, p1}, Landroid/support/v7/internal/widget/ActionBarView;->a(Landroid/support/v7/internal/view/menu/n;)V

    .line 428
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->b:Landroid/support/v7/internal/view/menu/ActionMenuPresenter;

    invoke-virtual {v0, p0}, Landroid/support/v7/internal/view/menu/ActionMenuPresenter;->a(Landroid/view/ViewGroup;)Landroid/support/v7/internal/view/menu/ac;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/view/menu/ActionMenuView;

    .line 429
    invoke-virtual {v0, p1}, Landroid/support/v7/internal/view/menu/ActionMenuView;->a(Landroid/support/v7/internal/view/menu/n;)V

    .line 430
    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/ActionMenuView;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    check-cast v1, Landroid/view/ViewGroup;

    .line 431
    if-eqz v1, :cond_84

    if-eq v1, p0, :cond_84

    .line 432
    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 434
    :cond_84
    invoke-virtual {p0, v0, v2}, Landroid/support/v7/internal/widget/ActionBarView;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 458
    :goto_87
    iput-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->a:Landroid/support/v7/internal/view/menu/ActionMenuView;

    goto/16 :goto_6

    .line 436
    :cond_8b
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->b:Landroid/support/v7/internal/view/menu/ActionMenuPresenter;

    invoke-virtual {v0, v4}, Landroid/support/v7/internal/view/menu/ActionMenuPresenter;->b(Z)V

    .line 438
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->b:Landroid/support/v7/internal/view/menu/ActionMenuPresenter;

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->widthPixels:I

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/view/menu/ActionMenuPresenter;->a(I)V

    .line 441
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->b:Landroid/support/v7/internal/view/menu/ActionMenuPresenter;

    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/ActionMenuPresenter;->b()V

    .line 443
    iput v3, v2, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 444
    invoke-direct {p0, p1}, Landroid/support/v7/internal/widget/ActionBarView;->a(Landroid/support/v7/internal/view/menu/n;)V

    .line 445
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->b:Landroid/support/v7/internal/view/menu/ActionMenuPresenter;

    invoke-virtual {v0, p0}, Landroid/support/v7/internal/view/menu/ActionMenuPresenter;->a(Landroid/view/ViewGroup;)Landroid/support/v7/internal/view/menu/ac;

    move-result-object v0

    check-cast v0, Landroid/support/v7/internal/view/menu/ActionMenuView;

    .line 446
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->c:Landroid/support/v7/internal/widget/ActionBarContainer;

    if-eqz v1, :cond_d5

    .line 447
    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/ActionMenuView;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    check-cast v1, Landroid/view/ViewGroup;

    .line 448
    if-eqz v1, :cond_c8

    iget-object v3, p0, Landroid/support/v7/internal/widget/ActionBarView;->c:Landroid/support/v7/internal/widget/ActionBarContainer;

    if-eq v1, v3, :cond_c8

    .line 449
    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 451
    :cond_c8
    invoke-super {p0}, Landroid/support/v7/internal/widget/a;->a()I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/view/menu/ActionMenuView;->setVisibility(I)V

    .line 452
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->c:Landroid/support/v7/internal/widget/ActionBarContainer;

    invoke-virtual {v1, v0, v2}, Landroid/support/v7/internal/widget/ActionBarContainer;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_87

    .line 455
    :cond_d5
    invoke-virtual {v0, v2}, Landroid/support/v7/internal/view/menu/ActionMenuView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    goto :goto_87
.end method

.method public final bridge synthetic a(Landroid/support/v7/internal/widget/ActionBarContainer;)V
    .registers 2

    .prologue
    .line 63
    invoke-super {p0, p1}, Landroid/support/v7/internal/widget/a;->a(Landroid/support/v7/internal/widget/ActionBarContainer;)V

    return-void
.end method

.method public final a(Landroid/support/v7/internal/widget/ActionBarContextView;)V
    .registers 2

    .prologue
    .line 805
    iput-object p1, p0, Landroid/support/v7/internal/widget/ActionBarView;->M:Landroid/support/v7/internal/widget/ActionBarContextView;

    .line 806
    return-void
.end method

.method public final a(Landroid/support/v7/internal/widget/ScrollingTabContainerView;)V
    .registers 5

    .prologue
    const/4 v1, 0x1

    .line 377
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->x:Landroid/support/v7/internal/widget/ScrollingTabContainerView;

    if-eqz v0, :cond_a

    .line 378
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->x:Landroid/support/v7/internal/widget/ScrollingTabContainerView;

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/ActionBarView;->removeView(Landroid/view/View;)V

    .line 380
    :cond_a
    iput-object p1, p0, Landroid/support/v7/internal/widget/ActionBarView;->x:Landroid/support/v7/internal/widget/ScrollingTabContainerView;

    .line 381
    if-eqz p1, :cond_2f

    move v0, v1

    :goto_f
    iput-boolean v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->I:Z

    .line 382
    iget-boolean v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->I:Z

    if-eqz v0, :cond_2e

    iget v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->i:I

    const/4 v2, 0x2

    if-ne v0, v2, :cond_2e

    .line 383
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->x:Landroid/support/v7/internal/widget/ScrollingTabContainerView;

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/ActionBarView;->addView(Landroid/view/View;)V

    .line 384
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->x:Landroid/support/v7/internal/widget/ScrollingTabContainerView;

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/ScrollingTabContainerView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    .line 385
    const/4 v2, -0x2

    iput v2, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 386
    const/4 v2, -0x1

    iput v2, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 387
    invoke-virtual {p1, v1}, Landroid/support/v7/internal/widget/ScrollingTabContainerView;->a(Z)V

    .line 389
    :cond_2e
    return-void

    .line 381
    :cond_2f
    const/4 v0, 0x0

    goto :goto_f
.end method

.method public final a(Landroid/view/View;)V
    .registers 4

    .prologue
    .line 489
    iget v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->j:I

    and-int/lit8 v0, v0, 0x10

    if-eqz v0, :cond_20

    const/4 v0, 0x1

    .line 490
    :goto_7
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->y:Landroid/view/View;

    if-eqz v1, :cond_12

    if-eqz v0, :cond_12

    .line 491
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->y:Landroid/view/View;

    invoke-virtual {p0, v1}, Landroid/support/v7/internal/widget/ActionBarView;->removeView(Landroid/view/View;)V

    .line 493
    :cond_12
    iput-object p1, p0, Landroid/support/v7/internal/widget/ActionBarView;->y:Landroid/view/View;

    .line 494
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->y:Landroid/view/View;

    if-eqz v1, :cond_1f

    if-eqz v0, :cond_1f

    .line 495
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->y:Landroid/view/View;

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/ActionBarView;->addView(Landroid/view/View;)V

    .line 497
    :cond_1f
    return-void

    .line 489
    :cond_20
    const/4 v0, 0x0

    goto :goto_7
.end method

.method public final a(Landroid/view/Window$Callback;)V
    .registers 2

    .prologue
    .line 294
    iput-object p1, p0, Landroid/support/v7/internal/widget/ActionBarView;->h:Landroid/view/Window$Callback;

    .line 295
    return-void
.end method

.method public final a(Ljava/lang/CharSequence;)V
    .registers 3

    .prologue
    .line 510
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->H:Z

    .line 511
    invoke-direct {p0, p1}, Landroid/support/v7/internal/widget/ActionBarView;->c(Ljava/lang/CharSequence;)V

    .line 512
    return-void
.end method

.method public final a(Z)V
    .registers 5

    .prologue
    const/4 v1, 0x0

    .line 329
    iget-boolean v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->d:Z

    if-eq v0, p1, :cond_57

    .line 330
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->a:Landroid/support/v7/internal/view/menu/ActionMenuView;

    if-eqz v0, :cond_33

    .line 331
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->a:Landroid/support/v7/internal/view/menu/ActionMenuView;

    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/ActionMenuView;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    check-cast v0, Landroid/view/ViewGroup;

    .line 332
    if-eqz v0, :cond_18

    .line 333
    iget-object v2, p0, Landroid/support/v7/internal/widget/ActionBarView;->a:Landroid/support/v7/internal/view/menu/ActionMenuView;

    invoke-virtual {v0, v2}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 335
    :cond_18
    if-eqz p1, :cond_58

    .line 336
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->c:Landroid/support/v7/internal/widget/ActionBarContainer;

    if-eqz v0, :cond_25

    .line 337
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->c:Landroid/support/v7/internal/widget/ActionBarContainer;

    iget-object v2, p0, Landroid/support/v7/internal/widget/ActionBarView;->a:Landroid/support/v7/internal/view/menu/ActionMenuView;

    invoke-virtual {v0, v2}, Landroid/support/v7/internal/widget/ActionBarContainer;->addView(Landroid/view/View;)V

    .line 339
    :cond_25
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->a:Landroid/support/v7/internal/view/menu/ActionMenuView;

    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/ActionMenuView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v2, -0x1

    iput v2, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 344
    :goto_2e
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->a:Landroid/support/v7/internal/view/menu/ActionMenuView;

    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/ActionMenuView;->requestLayout()V

    .line 346
    :cond_33
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->c:Landroid/support/v7/internal/widget/ActionBarContainer;

    if-eqz v0, :cond_3f

    .line 347
    iget-object v2, p0, Landroid/support/v7/internal/widget/ActionBarView;->c:Landroid/support/v7/internal/widget/ActionBarContainer;

    if-eqz p1, :cond_67

    move v0, v1

    :goto_3c
    invoke-virtual {v2, v0}, Landroid/support/v7/internal/widget/ActionBarContainer;->setVisibility(I)V

    .line 350
    :cond_3f
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->b:Landroid/support/v7/internal/view/menu/ActionMenuPresenter;

    if-eqz v0, :cond_54

    .line 351
    if-nez p1, :cond_6a

    .line 352
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->b:Landroid/support/v7/internal/view/menu/ActionMenuPresenter;

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    sget v2, Landroid/support/v7/a/d;->b:I

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getBoolean(I)Z

    move-result v1

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/view/menu/ActionMenuPresenter;->b(Z)V

    .line 364
    :cond_54
    :goto_54
    invoke-super {p0, p1}, Landroid/support/v7/internal/widget/a;->a(Z)V

    .line 366
    :cond_57
    return-void

    .line 341
    :cond_58
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->a:Landroid/support/v7/internal/view/menu/ActionMenuView;

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/ActionBarView;->addView(Landroid/view/View;)V

    .line 342
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->a:Landroid/support/v7/internal/view/menu/ActionMenuView;

    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/ActionMenuView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    const/4 v2, -0x2

    iput v2, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    goto :goto_2e

    .line 347
    :cond_67
    const/16 v0, 0x8

    goto :goto_3c

    .line 356
    :cond_6a
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->b:Landroid/support/v7/internal/view/menu/ActionMenuPresenter;

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/view/menu/ActionMenuPresenter;->b(Z)V

    .line 358
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->b:Landroid/support/v7/internal/view/menu/ActionMenuPresenter;

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->widthPixels:I

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/view/menu/ActionMenuPresenter;->a(I)V

    .line 361
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->b:Landroid/support/v7/internal/view/menu/ActionMenuPresenter;

    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/ActionMenuPresenter;->b()V

    goto :goto_54
.end method

.method public final b(I)V
    .registers 9

    .prologue
    const/16 v3, 0x8

    const/4 v0, -0x1

    const/4 v4, 0x1

    const/4 v2, 0x0

    .line 572
    iget v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->j:I

    if-ne v1, v0, :cond_99

    .line 573
    :goto_9
    iput p1, p0, Landroid/support/v7/internal/widget/ActionBarView;->j:I

    .line 575
    and-int/lit8 v1, v0, 0x1f

    if-eqz v1, :cond_bd

    .line 576
    and-int/lit8 v1, p1, 0x2

    if-eqz v1, :cond_9e

    move v5, v4

    .line 577
    :goto_14
    if-eqz v5, :cond_a1

    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->g:Landroid/view/View;

    if-nez v1, :cond_a1

    move v1, v2

    .line 578
    :goto_1b
    iget-object v6, p0, Landroid/support/v7/internal/widget/ActionBarView;->p:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    invoke-virtual {v6, v1}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->setVisibility(I)V

    .line 580
    and-int/lit8 v1, v0, 0x4

    if-eqz v1, :cond_33

    .line 581
    and-int/lit8 v1, p1, 0x4

    if-eqz v1, :cond_a4

    move v1, v4

    .line 582
    :goto_29
    iget-object v6, p0, Landroid/support/v7/internal/widget/ActionBarView;->p:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    invoke-virtual {v6, v1}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->a(Z)V

    .line 588
    if-eqz v1, :cond_33

    .line 589
    invoke-virtual {p0, v4}, Landroid/support/v7/internal/widget/ActionBarView;->c(Z)V

    .line 593
    :cond_33
    and-int/lit8 v1, v0, 0x1

    if-eqz v1, :cond_49

    .line 594
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->n:Landroid/graphics/drawable/Drawable;

    if-eqz v1, :cond_a6

    and-int/lit8 v1, p1, 0x1

    if-eqz v1, :cond_a6

    move v1, v4

    .line 596
    :goto_40
    iget-object v6, p0, Landroid/support/v7/internal/widget/ActionBarView;->p:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    if-eqz v1, :cond_a8

    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->n:Landroid/graphics/drawable/Drawable;

    :goto_46
    invoke-virtual {v6, v1}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->a(Landroid/graphics/drawable/Drawable;)V

    .line 599
    :cond_49
    and-int/lit8 v1, v0, 0x8

    if-eqz v1, :cond_54

    .line 600
    and-int/lit8 v1, p1, 0x8

    if-eqz v1, :cond_ab

    .line 601
    invoke-direct {p0}, Landroid/support/v7/internal/widget/ActionBarView;->q()V

    .line 607
    :cond_54
    :goto_54
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->r:Landroid/widget/LinearLayout;

    if-eqz v1, :cond_76

    and-int/lit8 v1, v0, 0x6

    if-eqz v1, :cond_76

    .line 609
    iget v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->j:I

    and-int/lit8 v1, v1, 0x4

    if-eqz v1, :cond_b1

    move v1, v4

    .line 610
    :goto_63
    iget-object v6, p0, Landroid/support/v7/internal/widget/ActionBarView;->u:Landroid/view/View;

    if-nez v5, :cond_6a

    if-eqz v1, :cond_b3

    move v3, v2

    :cond_6a
    :goto_6a
    invoke-virtual {v6, v3}, Landroid/view/View;->setVisibility(I)V

    .line 611
    iget-object v3, p0, Landroid/support/v7/internal/widget/ActionBarView;->r:Landroid/widget/LinearLayout;

    if-nez v5, :cond_b5

    if-eqz v1, :cond_b5

    :goto_73
    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setEnabled(Z)V

    .line 614
    :cond_76
    and-int/lit8 v0, v0, 0x10

    if-eqz v0, :cond_87

    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->y:Landroid/view/View;

    if-eqz v0, :cond_87

    .line 615
    and-int/lit8 v0, p1, 0x10

    if-eqz v0, :cond_b7

    .line 616
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->y:Landroid/view/View;

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/ActionBarView;->addView(Landroid/view/View;)V

    .line 622
    :cond_87
    :goto_87
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->requestLayout()V

    .line 628
    :goto_8a
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->p:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->isEnabled()Z

    move-result v0

    if-nez v0, :cond_c1

    .line 629
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->p:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 637
    :goto_98
    return-void

    .line 572
    :cond_99
    iget v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->j:I

    xor-int/2addr v0, p1

    goto/16 :goto_9

    :cond_9e
    move v5, v2

    .line 576
    goto/16 :goto_14

    :cond_a1
    move v1, v3

    .line 577
    goto/16 :goto_1b

    :cond_a4
    move v1, v2

    .line 581
    goto :goto_29

    :cond_a6
    move v1, v2

    .line 594
    goto :goto_40

    .line 596
    :cond_a8
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->m:Landroid/graphics/drawable/Drawable;

    goto :goto_46

    .line 603
    :cond_ab
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->r:Landroid/widget/LinearLayout;

    invoke-virtual {p0, v1}, Landroid/support/v7/internal/widget/ActionBarView;->removeView(Landroid/view/View;)V

    goto :goto_54

    :cond_b1
    move v1, v2

    .line 609
    goto :goto_63

    .line 610
    :cond_b3
    const/4 v3, 0x4

    goto :goto_6a

    :cond_b5
    move v4, v2

    .line 611
    goto :goto_73

    .line 618
    :cond_b7
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->y:Landroid/view/View;

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/ActionBarView;->removeView(Landroid/view/View;)V

    goto :goto_87

    .line 624
    :cond_bd
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->invalidate()V

    goto :goto_8a

    .line 630
    :cond_c1
    and-int/lit8 v0, p1, 0x4

    if-eqz v0, :cond_d7

    .line 631
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->p:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->o:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    sget v2, Landroid/support/v7/a/i;->b:I

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getText(I)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->setContentDescription(Ljava/lang/CharSequence;)V

    goto :goto_98

    .line 634
    :cond_d7
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->p:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->o:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    sget v2, Landroid/support/v7/a/i;->a:I

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getText(I)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->setContentDescription(Ljava/lang/CharSequence;)V

    goto :goto_98
.end method

.method public final b(Ljava/lang/CharSequence;)V
    .registers 3

    .prologue
    .line 521
    iget-boolean v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->H:Z

    if-nez v0, :cond_7

    .line 522
    invoke-direct {p0, p1}, Landroid/support/v7/internal/widget/ActionBarView;->c(Ljava/lang/CharSequence;)V

    .line 524
    :cond_7
    return-void
.end method

.method public final bridge synthetic b(Z)V
    .registers 2

    .prologue
    .line 63
    invoke-super {p0, p1}, Landroid/support/v7/internal/widget/a;->b(Z)V

    return-void
.end method

.method public final bridge synthetic b()Z
    .registers 2

    .prologue
    .line 63
    invoke-super {p0}, Landroid/support/v7/internal/widget/a;->b()Z

    move-result v0

    return v0
.end method

.method public final bridge synthetic c()V
    .registers 1

    .prologue
    .line 63
    invoke-super {p0}, Landroid/support/v7/internal/widget/a;->c()V

    return-void
.end method

.method public final c(Z)V
    .registers 5

    .prologue
    .line 557
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->p:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    invoke-virtual {v0, p1}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->setEnabled(Z)V

    .line 558
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->p:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    invoke-virtual {v0, p1}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->setFocusable(Z)V

    .line 560
    if-nez p1, :cond_13

    .line 561
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->p:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->setContentDescription(Ljava/lang/CharSequence;)V

    .line 569
    :goto_12
    return-void

    .line 562
    :cond_13
    iget v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->j:I

    and-int/lit8 v0, v0, 0x4

    if-eqz v0, :cond_2b

    .line 563
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->p:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->o:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    sget v2, Landroid/support/v7/a/i;->b:I

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getText(I)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->setContentDescription(Ljava/lang/CharSequence;)V

    goto :goto_12

    .line 566
    :cond_2b
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->p:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->o:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    sget v2, Landroid/support/v7/a/i;->a:I

    invoke-virtual {v1, v2}, Landroid/content/res/Resources;->getText(I)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->setContentDescription(Ljava/lang/CharSequence;)V

    goto :goto_12
.end method

.method public final d(Z)V
    .registers 2

    .prologue
    .line 809
    iput-boolean p1, p0, Landroid/support/v7/internal/widget/ActionBarView;->J:Z

    .line 810
    return-void
.end method

.method public final bridge synthetic d()Z
    .registers 2

    .prologue
    .line 63
    invoke-super {p0}, Landroid/support/v7/internal/widget/a;->d()Z

    move-result v0

    return v0
.end method

.method public final bridge synthetic e()Z
    .registers 2

    .prologue
    .line 63
    invoke-super {p0}, Landroid/support/v7/internal/widget/a;->e()Z

    move-result v0

    return v0
.end method

.method public final bridge synthetic f()Z
    .registers 2

    .prologue
    .line 63
    invoke-super {p0}, Landroid/support/v7/internal/widget/a;->f()Z

    move-result v0

    return v0
.end method

.method public final bridge synthetic g()V
    .registers 1

    .prologue
    .line 63
    invoke-super {p0}, Landroid/support/v7/internal/widget/a;->g()V

    return-void
.end method

.method protected generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    .registers 3

    .prologue
    .line 744
    new-instance v0, Landroid/support/v7/app/ActionBar$LayoutParams;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Landroid/support/v7/app/ActionBar$LayoutParams;-><init>(B)V

    return-object v0
.end method

.method public generateLayoutParams(Landroid/util/AttributeSet;)Landroid/view/ViewGroup$LayoutParams;
    .registers 4

    .prologue
    .line 1159
    new-instance v0, Landroid/support/v7/app/ActionBar$LayoutParams;

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1, p1}, Landroid/support/v7/app/ActionBar$LayoutParams;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-object v0
.end method

.method public generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
    .registers 2

    .prologue
    .line 1164
    if-nez p1, :cond_6

    .line 1165
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p1

    .line 1167
    :cond_6
    return-object p1
.end method

.method public final h()V
    .registers 4

    .prologue
    .line 312
    new-instance v0, Landroid/support/v7/internal/widget/ProgressBarICS;

    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->o:Landroid/content/Context;

    iget v2, p0, Landroid/support/v7/internal/widget/ActionBarView;->F:I

    invoke-direct {v0, v1, v2}, Landroid/support/v7/internal/widget/ProgressBarICS;-><init>(Landroid/content/Context;I)V

    iput-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->z:Landroid/support/v7/internal/widget/ProgressBarICS;

    .line 313
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->z:Landroid/support/v7/internal/widget/ProgressBarICS;

    sget v1, Landroid/support/v7/a/f;->s:I

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/widget/ProgressBarICS;->setId(I)V

    .line 314
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->z:Landroid/support/v7/internal/widget/ProgressBarICS;

    const/16 v1, 0x2710

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/widget/ProgressBarICS;->a(I)V

    .line 315
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->z:Landroid/support/v7/internal/widget/ProgressBarICS;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/widget/ProgressBarICS;->setVisibility(I)V

    .line 316
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->z:Landroid/support/v7/internal/widget/ProgressBarICS;

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/ActionBarView;->addView(Landroid/view/View;)V

    .line 317
    return-void
.end method

.method public final i()V
    .registers 4

    .prologue
    .line 320
    new-instance v0, Landroid/support/v7/internal/widget/ProgressBarICS;

    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->o:Landroid/content/Context;

    iget v2, p0, Landroid/support/v7/internal/widget/ActionBarView;->G:I

    invoke-direct {v0, v1, v2}, Landroid/support/v7/internal/widget/ProgressBarICS;-><init>(Landroid/content/Context;I)V

    iput-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->A:Landroid/support/v7/internal/widget/ProgressBarICS;

    .line 322
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->A:Landroid/support/v7/internal/widget/ProgressBarICS;

    sget v1, Landroid/support/v7/a/f;->r:I

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/widget/ProgressBarICS;->setId(I)V

    .line 323
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->A:Landroid/support/v7/internal/widget/ProgressBarICS;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/widget/ProgressBarICS;->setVisibility(I)V

    .line 324
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->A:Landroid/support/v7/internal/widget/ProgressBarICS;

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/ActionBarView;->addView(Landroid/view/View;)V

    .line 325
    return-void
.end method

.method public final j()Z
    .registers 2

    .prologue
    .line 369
    iget-boolean v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->d:Z

    return v0
.end method

.method public final k()Z
    .registers 2

    .prologue
    .line 476
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->Q:Landroid/support/v7/internal/widget/c;

    if-eqz v0, :cond_c

    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->Q:Landroid/support/v7/internal/widget/c;

    iget-object v0, v0, Landroid/support/v7/internal/widget/c;->b:Landroid/support/v7/internal/view/menu/r;

    if-eqz v0, :cond_c

    const/4 v0, 0x1

    :goto_b
    return v0

    :cond_c
    const/4 v0, 0x0

    goto :goto_b
.end method

.method public final l()V
    .registers 2

    .prologue
    .line 481
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->Q:Landroid/support/v7/internal/widget/c;

    if-nez v0, :cond_b

    const/4 v0, 0x0

    .line 483
    :goto_5
    if-eqz v0, :cond_a

    .line 484
    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->collapseActionView()Z

    .line 486
    :cond_a
    return-void

    .line 481
    :cond_b
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->Q:Landroid/support/v7/internal/widget/c;

    iget-object v0, v0, Landroid/support/v7/internal/widget/c;->b:Landroid/support/v7/internal/view/menu/r;

    goto :goto_5
.end method

.method public final m()Landroid/view/View;
    .registers 2

    .prologue
    .line 729
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->y:Landroid/view/View;

    return-object v0
.end method

.method public final n()I
    .registers 2

    .prologue
    .line 733
    iget v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->i:I

    return v0
.end method

.method public final o()I
    .registers 2

    .prologue
    .line 737
    iget v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->j:I

    return v0
.end method

.method protected onConfigurationChanged(Landroid/content/res/Configuration;)V
    .registers 4

    .prologue
    const/4 v1, 0x0

    .line 256
    invoke-super {p0, p1}, Landroid/support/v7/internal/widget/a;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    .line 258
    iput-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->s:Landroid/widget/TextView;

    .line 259
    iput-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->t:Landroid/widget/TextView;

    .line 260
    iput-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->u:Landroid/view/View;

    .line 261
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->r:Landroid/widget/LinearLayout;

    if-eqz v0, :cond_1b

    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->r:Landroid/widget/LinearLayout;

    invoke-virtual {v0}, Landroid/widget/LinearLayout;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    if-ne v0, p0, :cond_1b

    .line 262
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->r:Landroid/widget/LinearLayout;

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/ActionBarView;->removeView(Landroid/view/View;)V

    .line 264
    :cond_1b
    iput-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->r:Landroid/widget/LinearLayout;

    .line 265
    iget v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->j:I

    and-int/lit8 v0, v0, 0x8

    if-eqz v0, :cond_26

    .line 266
    invoke-direct {p0}, Landroid/support/v7/internal/widget/ActionBarView;->q()V

    .line 269
    :cond_26
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->x:Landroid/support/v7/internal/widget/ScrollingTabContainerView;

    if-eqz v0, :cond_42

    iget-boolean v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->I:Z

    if-eqz v0, :cond_42

    .line 270
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->x:Landroid/support/v7/internal/widget/ScrollingTabContainerView;

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/ScrollingTabContainerView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    .line 271
    if-eqz v0, :cond_3c

    .line 272
    const/4 v1, -0x2

    iput v1, v0, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 273
    const/4 v1, -0x1

    iput v1, v0, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 275
    :cond_3c
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->x:Landroid/support/v7/internal/widget/ScrollingTabContainerView;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/widget/ScrollingTabContainerView;->a(Z)V

    .line 278
    :cond_42
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->z:Landroid/support/v7/internal/widget/ProgressBarICS;

    if-eqz v0, :cond_4e

    .line 279
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->z:Landroid/support/v7/internal/widget/ProgressBarICS;

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/ActionBarView;->removeView(Landroid/view/View;)V

    .line 280
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->h()V

    .line 282
    :cond_4e
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->A:Landroid/support/v7/internal/widget/ProgressBarICS;

    if-eqz v0, :cond_5a

    .line 283
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->A:Landroid/support/v7/internal/widget/ProgressBarICS;

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/ActionBarView;->removeView(Landroid/view/View;)V

    .line 284
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->i()V

    .line 286
    :cond_5a
    return-void
.end method

.method public onDetachedFromWindow()V
    .registers 2

    .prologue
    .line 299
    invoke-super {p0}, Landroid/support/v7/internal/widget/a;->onDetachedFromWindow()V

    .line 300
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->P:Ljava/lang/Runnable;

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/ActionBarView;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 301
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->b:Landroid/support/v7/internal/view/menu/ActionMenuPresenter;

    if-eqz v0, :cond_16

    .line 302
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->b:Landroid/support/v7/internal/view/menu/ActionMenuPresenter;

    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/ActionMenuPresenter;->d()Z

    .line 303
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->b:Landroid/support/v7/internal/view/menu/ActionMenuPresenter;

    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/ActionMenuPresenter;->f()Z

    .line 305
    :cond_16
    return-void
.end method

.method protected onFinishInflate()V
    .registers 3

    .prologue
    .line 749
    invoke-super {p0}, Landroid/support/v7/internal/widget/a;->onFinishInflate()V

    .line 751
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->p:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/ActionBarView;->addView(Landroid/view/View;)V

    .line 753
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->y:Landroid/view/View;

    if-eqz v0, :cond_2a

    iget v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->j:I

    and-int/lit8 v0, v0, 0x10

    if-eqz v0, :cond_2a

    .line 754
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->y:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    .line 755
    if-eq v0, p0, :cond_2a

    .line 756
    instance-of v1, v0, Landroid/view/ViewGroup;

    if-eqz v1, :cond_25

    .line 757
    check-cast v0, Landroid/view/ViewGroup;

    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->y:Landroid/view/View;

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->removeView(Landroid/view/View;)V

    .line 759
    :cond_25
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->y:Landroid/view/View;

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/ActionBarView;->addView(Landroid/view/View;)V

    .line 762
    :cond_2a
    return-void
.end method

.method protected onLayout(ZIIII)V
    .registers 15

    .prologue
    .line 1015
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->getPaddingLeft()I

    move-result v1

    .line 1016
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->getPaddingTop()I

    move-result v2

    .line 1017
    sub-int v0, p5, p3

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->getPaddingTop()I

    move-result v3

    sub-int/2addr v0, v3

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->getPaddingBottom()I

    move-result v3

    sub-int v3, v0, v3

    .line 1019
    if-gtz v3, :cond_18

    .line 1155
    :cond_17
    :goto_17
    return-void

    .line 1024
    :cond_18
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->g:Landroid/view/View;

    if-eqz v0, :cond_117

    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->q:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    .line 1025
    :goto_1e
    invoke-virtual {v0}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->getVisibility()I

    move-result v4

    const/16 v5, 0x8

    if-eq v4, v5, :cond_1c0

    .line 1026
    invoke-virtual {v0}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->a()I

    move-result v4

    .line 1027
    add-int v5, v1, v4

    invoke-static {v0, v5, v2, v3}, Landroid/support/v7/internal/widget/ActionBarView;->a(Landroid/view/View;III)I

    move-result v0

    add-int/2addr v0, v4

    add-int/2addr v0, v1

    .line 1030
    :goto_32
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->g:Landroid/view/View;

    if-nez v1, :cond_59

    .line 1031
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->r:Landroid/widget/LinearLayout;

    if-eqz v1, :cond_11b

    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->r:Landroid/widget/LinearLayout;

    invoke-virtual {v1}, Landroid/widget/LinearLayout;->getVisibility()I

    move-result v1

    const/16 v4, 0x8

    if-eq v1, v4, :cond_11b

    iget v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->j:I

    and-int/lit8 v1, v1, 0x8

    if-eqz v1, :cond_11b

    const/4 v1, 0x1

    .line 1034
    :goto_4b
    if-eqz v1, :cond_54

    .line 1035
    iget-object v4, p0, Landroid/support/v7/internal/widget/ActionBarView;->r:Landroid/widget/LinearLayout;

    invoke-static {v4, v0, v2, v3}, Landroid/support/v7/internal/widget/ActionBarView;->a(Landroid/view/View;III)I

    move-result v4

    add-int/2addr v0, v4

    .line 1038
    :cond_54
    iget v4, p0, Landroid/support/v7/internal/widget/ActionBarView;->i:I

    packed-switch v4, :pswitch_data_1c4

    :cond_59
    move v1, v0

    .line 1060
    :goto_5a
    sub-int v0, p4, p2

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->getPaddingRight()I

    move-result v4

    sub-int/2addr v0, v4

    .line 1061
    iget-object v4, p0, Landroid/support/v7/internal/widget/ActionBarView;->a:Landroid/support/v7/internal/view/menu/ActionMenuView;

    if-eqz v4, :cond_79

    iget-object v4, p0, Landroid/support/v7/internal/widget/ActionBarView;->a:Landroid/support/v7/internal/view/menu/ActionMenuView;

    invoke-virtual {v4}, Landroid/support/v7/internal/view/menu/ActionMenuView;->getParent()Landroid/view/ViewParent;

    move-result-object v4

    if-ne v4, p0, :cond_79

    .line 1062
    iget-object v4, p0, Landroid/support/v7/internal/widget/ActionBarView;->a:Landroid/support/v7/internal/view/menu/ActionMenuView;

    invoke-static {v4, v0, v2, v3}, Landroid/support/v7/internal/widget/ActionBarView;->b(Landroid/view/View;III)I

    .line 1063
    iget-object v4, p0, Landroid/support/v7/internal/widget/ActionBarView;->a:Landroid/support/v7/internal/view/menu/ActionMenuView;

    invoke-virtual {v4}, Landroid/support/v7/internal/view/menu/ActionMenuView;->getMeasuredWidth()I

    move-result v4

    sub-int/2addr v0, v4

    .line 1066
    :cond_79
    iget-object v4, p0, Landroid/support/v7/internal/widget/ActionBarView;->A:Landroid/support/v7/internal/widget/ProgressBarICS;

    if-eqz v4, :cond_1bd

    iget-object v4, p0, Landroid/support/v7/internal/widget/ActionBarView;->A:Landroid/support/v7/internal/widget/ProgressBarICS;

    invoke-virtual {v4}, Landroid/support/v7/internal/widget/ProgressBarICS;->getVisibility()I

    move-result v4

    const/16 v5, 0x8

    if-eq v4, v5, :cond_1bd

    .line 1068
    iget-object v4, p0, Landroid/support/v7/internal/widget/ActionBarView;->A:Landroid/support/v7/internal/widget/ProgressBarICS;

    invoke-static {v4, v0, v2, v3}, Landroid/support/v7/internal/widget/ActionBarView;->b(Landroid/view/View;III)I

    .line 1069
    iget-object v2, p0, Landroid/support/v7/internal/widget/ActionBarView;->A:Landroid/support/v7/internal/widget/ProgressBarICS;

    invoke-virtual {v2}, Landroid/support/v7/internal/widget/ProgressBarICS;->getMeasuredWidth()I

    move-result v2

    sub-int/2addr v0, v2

    move v2, v0

    .line 1072
    :goto_94
    const/4 v0, 0x0

    .line 1073
    iget-object v3, p0, Landroid/support/v7/internal/widget/ActionBarView;->g:Landroid/view/View;

    if-eqz v3, :cond_14d

    .line 1074
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->g:Landroid/view/View;

    move-object v7, v0

    .line 1079
    :goto_9c
    if-eqz v7, :cond_f3

    .line 1080
    invoke-virtual {v7}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    .line 1081
    instance-of v3, v0, Landroid/support/v7/app/ActionBar$LayoutParams;

    if-eqz v3, :cond_15c

    check-cast v0, Landroid/support/v7/app/ActionBar$LayoutParams;

    move-object v5, v0

    .line 1084
    :goto_a9
    if-eqz v5, :cond_160

    iget v0, v5, Landroid/support/v7/app/ActionBar$LayoutParams;->a:I

    .line 1085
    :goto_ad
    invoke-virtual {v7}, Landroid/view/View;->getMeasuredWidth()I

    move-result v8

    .line 1087
    const/4 v4, 0x0

    .line 1088
    const/4 v3, 0x0

    .line 1089
    if-eqz v5, :cond_1b4

    .line 1090
    iget v3, v5, Landroid/support/v7/app/ActionBar$LayoutParams;->leftMargin:I

    add-int v4, v1, v3

    .line 1091
    iget v1, v5, Landroid/support/v7/app/ActionBar$LayoutParams;->rightMargin:I

    sub-int v3, v2, v1

    .line 1092
    iget v2, v5, Landroid/support/v7/app/ActionBar$LayoutParams;->topMargin:I

    .line 1093
    iget v1, v5, Landroid/support/v7/app/ActionBar$LayoutParams;->bottomMargin:I

    move v5, v2

    move v6, v3

    move v2, v4

    move v4, v1

    .line 1096
    :goto_c5
    and-int/lit8 v1, v0, 0x7

    .line 1098
    const/4 v3, 0x1

    if-ne v1, v3, :cond_16b

    .line 1099
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->getWidth()I

    move-result v3

    sub-int/2addr v3, v8

    div-int/lit8 v3, v3, 0x2

    .line 1100
    if-ge v3, v2, :cond_164

    .line 1101
    const/4 v1, 0x3

    move v3, v1

    .line 1109
    :goto_d5
    const/4 v1, 0x0

    .line 1110
    packed-switch v3, :pswitch_data_1ce

    :pswitch_d9
    move v2, v1

    .line 1122
    :goto_da
    :pswitch_da
    and-int/lit8 v1, v0, 0x70

    .line 1124
    const/4 v3, -0x1

    if-ne v0, v3, :cond_e2

    .line 1125
    const/16 v0, 0x10

    move v1, v0

    .line 1128
    :cond_e2
    const/4 v0, 0x0

    .line 1129
    sparse-switch v1, :sswitch_data_1dc

    .line 1143
    :goto_e6
    invoke-virtual {v7}, Landroid/view/View;->getMeasuredWidth()I

    move-result v1

    .line 1144
    add-int/2addr v1, v2

    invoke-virtual {v7}, Landroid/view/View;->getMeasuredHeight()I

    move-result v3

    add-int/2addr v3, v0

    invoke-virtual {v7, v2, v0, v1, v3}, Landroid/view/View;->layout(IIII)V

    .line 1146
    :cond_f3
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->z:Landroid/support/v7/internal/widget/ProgressBarICS;

    if-eqz v0, :cond_17

    .line 1150
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->z:Landroid/support/v7/internal/widget/ProgressBarICS;

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/ProgressBarICS;->bringToFront()V

    .line 1151
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->z:Landroid/support/v7/internal/widget/ProgressBarICS;

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/ProgressBarICS;->getMeasuredHeight()I

    move-result v0

    div-int/lit8 v0, v0, 0x2

    .line 1152
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->z:Landroid/support/v7/internal/widget/ProgressBarICS;

    iget v2, p0, Landroid/support/v7/internal/widget/ActionBarView;->B:I

    neg-int v3, v0

    iget v4, p0, Landroid/support/v7/internal/widget/ActionBarView;->B:I

    iget-object v5, p0, Landroid/support/v7/internal/widget/ActionBarView;->z:Landroid/support/v7/internal/widget/ProgressBarICS;

    invoke-virtual {v5}, Landroid/support/v7/internal/widget/ProgressBarICS;->getMeasuredWidth()I

    move-result v5

    add-int/2addr v4, v5

    invoke-virtual {v1, v2, v3, v4, v0}, Landroid/support/v7/internal/widget/ProgressBarICS;->layout(IIII)V

    goto/16 :goto_17

    .line 1024
    :cond_117
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->p:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    goto/16 :goto_1e

    .line 1031
    :cond_11b
    const/4 v1, 0x0

    goto/16 :goto_4b

    :pswitch_11e
    move v1, v0

    .line 1040
    goto/16 :goto_5a

    .line 1042
    :pswitch_121
    iget-object v4, p0, Landroid/support/v7/internal/widget/ActionBarView;->w:Landroid/widget/LinearLayout;

    if-eqz v4, :cond_59

    .line 1043
    if-eqz v1, :cond_12a

    .line 1044
    iget v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->C:I

    add-int/2addr v0, v1

    .line 1046
    :cond_12a
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->w:Landroid/widget/LinearLayout;

    invoke-static {v1, v0, v2, v3}, Landroid/support/v7/internal/widget/ActionBarView;->a(Landroid/view/View;III)I

    move-result v1

    iget v4, p0, Landroid/support/v7/internal/widget/ActionBarView;->C:I

    add-int/2addr v1, v4

    add-int/2addr v0, v1

    move v1, v0

    goto/16 :goto_5a

    .line 1050
    :pswitch_137
    iget-object v4, p0, Landroid/support/v7/internal/widget/ActionBarView;->x:Landroid/support/v7/internal/widget/ScrollingTabContainerView;

    if-eqz v4, :cond_59

    .line 1051
    if-eqz v1, :cond_140

    .line 1052
    iget v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->C:I

    add-int/2addr v0, v1

    .line 1054
    :cond_140
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView;->x:Landroid/support/v7/internal/widget/ScrollingTabContainerView;

    invoke-static {v1, v0, v2, v3}, Landroid/support/v7/internal/widget/ActionBarView;->a(Landroid/view/View;III)I

    move-result v1

    iget v4, p0, Landroid/support/v7/internal/widget/ActionBarView;->C:I

    add-int/2addr v1, v4

    add-int/2addr v0, v1

    move v1, v0

    goto/16 :goto_5a

    .line 1075
    :cond_14d
    iget v3, p0, Landroid/support/v7/internal/widget/ActionBarView;->j:I

    and-int/lit8 v3, v3, 0x10

    if-eqz v3, :cond_1ba

    iget-object v3, p0, Landroid/support/v7/internal/widget/ActionBarView;->y:Landroid/view/View;

    if-eqz v3, :cond_1ba

    .line 1077
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->y:Landroid/view/View;

    move-object v7, v0

    goto/16 :goto_9c

    .line 1081
    :cond_15c
    const/4 v0, 0x0

    move-object v5, v0

    goto/16 :goto_a9

    .line 1084
    :cond_160
    const/16 v0, 0x13

    goto/16 :goto_ad

    .line 1102
    :cond_164
    add-int/2addr v3, v8

    if-le v3, v6, :cond_168

    .line 1103
    const/4 v1, 0x5

    :cond_168
    move v3, v1

    .line 1105
    goto/16 :goto_d5

    :cond_16b
    const/4 v3, -0x1

    if-ne v0, v3, :cond_1b1

    .line 1106
    const/4 v1, 0x3

    move v3, v1

    goto/16 :goto_d5

    .line 1112
    :pswitch_172
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->getWidth()I

    move-result v1

    sub-int/2addr v1, v8

    div-int/lit8 v1, v1, 0x2

    move v2, v1

    .line 1113
    goto/16 :goto_da

    .line 1118
    :pswitch_17c
    sub-int v1, v6, v8

    move v2, v1

    goto/16 :goto_da

    .line 1131
    :sswitch_181
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->getPaddingTop()I

    move-result v0

    .line 1132
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->getHeight()I

    move-result v1

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->getPaddingBottom()I

    move-result v3

    sub-int/2addr v1, v3

    .line 1133
    sub-int v0, v1, v0

    invoke-virtual {v7}, Landroid/view/View;->getMeasuredHeight()I

    move-result v1

    sub-int/2addr v0, v1

    div-int/lit8 v0, v0, 0x2

    goto/16 :goto_e6

    .line 1136
    :sswitch_199
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->getPaddingTop()I

    move-result v0

    add-int/2addr v0, v5

    .line 1137
    goto/16 :goto_e6

    .line 1139
    :sswitch_1a0
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->getHeight()I

    move-result v0

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView;->getPaddingBottom()I

    move-result v1

    sub-int/2addr v0, v1

    invoke-virtual {v7}, Landroid/view/View;->getMeasuredHeight()I

    move-result v1

    sub-int/2addr v0, v1

    sub-int/2addr v0, v4

    goto/16 :goto_e6

    :cond_1b1
    move v3, v1

    goto/16 :goto_d5

    :cond_1b4
    move v5, v4

    move v6, v2

    move v4, v3

    move v2, v1

    goto/16 :goto_c5

    :cond_1ba
    move-object v7, v0

    goto/16 :goto_9c

    :cond_1bd
    move v2, v0

    goto/16 :goto_94

    :cond_1c0
    move v0, v1

    goto/16 :goto_32

    .line 1038
    nop

    :pswitch_data_1c4
    .packed-switch 0x0
        :pswitch_11e
        :pswitch_121
        :pswitch_137
    .end packed-switch

    .line 1110
    :pswitch_data_1ce
    .packed-switch 0x1
        :pswitch_172
        :pswitch_d9
        :pswitch_da
        :pswitch_d9
        :pswitch_17c
    .end packed-switch

    .line 1129
    :sswitch_data_1dc
    .sparse-switch
        0x10 -> :sswitch_181
        0x30 -> :sswitch_199
        0x50 -> :sswitch_1a0
    .end sparse-switch
.end method

.method protected onMeasure(II)V
    .registers 22

    .prologue
    .line 818
    invoke-virtual/range {p0 .. p0}, Landroid/support/v7/internal/widget/ActionBarView;->getChildCount()I

    move-result v13

    .line 819
    move-object/from16 v0, p0

    iget-boolean v1, v0, Landroid/support/v7/internal/widget/ActionBarView;->J:Z

    if-eqz v1, :cond_45

    .line 820
    const/4 v2, 0x0

    .line 821
    const/4 v1, 0x0

    move/from16 v18, v1

    move v1, v2

    move/from16 v2, v18

    :goto_11
    if-ge v2, v13, :cond_36

    .line 822
    move-object/from16 v0, p0

    invoke-virtual {v0, v2}, Landroid/support/v7/internal/widget/ActionBarView;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    .line 823
    invoke-virtual {v3}, Landroid/view/View;->getVisibility()I

    move-result v4

    const/16 v5, 0x8

    if-eq v4, v5, :cond_33

    move-object/from16 v0, p0

    iget-object v4, v0, Landroid/support/v7/internal/widget/ActionBarView;->a:Landroid/support/v7/internal/view/menu/ActionMenuView;

    if-ne v3, v4, :cond_31

    move-object/from16 v0, p0

    iget-object v3, v0, Landroid/support/v7/internal/widget/ActionBarView;->a:Landroid/support/v7/internal/view/menu/ActionMenuView;

    invoke-virtual {v3}, Landroid/support/v7/internal/view/menu/ActionMenuView;->getChildCount()I

    move-result v3

    if-eqz v3, :cond_33

    .line 825
    :cond_31
    add-int/lit8 v1, v1, 0x1

    .line 821
    :cond_33
    add-int/lit8 v2, v2, 0x1

    goto :goto_11

    .line 829
    :cond_36
    if-nez v1, :cond_45

    .line 831
    const/4 v1, 0x0

    const/4 v2, 0x0

    move-object/from16 v0, p0

    invoke-virtual {v0, v1, v2}, Landroid/support/v7/internal/widget/ActionBarView;->setMeasuredDimension(II)V

    .line 832
    const/4 v1, 0x1

    move-object/from16 v0, p0

    iput-boolean v1, v0, Landroid/support/v7/internal/widget/ActionBarView;->K:Z

    .line 1011
    :cond_44
    :goto_44
    return-void

    .line 836
    :cond_45
    const/4 v1, 0x0

    move-object/from16 v0, p0

    iput-boolean v1, v0, Landroid/support/v7/internal/widget/ActionBarView;->K:Z

    .line 838
    invoke-static/range {p1 .. p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v1

    .line 839
    const/high16 v2, 0x40000000    # 2.0f

    if-eq v1, v2, :cond_73

    .line 840
    new-instance v1, Ljava/lang/IllegalStateException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual/range {p0 .. p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " can only be used with android:layout_width=\"MATCH_PARENT\" (or fill_parent)"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 844
    :cond_73
    invoke-static/range {p2 .. p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v1

    .line 845
    const/high16 v2, -0x80000000

    if-eq v1, v2, :cond_9c

    .line 846
    new-instance v1, Ljava/lang/IllegalStateException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual/range {p0 .. p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " can only be used with android:layout_height=\"wrap_content\""

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    .line 850
    :cond_9c
    invoke-static/range {p1 .. p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v14

    .line 852
    move-object/from16 v0, p0

    iget v1, v0, Landroid/support/v7/internal/widget/ActionBarView;->f:I

    if-lez v1, :cond_264

    move-object/from16 v0, p0

    iget v1, v0, Landroid/support/v7/internal/widget/ActionBarView;->f:I

    move v3, v1

    .line 855
    :goto_ab
    invoke-virtual/range {p0 .. p0}, Landroid/support/v7/internal/widget/ActionBarView;->getPaddingTop()I

    move-result v1

    invoke-virtual/range {p0 .. p0}, Landroid/support/v7/internal/widget/ActionBarView;->getPaddingBottom()I

    move-result v2

    add-int v15, v1, v2

    .line 856
    invoke-virtual/range {p0 .. p0}, Landroid/support/v7/internal/widget/ActionBarView;->getPaddingLeft()I

    move-result v1

    .line 857
    invoke-virtual/range {p0 .. p0}, Landroid/support/v7/internal/widget/ActionBarView;->getPaddingRight()I

    move-result v2

    .line 858
    sub-int v10, v3, v15

    .line 859
    const/high16 v4, -0x80000000

    invoke-static {v10, v4}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v6

    .line 861
    sub-int v1, v14, v1

    sub-int v5, v1, v2

    .line 862
    div-int/lit8 v4, v5, 0x2

    .line 865
    move-object/from16 v0, p0

    iget-object v1, v0, Landroid/support/v7/internal/widget/ActionBarView;->g:Landroid/view/View;

    if-eqz v1, :cond_26b

    move-object/from16 v0, p0

    iget-object v1, v0, Landroid/support/v7/internal/widget/ActionBarView;->q:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    .line 867
    :goto_d5
    invoke-virtual {v1}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->getVisibility()I

    move-result v2

    const/16 v7, 0x8

    if-eq v2, v7, :cond_392

    .line 868
    invoke-virtual {v1}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    .line 870
    iget v7, v2, Landroid/view/ViewGroup$LayoutParams;->width:I

    if-gez v7, :cond_271

    .line 871
    const/high16 v2, -0x80000000

    invoke-static {v5, v2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v2

    .line 875
    :goto_eb
    const/high16 v7, 0x40000000    # 2.0f

    invoke-static {v10, v7}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v7

    invoke-virtual {v1, v2, v7}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->measure(II)V

    .line 877
    invoke-virtual {v1}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->getMeasuredWidth()I

    move-result v2

    invoke-virtual {v1}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->a()I

    move-result v1

    add-int/2addr v1, v2

    .line 878
    const/4 v2, 0x0

    sub-int/2addr v5, v1

    invoke-static {v2, v5}, Ljava/lang/Math;->max(II)I

    move-result v2

    .line 879
    const/4 v5, 0x0

    sub-int v1, v2, v1

    invoke-static {v5, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    .line 882
    :goto_10a
    move-object/from16 v0, p0

    iget-object v5, v0, Landroid/support/v7/internal/widget/ActionBarView;->a:Landroid/support/v7/internal/view/menu/ActionMenuView;

    if-eqz v5, :cond_132

    move-object/from16 v0, p0

    iget-object v5, v0, Landroid/support/v7/internal/widget/ActionBarView;->a:Landroid/support/v7/internal/view/menu/ActionMenuView;

    invoke-virtual {v5}, Landroid/support/v7/internal/view/menu/ActionMenuView;->getParent()Landroid/view/ViewParent;

    move-result-object v5

    move-object/from16 v0, p0

    if-ne v5, v0, :cond_132

    .line 883
    move-object/from16 v0, p0

    iget-object v5, v0, Landroid/support/v7/internal/widget/ActionBarView;->a:Landroid/support/v7/internal/view/menu/ActionMenuView;

    invoke-static {v5, v2, v6}, Landroid/support/v7/internal/widget/ActionBarView;->a(Landroid/view/View;II)I

    move-result v2

    .line 885
    const/4 v5, 0x0

    move-object/from16 v0, p0

    iget-object v7, v0, Landroid/support/v7/internal/widget/ActionBarView;->a:Landroid/support/v7/internal/view/menu/ActionMenuView;

    invoke-virtual {v7}, Landroid/support/v7/internal/view/menu/ActionMenuView;->getMeasuredWidth()I

    move-result v7

    sub-int/2addr v4, v7

    invoke-static {v5, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    .line 888
    :cond_132
    move-object/from16 v0, p0

    iget-object v5, v0, Landroid/support/v7/internal/widget/ActionBarView;->A:Landroid/support/v7/internal/widget/ProgressBarICS;

    if-eqz v5, :cond_15a

    move-object/from16 v0, p0

    iget-object v5, v0, Landroid/support/v7/internal/widget/ActionBarView;->A:Landroid/support/v7/internal/widget/ProgressBarICS;

    invoke-virtual {v5}, Landroid/support/v7/internal/widget/ProgressBarICS;->getVisibility()I

    move-result v5

    const/16 v7, 0x8

    if-eq v5, v7, :cond_15a

    .line 890
    move-object/from16 v0, p0

    iget-object v5, v0, Landroid/support/v7/internal/widget/ActionBarView;->A:Landroid/support/v7/internal/widget/ProgressBarICS;

    invoke-static {v5, v2, v6}, Landroid/support/v7/internal/widget/ActionBarView;->a(Landroid/view/View;II)I

    move-result v2

    .line 892
    const/4 v5, 0x0

    move-object/from16 v0, p0

    iget-object v6, v0, Landroid/support/v7/internal/widget/ActionBarView;->A:Landroid/support/v7/internal/widget/ProgressBarICS;

    invoke-virtual {v6}, Landroid/support/v7/internal/widget/ProgressBarICS;->getMeasuredWidth()I

    move-result v6

    sub-int/2addr v4, v6

    invoke-static {v5, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    .line 896
    :cond_15a
    move-object/from16 v0, p0

    iget-object v5, v0, Landroid/support/v7/internal/widget/ActionBarView;->r:Landroid/widget/LinearLayout;

    if-eqz v5, :cond_27b

    move-object/from16 v0, p0

    iget-object v5, v0, Landroid/support/v7/internal/widget/ActionBarView;->r:Landroid/widget/LinearLayout;

    invoke-virtual {v5}, Landroid/widget/LinearLayout;->getVisibility()I

    move-result v5

    const/16 v6, 0x8

    if-eq v5, v6, :cond_27b

    move-object/from16 v0, p0

    iget v5, v0, Landroid/support/v7/internal/widget/ActionBarView;->j:I

    and-int/lit8 v5, v5, 0x8

    if-eqz v5, :cond_27b

    const/4 v5, 0x1

    .line 899
    :goto_175
    move-object/from16 v0, p0

    iget-object v6, v0, Landroid/support/v7/internal/widget/ActionBarView;->g:Landroid/view/View;

    if-nez v6, :cond_182

    .line 900
    move-object/from16 v0, p0

    iget v6, v0, Landroid/support/v7/internal/widget/ActionBarView;->i:I

    packed-switch v6, :pswitch_data_396

    :cond_182
    move v6, v1

    move v7, v2

    .line 930
    :goto_184
    const/4 v1, 0x0

    .line 931
    move-object/from16 v0, p0

    iget-object v2, v0, Landroid/support/v7/internal/widget/ActionBarView;->g:Landroid/view/View;

    if-eqz v2, :cond_312

    .line 932
    move-object/from16 v0, p0

    iget-object v1, v0, Landroid/support/v7/internal/widget/ActionBarView;->g:Landroid/view/View;

    move-object v12, v1

    .line 938
    :goto_190
    if-eqz v12, :cond_220

    .line 939
    invoke-virtual {v12}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    move-object/from16 v0, p0

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/widget/ActionBarView;->generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    .line 940
    instance-of v1, v2, Landroid/support/v7/app/ActionBar$LayoutParams;

    if-eqz v1, :cond_327

    move-object v1, v2

    check-cast v1, Landroid/support/v7/app/ActionBar$LayoutParams;

    move-object v11, v1

    .line 943
    :goto_1a4
    const/4 v8, 0x0

    .line 944
    const/4 v1, 0x0

    .line 945
    if-eqz v11, :cond_1b2

    .line 946
    iget v1, v11, Landroid/support/v7/app/ActionBar$LayoutParams;->leftMargin:I

    iget v8, v11, Landroid/support/v7/app/ActionBar$LayoutParams;->rightMargin:I

    add-int/2addr v8, v1

    .line 947
    iget v1, v11, Landroid/support/v7/app/ActionBar$LayoutParams;->topMargin:I

    iget v9, v11, Landroid/support/v7/app/ActionBar$LayoutParams;->bottomMargin:I

    add-int/2addr v1, v9

    .line 953
    :cond_1b2
    move-object/from16 v0, p0

    iget v9, v0, Landroid/support/v7/internal/widget/ActionBarView;->f:I

    if-lez v9, :cond_32b

    .line 954
    iget v9, v2, Landroid/view/ViewGroup$LayoutParams;->height:I

    const/16 v16, -0x2

    move/from16 v0, v16

    if-eq v9, v0, :cond_32b

    const/high16 v9, 0x40000000    # 2.0f

    .line 959
    :goto_1c2
    const/16 v16, 0x0

    iget v0, v2, Landroid/view/ViewGroup$LayoutParams;->height:I

    move/from16 v17, v0

    if-ltz v17, :cond_1d4

    iget v0, v2, Landroid/view/ViewGroup$LayoutParams;->height:I

    move/from16 v17, v0

    move/from16 v0, v17

    invoke-static {v0, v10}, Ljava/lang/Math;->min(II)I

    move-result v10

    :cond_1d4
    sub-int v1, v10, v1

    move/from16 v0, v16

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v16

    .line 962
    iget v1, v2, Landroid/view/ViewGroup$LayoutParams;->width:I

    const/4 v10, -0x2

    if-eq v1, v10, :cond_32f

    const/high16 v1, 0x40000000    # 2.0f

    .line 964
    :goto_1e3
    const/16 v17, 0x0

    iget v10, v2, Landroid/view/ViewGroup$LayoutParams;->width:I

    if-ltz v10, :cond_333

    iget v10, v2, Landroid/view/ViewGroup$LayoutParams;->width:I

    invoke-static {v10, v7}, Ljava/lang/Math;->min(II)I

    move-result v10

    :goto_1ef
    sub-int/2addr v10, v8

    move/from16 v0, v17

    invoke-static {v0, v10}, Ljava/lang/Math;->max(II)I

    move-result v10

    .line 967
    if-eqz v11, :cond_336

    iget v11, v11, Landroid/support/v7/app/ActionBar$LayoutParams;->a:I

    :goto_1fa
    and-int/lit8 v11, v11, 0x7

    .line 972
    const/16 v17, 0x1

    move/from16 v0, v17

    if-ne v11, v0, :cond_38c

    iget v2, v2, Landroid/view/ViewGroup$LayoutParams;->width:I

    const/4 v11, -0x1

    if-ne v2, v11, :cond_38c

    .line 973
    invoke-static {v6, v4}, Ljava/lang/Math;->min(II)I

    move-result v2

    mul-int/lit8 v2, v2, 0x2

    .line 976
    :goto_20d
    invoke-static {v2, v1}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v1

    move/from16 v0, v16

    invoke-static {v0, v9}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v2

    invoke-virtual {v12, v1, v2}, Landroid/view/View;->measure(II)V

    .line 979
    invoke-virtual {v12}, Landroid/view/View;->getMeasuredWidth()I

    move-result v1

    add-int/2addr v1, v8

    sub-int/2addr v7, v1

    .line 982
    :cond_220
    move-object/from16 v0, p0

    iget-object v1, v0, Landroid/support/v7/internal/widget/ActionBarView;->g:Landroid/view/View;

    if-nez v1, :cond_247

    if-eqz v5, :cond_247

    .line 983
    move-object/from16 v0, p0

    iget-object v1, v0, Landroid/support/v7/internal/widget/ActionBarView;->r:Landroid/widget/LinearLayout;

    move-object/from16 v0, p0

    iget v2, v0, Landroid/support/v7/internal/widget/ActionBarView;->f:I

    const/high16 v4, 0x40000000    # 2.0f

    invoke-static {v2, v4}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v2

    invoke-static {v1, v7, v2}, Landroid/support/v7/internal/widget/ActionBarView;->a(Landroid/view/View;II)I

    .line 985
    const/4 v1, 0x0

    move-object/from16 v0, p0

    iget-object v2, v0, Landroid/support/v7/internal/widget/ActionBarView;->r:Landroid/widget/LinearLayout;

    invoke-virtual {v2}, Landroid/widget/LinearLayout;->getMeasuredWidth()I

    move-result v2

    sub-int v2, v6, v2

    invoke-static {v1, v2}, Ljava/lang/Math;->max(II)I

    .line 988
    :cond_247
    move-object/from16 v0, p0

    iget v1, v0, Landroid/support/v7/internal/widget/ActionBarView;->f:I

    if-gtz v1, :cond_383

    .line 989
    const/4 v2, 0x0

    .line 990
    const/4 v1, 0x0

    move v3, v1

    :goto_250
    if-ge v3, v13, :cond_33a

    .line 991
    move-object/from16 v0, p0

    invoke-virtual {v0, v3}, Landroid/support/v7/internal/widget/ActionBarView;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    .line 992
    invoke-virtual {v1}, Landroid/view/View;->getMeasuredHeight()I

    move-result v1

    add-int/2addr v1, v15

    .line 993
    if-le v1, v2, :cond_389

    .line 990
    :goto_25f
    add-int/lit8 v2, v3, 0x1

    move v3, v2

    move v2, v1

    goto :goto_250

    .line 852
    :cond_264
    invoke-static/range {p2 .. p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v1

    move v3, v1

    goto/16 :goto_ab

    .line 865
    :cond_26b
    move-object/from16 v0, p0

    iget-object v1, v0, Landroid/support/v7/internal/widget/ActionBarView;->p:Landroid/support/v7/internal/widget/ActionBarView$HomeView;

    goto/16 :goto_d5

    .line 873
    :cond_271
    iget v2, v2, Landroid/view/ViewGroup$LayoutParams;->width:I

    const/high16 v7, 0x40000000    # 2.0f

    invoke-static {v2, v7}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v2

    goto/16 :goto_eb

    .line 896
    :cond_27b
    const/4 v5, 0x0

    goto/16 :goto_175

    .line 902
    :pswitch_27e
    move-object/from16 v0, p0

    iget-object v6, v0, Landroid/support/v7/internal/widget/ActionBarView;->w:Landroid/widget/LinearLayout;

    if-eqz v6, :cond_182

    .line 903
    if-eqz v5, :cond_2c3

    move-object/from16 v0, p0

    iget v6, v0, Landroid/support/v7/internal/widget/ActionBarView;->C:I

    mul-int/lit8 v6, v6, 0x2

    .line 904
    :goto_28c
    const/4 v7, 0x0

    sub-int/2addr v2, v6

    invoke-static {v7, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    .line 905
    const/4 v7, 0x0

    sub-int/2addr v1, v6

    invoke-static {v7, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    .line 906
    move-object/from16 v0, p0

    iget-object v6, v0, Landroid/support/v7/internal/widget/ActionBarView;->w:Landroid/widget/LinearLayout;

    const/high16 v7, -0x80000000

    invoke-static {v2, v7}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v7

    const/high16 v8, 0x40000000    # 2.0f

    invoke-static {v10, v8}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v8

    invoke-virtual {v6, v7, v8}, Landroid/widget/LinearLayout;->measure(II)V

    .line 909
    move-object/from16 v0, p0

    iget-object v6, v0, Landroid/support/v7/internal/widget/ActionBarView;->w:Landroid/widget/LinearLayout;

    invoke-virtual {v6}, Landroid/widget/LinearLayout;->getMeasuredWidth()I

    move-result v6

    .line 910
    const/4 v7, 0x0

    sub-int/2addr v2, v6

    invoke-static {v7, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    .line 911
    const/4 v7, 0x0

    sub-int/2addr v1, v6

    invoke-static {v7, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    move v6, v1

    move v7, v2

    .line 912
    goto/16 :goto_184

    .line 903
    :cond_2c3
    move-object/from16 v0, p0

    iget v6, v0, Landroid/support/v7/internal/widget/ActionBarView;->C:I

    goto :goto_28c

    .line 915
    :pswitch_2c8
    move-object/from16 v0, p0

    iget-object v6, v0, Landroid/support/v7/internal/widget/ActionBarView;->x:Landroid/support/v7/internal/widget/ScrollingTabContainerView;

    if-eqz v6, :cond_182

    .line 916
    if-eqz v5, :cond_30d

    move-object/from16 v0, p0

    iget v6, v0, Landroid/support/v7/internal/widget/ActionBarView;->C:I

    mul-int/lit8 v6, v6, 0x2

    .line 917
    :goto_2d6
    const/4 v7, 0x0

    sub-int/2addr v2, v6

    invoke-static {v7, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    .line 918
    const/4 v7, 0x0

    sub-int/2addr v1, v6

    invoke-static {v7, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    .line 919
    move-object/from16 v0, p0

    iget-object v6, v0, Landroid/support/v7/internal/widget/ActionBarView;->x:Landroid/support/v7/internal/widget/ScrollingTabContainerView;

    const/high16 v7, -0x80000000

    invoke-static {v2, v7}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v7

    const/high16 v8, 0x40000000    # 2.0f

    invoke-static {v10, v8}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v8

    invoke-virtual {v6, v7, v8}, Landroid/support/v7/internal/widget/ScrollingTabContainerView;->measure(II)V

    .line 922
    move-object/from16 v0, p0

    iget-object v6, v0, Landroid/support/v7/internal/widget/ActionBarView;->x:Landroid/support/v7/internal/widget/ScrollingTabContainerView;

    invoke-virtual {v6}, Landroid/support/v7/internal/widget/ScrollingTabContainerView;->getMeasuredWidth()I

    move-result v6

    .line 923
    const/4 v7, 0x0

    sub-int/2addr v2, v6

    invoke-static {v7, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    .line 924
    const/4 v7, 0x0

    sub-int/2addr v1, v6

    invoke-static {v7, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    move v6, v1

    move v7, v2

    goto/16 :goto_184

    .line 916
    :cond_30d
    move-object/from16 v0, p0

    iget v6, v0, Landroid/support/v7/internal/widget/ActionBarView;->C:I

    goto :goto_2d6

    .line 933
    :cond_312
    move-object/from16 v0, p0

    iget v2, v0, Landroid/support/v7/internal/widget/ActionBarView;->j:I

    and-int/lit8 v2, v2, 0x10

    if-eqz v2, :cond_38f

    move-object/from16 v0, p0

    iget-object v2, v0, Landroid/support/v7/internal/widget/ActionBarView;->y:Landroid/view/View;

    if-eqz v2, :cond_38f

    .line 935
    move-object/from16 v0, p0

    iget-object v1, v0, Landroid/support/v7/internal/widget/ActionBarView;->y:Landroid/view/View;

    move-object v12, v1

    goto/16 :goto_190

    .line 940
    :cond_327
    const/4 v1, 0x0

    move-object v11, v1

    goto/16 :goto_1a4

    .line 954
    :cond_32b
    const/high16 v9, -0x80000000

    goto/16 :goto_1c2

    .line 962
    :cond_32f
    const/high16 v1, -0x80000000

    goto/16 :goto_1e3

    :cond_333
    move v10, v7

    .line 964
    goto/16 :goto_1ef

    .line 967
    :cond_336
    const/16 v11, 0x13

    goto/16 :goto_1fa

    .line 997
    :cond_33a
    move-object/from16 v0, p0

    invoke-virtual {v0, v14, v2}, Landroid/support/v7/internal/widget/ActionBarView;->setMeasuredDimension(II)V

    .line 1002
    :goto_33f
    move-object/from16 v0, p0

    iget-object v1, v0, Landroid/support/v7/internal/widget/ActionBarView;->M:Landroid/support/v7/internal/widget/ActionBarContextView;

    if-eqz v1, :cond_350

    .line 1003
    move-object/from16 v0, p0

    iget-object v1, v0, Landroid/support/v7/internal/widget/ActionBarView;->M:Landroid/support/v7/internal/widget/ActionBarContextView;

    invoke-virtual/range {p0 .. p0}, Landroid/support/v7/internal/widget/ActionBarView;->getMeasuredHeight()I

    move-result v2

    invoke-virtual {v1, v2}, Landroid/support/v7/internal/widget/ActionBarContextView;->a(I)V

    .line 1006
    :cond_350
    move-object/from16 v0, p0

    iget-object v1, v0, Landroid/support/v7/internal/widget/ActionBarView;->z:Landroid/support/v7/internal/widget/ProgressBarICS;

    if-eqz v1, :cond_44

    move-object/from16 v0, p0

    iget-object v1, v0, Landroid/support/v7/internal/widget/ActionBarView;->z:Landroid/support/v7/internal/widget/ProgressBarICS;

    invoke-virtual {v1}, Landroid/support/v7/internal/widget/ProgressBarICS;->getVisibility()I

    move-result v1

    const/16 v2, 0x8

    if-eq v1, v2, :cond_44

    .line 1007
    move-object/from16 v0, p0

    iget-object v1, v0, Landroid/support/v7/internal/widget/ActionBarView;->z:Landroid/support/v7/internal/widget/ProgressBarICS;

    move-object/from16 v0, p0

    iget v2, v0, Landroid/support/v7/internal/widget/ActionBarView;->B:I

    mul-int/lit8 v2, v2, 0x2

    sub-int v2, v14, v2

    const/high16 v3, 0x40000000    # 2.0f

    invoke-static {v2, v3}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v2

    invoke-virtual/range {p0 .. p0}, Landroid/support/v7/internal/widget/ActionBarView;->getMeasuredHeight()I

    move-result v3

    const/high16 v4, -0x80000000

    invoke-static {v3, v4}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v3

    invoke-virtual {v1, v2, v3}, Landroid/support/v7/internal/widget/ProgressBarICS;->measure(II)V

    goto/16 :goto_44

    .line 999
    :cond_383
    move-object/from16 v0, p0

    invoke-virtual {v0, v14, v3}, Landroid/support/v7/internal/widget/ActionBarView;->setMeasuredDimension(II)V

    goto :goto_33f

    :cond_389
    move v1, v2

    goto/16 :goto_25f

    :cond_38c
    move v2, v10

    goto/16 :goto_20d

    :cond_38f
    move-object v12, v1

    goto/16 :goto_190

    :cond_392
    move v1, v4

    move v2, v5

    goto/16 :goto_10a

    .line 900
    :pswitch_data_396
    .packed-switch 0x1
        :pswitch_27e
        :pswitch_2c8
    .end packed-switch
.end method

.method public onRestoreInstanceState(Landroid/os/Parcelable;)V
    .registers 4

    .prologue
    .line 1186
    check-cast p1, Landroid/support/v7/internal/widget/ActionBarView$SavedState;

    .line 1188
    invoke-virtual {p1}, Landroid/support/v7/internal/widget/ActionBarView$SavedState;->getSuperState()Landroid/os/Parcelable;

    move-result-object v0

    invoke-super {p0, v0}, Landroid/support/v7/internal/widget/a;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    .line 1190
    iget v0, p1, Landroid/support/v7/internal/widget/ActionBarView$SavedState;->a:I

    if-eqz v0, :cond_24

    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->Q:Landroid/support/v7/internal/widget/c;

    if-eqz v0, :cond_24

    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->L:Landroid/support/v7/internal/view/menu/n;

    if-eqz v0, :cond_24

    .line 1192
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->L:Landroid/support/v7/internal/view/menu/n;

    iget v1, p1, Landroid/support/v7/internal/widget/ActionBarView$SavedState;->a:I

    invoke-virtual {v0, v1}, Landroid/support/v7/internal/view/menu/n;->findItem(I)Landroid/view/MenuItem;

    move-result-object v0

    check-cast v0, Landroid/support/v4/a/a/b;

    .line 1194
    if-eqz v0, :cond_24

    .line 1195
    invoke-interface {v0}, Landroid/support/v4/a/a/b;->expandActionView()Z

    .line 1199
    :cond_24
    iget-boolean v0, p1, Landroid/support/v7/internal/widget/ActionBarView$SavedState;->b:Z

    if-eqz v0, :cond_2b

    .line 1200
    invoke-super {p0}, Landroid/support/v7/internal/widget/a;->c()V

    .line 1202
    :cond_2b
    return-void
.end method

.method public onSaveInstanceState()Landroid/os/Parcelable;
    .registers 3

    .prologue
    .line 1172
    invoke-super {p0}, Landroid/support/v7/internal/widget/a;->onSaveInstanceState()Landroid/os/Parcelable;

    move-result-object v0

    .line 1173
    new-instance v1, Landroid/support/v7/internal/widget/ActionBarView$SavedState;

    invoke-direct {v1, v0}, Landroid/support/v7/internal/widget/ActionBarView$SavedState;-><init>(Landroid/os/Parcelable;)V

    .line 1175
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->Q:Landroid/support/v7/internal/widget/c;

    if-eqz v0, :cond_1d

    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->Q:Landroid/support/v7/internal/widget/c;

    iget-object v0, v0, Landroid/support/v7/internal/widget/c;->b:Landroid/support/v7/internal/view/menu/r;

    if-eqz v0, :cond_1d

    .line 1176
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->Q:Landroid/support/v7/internal/widget/c;

    iget-object v0, v0, Landroid/support/v7/internal/widget/c;->b:Landroid/support/v7/internal/view/menu/r;

    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->getItemId()I

    move-result v0

    iput v0, v1, Landroid/support/v7/internal/widget/ActionBarView$SavedState;->a:I

    .line 1179
    :cond_1d
    invoke-super {p0}, Landroid/support/v7/internal/widget/a;->e()Z

    move-result v0

    iput-boolean v0, v1, Landroid/support/v7/internal/widget/ActionBarView$SavedState;->b:Z

    .line 1181
    return-object v1
.end method

.method public final p()Z
    .registers 2

    .prologue
    .line 813
    iget-boolean v0, p0, Landroid/support/v7/internal/widget/ActionBarView;->K:Z

    return v0
.end method

.method public bridge synthetic setVisibility(I)V
    .registers 2

    .prologue
    .line 63
    invoke-super {p0, p1}, Landroid/support/v7/internal/widget/a;->setVisibility(I)V

    return-void
.end method

.method public shouldDelayChildPressedState()Z
    .registers 2

    .prologue
    .line 308
    const/4 v0, 0x0

    return v0
.end method

###### Class android.support.v7.internal.widget.ActionBarView.AnonymousClass1 (android.support.v7.internal.widget.ActionBarView$1)
.class final Landroid/support/v7/internal/widget/ActionBarView$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/support/v7/internal/widget/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/v7/internal/widget/ActionBarView;
.end annotation


# instance fields
.field final synthetic a:Landroid/support/v7/internal/widget/ActionBarView;


# direct methods
.method constructor <init>(Landroid/support/v7/internal/widget/ActionBarView;)V
    .registers 2

    .prologue
    .line 136
    iput-object p1, p0, Landroid/support/v7/internal/widget/ActionBarView$1;->a:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(I)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    .prologue
    .line 139
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView$1;->a:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->a(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/app/b;

    move-result-object v0

    if-eqz v0, :cond_11

    .line 140
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView$1;->a:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->a(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/app/b;

    move-result-object v0

    invoke-interface {v0, p1}, Landroid/support/v7/app/b;->b_(I)Z

    .line 142
    :cond_11
    return-void
.end method

###### Class android.support.v7.internal.widget.ActionBarView.AnonymousClass2 (android.support.v7.internal.widget.ActionBarView$2)
.class final Landroid/support/v7/internal/widget/ActionBarView$2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/v7/internal/widget/ActionBarView;
.end annotation


# instance fields
.field final synthetic a:Landroid/support/v7/internal/widget/ActionBarView;


# direct methods
.method constructor <init>(Landroid/support/v7/internal/widget/ActionBarView;)V
    .registers 2

    .prologue
    .line 149
    iput-object p1, p0, Landroid/support/v7/internal/widget/ActionBarView$2;->a:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 3

    .prologue
    .line 152
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView$2;->a:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v0}, Landroid/support/v7/internal/widget/ActionBarView;->b(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/internal/widget/c;

    move-result-object v0

    iget-object v0, v0, Landroid/support/v7/internal/widget/c;->b:Landroid/support/v7/internal/view/menu/r;

    .line 153
    if-eqz v0, :cond_d

    .line 154
    invoke-virtual {v0}, Landroid/support/v7/internal/view/menu/r;->collapseActionView()Z

    .line 156
    :cond_d
    return-void
.end method

###### Class android.support.v7.internal.widget.ActionBarView.AnonymousClass3 (android.support.v7.internal.widget.ActionBarView$3)
.class final Landroid/support/v7/internal/widget/ActionBarView$3;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/v7/internal/widget/ActionBarView;
.end annotation


# instance fields
.field final synthetic a:Landroid/support/v7/internal/widget/ActionBarView;


# direct methods
.method constructor <init>(Landroid/support/v7/internal/widget/ActionBarView;)V
    .registers 2

    .prologue
    .line 159
    iput-object p1, p0, Landroid/support/v7/internal/widget/ActionBarView$3;->a:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 5

    .prologue
    .line 161
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView$3;->a:Landroid/support/v7/internal/widget/ActionBarView;

    iget-object v0, v0, Landroid/support/v7/internal/widget/ActionBarView;->h:Landroid/view/Window$Callback;

    const/4 v1, 0x0

    iget-object v2, p0, Landroid/support/v7/internal/widget/ActionBarView$3;->a:Landroid/support/v7/internal/widget/ActionBarView;

    invoke-static {v2}, Landroid/support/v7/internal/widget/ActionBarView;->c(Landroid/support/v7/internal/widget/ActionBarView;)Landroid/support/v7/internal/view/menu/a;

    move-result-object v2

    invoke-interface {v0, v1, v2}, Landroid/view/Window$Callback;->onMenuItemSelected(ILandroid/view/MenuItem;)Z

    .line 162
    return-void
.end method

###### Class android.support.v7.internal.widget.ActionBarView.HomeView (android.support.v7.internal.widget.ActionBarView$HomeView)
.class Landroid/support/v7/internal/widget/ActionBarView$HomeView;
.super Landroid/widget/FrameLayout;
.source "SourceFile"


# instance fields
.field private a:Landroid/widget/ImageView;

.field private b:Landroid/widget/ImageView;

.field private c:I

.field private d:I

.field private e:Landroid/graphics/drawable/Drawable;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 3

    .prologue
    .line 1254
    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 1255
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 3

    .prologue
    .line 1258
    invoke-direct {p0, p1, p2}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 1259
    return-void
.end method


# virtual methods
.method public final a()I
    .registers 3

    .prologue
    .line 1306
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->a:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->getVisibility()I

    move-result v0

    const/16 v1, 0x8

    if-ne v0, v1, :cond_d

    iget v0, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->c:I

    :goto_c
    return v0

    :cond_d
    const/4 v0, 0x0

    goto :goto_c
.end method

.method public final a(Landroid/graphics/drawable/Drawable;)V
    .registers 3

    .prologue
    .line 1266
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->b:Landroid/widget/ImageView;

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 1267
    return-void
.end method

.method public final a(Z)V
    .registers 4

    .prologue
    .line 1262
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->a:Landroid/widget/ImageView;

    if-eqz p1, :cond_9

    const/4 v0, 0x0

    :goto_5
    invoke-virtual {v1, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    .line 1263
    return-void

    .line 1262
    :cond_9
    const/16 v0, 0x8

    goto :goto_5
.end method

.method public dispatchPopulateAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)Z
    .registers 4

    .prologue
    .line 1291
    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v0

    .line 1292
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_11

    .line 1293
    invoke-virtual {p1}, Landroid/view/accessibility/AccessibilityEvent;->getText()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1295
    :cond_11
    const/4 v0, 0x1

    return v0
.end method

.method protected onConfigurationChanged(Landroid/content/res/Configuration;)V
    .registers 5

    .prologue
    .line 1282
    invoke-super {p0, p1}, Landroid/widget/FrameLayout;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    .line 1283
    iget v0, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->d:I

    if-eqz v0, :cond_1a

    .line 1285
    iget v0, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->d:I

    iput v0, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->d:I

    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->a:Landroid/widget/ImageView;

    if-eqz v0, :cond_1b

    invoke-virtual {p0}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2, v0}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    :goto_17
    invoke-virtual {v1, v0}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 1287
    :cond_1a
    return-void

    .line 1285
    :cond_1b
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->e:Landroid/graphics/drawable/Drawable;

    goto :goto_17
.end method

.method protected onFinishInflate()V
    .registers 2

    .prologue
    .line 1300
    sget v0, Landroid/support/v7/a/f;->G:I

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->a:Landroid/widget/ImageView;

    .line 1301
    sget v0, Landroid/support/v7/a/f;->n:I

    invoke-virtual {p0, v0}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/ImageView;

    iput-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->b:Landroid/widget/ImageView;

    .line 1302
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->a:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    iput-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->e:Landroid/graphics/drawable/Drawable;

    .line 1303
    return-void
.end method

.method protected onLayout(ZIIII)V
    .registers 14

    .prologue
    const/4 v1, 0x0

    .line 1354
    sub-int v0, p5, p3

    div-int/lit8 v2, v0, 0x2

    .line 1357
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->a:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->getVisibility()I

    move-result v0

    const/16 v3, 0x8

    if-eq v0, v3, :cond_35

    .line 1358
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->a:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/widget/FrameLayout$LayoutParams;

    .line 1359
    iget-object v3, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->a:Landroid/widget/ImageView;

    invoke-virtual {v3}, Landroid/widget/ImageView;->getMeasuredHeight()I

    move-result v3

    .line 1360
    iget-object v4, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->a:Landroid/widget/ImageView;

    invoke-virtual {v4}, Landroid/widget/ImageView;->getMeasuredWidth()I

    move-result v4

    .line 1361
    div-int/lit8 v5, v3, 0x2

    sub-int v5, v2, v5

    .line 1362
    iget-object v6, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->a:Landroid/widget/ImageView;

    add-int/2addr v3, v5

    invoke-virtual {v6, v1, v5, v4, v3}, Landroid/widget/ImageView;->layout(IIII)V

    .line 1363
    iget v1, v0, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    add-int/2addr v1, v4

    iget v0, v0, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    add-int/2addr v0, v1

    .line 1364
    add-int/2addr p2, v0

    move v1, v0

    .line 1367
    :cond_35
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->b:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/widget/FrameLayout$LayoutParams;

    .line 1368
    iget-object v3, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->b:Landroid/widget/ImageView;

    invoke-virtual {v3}, Landroid/widget/ImageView;->getMeasuredHeight()I

    move-result v3

    .line 1369
    iget-object v4, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->b:Landroid/widget/ImageView;

    invoke-virtual {v4}, Landroid/widget/ImageView;->getMeasuredWidth()I

    move-result v4

    .line 1370
    sub-int v5, p4, p2

    div-int/lit8 v5, v5, 0x2

    .line 1371
    iget v6, v0, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    div-int/lit8 v7, v4, 0x2

    sub-int/2addr v5, v7

    invoke-static {v6, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    add-int/2addr v1, v5

    .line 1372
    iget v0, v0, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    div-int/lit8 v5, v3, 0x2

    sub-int/2addr v2, v5

    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 1373
    iget-object v2, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->b:Landroid/widget/ImageView;

    add-int/2addr v4, v1

    add-int/2addr v3, v0

    invoke-virtual {v2, v1, v0, v4, v3}, Landroid/widget/ImageView;->layout(IIII)V

    .line 1374
    return-void
.end method

.method protected onMeasure(II)V
    .registers 13

    .prologue
    const/4 v3, 0x0

    .line 1311
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->a:Landroid/widget/ImageView;

    move-object v0, p0

    move v2, p1

    move v4, p2

    move v5, v3

    invoke-virtual/range {v0 .. v5}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->measureChildWithMargins(Landroid/view/View;IIII)V

    .line 1312
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->a:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/widget/FrameLayout$LayoutParams;

    .line 1313
    iget v1, v0, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    iget-object v2, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->a:Landroid/widget/ImageView;

    invoke-virtual {v2}, Landroid/widget/ImageView;->getMeasuredWidth()I

    move-result v2

    add-int/2addr v1, v2

    iget v2, v0, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    add-int/2addr v1, v2

    iput v1, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->c:I

    .line 1314
    iget-object v1, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->a:Landroid/widget/ImageView;

    invoke-virtual {v1}, Landroid/widget/ImageView;->getVisibility()I

    move-result v1

    const/16 v2, 0x8

    if-ne v1, v2, :cond_82

    move v7, v3

    .line 1315
    :goto_2b
    iget v1, v0, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    iget-object v2, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->a:Landroid/widget/ImageView;

    invoke-virtual {v2}, Landroid/widget/ImageView;->getMeasuredHeight()I

    move-result v2

    add-int/2addr v1, v2

    iget v0, v0, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    add-int/2addr v1, v0

    .line 1316
    iget-object v5, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->b:Landroid/widget/ImageView;

    move-object v4, p0

    move v6, p1

    move v8, p2

    move v9, v3

    invoke-virtual/range {v4 .. v9}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->measureChildWithMargins(Landroid/view/View;IIII)V

    .line 1317
    iget-object v0, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->b:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/widget/ImageView;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Landroid/widget/FrameLayout$LayoutParams;

    .line 1318
    iget v2, v0, Landroid/widget/FrameLayout$LayoutParams;->leftMargin:I

    iget-object v3, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->b:Landroid/widget/ImageView;

    invoke-virtual {v3}, Landroid/widget/ImageView;->getMeasuredWidth()I

    move-result v3

    add-int/2addr v2, v3

    iget v3, v0, Landroid/widget/FrameLayout$LayoutParams;->rightMargin:I

    add-int/2addr v2, v3

    add-int v3, v7, v2

    .line 1319
    iget v2, v0, Landroid/widget/FrameLayout$LayoutParams;->topMargin:I

    iget-object v4, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->b:Landroid/widget/ImageView;

    invoke-virtual {v4}, Landroid/widget/ImageView;->getMeasuredHeight()I

    move-result v4

    add-int/2addr v2, v4

    iget v0, v0, Landroid/widget/FrameLayout$LayoutParams;->bottomMargin:I

    add-int/2addr v0, v2

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v1

    .line 1322
    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v4

    .line 1323
    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v5

    .line 1324
    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v2

    .line 1325
    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result v0

    .line 1327
    sparse-switch v4, :sswitch_data_90

    move v2, v3

    .line 1333
    :goto_7a
    :sswitch_7a
    sparse-switch v5, :sswitch_data_9a

    move v0, v1

    .line 1344
    :goto_7e
    :sswitch_7e
    invoke-virtual {p0, v2, v0}, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->setMeasuredDimension(II)V

    .line 1350
    return-void

    .line 1314
    :cond_82
    iget v7, p0, Landroid/support/v7/internal/widget/ActionBarView$HomeView;->c:I

    goto :goto_2b

    .line 1329
    :sswitch_85
    invoke-static {v3, v2}, Ljava/lang/Math;->min(II)I

    move-result v2

    goto :goto_7a

    .line 1340
    :sswitch_8a
    invoke-static {v1, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    goto :goto_7e

    .line 1327
    nop

    :sswitch_data_90
    .sparse-switch
        -0x80000000 -> :sswitch_85
        0x40000000 -> :sswitch_7a
    .end sparse-switch

    .line 1333
    :sswitch_data_9a
    .sparse-switch
        -0x80000000 -> :sswitch_8a
        0x40000000 -> :sswitch_7e
    .end sparse-switch
.end method

###### Class android.support.v7.internal.widget.ActionBarView.SavedState (android.support.v7.internal.widget.ActionBarView$SavedState)
.class Landroid/support/v7/internal/widget/ActionBarView$SavedState;
.super Landroid/view/View$BaseSavedState;
.source "SourceFile"


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator",
            "<",
            "Landroid/support/v7/internal/widget/ActionBarView$SavedState;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field a:I

.field b:Z


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .prologue
    .line 1234
    new-instance v0, Landroid/support/v7/internal/widget/ActionBarView$SavedState$1;

    invoke-direct {v0}, Landroid/support/v7/internal/widget/ActionBarView$SavedState$1;-><init>()V

    sput-object v0, Landroid/support/v7/internal/widget/ActionBarView$SavedState;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method private constructor <init>(Landroid/os/Parcel;)V
    .registers 3

    .prologue
    .line 1222
    invoke-direct {p0, p1}, Landroid/view/View$BaseSavedState;-><init>(Landroid/os/Parcel;)V

    .line 1223
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Landroid/support/v7/internal/widget/ActionBarView$SavedState;->a:I

    .line 1224
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    if-eqz v0, :cond_13

    const/4 v0, 0x1

    :goto_10
    iput-boolean v0, p0, Landroid/support/v7/internal/widget/ActionBarView$SavedState;->b:Z

    .line 1225
    return-void

    .line 1224
    :cond_13
    const/4 v0, 0x0

    goto :goto_10
.end method

.method synthetic constructor <init>(Landroid/os/Parcel;B)V
    .registers 3

    .prologue
    .line 1212
    invoke-direct {p0, p1}, Landroid/support/v7/internal/widget/ActionBarView$SavedState;-><init>(Landroid/os/Parcel;)V

    return-void
.end method

.method constructor <init>(Landroid/os/Parcelable;)V
    .registers 2

    .prologue
    .line 1218
    invoke-direct {p0, p1}, Landroid/view/View$BaseSavedState;-><init>(Landroid/os/Parcelable;)V

    .line 1219
    return-void
.end method


# virtual methods
.method public writeToParcel(Landroid/os/Parcel;I)V
    .registers 4

    .prologue
    .line 1229
    invoke-super {p0, p1, p2}, Landroid/view/View$BaseSavedState;->writeToParcel(Landroid/os/Parcel;I)V

    .line 1230
    iget v0, p0, Landroid/support/v7/internal/widget/ActionBarView$SavedState;->a:I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 1231
    iget-boolean v0, p0, Landroid/support/v7/internal/widget/ActionBarView$SavedState;->b:Z

    if-eqz v0, :cond_11

    const/4 v0, 0x1

    :goto_d
    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 1232
    return-void

    .line 1231
    :cond_11
    const/4 v0, 0x0

    goto :goto_d
.end method

###### Class android.support.v7.internal.widget.ActionBarView.SavedState.AnonymousClass1 (android.support.v7.internal.widget.ActionBarView$SavedState$1)
.class final Landroid/support/v7/internal/widget/ActionBarView$SavedState$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/v7/internal/widget/ActionBarView$SavedState;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$Creator",
        "<",
        "Landroid/support/v7/internal/widget/ActionBarView$SavedState;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 1235
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .registers 4

    .prologue
    .line 1235
    new-instance v0, Landroid/support/v7/internal/widget/ActionBarView$SavedState;

    const/4 v1, 0x0

    invoke-direct {v0, p1, v1}, Landroid/support/v7/internal/widget/ActionBarView$SavedState;-><init>(Landroid/os/Parcel;B)V

    return-object v0
.end method

.method public final bridge synthetic newArray(I)[Ljava/lang/Object;
    .registers 3

    .prologue
    .line 1235
    new-array v0, p1, [Landroid/support/v7/internal/widget/ActionBarView$SavedState;

    return-object v0
.end method
