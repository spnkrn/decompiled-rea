###### Class android.support.v7.internal.widget.h (android.support.v7.internal.widget.h)
.class public interface abstract Landroid/support/v7/internal/widget/h;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()Z
.end method
