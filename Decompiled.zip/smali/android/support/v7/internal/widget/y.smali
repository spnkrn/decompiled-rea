###### Class android.support.v7.internal.widget.y (android.support.v7.internal.widget.y)
.class public interface abstract Landroid/support/v7/internal/widget/y;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Landroid/view/ActionMode$Callback;)Landroid/view/ActionMode$Callback;
.end method
