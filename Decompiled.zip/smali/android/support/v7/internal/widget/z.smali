###### Class android.support.v7.internal.widget.z (android.support.v7.internal.widget.z)
.class final Landroid/support/v7/internal/widget/z;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Landroid/support/v7/internal/widget/ProgressBarICS;

.field private b:I

.field private c:I

.field private d:Z


# direct methods
.method constructor <init>(Landroid/support/v7/internal/widget/ProgressBarICS;II)V
    .registers 5

    .prologue
    .line 396
    iput-object p1, p0, Landroid/support/v7/internal/widget/z;->a:Landroid/support/v7/internal/widget/ProgressBarICS;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 397
    iput p2, p0, Landroid/support/v7/internal/widget/z;->b:I

    .line 398
    iput p3, p0, Landroid/support/v7/internal/widget/z;->c:I

    .line 399
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v7/internal/widget/z;->d:Z

    .line 400
    return-void
.end method


# virtual methods
.method public final a(II)V
    .registers 4

    .prologue
    .line 409
    iput p1, p0, Landroid/support/v7/internal/widget/z;->b:I

    .line 410
    iput p2, p0, Landroid/support/v7/internal/widget/z;->c:I

    .line 411
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v7/internal/widget/z;->d:Z

    .line 412
    return-void
.end method

.method public final run()V
    .registers 5

    .prologue
    .line 403
    iget-object v0, p0, Landroid/support/v7/internal/widget/z;->a:Landroid/support/v7/internal/widget/ProgressBarICS;

    iget v1, p0, Landroid/support/v7/internal/widget/z;->b:I

    iget v2, p0, Landroid/support/v7/internal/widget/z;->c:I

    iget-boolean v3, p0, Landroid/support/v7/internal/widget/z;->d:Z

    invoke-static {v0, v1, v2}, Landroid/support/v7/internal/widget/ProgressBarICS;->a(Landroid/support/v7/internal/widget/ProgressBarICS;II)V

    .line 405
    iget-object v0, p0, Landroid/support/v7/internal/widget/z;->a:Landroid/support/v7/internal/widget/ProgressBarICS;

    invoke-static {v0, p0}, Landroid/support/v7/internal/widget/ProgressBarICS;->a(Landroid/support/v7/internal/widget/ProgressBarICS;Landroid/support/v7/internal/widget/z;)Landroid/support/v7/internal/widget/z;

    .line 406
    return-void
.end method
