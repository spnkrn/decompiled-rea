###### Class android.support.v7.internal.widget.m (android.support.v7.internal.widget.m)
.class final Landroid/support/v7/internal/widget/m;
.super Landroid/database/DataSetObserver;
.source "SourceFile"


# instance fields
.field final synthetic a:Landroid/support/v7/internal/widget/l;

.field private b:Landroid/os/Parcelable;


# direct methods
.method constructor <init>(Landroid/support/v7/internal/widget/l;)V
    .registers 3

    .prologue
    .line 796
    iput-object p1, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    invoke-direct {p0}, Landroid/database/DataSetObserver;-><init>()V

    .line 798
    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v7/internal/widget/m;->b:Landroid/os/Parcelable;

    return-void
.end method


# virtual methods
.method public final onChanged()V
    .registers 3

    .prologue
    .line 802
    iget-object v0, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    const/4 v1, 0x1

    iput-boolean v1, v0, Landroid/support/v7/internal/widget/l;->u:Z

    .line 803
    iget-object v0, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    iget-object v1, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    iget v1, v1, Landroid/support/v7/internal/widget/l;->z:I

    iput v1, v0, Landroid/support/v7/internal/widget/l;->A:I

    .line 804
    iget-object v0, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    iget-object v1, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    invoke-virtual {v1}, Landroid/support/v7/internal/widget/l;->c()Landroid/widget/Adapter;

    move-result-object v1

    invoke-interface {v1}, Landroid/widget/Adapter;->getCount()I

    move-result v1

    iput v1, v0, Landroid/support/v7/internal/widget/l;->z:I

    .line 808
    iget-object v0, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/l;->c()Landroid/widget/Adapter;

    move-result-object v0

    invoke-interface {v0}, Landroid/widget/Adapter;->hasStableIds()Z

    move-result v0

    if-eqz v0, :cond_4c

    iget-object v0, p0, Landroid/support/v7/internal/widget/m;->b:Landroid/os/Parcelable;

    if-eqz v0, :cond_4c

    iget-object v0, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    iget v0, v0, Landroid/support/v7/internal/widget/l;->A:I

    if-nez v0, :cond_4c

    iget-object v0, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    iget v0, v0, Landroid/support/v7/internal/widget/l;->z:I

    if-lez v0, :cond_4c

    .line 810
    iget-object v0, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    iget-object v1, p0, Landroid/support/v7/internal/widget/m;->b:Landroid/os/Parcelable;

    invoke-static {v0, v1}, Landroid/support/v7/internal/widget/l;->a(Landroid/support/v7/internal/widget/l;Landroid/os/Parcelable;)V

    .line 811
    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v7/internal/widget/m;->b:Landroid/os/Parcelable;

    .line 815
    :goto_41
    iget-object v0, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/l;->d()V

    .line 816
    iget-object v0, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/l;->requestLayout()V

    .line 817
    return-void

    .line 813
    :cond_4c
    iget-object v0, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/l;->g()V

    goto :goto_41
.end method

.method public final onInvalidated()V
    .registers 7

    .prologue
    const-wide/high16 v4, -0x8000000000000000L

    const/4 v3, 0x0

    const/4 v2, -0x1

    .line 821
    iget-object v0, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    const/4 v1, 0x1

    iput-boolean v1, v0, Landroid/support/v7/internal/widget/l;->u:Z

    .line 823
    iget-object v0, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/l;->c()Landroid/widget/Adapter;

    move-result-object v0

    invoke-interface {v0}, Landroid/widget/Adapter;->hasStableIds()Z

    move-result v0

    if-eqz v0, :cond_1d

    .line 826
    iget-object v0, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    invoke-static {v0}, Landroid/support/v7/internal/widget/l;->a(Landroid/support/v7/internal/widget/l;)Landroid/os/Parcelable;

    move-result-object v0

    iput-object v0, p0, Landroid/support/v7/internal/widget/m;->b:Landroid/os/Parcelable;

    .line 830
    :cond_1d
    iget-object v0, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    iget-object v1, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    iget v1, v1, Landroid/support/v7/internal/widget/l;->z:I

    iput v1, v0, Landroid/support/v7/internal/widget/l;->A:I

    .line 831
    iget-object v0, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    iput v3, v0, Landroid/support/v7/internal/widget/l;->z:I

    .line 832
    iget-object v0, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    iput v2, v0, Landroid/support/v7/internal/widget/l;->x:I

    .line 833
    iget-object v0, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    iput-wide v4, v0, Landroid/support/v7/internal/widget/l;->y:J

    .line 834
    iget-object v0, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    iput v2, v0, Landroid/support/v7/internal/widget/l;->v:I

    .line 835
    iget-object v0, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    iput-wide v4, v0, Landroid/support/v7/internal/widget/l;->w:J

    .line 836
    iget-object v0, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    iput-boolean v3, v0, Landroid/support/v7/internal/widget/l;->p:Z

    .line 838
    iget-object v0, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/l;->d()V

    .line 839
    iget-object v0, p0, Landroid/support/v7/internal/widget/m;->a:Landroid/support/v7/internal/widget/l;

    invoke-virtual {v0}, Landroid/support/v7/internal/widget/l;->requestLayout()V

    .line 840
    return-void
.end method
