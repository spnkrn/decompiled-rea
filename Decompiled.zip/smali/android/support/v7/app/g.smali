###### Class android.support.v7.app.g (android.support.v7.app.g)
.class Landroid/support/v7/app/g;
.super Landroid/support/v7/app/d;
.source "SourceFile"


# instance fields
.field d:Landroid/view/Menu;


# direct methods
.method constructor <init>(Landroid/support/v7/app/ActionBarActivity;)V
    .registers 2

    .prologue
    .line 41
    invoke-direct {p0, p1}, Landroid/support/v7/app/d;-><init>(Landroid/support/v7/app/ActionBarActivity;)V

    .line 42
    return-void
.end method


# virtual methods
.method public a()Landroid/support/v7/app/ActionBar;
    .registers 4

    .prologue
    .line 46
    new-instance v0, Landroid/support/v7/app/n;

    iget-object v1, p0, Landroid/support/v7/app/g;->a:Landroid/support/v7/app/ActionBarActivity;

    iget-object v2, p0, Landroid/support/v7/app/g;->a:Landroid/support/v7/app/ActionBarActivity;

    invoke-direct {v0, v1, v2}, Landroid/support/v7/app/n;-><init>(Landroid/app/Activity;Landroid/support/v7/app/a;)V

    return-object v0
.end method

.method a(Landroid/content/Context;Landroid/view/ActionMode;)Landroid/support/v7/internal/view/b;
    .registers 4

    .prologue
    .line 246
    new-instance v0, Landroid/support/v7/internal/view/b;

    invoke-direct {v0, p1, p2}, Landroid/support/v7/internal/view/b;-><init>(Landroid/content/Context;Landroid/view/ActionMode;)V

    return-object v0
.end method

.method public final a(I)V
    .registers 3

    .prologue
    .line 110
    iget-object v0, p0, Landroid/support/v7/app/g;->a:Landroid/support/v7/app/ActionBarActivity;

    invoke-virtual {v0, p1}, Landroid/support/v7/app/ActionBarActivity;->a(I)V

    .line 111
    return-void
.end method

.method public final a(Landroid/os/Bundle;)V
    .registers 5

    .prologue
    const/4 v2, 0x1

    .line 52
    const-string v0, "splitActionBarWhenNarrow"

    invoke-virtual {p0}, Landroid/support/v7/app/g;->j()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_16

    .line 53
    iget-object v0, p0, Landroid/support/v7/app/g;->a:Landroid/support/v7/app/ActionBarActivity;

    invoke-virtual {v0}, Landroid/support/v7/app/ActionBarActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    invoke-virtual {v0, v2, v2}, Landroid/view/Window;->setUiOptions(II)V

    .line 57
    :cond_16
    invoke-super {p0, p1}, Landroid/support/v7/app/d;->a(Landroid/os/Bundle;)V

    .line 59
    iget-boolean v0, p0, Landroid/support/v7/app/g;->b:Z

    if-eqz v0, :cond_24

    .line 62
    iget-object v0, p0, Landroid/support/v7/app/g;->a:Landroid/support/v7/app/ActionBarActivity;

    const/16 v1, 0x8

    invoke-virtual {v0, v1}, Landroid/support/v7/app/ActionBarActivity;->requestWindowFeature(I)Z

    .line 64
    :cond_24
    iget-boolean v0, p0, Landroid/support/v7/app/g;->c:Z

    if-eqz v0, :cond_2f

    .line 65
    iget-object v0, p0, Landroid/support/v7/app/g;->a:Landroid/support/v7/app/ActionBarActivity;

    const/16 v1, 0x9

    invoke-virtual {v0, v1}, Landroid/support/v7/app/ActionBarActivity;->requestWindowFeature(I)Z

    .line 83
    :cond_2f
    iget-object v0, p0, Landroid/support/v7/app/g;->a:Landroid/support/v7/app/ActionBarActivity;

    invoke-virtual {v0}, Landroid/support/v7/app/ActionBarActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    .line 84
    invoke-virtual {v0}, Landroid/view/Window;->getCallback()Landroid/view/Window$Callback;

    move-result-object v1

    new-instance v2, Landroid/support/v7/app/h;

    invoke-direct {v2, p0, v1}, Landroid/support/v7/app/h;-><init>(Landroid/support/v7/app/g;Landroid/view/Window$Callback;)V

    invoke-virtual {v0, v2}, Landroid/view/Window;->setCallback(Landroid/view/Window$Callback;)V

    .line 85
    return-void
.end method

.method public final a(Landroid/view/ActionMode;)V
    .registers 3

    .prologue
    .line 195
    iget-object v0, p0, Landroid/support/v7/app/g;->a:Landroid/support/v7/app/ActionBarActivity;

    invoke-virtual {p0}, Landroid/support/v7/app/g;->k()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {p0, v0, p1}, Landroid/support/v7/app/g;->a(Landroid/content/Context;Landroid/view/ActionMode;)Landroid/support/v7/internal/view/b;

    .line 197
    return-void
.end method

.method public final a(Landroid/view/View;)V
    .registers 3

    .prologue
    .line 105
    iget-object v0, p0, Landroid/support/v7/app/g;->a:Landroid/support/v7/app/ActionBarActivity;

    invoke-virtual {v0, p1}, Landroid/support/v7/app/ActionBarActivity;->a(Landroid/view/View;)V

    .line 106
    return-void
.end method

.method public final a(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .registers 4

    .prologue
    .line 115
    iget-object v0, p0, Landroid/support/v7/app/g;->a:Landroid/support/v7/app/ActionBarActivity;

    invoke-virtual {v0, p1, p2}, Landroid/support/v7/app/ActionBarActivity;->a(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 116
    return-void
.end method

.method public final a(Ljava/lang/CharSequence;)V
    .registers 2

    .prologue
    .line 170
    return-void
.end method

.method public final a(ILandroid/view/Menu;)Z
    .registers 5

    .prologue
    .line 142
    if-eqz p1, :cond_6

    const/16 v0, 0x8

    if-ne p1, v0, :cond_19

    .line 143
    :cond_6
    iget-object v0, p0, Landroid/support/v7/app/g;->d:Landroid/view/Menu;

    if-nez v0, :cond_10

    .line 144
    invoke-static {p2}, Landroid/support/v7/internal/view/menu/ae;->a(Landroid/view/Menu;)Landroid/view/Menu;

    move-result-object v0

    iput-object v0, p0, Landroid/support/v7/app/g;->d:Landroid/view/Menu;

    .line 146
    :cond_10
    iget-object v0, p0, Landroid/support/v7/app/g;->a:Landroid/support/v7/app/ActionBarActivity;

    iget-object v1, p0, Landroid/support/v7/app/g;->d:Landroid/view/Menu;

    invoke-virtual {v0, p1, v1}, Landroid/support/v7/app/ActionBarActivity;->a(ILandroid/view/Menu;)Z

    move-result v0

    .line 148
    :goto_18
    return v0

    :cond_19
    iget-object v0, p0, Landroid/support/v7/app/g;->a:Landroid/support/v7/app/ActionBarActivity;

    invoke-virtual {v0, p1, p2}, Landroid/support/v7/app/ActionBarActivity;->a(ILandroid/view/Menu;)Z

    move-result v0

    goto :goto_18
.end method

.method public final a(ILandroid/view/MenuItem;)Z
    .registers 4

    .prologue
    .line 161
    if-nez p1, :cond_6

    .line 162
    invoke-static {p2}, Landroid/support/v7/internal/view/menu/ae;->a(Landroid/view/MenuItem;)Landroid/view/MenuItem;

    move-result-object p2

    .line 164
    :cond_6
    iget-object v0, p0, Landroid/support/v7/app/g;->a:Landroid/support/v7/app/ActionBarActivity;

    invoke-virtual {v0, p1, p2}, Landroid/support/v7/app/ActionBarActivity;->a(ILandroid/view/MenuItem;)Z

    move-result v0

    return v0
.end method

.method public final a(ILandroid/view/View;Landroid/view/Menu;)Z
    .registers 6

    .prologue
    .line 153
    if-eqz p1, :cond_6

    const/16 v0, 0x8

    if-ne p1, v0, :cond_f

    .line 154
    :cond_6
    iget-object v0, p0, Landroid/support/v7/app/g;->a:Landroid/support/v7/app/ActionBarActivity;

    iget-object v1, p0, Landroid/support/v7/app/g;->d:Landroid/view/Menu;

    invoke-virtual {v0, p1, p2, v1}, Landroid/support/v7/app/ActionBarActivity;->a(ILandroid/view/View;Landroid/view/Menu;)Z

    move-result v0

    .line 156
    :goto_e
    return v0

    :cond_f
    iget-object v0, p0, Landroid/support/v7/app/g;->a:Landroid/support/v7/app/ActionBarActivity;

    invoke-virtual {v0, p1, p2, p3}, Landroid/support/v7/app/ActionBarActivity;->a(ILandroid/view/View;Landroid/view/Menu;)Z

    move-result v0

    goto :goto_e
.end method

.method public final b(I)Landroid/view/View;
    .registers 3

    .prologue
    .line 137
    const/4 v0, 0x0

    return-object v0
.end method

.method public final b(Landroid/view/ActionMode;)V
    .registers 3

    .prologue
    .line 220
    iget-object v0, p0, Landroid/support/v7/app/g;->a:Landroid/support/v7/app/ActionBarActivity;

    invoke-virtual {p0}, Landroid/support/v7/app/g;->k()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {p0, v0, p1}, Landroid/support/v7/app/g;->a(Landroid/content/Context;Landroid/view/ActionMode;)Landroid/support/v7/internal/view/b;

    .line 222
    return-void
.end method

.method public final b(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .registers 4

    .prologue
    .line 120
    iget-object v0, p0, Landroid/support/v7/app/g;->a:Landroid/support/v7/app/ActionBarActivity;

    invoke-virtual {v0, p1, p2}, Landroid/support/v7/app/ActionBarActivity;->b(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 121
    return-void
.end method

.method public final d()V
    .registers 1

    .prologue
    .line 93
    return-void
.end method

.method public final e()V
    .registers 1

    .prologue
    .line 97
    return-void
.end method

.method public final f()V
    .registers 1

    .prologue
    .line 101
    return-void
.end method

.method public final g()V
    .registers 2

    .prologue
    .line 226
    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v7/app/g;->d:Landroid/view/Menu;

    .line 227
    return-void
.end method

.method public final h()Z
    .registers 2

    .prologue
    .line 231
    const/4 v0, 0x0

    return v0
.end method

.method public final i()V
    .registers 2

    .prologue
    .line 126
    iget-object v0, p0, Landroid/support/v7/app/g;->a:Landroid/support/v7/app/ActionBarActivity;

    .line 127
    return-void
.end method
