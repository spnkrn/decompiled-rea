###### Class android.support.v7.app.n (android.support.v7.app.n)
.class Landroid/support/v7/app/n;
.super Landroid/support/v7/app/ActionBar;
.source "SourceFile"


# instance fields
.field final a:Landroid/app/Activity;

.field final b:Landroid/support/v7/app/a;

.field final c:Landroid/app/ActionBar;

.field private d:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>(Landroid/app/Activity;Landroid/support/v7/app/a;)V
    .registers 4

    .prologue
    .line 46
    const/4 v0, 0x1

    invoke-direct {p0, p1, p2, v0}, Landroid/support/v7/app/n;-><init>(Landroid/app/Activity;Landroid/support/v7/app/a;Z)V

    .line 47
    return-void
.end method

.method constructor <init>(Landroid/app/Activity;Landroid/support/v7/app/a;Z)V
    .registers 5

    .prologue
    .line 49
    invoke-direct {p0}, Landroid/support/v7/app/ActionBar;-><init>()V

    .line 42
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroid/support/v7/app/n;->d:Ljava/util/ArrayList;

    .line 50
    iput-object p1, p0, Landroid/support/v7/app/n;->a:Landroid/app/Activity;

    .line 51
    iput-object p2, p0, Landroid/support/v7/app/n;->b:Landroid/support/v7/app/a;

    .line 52
    invoke-virtual {p1}, Landroid/app/Activity;->getActionBar()Landroid/app/ActionBar;

    move-result-object v0

    iput-object v0, p0, Landroid/support/v7/app/n;->c:Landroid/app/ActionBar;

    .line 54
    if-eqz p3, :cond_22

    .line 57
    invoke-virtual {p0}, Landroid/support/v7/app/n;->b()I

    move-result v0

    and-int/lit8 v0, v0, 0x4

    if-eqz v0, :cond_22

    .line 58
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroid/support/v7/app/n;->c(Z)V

    .line 61
    :cond_22
    return-void
.end method


# virtual methods
.method public a()Landroid/view/View;
    .registers 2

    .prologue
    .line 209
    iget-object v0, p0, Landroid/support/v7/app/n;->c:Landroid/app/ActionBar;

    invoke-virtual {v0}, Landroid/app/ActionBar;->getCustomView()Landroid/view/View;

    move-result-object v0

    return-object v0
.end method

.method public a(I)V
    .registers 3

    .prologue
    .line 93
    iget-object v0, p0, Landroid/support/v7/app/n;->c:Landroid/app/ActionBar;

    invoke-virtual {v0, p1}, Landroid/app/ActionBar;->setCustomView(I)V

    .line 94
    return-void
.end method

.method public a(Landroid/graphics/drawable/Drawable;)V
    .registers 3

    .prologue
    .line 103
    iget-object v0, p0, Landroid/support/v7/app/n;->c:Landroid/app/ActionBar;

    invoke-virtual {v0, p1}, Landroid/app/ActionBar;->setIcon(Landroid/graphics/drawable/Drawable;)V

    .line 104
    return-void
.end method

.method public a(Landroid/view/View;)V
    .registers 3

    .prologue
    .line 79
    iget-object v0, p0, Landroid/support/v7/app/n;->c:Landroid/app/ActionBar;

    invoke-virtual {v0, p1}, Landroid/app/ActionBar;->setCustomView(Landroid/view/View;)V

    .line 80
    return-void
.end method

.method public a(Ljava/lang/CharSequence;)V
    .registers 3

    .prologue
    .line 139
    iget-object v0, p0, Landroid/support/v7/app/n;->c:Landroid/app/ActionBar;

    invoke-virtual {v0, p1}, Landroid/app/ActionBar;->setTitle(Ljava/lang/CharSequence;)V

    .line 140
    return-void
.end method

.method public a(Z)V
    .registers 3

    .prologue
    .line 179
    iget-object v0, p0, Landroid/support/v7/app/n;->c:Landroid/app/ActionBar;

    invoke-virtual {v0, p1}, Landroid/app/ActionBar;->setDisplayHomeAsUpEnabled(Z)V

    .line 180
    return-void
.end method

.method public b()I
    .registers 2

    .prologue
    .line 234
    iget-object v0, p0, Landroid/support/v7/app/n;->c:Landroid/app/ActionBar;

    invoke-virtual {v0}, Landroid/app/ActionBar;->getDisplayOptions()I

    move-result v0

    return v0
.end method

.method public b(Landroid/graphics/drawable/Drawable;)V
    .registers 3

    .prologue
    .line 194
    iget-object v0, p0, Landroid/support/v7/app/n;->c:Landroid/app/ActionBar;

    invoke-virtual {v0, p1}, Landroid/app/ActionBar;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 195
    return-void
.end method

.method public b(Z)V
    .registers 3

    .prologue
    .line 189
    iget-object v0, p0, Landroid/support/v7/app/n;->c:Landroid/app/ActionBar;

    invoke-virtual {v0, p1}, Landroid/app/ActionBar;->setDisplayShowCustomEnabled(Z)V

    .line 190
    return-void
.end method

.method public c()Landroid/content/Context;
    .registers 2

    .prologue
    .line 302
    iget-object v0, p0, Landroid/support/v7/app/n;->c:Landroid/app/ActionBar;

    invoke-virtual {v0}, Landroid/app/ActionBar;->getThemedContext()Landroid/content/Context;

    move-result-object v0

    return-object v0
.end method

.method public c(Z)V
    .registers 3

    .prologue
    .line 365
    iget-object v0, p0, Landroid/support/v7/app/n;->c:Landroid/app/ActionBar;

    invoke-virtual {v0, p1}, Landroid/app/ActionBar;->setHomeButtonEnabled(Z)V

    .line 366
    return-void
.end method
