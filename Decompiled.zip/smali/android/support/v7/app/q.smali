###### Class android.support.v7.app.q (android.support.v7.app.q)
.class final Landroid/support/v7/app/q;
.super Lcom/spotify/mobile/android/util/ui/b;
.source "SourceFile"


# direct methods
.method public constructor <init>(Landroid/view/Window$Callback;)V
    .registers 2

    .prologue
    .line 89
    invoke-direct {p0, p1}, Lcom/spotify/mobile/android/util/ui/b;-><init>(Landroid/view/Window$Callback;)V

    .line 90
    return-void
.end method


# virtual methods
.method public final onMenuItemSelected(ILandroid/view/MenuItem;)Z
    .registers 5

    .prologue
    .line 96
    invoke-interface {p2}, Landroid/view/MenuItem;->getTitleCondensed()Ljava/lang/CharSequence;

    move-result-object v0

    .line 97
    if-eqz v0, :cond_15

    .line 98
    invoke-interface {v0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-interface {p2, v1}, Landroid/view/MenuItem;->setTitleCondensed(Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    .line 102
    :cond_d
    :goto_d
    invoke-super {p0, p1, p2}, Lcom/spotify/mobile/android/util/ui/b;->onMenuItemSelected(ILandroid/view/MenuItem;)Z

    move-result v1

    .line 104
    invoke-interface {p2, v0}, Landroid/view/MenuItem;->setTitleCondensed(Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    .line 105
    return v1

    .line 99
    :cond_15
    invoke-interface {p2}, Landroid/view/MenuItem;->getTitle()Ljava/lang/CharSequence;

    move-result-object v1

    if-eqz v1, :cond_d

    .line 100
    invoke-interface {p2}, Landroid/view/MenuItem;->getTitle()Ljava/lang/CharSequence;

    move-result-object v1

    invoke-interface {v1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-interface {p2, v1}, Landroid/view/MenuItem;->setTitleCondensed(Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    goto :goto_d
.end method
