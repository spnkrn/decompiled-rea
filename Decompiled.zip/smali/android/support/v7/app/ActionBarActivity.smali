###### Class android.support.v7.app.ActionBarActivity (android.support.v7.app.ActionBarActivity)
.class public Landroid/support/v7/app/ActionBarActivity;
.super Landroid/support/v4/app/FragmentActivity;
.source "SourceFile"

# interfaces
.implements Landroid/support/v4/app/al;
.implements Landroid/support/v7/app/a;


# instance fields
.field n:Landroid/support/v7/app/d;


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 54
    invoke-direct {p0}, Landroid/support/v4/app/FragmentActivity;-><init>()V

    return-void
.end method

.method private f()Z
    .registers 3

    .prologue
    .line 382
    invoke-static {p0}, Landroid/support/v4/app/r;->a(Landroid/app/Activity;)Landroid/content/Intent;

    move-result-object v0

    .line 384
    if-eqz v0, :cond_2e

    .line 385
    invoke-static {p0, v0}, Landroid/support/v4/app/r;->a(Landroid/app/Activity;Landroid/content/Intent;)Z

    move-result v1

    if-eqz v1, :cond_2a

    .line 386
    invoke-static {p0}, Landroid/support/v4/app/ak;->a(Landroid/content/Context;)Landroid/support/v4/app/ak;

    move-result-object v0

    .line 387
    invoke-virtual {v0, p0}, Landroid/support/v4/app/ak;->a(Landroid/app/Activity;)Landroid/support/v4/app/ak;

    .line 388
    invoke-virtual {v0}, Landroid/support/v4/app/ak;->a()V

    .line 392
    :try_start_16
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x10

    if-lt v0, v1, :cond_21

    invoke-virtual {p0}, Landroid/app/Activity;->finishAffinity()V

    .line 403
    :goto_1f
    const/4 v0, 0x1

    .line 405
    :goto_20
    return v0

    .line 392
    :cond_21
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V
    :try_end_24
    .catch Ljava/lang/IllegalStateException; {:try_start_16 .. :try_end_24} :catch_25

    goto :goto_1f

    .line 396
    :catch_25
    move-exception v0

    invoke-virtual {p0}, Landroid/support/v7/app/ActionBarActivity;->finish()V

    goto :goto_1f

    .line 401
    :cond_2a
    invoke-static {p0, v0}, Landroid/support/v4/app/r;->b(Landroid/app/Activity;Landroid/content/Intent;)V

    goto :goto_1f

    .line 405
    :cond_2e
    const/4 v0, 0x0

    goto :goto_20
.end method


# virtual methods
.method final a(I)V
    .registers 2

    .prologue
    .line 216
    invoke-super {p0, p1}, Landroid/support/v4/app/FragmentActivity;->setContentView(I)V

    .line 217
    return-void
.end method

.method final a(Landroid/view/View;)V
    .registers 2

    .prologue
    .line 220
    invoke-super {p0, p1}, Landroid/support/v4/app/FragmentActivity;->setContentView(Landroid/view/View;)V

    .line 221
    return-void
.end method

.method final a(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .registers 3

    .prologue
    .line 224
    invoke-super {p0, p1, p2}, Landroid/support/v4/app/FragmentActivity;->setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 225
    return-void
.end method

.method a(ILandroid/view/Menu;)Z
    .registers 4

    .prologue
    .line 232
    invoke-super {p0, p1, p2}, Landroid/support/v4/app/FragmentActivity;->onCreatePanelMenu(ILandroid/view/Menu;)Z

    move-result v0

    return v0
.end method

.method final a(ILandroid/view/MenuItem;)Z
    .registers 4

    .prologue
    .line 244
    invoke-super {p0, p1, p2}, Landroid/support/v4/app/FragmentActivity;->onMenuItemSelected(ILandroid/view/MenuItem;)Z

    move-result v0

    return v0
.end method

.method final a(ILandroid/view/View;Landroid/view/Menu;)Z
    .registers 5

    .prologue
    .line 236
    invoke-super {p0, p1, p2, p3}, Landroid/support/v4/app/FragmentActivity;->onPreparePanel(ILandroid/view/View;Landroid/view/Menu;)Z

    move-result v0

    return v0
.end method

.method protected final a(Landroid/view/View;Landroid/view/Menu;)Z
    .registers 6

    .prologue
    .line 212
    iget-object v0, p0, Landroid/support/v7/app/ActionBarActivity;->n:Landroid/support/v7/app/d;

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x10

    if-ge v1, v2, :cond_f

    iget-object v0, v0, Landroid/support/v7/app/d;->a:Landroid/support/v7/app/ActionBarActivity;

    invoke-virtual {v0, p2}, Landroid/support/v7/app/ActionBarActivity;->onPrepareOptionsMenu(Landroid/view/Menu;)Z

    move-result v0

    :goto_e
    return v0

    :cond_f
    iget-object v0, v0, Landroid/support/v7/app/d;->a:Landroid/support/v7/app/ActionBarActivity;

    invoke-super {v0, p1, p2}, Landroid/support/v4/app/FragmentActivity;->a(Landroid/view/View;Landroid/view/Menu;)Z

    move-result v0

    goto :goto_e
.end method

.method public final a_()Landroid/content/Intent;
    .registers 2

    .prologue
    .line 418
    invoke-static {p0}, Landroid/support/v4/app/r;->a(Landroid/app/Activity;)Landroid/content/Intent;

    move-result-object v0

    return-object v0
.end method

.method public addContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .registers 4

    .prologue
    .line 91
    iget-object v0, p0, Landroid/support/v7/app/ActionBarActivity;->n:Landroid/support/v7/app/d;

    invoke-virtual {v0, p1, p2}, Landroid/support/v7/app/d;->b(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 92
    return-void
.end method

.method final b(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .registers 3

    .prologue
    .line 228
    invoke-super {p0, p1, p2}, Landroid/support/v4/app/FragmentActivity;->addContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 229
    return-void
.end method

.method public final e()Landroid/support/v7/app/ActionBar;
    .registers 2

    .prologue
    .line 66
    iget-object v0, p0, Landroid/support/v7/app/ActionBarActivity;->n:Landroid/support/v7/app/d;

    invoke-virtual {v0}, Landroid/support/v7/app/d;->b()Landroid/support/v7/app/ActionBar;

    move-result-object v0

    return-object v0
.end method

.method public getMenuInflater()Landroid/view/MenuInflater;
    .registers 2

    .prologue
    .line 71
    iget-object v0, p0, Landroid/support/v7/app/ActionBarActivity;->n:Landroid/support/v7/app/d;

    invoke-virtual {v0}, Landroid/support/v7/app/d;->c()Landroid/view/MenuInflater;

    move-result-object v0

    return-object v0
.end method

.method public onBackPressed()V
    .registers 2

    .prologue
    .line 249
    iget-object v0, p0, Landroid/support/v7/app/ActionBarActivity;->n:Landroid/support/v7/app/d;

    invoke-virtual {v0}, Landroid/support/v7/app/d;->h()Z

    move-result v0

    if-nez v0, :cond_b

    .line 250
    invoke-super {p0}, Landroid/support/v4/app/FragmentActivity;->onBackPressed()V

    .line 252
    :cond_b
    return-void
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .registers 3

    .prologue
    .line 103
    invoke-super {p0, p1}, Landroid/support/v4/app/FragmentActivity;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    .line 104
    iget-object v0, p0, Landroid/support/v7/app/ActionBarActivity;->n:Landroid/support/v7/app/d;

    invoke-virtual {v0}, Landroid/support/v7/app/d;->d()V

    .line 105
    return-void
.end method

.method public final onContentChanged()V
    .registers 2

    .prologue
    .line 463
    iget-object v0, p0, Landroid/support/v7/app/ActionBarActivity;->n:Landroid/support/v7/app/d;

    invoke-virtual {v0}, Landroid/support/v7/app/d;->i()V

    .line 464
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .registers 4

    .prologue
    .line 96
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x12

    if-lt v0, v1, :cond_16

    new-instance v0, Landroid/support/v7/app/j;

    invoke-direct {v0, p0}, Landroid/support/v7/app/j;-><init>(Landroid/support/v7/app/ActionBarActivity;)V

    :goto_b
    iput-object v0, p0, Landroid/support/v7/app/ActionBarActivity;->n:Landroid/support/v7/app/d;

    .line 97
    invoke-super {p0, p1}, Landroid/support/v4/app/FragmentActivity;->onCreate(Landroid/os/Bundle;)V

    .line 98
    iget-object v0, p0, Landroid/support/v7/app/ActionBarActivity;->n:Landroid/support/v7/app/d;

    invoke-virtual {v0, p1}, Landroid/support/v7/app/d;->a(Landroid/os/Bundle;)V

    .line 99
    return-void

    .line 96
    :cond_16
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x10

    if-lt v0, v1, :cond_22

    new-instance v0, Landroid/support/v7/app/i;

    invoke-direct {v0, p0}, Landroid/support/v7/app/i;-><init>(Landroid/support/v7/app/ActionBarActivity;)V

    goto :goto_b

    :cond_22
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0xe

    if-lt v0, v1, :cond_2e

    new-instance v0, Landroid/support/v7/app/g;

    invoke-direct {v0, p0}, Landroid/support/v7/app/g;-><init>(Landroid/support/v7/app/ActionBarActivity;)V

    goto :goto_b

    :cond_2e
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0xb

    if-lt v0, v1, :cond_3a

    new-instance v0, Landroid/support/v7/app/f;

    invoke-direct {v0, p0}, Landroid/support/v7/app/f;-><init>(Landroid/support/v7/app/ActionBarActivity;)V

    goto :goto_b

    :cond_3a
    new-instance v0, Landroid/support/v7/app/e;

    invoke-direct {v0, p0}, Landroid/support/v7/app/e;-><init>(Landroid/support/v7/app/ActionBarActivity;)V

    goto :goto_b
.end method

.method public onCreatePanelMenu(ILandroid/view/Menu;)Z
    .registers 4

    .prologue
    .line 199
    iget-object v0, p0, Landroid/support/v7/app/ActionBarActivity;->n:Landroid/support/v7/app/d;

    invoke-virtual {v0, p1, p2}, Landroid/support/v7/app/d;->a(ILandroid/view/Menu;)Z

    move-result v0

    return v0
.end method

.method public onCreatePanelView(I)Landroid/view/View;
    .registers 3

    .prologue
    .line 121
    if-nez p1, :cond_9

    .line 122
    iget-object v0, p0, Landroid/support/v7/app/ActionBarActivity;->n:Landroid/support/v7/app/d;

    invoke-virtual {v0, p1}, Landroid/support/v7/app/d;->b(I)Landroid/view/View;

    move-result-object v0

    .line 124
    :goto_8
    return-object v0

    :cond_9
    invoke-super {p0, p1}, Landroid/support/v4/app/FragmentActivity;->onCreatePanelView(I)Landroid/view/View;

    move-result-object v0

    goto :goto_8
.end method

.method public final onMenuItemSelected(ILandroid/view/MenuItem;)Z
    .registers 6

    .prologue
    .line 130
    iget-object v0, p0, Landroid/support/v7/app/ActionBarActivity;->n:Landroid/support/v7/app/d;

    invoke-virtual {v0, p1, p2}, Landroid/support/v7/app/d;->a(ILandroid/view/MenuItem;)Z

    move-result v0

    if-eqz v0, :cond_a

    .line 131
    const/4 v0, 0x1

    .line 139
    :goto_9
    return v0

    .line 134
    :cond_a
    iget-object v0, p0, Landroid/support/v7/app/ActionBarActivity;->n:Landroid/support/v7/app/d;

    invoke-virtual {v0}, Landroid/support/v7/app/d;->b()Landroid/support/v7/app/ActionBar;

    move-result-object v0

    .line 135
    invoke-interface {p2}, Landroid/view/MenuItem;->getItemId()I

    move-result v1

    const v2, 0x102002c

    if-ne v1, v2, :cond_28

    if-eqz v0, :cond_28

    invoke-virtual {v0}, Landroid/support/v7/app/ActionBar;->b()I

    move-result v0

    and-int/lit8 v0, v0, 0x4

    if-eqz v0, :cond_28

    .line 137
    invoke-direct {p0}, Landroid/support/v7/app/ActionBarActivity;->f()Z

    move-result v0

    goto :goto_9

    .line 139
    :cond_28
    const/4 v0, 0x0

    goto :goto_9
.end method

.method protected onPostResume()V
    .registers 2

    .prologue
    .line 115
    invoke-super {p0}, Landroid/support/v4/app/FragmentActivity;->onPostResume()V

    .line 116
    iget-object v0, p0, Landroid/support/v7/app/ActionBarActivity;->n:Landroid/support/v7/app/d;

    invoke-virtual {v0}, Landroid/support/v7/app/d;->f()V

    .line 117
    return-void
.end method

.method public onPreparePanel(ILandroid/view/View;Landroid/view/Menu;)Z
    .registers 5

    .prologue
    .line 204
    iget-object v0, p0, Landroid/support/v7/app/ActionBarActivity;->n:Landroid/support/v7/app/d;

    invoke-virtual {v0, p1, p2, p3}, Landroid/support/v7/app/d;->a(ILandroid/view/View;Landroid/view/Menu;)Z

    move-result v0

    return v0
.end method

.method protected onStop()V
    .registers 2

    .prologue
    .line 109
    invoke-super {p0}, Landroid/support/v4/app/FragmentActivity;->onStop()V

    .line 110
    iget-object v0, p0, Landroid/support/v7/app/ActionBarActivity;->n:Landroid/support/v7/app/d;

    invoke-virtual {v0}, Landroid/support/v7/app/d;->e()V

    .line 111
    return-void
.end method

.method protected onTitleChanged(Ljava/lang/CharSequence;I)V
    .registers 4

    .prologue
    .line 144
    invoke-super {p0, p1, p2}, Landroid/support/v4/app/FragmentActivity;->onTitleChanged(Ljava/lang/CharSequence;I)V

    .line 145
    iget-object v0, p0, Landroid/support/v7/app/ActionBarActivity;->n:Landroid/support/v7/app/d;

    invoke-virtual {v0, p1}, Landroid/support/v7/app/d;->a(Ljava/lang/CharSequence;)V

    .line 146
    return-void
.end method

.method public setContentView(I)V
    .registers 3

    .prologue
    .line 76
    iget-object v0, p0, Landroid/support/v7/app/ActionBarActivity;->n:Landroid/support/v7/app/d;

    invoke-virtual {v0, p1}, Landroid/support/v7/app/d;->a(I)V

    .line 77
    return-void
.end method

.method public setContentView(Landroid/view/View;)V
    .registers 3

    .prologue
    .line 81
    iget-object v0, p0, Landroid/support/v7/app/ActionBarActivity;->n:Landroid/support/v7/app/d;

    invoke-virtual {v0, p1}, Landroid/support/v7/app/d;->a(Landroid/view/View;)V

    .line 82
    return-void
.end method

.method public setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .registers 4

    .prologue
    .line 86
    iget-object v0, p0, Landroid/support/v7/app/ActionBarActivity;->n:Landroid/support/v7/app/d;

    invoke-virtual {v0, p1, p2}, Landroid/support/v7/app/d;->a(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    .line 87
    return-void
.end method

.method public final w_()V
    .registers 3

    .prologue
    .line 169
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0xe

    if-lt v0, v1, :cond_9

    .line 170
    invoke-super {p0}, Landroid/support/v4/app/FragmentActivity;->w_()V

    .line 172
    :cond_9
    iget-object v0, p0, Landroid/support/v7/app/ActionBarActivity;->n:Landroid/support/v7/app/d;

    invoke-virtual {v0}, Landroid/support/v7/app/d;->g()V

    .line 173
    return-void
.end method
