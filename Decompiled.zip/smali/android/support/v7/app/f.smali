###### Class android.support.v7.app.f (android.support.v7.app.f)
.class final Landroid/support/v7/app/f;
.super Landroid/support/v7/app/e;
.source "SourceFile"


# direct methods
.method constructor <init>(Landroid/support/v7/app/ActionBarActivity;)V
    .registers 2

    .prologue
    .line 22
    invoke-direct {p0, p1}, Landroid/support/v7/app/e;-><init>(Landroid/support/v7/app/ActionBarActivity;)V

    .line 23
    return-void
.end method


# virtual methods
.method public final a()Landroid/support/v7/app/ActionBar;
    .registers 4

    .prologue
    .line 27
    invoke-virtual {p0}, Landroid/support/v7/app/f;->l()V

    .line 28
    new-instance v0, Landroid/support/v7/app/l;

    iget-object v1, p0, Landroid/support/v7/app/f;->a:Landroid/support/v7/app/ActionBarActivity;

    iget-object v2, p0, Landroid/support/v7/app/f;->a:Landroid/support/v7/app/ActionBarActivity;

    invoke-direct {v0, v1, v2}, Landroid/support/v7/app/l;-><init>(Landroid/support/v7/app/ActionBarActivity;Landroid/support/v7/app/a;)V

    return-object v0
.end method
