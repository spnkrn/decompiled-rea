###### Class android.support.v7.app.j (android.support.v7.app.j)
.class final Landroid/support/v7/app/j;
.super Landroid/support/v7/app/i;
.source "SourceFile"


# direct methods
.method constructor <init>(Landroid/support/v7/app/ActionBarActivity;)V
    .registers 2

    .prologue
    .line 22
    invoke-direct {p0, p1}, Landroid/support/v7/app/i;-><init>(Landroid/support/v7/app/ActionBarActivity;)V

    .line 23
    return-void
.end method


# virtual methods
.method public final a()Landroid/support/v7/app/ActionBar;
    .registers 4

    .prologue
    .line 27
    new-instance v0, Landroid/support/v7/app/p;

    iget-object v1, p0, Landroid/support/v7/app/j;->a:Landroid/support/v7/app/ActionBarActivity;

    iget-object v2, p0, Landroid/support/v7/app/j;->a:Landroid/support/v7/app/ActionBarActivity;

    invoke-direct {v0, v1, v2}, Landroid/support/v7/app/p;-><init>(Landroid/app/Activity;Landroid/support/v7/app/a;)V

    return-object v0
.end method
