###### Class android.support.v7.app.p (android.support.v7.app.p)
.class public final Landroid/support/v7/app/p;
.super Landroid/support/v7/app/o;
.source "SourceFile"


# direct methods
.method public constructor <init>(Landroid/app/Activity;Landroid/support/v7/app/a;)V
    .registers 3

    .prologue
    .line 24
    invoke-direct {p0, p1, p2}, Landroid/support/v7/app/o;-><init>(Landroid/app/Activity;Landroid/support/v7/app/a;)V

    .line 25
    return-void
.end method
