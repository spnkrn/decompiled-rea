###### Class android.support.v7.app.ActionBarQuirksFixedActivity (android.support.v7.app.ActionBarQuirksFixedActivity)
.class public Landroid/support/v7/app/ActionBarQuirksFixedActivity;
.super Landroid/support/v7/app/ActionBarActivity;
.source "SourceFile"


# instance fields
.field private o:Z


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 58
    invoke-direct {p0}, Landroid/support/v7/app/ActionBarActivity;-><init>()V

    .line 87
    return-void
.end method


# virtual methods
.method final a(ILandroid/view/Menu;)Z
    .registers 4

    .prologue
    .line 81
    iget-boolean v0, p0, Landroid/support/v7/app/ActionBarQuirksFixedActivity;->o:Z

    if-eqz v0, :cond_6

    .line 82
    const/4 v0, 0x0

    .line 84
    :goto_5
    return v0

    :cond_6
    invoke-super {p0, p1, p2}, Landroid/support/v7/app/ActionBarActivity;->a(ILandroid/view/Menu;)Z

    move-result v0

    goto :goto_5
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .registers 5

    .prologue
    .line 63
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v7/app/ActionBarQuirksFixedActivity;->o:Z

    .line 64
    invoke-super {p0, p1}, Landroid/support/v7/app/ActionBarActivity;->onCreate(Landroid/os/Bundle;)V

    .line 67
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0xb

    if-lt v0, v1, :cond_26

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x12

    if-ge v0, v1, :cond_26

    .line 69
    invoke-virtual {p0}, Landroid/support/v7/app/ActionBarQuirksFixedActivity;->getWindow()Landroid/view/Window;

    move-result-object v0

    new-instance v1, Landroid/support/v7/app/q;

    invoke-virtual {p0}, Landroid/support/v7/app/ActionBarQuirksFixedActivity;->getWindow()Landroid/view/Window;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/Window;->getCallback()Landroid/view/Window$Callback;

    move-result-object v2

    invoke-direct {v1, v2}, Landroid/support/v7/app/q;-><init>(Landroid/view/Window$Callback;)V

    invoke-virtual {v0, v1}, Landroid/view/Window;->setCallback(Landroid/view/Window$Callback;)V

    .line 71
    :cond_26
    return-void
.end method

.method protected onDestroy()V
    .registers 2

    .prologue
    .line 75
    invoke-super {p0}, Landroid/support/v7/app/ActionBarActivity;->onDestroy()V

    .line 76
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v7/app/ActionBarQuirksFixedActivity;->o:Z

    .line 77
    return-void
.end method
