###### Class android.support.v4.view.bh (android.support.v4.view.bh)
.class public final Landroid/support/v4/view/bh;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field static final a:Landroid/support/v4/view/bk;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .prologue
    .line 105
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 106
    const/16 v1, 0x12

    if-lt v0, v1, :cond_e

    .line 107
    new-instance v0, Landroid/support/v4/view/bl;

    invoke-direct {v0}, Landroid/support/v4/view/bl;-><init>()V

    sput-object v0, Landroid/support/v4/view/bh;->a:Landroid/support/v4/view/bk;

    .line 115
    :goto_d
    return-void

    .line 108
    :cond_e
    const/16 v1, 0xe

    if-lt v0, v1, :cond_1a

    .line 109
    new-instance v0, Landroid/support/v4/view/bj;

    invoke-direct {v0}, Landroid/support/v4/view/bj;-><init>()V

    sput-object v0, Landroid/support/v4/view/bh;->a:Landroid/support/v4/view/bk;

    goto :goto_d

    .line 110
    :cond_1a
    const/16 v1, 0xb

    if-lt v0, v1, :cond_26

    .line 111
    new-instance v0, Landroid/support/v4/view/bi;

    invoke-direct {v0}, Landroid/support/v4/view/bi;-><init>()V

    sput-object v0, Landroid/support/v4/view/bh;->a:Landroid/support/v4/view/bk;

    goto :goto_d

    .line 113
    :cond_26
    new-instance v0, Landroid/support/v4/view/bm;

    invoke-direct {v0}, Landroid/support/v4/view/bm;-><init>()V

    sput-object v0, Landroid/support/v4/view/bh;->a:Landroid/support/v4/view/bk;

    goto :goto_d
.end method

.method public static a(Landroid/view/ViewGroup;)V
    .registers 2

    .prologue
    .line 161
    sget-object v0, Landroid/support/v4/view/bh;->a:Landroid/support/v4/view/bk;

    invoke-interface {v0, p0}, Landroid/support/v4/view/bk;->a(Landroid/view/ViewGroup;)V

    .line 162
    return-void
.end method
