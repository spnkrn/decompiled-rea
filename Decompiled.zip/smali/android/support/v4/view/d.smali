###### Class android.support.v4.view.d (android.support.v4.view.d)
.class final Landroid/support/v4/view/d;
.super Landroid/support/v4/view/b;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 214
    invoke-direct {p0}, Landroid/support/v4/view/b;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Landroid/view/View;)Landroid/support/v4/view/a/h;
    .registers 5

    .prologue
    .line 275
    check-cast p1, Landroid/view/View$AccessibilityDelegate;

    invoke-virtual {p1, p2}, Landroid/view/View$AccessibilityDelegate;->getAccessibilityNodeProvider(Landroid/view/View;)Landroid/view/accessibility/AccessibilityNodeProvider;

    move-result-object v1

    .line 277
    if-eqz v1, :cond_e

    .line 278
    new-instance v0, Landroid/support/v4/view/a/h;

    invoke-direct {v0, v1}, Landroid/support/v4/view/a/h;-><init>(Ljava/lang/Object;)V

    .line 280
    :goto_d
    return-object v0

    :cond_e
    const/4 v0, 0x0

    goto :goto_d
.end method

.method public final a(Landroid/support/v4/view/a;)Ljava/lang/Object;
    .registers 4

    .prologue
    .line 217
    new-instance v0, Landroid/support/v4/view/d$1;

    invoke-direct {v0, p0, p1}, Landroid/support/v4/view/d$1;-><init>(Landroid/support/v4/view/d;Landroid/support/v4/view/a;)V

    new-instance v1, Landroid/support/v4/view/h$1;

    invoke-direct {v1, v0}, Landroid/support/v4/view/h$1;-><init>(Landroid/support/v4/view/i;)V

    return-object v1
.end method

.method public final a(Ljava/lang/Object;Landroid/view/View;ILandroid/os/Bundle;)Z
    .registers 6

    .prologue
    .line 286
    check-cast p1, Landroid/view/View$AccessibilityDelegate;

    invoke-virtual {p1, p2, p3, p4}, Landroid/view/View$AccessibilityDelegate;->performAccessibilityAction(Landroid/view/View;ILandroid/os/Bundle;)Z

    move-result v0

    return v0
.end method

###### Class android.support.v4.view.d.AnonymousClass1 (android.support.v4.view.d$1)
.class final Landroid/support/v4/view/d$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/support/v4/view/i;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroid/support/v4/view/d;->a(Landroid/support/v4/view/a;)Ljava/lang/Object;
.end annotation


# instance fields
.field final synthetic a:Landroid/support/v4/view/a;

.field final synthetic b:Landroid/support/v4/view/d;


# direct methods
.method constructor <init>(Landroid/support/v4/view/d;Landroid/support/v4/view/a;)V
    .registers 3

    .prologue
    .line 219
    iput-object p1, p0, Landroid/support/v4/view/d$1;->b:Landroid/support/v4/view/d;

    iput-object p2, p0, Landroid/support/v4/view/d$1;->a:Landroid/support/v4/view/a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/view/View;)Ljava/lang/Object;
    .registers 3

    .prologue
    .line 260
    iget-object v0, p0, Landroid/support/v4/view/d$1;->a:Landroid/support/v4/view/a;

    invoke-static {p1}, Landroid/support/v4/view/a;->a(Landroid/view/View;)Landroid/support/v4/view/a/h;

    move-result-object v0

    .line 262
    if-eqz v0, :cond_d

    invoke-virtual {v0}, Landroid/support/v4/view/a/h;->a()Ljava/lang/Object;

    move-result-object v0

    :goto_c
    return-object v0

    :cond_d
    const/4 v0, 0x0

    goto :goto_c
.end method

.method public final a(Landroid/view/View;I)V
    .registers 4

    .prologue
    .line 250
    iget-object v0, p0, Landroid/support/v4/view/d$1;->a:Landroid/support/v4/view/a;

    invoke-static {p1, p2}, Landroid/support/v4/view/a;->a(Landroid/view/View;I)V

    .line 251
    return-void
.end method

.method public final a(Landroid/view/View;Ljava/lang/Object;)V
    .registers 5

    .prologue
    .line 233
    iget-object v0, p0, Landroid/support/v4/view/d$1;->a:Landroid/support/v4/view/a;

    new-instance v1, Landroid/support/v4/view/a/a;

    invoke-direct {v1, p2}, Landroid/support/v4/view/a/a;-><init>(Ljava/lang/Object;)V

    invoke-virtual {v0, p1, v1}, Landroid/support/v4/view/a;->a(Landroid/view/View;Landroid/support/v4/view/a/a;)V

    .line 235
    return-void
.end method

.method public final a(Landroid/view/View;ILandroid/os/Bundle;)Z
    .registers 5

    .prologue
    .line 267
    iget-object v0, p0, Landroid/support/v4/view/d$1;->a:Landroid/support/v4/view/a;

    invoke-virtual {v0, p1, p2, p3}, Landroid/support/v4/view/a;->a(Landroid/view/View;ILandroid/os/Bundle;)Z

    move-result v0

    return v0
.end method

.method public final a(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z
    .registers 4

    .prologue
    .line 223
    iget-object v0, p0, Landroid/support/v4/view/d$1;->a:Landroid/support/v4/view/a;

    invoke-virtual {v0, p1, p2}, Landroid/support/v4/view/a;->b(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z

    move-result v0

    return v0
.end method

.method public final a(Landroid/view/ViewGroup;Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z
    .registers 5

    .prologue
    .line 245
    iget-object v0, p0, Landroid/support/v4/view/d$1;->a:Landroid/support/v4/view/a;

    invoke-virtual {v0, p1, p2, p3}, Landroid/support/v4/view/a;->a(Landroid/view/ViewGroup;Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z

    move-result v0

    return v0
.end method

.method public final b(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .registers 4

    .prologue
    .line 228
    iget-object v0, p0, Landroid/support/v4/view/d$1;->a:Landroid/support/v4/view/a;

    invoke-virtual {v0, p1, p2}, Landroid/support/v4/view/a;->d(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    .line 229
    return-void
.end method

.method public final c(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .registers 4

    .prologue
    .line 239
    iget-object v0, p0, Landroid/support/v4/view/d$1;->a:Landroid/support/v4/view/a;

    invoke-static {p1, p2}, Landroid/support/v4/view/a;->c(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    .line 240
    return-void
.end method

.method public final d(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .registers 4

    .prologue
    .line 255
    iget-object v0, p0, Landroid/support/v4/view/d$1;->a:Landroid/support/v4/view/a;

    invoke-static {p1, p2}, Landroid/support/v4/view/a;->a(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    .line 256
    return-void
.end method

###### Class android.support.v4.view.h.AnonymousClass1 (android.support.v4.view.h$1)
.class final Landroid/support/v4/view/h$1;
.super Landroid/view/View$AccessibilityDelegate;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/v4/view/h;
.end annotation


# instance fields
.field final synthetic a:Landroid/support/v4/view/i;


# direct methods
.method constructor <init>(Landroid/support/v4/view/i;)V
    .registers 2

    .prologue
    .line 47
    iput-object p1, p0, Landroid/support/v4/view/h$1;->a:Landroid/support/v4/view/i;

    invoke-direct {p0}, Landroid/view/View$AccessibilityDelegate;-><init>()V

    return-void
.end method


# virtual methods
.method public final dispatchPopulateAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z
    .registers 4

    .prologue
    .line 51
    iget-object v0, p0, Landroid/support/v4/view/h$1;->a:Landroid/support/v4/view/i;

    invoke-interface {v0, p1, p2}, Landroid/support/v4/view/i;->a(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z

    move-result v0

    return v0
.end method

.method public final getAccessibilityNodeProvider(Landroid/view/View;)Landroid/view/accessibility/AccessibilityNodeProvider;
    .registers 3

    .prologue
    .line 87
    iget-object v0, p0, Landroid/support/v4/view/h$1;->a:Landroid/support/v4/view/i;

    invoke-interface {v0, p1}, Landroid/support/v4/view/i;->a(Landroid/view/View;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/accessibility/AccessibilityNodeProvider;

    return-object v0
.end method

.method public final onInitializeAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .registers 4

    .prologue
    .line 56
    iget-object v0, p0, Landroid/support/v4/view/h$1;->a:Landroid/support/v4/view/i;

    invoke-interface {v0, p1, p2}, Landroid/support/v4/view/i;->b(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    .line 57
    return-void
.end method

.method public final onInitializeAccessibilityNodeInfo(Landroid/view/View;Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .registers 4

    .prologue
    .line 61
    iget-object v0, p0, Landroid/support/v4/view/h$1;->a:Landroid/support/v4/view/i;

    invoke-interface {v0, p1, p2}, Landroid/support/v4/view/i;->a(Landroid/view/View;Ljava/lang/Object;)V

    .line 62
    return-void
.end method

.method public final onPopulateAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .registers 4

    .prologue
    .line 66
    iget-object v0, p0, Landroid/support/v4/view/h$1;->a:Landroid/support/v4/view/i;

    invoke-interface {v0, p1, p2}, Landroid/support/v4/view/i;->c(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    .line 67
    return-void
.end method

.method public final onRequestSendAccessibilityEvent(Landroid/view/ViewGroup;Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z
    .registers 5

    .prologue
    .line 72
    iget-object v0, p0, Landroid/support/v4/view/h$1;->a:Landroid/support/v4/view/i;

    invoke-interface {v0, p1, p2, p3}, Landroid/support/v4/view/i;->a(Landroid/view/ViewGroup;Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z

    move-result v0

    return v0
.end method

.method public final performAccessibilityAction(Landroid/view/View;ILandroid/os/Bundle;)Z
    .registers 5

    .prologue
    .line 92
    iget-object v0, p0, Landroid/support/v4/view/h$1;->a:Landroid/support/v4/view/i;

    invoke-interface {v0, p1, p2, p3}, Landroid/support/v4/view/i;->a(Landroid/view/View;ILandroid/os/Bundle;)Z

    move-result v0

    return v0
.end method

.method public final sendAccessibilityEvent(Landroid/view/View;I)V
    .registers 4

    .prologue
    .line 77
    iget-object v0, p0, Landroid/support/v4/view/h$1;->a:Landroid/support/v4/view/i;

    invoke-interface {v0, p1, p2}, Landroid/support/v4/view/i;->a(Landroid/view/View;I)V

    .line 78
    return-void
.end method

.method public final sendAccessibilityEventUnchecked(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .registers 4

    .prologue
    .line 82
    iget-object v0, p0, Landroid/support/v4/view/h$1;->a:Landroid/support/v4/view/i;

    invoke-interface {v0, p1, p2}, Landroid/support/v4/view/i;->d(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    .line 83
    return-void
.end method
