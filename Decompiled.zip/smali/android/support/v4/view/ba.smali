###### Class android.support.v4.view.ba (android.support.v4.view.ba)
.class Landroid/support/v4/view/ba;
.super Landroid/support/v4/view/az;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 506
    invoke-direct {p0}, Landroid/support/v4/view/az;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/view/View;Landroid/graphics/Paint;)V
    .registers 3

    .prologue
    .line 520
    invoke-virtual {p1, p2}, Landroid/view/View;->setLayerPaint(Landroid/graphics/Paint;)V

    .line 521
    return-void
.end method

.method public final g(Landroid/view/View;)I
    .registers 3

    .prologue
    .line 525
    invoke-virtual {p1}, Landroid/view/View;->getLayoutDirection()I

    move-result v0

    return v0
.end method
