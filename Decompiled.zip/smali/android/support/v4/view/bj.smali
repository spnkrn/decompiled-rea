###### Class android.support.v4.view.bj (android.support.v4.view.bj)
.class Landroid/support/v4/view/bj;
.super Landroid/support/v4/view/bi;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 83
    invoke-direct {p0}, Landroid/support/v4/view/bi;-><init>()V

    return-void
.end method
