###### Class android.support.v4.view.bi (android.support.v4.view.bi)
.class Landroid/support/v4/view/bi;
.super Landroid/support/v4/view/bm;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 76
    invoke-direct {p0}, Landroid/support/v4/view/bm;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/view/ViewGroup;)V
    .registers 3

    .prologue
    .line 79
    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->setMotionEventSplittingEnabled(Z)V

    .line 80
    return-void
.end method
