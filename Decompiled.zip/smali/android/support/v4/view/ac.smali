###### Class android.support.v4.view.ac (android.support.v4.view.ac)
.class public interface abstract Landroid/support/v4/view/ac;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()Z
.end method

.method public abstract b()Z
.end method
