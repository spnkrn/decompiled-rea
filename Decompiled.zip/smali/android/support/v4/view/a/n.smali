###### Class android.support.v4.view.a.n (android.support.v4.view.a.n)
.class interface abstract Landroid/support/v4/view/a/n;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()Z
.end method

.method public abstract b()Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List",
            "<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end method

.method public abstract c()Ljava/lang/Object;
.end method
