###### Class android.support.v4.view.a.u (android.support.v4.view.a.u)
.class final Landroid/support/v4/view/a/u;
.super Landroid/support/v4/view/a/s;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 498
    invoke-direct {p0}, Landroid/support/v4/view/a/s;-><init>()V

    return-void
.end method
