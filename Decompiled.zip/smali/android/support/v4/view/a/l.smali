###### Class android.support.v4.view.a.l (android.support.v4.view.a.l)
.class Landroid/support/v4/view/a/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/support/v4/view/a/i;


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 36
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/support/v4/view/a/h;)Ljava/lang/Object;
    .registers 3

    .prologue
    .line 39
    const/4 v0, 0x0

    return-object v0
.end method
