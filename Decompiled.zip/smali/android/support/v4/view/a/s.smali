###### Class android.support.v4.view.a.s (android.support.v4.view.a.s)
.class Landroid/support/v4/view/a/s;
.super Landroid/support/v4/view/a/r;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 476
    invoke-direct {p0}, Landroid/support/v4/view/a/r;-><init>()V

    return-void
.end method
