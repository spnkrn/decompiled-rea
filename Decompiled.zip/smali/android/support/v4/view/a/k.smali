###### Class android.support.v4.view.a.k (android.support.v4.view.a.k)
.class final Landroid/support/v4/view/a/k;
.super Landroid/support/v4/view/a/l;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 84
    invoke-direct {p0}, Landroid/support/v4/view/a/l;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/support/v4/view/a/h;)Ljava/lang/Object;
    .registers 4

    .prologue
    .line 88
    new-instance v0, Landroid/support/v4/view/a/k$1;

    invoke-direct {v0, p0, p1}, Landroid/support/v4/view/a/k$1;-><init>(Landroid/support/v4/view/a/k;Landroid/support/v4/view/a/h;)V

    new-instance v1, Landroid/support/v4/view/a/o$1;

    invoke-direct {v1, v0}, Landroid/support/v4/view/a/o$1;-><init>(Landroid/support/v4/view/a/p;)V

    return-object v1
.end method

###### Class android.support.v4.view.a.k.AnonymousClass1 (android.support.v4.view.a.k$1)
.class final Landroid/support/v4/view/a/k$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/support/v4/view/a/p;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroid/support/v4/view/a/k;->a(Landroid/support/v4/view/a/h;)Ljava/lang/Object;
.end annotation


# instance fields
.field final synthetic a:Landroid/support/v4/view/a/h;

.field final synthetic b:Landroid/support/v4/view/a/k;


# direct methods
.method constructor <init>(Landroid/support/v4/view/a/k;Landroid/support/v4/view/a/h;)V
    .registers 3

    .prologue
    .line 89
    iput-object p1, p0, Landroid/support/v4/view/a/k$1;->b:Landroid/support/v4/view/a/k;

    iput-object p2, p0, Landroid/support/v4/view/a/k$1;->a:Landroid/support/v4/view/a/h;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Z
    .registers 2

    .prologue
    .line 93
    iget-object v0, p0, Landroid/support/v4/view/a/k$1;->a:Landroid/support/v4/view/a/h;

    invoke-static {}, Landroid/support/v4/view/a/h;->c()Z

    move-result v0

    return v0
.end method

.method public final b()Ljava/util/List;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List",
            "<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .prologue
    const/4 v4, 0x0

    .line 99
    iget-object v0, p0, Landroid/support/v4/view/a/k$1;->a:Landroid/support/v4/view/a/h;

    invoke-static {}, Landroid/support/v4/view/a/h;->d()Ljava/util/List;

    .line 101
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 102
    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v3

    .line 103
    const/4 v0, 0x0

    move v1, v0

    :goto_11
    if-ge v1, v3, :cond_24

    .line 104
    invoke-interface {v4, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/view/a/a;

    .line 105
    invoke-virtual {v0}, Landroid/support/v4/view/a/a;->a()Ljava/lang/Object;

    move-result-object v0

    invoke-interface {v2, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 103
    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_11

    .line 107
    :cond_24
    return-object v2
.end method

.method public final c()Ljava/lang/Object;
    .registers 2

    .prologue
    .line 112
    iget-object v0, p0, Landroid/support/v4/view/a/k$1;->a:Landroid/support/v4/view/a/h;

    invoke-static {}, Landroid/support/v4/view/a/h;->b()Landroid/support/v4/view/a/a;

    .line 114
    const/4 v0, 0x0

    return-object v0
.end method

.method public final d()Ljava/lang/Object;
    .registers 2

    .prologue
    .line 123
    iget-object v0, p0, Landroid/support/v4/view/a/k$1;->a:Landroid/support/v4/view/a/h;

    invoke-static {}, Landroid/support/v4/view/a/h;->e()Landroid/support/v4/view/a/a;

    .line 124
    const/4 v0, 0x0

    return-object v0
.end method

###### Class android.support.v4.view.a.o.AnonymousClass1 (android.support.v4.view.a.o$1)
.class final Landroid/support/v4/view/a/o$1;
.super Landroid/view/accessibility/AccessibilityNodeProvider;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/v4/view/a/o;
.end annotation


# instance fields
.field final synthetic a:Landroid/support/v4/view/a/p;


# direct methods
.method constructor <init>(Landroid/support/v4/view/a/p;)V
    .registers 2

    .prologue
    .line 39
    iput-object p1, p0, Landroid/support/v4/view/a/o$1;->a:Landroid/support/v4/view/a/p;

    invoke-direct {p0}, Landroid/view/accessibility/AccessibilityNodeProvider;-><init>()V

    return-void
.end method


# virtual methods
.method public final createAccessibilityNodeInfo(I)Landroid/view/accessibility/AccessibilityNodeInfo;
    .registers 3

    .prologue
    .line 42
    iget-object v0, p0, Landroid/support/v4/view/a/o$1;->a:Landroid/support/v4/view/a/p;

    invoke-interface {v0}, Landroid/support/v4/view/a/p;->c()Ljava/lang/Object;

    const/4 v0, 0x0

    return-object v0
.end method

.method public final findAccessibilityNodeInfosByText(Ljava/lang/String;I)Ljava/util/List;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "I)",
            "Ljava/util/List",
            "<",
            "Landroid/view/accessibility/AccessibilityNodeInfo;",
            ">;"
        }
    .end annotation

    .prologue
    .line 50
    iget-object v0, p0, Landroid/support/v4/view/a/o$1;->a:Landroid/support/v4/view/a/p;

    invoke-interface {v0}, Landroid/support/v4/view/a/p;->b()Ljava/util/List;

    move-result-object v0

    return-object v0
.end method

.method public final findFocus(I)Landroid/view/accessibility/AccessibilityNodeInfo;
    .registers 3

    .prologue
    .line 61
    iget-object v0, p0, Landroid/support/v4/view/a/o$1;->a:Landroid/support/v4/view/a/p;

    invoke-interface {v0}, Landroid/support/v4/view/a/p;->d()Ljava/lang/Object;

    const/4 v0, 0x0

    return-object v0
.end method

.method public final performAction(IILandroid/os/Bundle;)Z
    .registers 5

    .prologue
    .line 56
    iget-object v0, p0, Landroid/support/v4/view/a/o$1;->a:Landroid/support/v4/view/a/p;

    invoke-interface {v0}, Landroid/support/v4/view/a/p;->a()Z

    move-result v0

    return v0
.end method
