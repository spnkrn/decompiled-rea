###### Class android.support.v4.view.j (android.support.v4.view.j)
.class final Landroid/support/v4/view/j;
.super Landroid/database/DataSetObserver;
.source "SourceFile"

# interfaces
.implements Landroid/support/v4/view/bq;
.implements Landroid/support/v4/view/br;


# instance fields
.field final synthetic a:Landroid/support/v4/view/ActionBarTabStrip;

.field private b:I


# direct methods
.method private constructor <init>(Landroid/support/v4/view/ActionBarTabStrip;)V
    .registers 2

    .prologue
    .line 239
    iput-object p1, p0, Landroid/support/v4/view/j;->a:Landroid/support/v4/view/ActionBarTabStrip;

    invoke-direct {p0}, Landroid/database/DataSetObserver;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Landroid/support/v4/view/ActionBarTabStrip;B)V
    .registers 3

    .prologue
    .line 239
    invoke-direct {p0, p1}, Landroid/support/v4/view/j;-><init>(Landroid/support/v4/view/ActionBarTabStrip;)V

    return-void
.end method


# virtual methods
.method public final a(I)V
    .registers 4

    .prologue
    .line 255
    iget v0, p0, Landroid/support/v4/view/j;->b:I

    .line 259
    iget-object v0, p0, Landroid/support/v4/view/j;->a:Landroid/support/v4/view/ActionBarTabStrip;

    invoke-static {v0, p1}, Landroid/support/v4/view/ActionBarTabStrip;->a(Landroid/support/v4/view/ActionBarTabStrip;I)I

    .line 261
    const/4 v0, 0x0

    :goto_8
    iget-object v1, p0, Landroid/support/v4/view/j;->a:Landroid/support/v4/view/ActionBarTabStrip;

    invoke-virtual {v1}, Landroid/support/v4/view/ActionBarTabStrip;->getChildCount()I

    move-result v1

    if-ge v0, v1, :cond_1c

    .line 262
    iget-object v1, p0, Landroid/support/v4/view/j;->a:Landroid/support/v4/view/ActionBarTabStrip;

    invoke-virtual {v1, v0}, Landroid/support/v4/view/ActionBarTabStrip;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->refreshDrawableState()V

    .line 261
    add-int/lit8 v0, v0, 0x1

    goto :goto_8

    .line 264
    :cond_1c
    return-void
.end method

.method public final a(IFI)V
    .registers 4

    .prologue
    .line 246
    return-void
.end method

.method public final a(Landroid/support/v4/view/ah;Landroid/support/v4/view/ah;)V
    .registers 4

    .prologue
    .line 273
    iget-object v0, p0, Landroid/support/v4/view/j;->a:Landroid/support/v4/view/ActionBarTabStrip;

    invoke-virtual {v0, p1, p2}, Landroid/support/v4/view/ActionBarTabStrip;->a(Landroid/support/v4/view/ah;Landroid/support/v4/view/ah;)V

    .line 274
    return-void
.end method

.method public final b(I)V
    .registers 2

    .prologue
    .line 268
    iput p1, p0, Landroid/support/v4/view/j;->b:I

    .line 269
    return-void
.end method

.method public final onChanged()V
    .registers 2

    .prologue
    .line 278
    iget-object v0, p0, Landroid/support/v4/view/j;->a:Landroid/support/v4/view/ActionBarTabStrip;

    invoke-static {v0}, Landroid/support/v4/view/ActionBarTabStrip;->d(Landroid/support/v4/view/ActionBarTabStrip;)V

    .line 279
    return-void
.end method
