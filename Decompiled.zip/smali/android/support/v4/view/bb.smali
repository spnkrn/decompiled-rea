###### Class android.support.v4.view.bb (android.support.v4.view.bb)
.class final Landroid/support/v4/view/bb;
.super Landroid/support/v4/view/ba;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 534
    invoke-direct {p0}, Landroid/support/v4/view/ba;-><init>()V

    return-void
.end method
