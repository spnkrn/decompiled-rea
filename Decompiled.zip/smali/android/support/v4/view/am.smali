###### Class android.support.v4.view.am (android.support.v4.view.am)
.class final Landroid/support/v4/view/am;
.super Landroid/database/DataSetObserver;
.source "SourceFile"

# interfaces
.implements Landroid/support/v4/view/bq;
.implements Landroid/support/v4/view/br;


# instance fields
.field final synthetic a:Landroid/support/v4/view/PagerTitleStripHacked;

.field private b:I


# direct methods
.method private constructor <init>(Landroid/support/v4/view/PagerTitleStripHacked;)V
    .registers 2

    .prologue
    .line 291
    iput-object p1, p0, Landroid/support/v4/view/am;->a:Landroid/support/v4/view/PagerTitleStripHacked;

    invoke-direct {p0}, Landroid/database/DataSetObserver;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Landroid/support/v4/view/PagerTitleStripHacked;B)V
    .registers 3

    .prologue
    .line 291
    invoke-direct {p0, p1}, Landroid/support/v4/view/am;-><init>(Landroid/support/v4/view/PagerTitleStripHacked;)V

    return-void
.end method


# virtual methods
.method public final a(I)V
    .registers 5

    .prologue
    .line 304
    iget v0, p0, Landroid/support/v4/view/am;->b:I

    if-nez v0, :cond_19

    .line 306
    iget-object v0, p0, Landroid/support/v4/view/am;->a:Landroid/support/v4/view/PagerTitleStripHacked;

    iget-object v1, p0, Landroid/support/v4/view/am;->a:Landroid/support/v4/view/PagerTitleStripHacked;

    iget-object v1, v1, Landroid/support/v4/view/PagerTitleStripHacked;->a:Landroid/support/v4/view/ViewPager;

    invoke-virtual {v1}, Landroid/support/v4/view/ViewPager;->b()I

    move-result v1

    iget-object v2, p0, Landroid/support/v4/view/am;->a:Landroid/support/v4/view/PagerTitleStripHacked;

    iget-object v2, v2, Landroid/support/v4/view/PagerTitleStripHacked;->a:Landroid/support/v4/view/ViewPager;

    invoke-virtual {v2}, Landroid/support/v4/view/ViewPager;->a()Landroid/support/v4/view/ah;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/support/v4/view/PagerTitleStripHacked;->a(ILandroid/support/v4/view/ah;)V

    .line 308
    :cond_19
    return-void
.end method

.method public final a(IFI)V
    .registers 5

    .prologue
    .line 296
    const/high16 v0, 0x3f000000    # 0.5f

    cmpl-float v0, p2, v0

    if-lez v0, :cond_8

    .line 298
    add-int/lit8 p1, p1, 0x1

    .line 300
    :cond_8
    iget-object v0, p0, Landroid/support/v4/view/am;->a:Landroid/support/v4/view/PagerTitleStripHacked;

    invoke-virtual {v0, p1, p2}, Landroid/support/v4/view/PagerTitleStripHacked;->a(IF)V

    .line 301
    return-void
.end method

.method public final a(Landroid/support/v4/view/ah;Landroid/support/v4/view/ah;)V
    .registers 4

    .prologue
    .line 315
    iget-object v0, p0, Landroid/support/v4/view/am;->a:Landroid/support/v4/view/PagerTitleStripHacked;

    invoke-virtual {v0, p1, p2}, Landroid/support/v4/view/PagerTitleStripHacked;->a(Landroid/support/v4/view/ah;Landroid/support/v4/view/ah;)V

    .line 316
    return-void
.end method

.method public final b(I)V
    .registers 2

    .prologue
    .line 311
    iput p1, p0, Landroid/support/v4/view/am;->b:I

    .line 312
    return-void
.end method

.method public final onChanged()V
    .registers 4

    .prologue
    .line 319
    iget-object v0, p0, Landroid/support/v4/view/am;->a:Landroid/support/v4/view/PagerTitleStripHacked;

    iget-object v1, p0, Landroid/support/v4/view/am;->a:Landroid/support/v4/view/PagerTitleStripHacked;

    iget-object v1, v1, Landroid/support/v4/view/PagerTitleStripHacked;->a:Landroid/support/v4/view/ViewPager;

    invoke-virtual {v1}, Landroid/support/v4/view/ViewPager;->b()I

    move-result v1

    iget-object v2, p0, Landroid/support/v4/view/am;->a:Landroid/support/v4/view/PagerTitleStripHacked;

    iget-object v2, v2, Landroid/support/v4/view/PagerTitleStripHacked;->a:Landroid/support/v4/view/ViewPager;

    invoke-virtual {v2}, Landroid/support/v4/view/ViewPager;->a()Landroid/support/v4/view/ah;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Landroid/support/v4/view/PagerTitleStripHacked;->a(ILandroid/support/v4/view/ah;)V

    .line 320
    return-void
.end method
