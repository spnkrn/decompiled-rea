###### Class android.support.v4.view.av (android.support.v4.view.av)
.class Landroid/support/v4/view/av;
.super Landroid/support/v4/view/au;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 366
    invoke-direct {p0}, Landroid/support/v4/view/au;-><init>()V

    return-void
.end method


# virtual methods
.method public final i(Landroid/view/View;)Z
    .registers 3

    .prologue
    .line 369
    invoke-virtual {p1}, Landroid/view/View;->isOpaque()Z

    move-result v0

    return v0
.end method
