###### Class android.support.v4.view.ay (android.support.v4.view.ay)
.class Landroid/support/v4/view/ay;
.super Landroid/support/v4/view/ax;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 427
    invoke-direct {p0}, Landroid/support/v4/view/ax;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/view/View;Landroid/support/v4/view/a;)V
    .registers 4

    .prologue
    .line 450
    iget-object v0, p2, Landroid/support/v4/view/a;->a:Ljava/lang/Object;

    check-cast v0, Landroid/view/View$AccessibilityDelegate;

    invoke-virtual {p1, v0}, Landroid/view/View;->setAccessibilityDelegate(Landroid/view/View$AccessibilityDelegate;)V

    .line 451
    return-void
.end method

.method public final a(Landroid/view/View;)Z
    .registers 3

    .prologue
    .line 434
    const/4 v0, -0x1

    invoke-virtual {p1, v0}, Landroid/view/View;->canScrollVertically(I)Z

    move-result v0

    return v0
.end method

.method public final a(Landroid/view/View;I)Z
    .registers 4

    .prologue
    .line 430
    invoke-virtual {p1, p2}, Landroid/view/View;->canScrollHorizontally(I)Z

    move-result v0

    return v0
.end method
