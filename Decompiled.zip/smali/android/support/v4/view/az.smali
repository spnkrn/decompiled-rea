###### Class android.support.v4.view.az (android.support.v4.view.az)
.class Landroid/support/v4/view/az;
.super Landroid/support/v4/view/ay;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 454
    invoke-direct {p0}, Landroid/support/v4/view/ay;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/view/View;IIII)V
    .registers 6

    .prologue
    .line 469
    invoke-virtual {p1, p2, p3, p4, p5}, Landroid/view/View;->postInvalidate(IIII)V

    .line 470
    return-void
.end method

.method public final a(Landroid/view/View;Ljava/lang/Runnable;)V
    .registers 3

    .prologue
    .line 473
    invoke-virtual {p1, p2}, Landroid/view/View;->postOnAnimation(Ljava/lang/Runnable;)V

    .line 474
    return-void
.end method

.method public final c(Landroid/view/View;)V
    .registers 2

    .prologue
    .line 465
    invoke-virtual {p1}, Landroid/view/View;->postInvalidateOnAnimation()V

    .line 466
    return-void
.end method

.method public final d(Landroid/view/View;)I
    .registers 3

    .prologue
    .line 481
    invoke-virtual {p1}, Landroid/view/View;->getImportantForAccessibility()I

    move-result v0

    return v0
.end method

.method public final e(Landroid/view/View;)V
    .registers 3

    .prologue
    .line 485
    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Landroid/view/View;->setImportantForAccessibility(I)V

    .line 486
    return-void
.end method

.method public final h(Landroid/view/View;)Landroid/view/ViewParent;
    .registers 3

    .prologue
    .line 502
    invoke-virtual {p1}, Landroid/view/View;->getParentForAccessibility()Landroid/view/ViewParent;

    move-result-object v0

    return-object v0
.end method
