###### Class android.support.v4.view.ak (android.support.v4.view.ak)
.class final Landroid/support/v4/view/ak;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/support/v4/view/aj;


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 86
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/widget/TextView;)V
    .registers 2

    .prologue
    .line 88
    invoke-virtual {p1}, Landroid/widget/TextView;->setSingleLine()V

    .line 89
    return-void
.end method
