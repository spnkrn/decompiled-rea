###### Class android.support.v4.c.g (android.support.v4.c.g)
.class abstract Landroid/support/v4/c/g;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field b:Landroid/support/v4/c/i;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/support/v4/c/g",
            "<TK;TV;>.android/support/v4/c/i;"
        }
    .end annotation
.end field

.field c:Landroid/support/v4/c/j;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/support/v4/c/g",
            "<TK;TV;>.android/support/v4/c/j;"
        }
    .end annotation
.end field

.field d:Landroid/support/v4/c/l;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/support/v4/c/g",
            "<TK;TV;>.android/support/v4/c/l;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 30
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a(Ljava/util/Set;Ljava/lang/Object;)Z
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/Set",
            "<TT;>;",
            "Ljava/lang/Object;",
            ")Z"
        }
    .end annotation

    .prologue
    const/4 v0, 0x1

    const/4 v1, 0x0

    .line 511
    if-ne p0, p1, :cond_5

    .line 525
    :cond_4
    :goto_4
    return v0

    .line 514
    :cond_5
    instance-of v2, p1, Ljava/util/Set;

    if-eqz v2, :cond_23

    .line 515
    check-cast p1, Ljava/util/Set;

    .line 518
    :try_start_b
    invoke-interface {p0}, Ljava/util/Set;->size()I

    move-result v2

    invoke-interface {p1}, Ljava/util/Set;->size()I

    move-result v3

    if-ne v2, v3, :cond_1b

    invoke-interface {p0, p1}, Ljava/util/Set;->containsAll(Ljava/util/Collection;)Z
    :try_end_18
    .catch Ljava/lang/NullPointerException; {:try_start_b .. :try_end_18} :catch_1d
    .catch Ljava/lang/ClassCastException; {:try_start_b .. :try_end_18} :catch_20

    move-result v2

    if-nez v2, :cond_4

    :cond_1b
    move v0, v1

    goto :goto_4

    .line 520
    :catch_1d
    move-exception v0

    move v0, v1

    goto :goto_4

    .line 522
    :catch_20
    move-exception v0

    move v0, v1

    goto :goto_4

    :cond_23
    move v0, v1

    .line 525
    goto :goto_4
.end method


# virtual methods
.method protected abstract a()I
.end method

.method protected abstract a(Ljava/lang/Object;)I
.end method

.method protected abstract a(II)Ljava/lang/Object;
.end method

.method protected abstract a(ILjava/lang/Object;)Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ITV;)TV;"
        }
    .end annotation
.end method

.method protected abstract a(I)V
.end method

.method protected abstract a(Ljava/lang/Object;Ljava/lang/Object;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;TV;)V"
        }
    .end annotation
.end method

.method public final a([Ljava/lang/Object;I)[Ljava/lang/Object;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;I)[TT;"
        }
    .end annotation

    .prologue
    .line 495
    invoke-virtual {p0}, Landroid/support/v4/c/g;->a()I

    move-result v2

    .line 496
    array-length v0, p1

    if-ge v0, v2, :cond_28

    .line 497
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object v0

    invoke-static {v0, v2}, Ljava/lang/reflect/Array;->newInstance(Ljava/lang/Class;I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/lang/Object;

    .line 501
    :goto_15
    const/4 v1, 0x0

    :goto_16
    if-ge v1, v2, :cond_21

    .line 502
    invoke-virtual {p0, v1, p2}, Landroid/support/v4/c/g;->a(II)Ljava/lang/Object;

    move-result-object v3

    aput-object v3, v0, v1

    .line 501
    add-int/lit8 v1, v1, 0x1

    goto :goto_16

    .line 504
    :cond_21
    array-length v1, v0

    if-le v1, v2, :cond_27

    .line 505
    const/4 v1, 0x0

    aput-object v1, v0, v2

    .line 507
    :cond_27
    return-object v0

    :cond_28
    move-object v0, p1

    goto :goto_15
.end method

.method protected abstract b(Ljava/lang/Object;)I
.end method

.method protected abstract b()Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map",
            "<TK;TV;>;"
        }
    .end annotation
.end method

.method public final b(I)[Ljava/lang/Object;
    .registers 6

    .prologue
    .line 486
    invoke-virtual {p0}, Landroid/support/v4/c/g;->a()I

    move-result v1

    .line 487
    new-array v2, v1, [Ljava/lang/Object;

    .line 488
    const/4 v0, 0x0

    :goto_7
    if-ge v0, v1, :cond_12

    .line 489
    invoke-virtual {p0, v0, p1}, Landroid/support/v4/c/g;->a(II)Ljava/lang/Object;

    move-result-object v3

    aput-object v3, v2, v0

    .line 488
    add-int/lit8 v0, v0, 0x1

    goto :goto_7

    .line 491
    :cond_12
    return-object v2
.end method

.method protected abstract c()V
.end method

###### Class android.support.v4.c.i (android.support.v4.c.i)
.class final Landroid/support/v4/c/i;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Set;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Set",
        "<",
        "Ljava/util/Map$Entry",
        "<TK;TV;>;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Landroid/support/v4/c/g;


# direct methods
.method constructor <init>(Landroid/support/v4/c/g;)V
    .registers 2

    .prologue
    .line 163
    iput-object p1, p0, Landroid/support/v4/c/i;->a:Landroid/support/v4/c/g;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final synthetic add(Ljava/lang/Object;)Z
    .registers 3

    .prologue
    .line 163
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final addAll(Ljava/util/Collection;)Z
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection",
            "<+",
            "Ljava/util/Map$Entry",
            "<TK;TV;>;>;)Z"
        }
    .end annotation

    .prologue
    .line 171
    iget-object v0, p0, Landroid/support/v4/c/i;->a:Landroid/support/v4/c/g;

    invoke-virtual {v0}, Landroid/support/v4/c/g;->a()I

    move-result v1

    .line 172
    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_a
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_24

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    .line 173
    iget-object v3, p0, Landroid/support/v4/c/i;->a:Landroid/support/v4/c/g;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v3, v4, v0}, Landroid/support/v4/c/g;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_a

    .line 175
    :cond_24
    iget-object v0, p0, Landroid/support/v4/c/i;->a:Landroid/support/v4/c/g;

    invoke-virtual {v0}, Landroid/support/v4/c/g;->a()I

    move-result v0

    if-eq v1, v0, :cond_2e

    const/4 v0, 0x1

    :goto_2d
    return v0

    :cond_2e
    const/4 v0, 0x0

    goto :goto_2d
.end method

.method public final clear()V
    .registers 2

    .prologue
    .line 180
    iget-object v0, p0, Landroid/support/v4/c/i;->a:Landroid/support/v4/c/g;

    invoke-virtual {v0}, Landroid/support/v4/c/g;->c()V

    .line 181
    return-void
.end method

.method public final contains(Ljava/lang/Object;)Z
    .registers 5

    .prologue
    const/4 v0, 0x0

    .line 185
    instance-of v1, p1, Ljava/util/Map$Entry;

    if-nez v1, :cond_6

    .line 193
    :cond_5
    :goto_5
    return v0

    .line 187
    :cond_6
    check-cast p1, Ljava/util/Map$Entry;

    .line 188
    iget-object v1, p0, Landroid/support/v4/c/i;->a:Landroid/support/v4/c/g;

    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/support/v4/c/g;->a(Ljava/lang/Object;)I

    move-result v1

    .line 189
    if-ltz v1, :cond_5

    .line 192
    iget-object v0, p0, Landroid/support/v4/c/i;->a:Landroid/support/v4/c/g;

    const/4 v2, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/support/v4/c/g;->a(II)Ljava/lang/Object;

    move-result-object v0

    .line 193
    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/support/v4/c/b;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    goto :goto_5
.end method

.method public final containsAll(Ljava/util/Collection;)Z
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection",
            "<*>;)Z"
        }
    .end annotation

    .prologue
    .line 198
    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    .line 199
    :cond_4
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_16

    .line 200
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {p0, v1}, Landroid/support/v4/c/i;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4

    .line 201
    const/4 v0, 0x0

    .line 204
    :goto_15
    return v0

    :cond_16
    const/4 v0, 0x1

    goto :goto_15
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 3

    .prologue
    .line 249
    invoke-static {p0, p1}, Landroid/support/v4/c/g;->a(Ljava/util/Set;Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public final hashCode()I
    .registers 7

    .prologue
    const/4 v1, 0x0

    .line 254
    .line 255
    iget-object v0, p0, Landroid/support/v4/c/i;->a:Landroid/support/v4/c/g;

    invoke-virtual {v0}, Landroid/support/v4/c/g;->a()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    move v3, v0

    move v4, v1

    :goto_b
    if-ltz v3, :cond_33

    .line 256
    iget-object v0, p0, Landroid/support/v4/c/i;->a:Landroid/support/v4/c/g;

    invoke-virtual {v0, v3, v1}, Landroid/support/v4/c/g;->a(II)Ljava/lang/Object;

    move-result-object v0

    .line 257
    iget-object v2, p0, Landroid/support/v4/c/i;->a:Landroid/support/v4/c/g;

    const/4 v5, 0x1

    invoke-virtual {v2, v3, v5}, Landroid/support/v4/c/g;->a(II)Ljava/lang/Object;

    move-result-object v5

    .line 258
    if-nez v0, :cond_28

    move v2, v1

    :goto_1d
    if-nez v5, :cond_2e

    move v0, v1

    :goto_20
    xor-int/2addr v0, v2

    add-int v2, v4, v0

    .line 255
    add-int/lit8 v0, v3, -0x1

    move v3, v0

    move v4, v2

    goto :goto_b

    .line 258
    :cond_28
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    move v2, v0

    goto :goto_1d

    :cond_2e
    invoke-virtual {v5}, Ljava/lang/Object;->hashCode()I

    move-result v0

    goto :goto_20

    .line 261
    :cond_33
    return v4
.end method

.method public final isEmpty()Z
    .registers 2

    .prologue
    .line 209
    iget-object v0, p0, Landroid/support/v4/c/i;->a:Landroid/support/v4/c/g;

    invoke-virtual {v0}, Landroid/support/v4/c/g;->a()I

    move-result v0

    if-nez v0, :cond_a

    const/4 v0, 0x1

    :goto_9
    return v0

    :cond_a
    const/4 v0, 0x0

    goto :goto_9
.end method

.method public final iterator()Ljava/util/Iterator;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator",
            "<",
            "Ljava/util/Map$Entry",
            "<TK;TV;>;>;"
        }
    .end annotation

    .prologue
    .line 214
    new-instance v0, Landroid/support/v4/c/k;

    iget-object v1, p0, Landroid/support/v4/c/i;->a:Landroid/support/v4/c/g;

    invoke-direct {v0, v1}, Landroid/support/v4/c/k;-><init>(Landroid/support/v4/c/g;)V

    return-object v0
.end method

.method public final remove(Ljava/lang/Object;)Z
    .registers 3

    .prologue
    .line 219
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final removeAll(Ljava/util/Collection;)Z
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection",
            "<*>;)Z"
        }
    .end annotation

    .prologue
    .line 224
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final retainAll(Ljava/util/Collection;)Z
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection",
            "<*>;)Z"
        }
    .end annotation

    .prologue
    .line 229
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final size()I
    .registers 2

    .prologue
    .line 234
    iget-object v0, p0, Landroid/support/v4/c/i;->a:Landroid/support/v4/c/g;

    invoke-virtual {v0}, Landroid/support/v4/c/g;->a()I

    move-result v0

    return v0
.end method

.method public final toArray()[Ljava/lang/Object;
    .registers 2

    .prologue
    .line 239
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;)[TT;"
        }
    .end annotation

    .prologue
    .line 244
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

###### Class android.support.v4.c.j (android.support.v4.c.j)
.class final Landroid/support/v4/c/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Set;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Set",
        "<TK;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Landroid/support/v4/c/g;


# direct methods
.method constructor <init>(Landroid/support/v4/c/g;)V
    .registers 2

    .prologue
    .line 265
    iput-object p1, p0, Landroid/support/v4/c/j;->a:Landroid/support/v4/c/g;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final add(Ljava/lang/Object;)Z
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;)Z"
        }
    .end annotation

    .prologue
    .line 269
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final addAll(Ljava/util/Collection;)Z
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection",
            "<+TK;>;)Z"
        }
    .end annotation

    .prologue
    .line 274
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final clear()V
    .registers 2

    .prologue
    .line 279
    iget-object v0, p0, Landroid/support/v4/c/j;->a:Landroid/support/v4/c/g;

    invoke-virtual {v0}, Landroid/support/v4/c/g;->c()V

    .line 280
    return-void
.end method

.method public final contains(Ljava/lang/Object;)Z
    .registers 3

    .prologue
    .line 284
    iget-object v0, p0, Landroid/support/v4/c/j;->a:Landroid/support/v4/c/g;

    invoke-virtual {v0, p1}, Landroid/support/v4/c/g;->a(Ljava/lang/Object;)I

    move-result v0

    if-ltz v0, :cond_a

    const/4 v0, 0x1

    :goto_9
    return v0

    :cond_a
    const/4 v0, 0x0

    goto :goto_9
.end method

.method public final containsAll(Ljava/util/Collection;)Z
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection",
            "<*>;)Z"
        }
    .end annotation

    .prologue
    .line 289
    iget-object v0, p0, Landroid/support/v4/c/j;->a:Landroid/support/v4/c/g;

    invoke-virtual {v0}, Landroid/support/v4/c/g;->b()Ljava/util/Map;

    move-result-object v0

    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_a
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1c

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    invoke-interface {v0, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_a

    const/4 v0, 0x0

    :goto_1b
    return v0

    :cond_1c
    const/4 v0, 0x1

    goto :goto_1b
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 3

    .prologue
    .line 339
    invoke-static {p0, p1}, Landroid/support/v4/c/g;->a(Ljava/util/Set;Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public final hashCode()I
    .registers 5

    .prologue
    const/4 v1, 0x0

    .line 344
    .line 345
    iget-object v0, p0, Landroid/support/v4/c/j;->a:Landroid/support/v4/c/g;

    invoke-virtual {v0}, Landroid/support/v4/c/g;->a()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    move v2, v0

    move v3, v1

    :goto_b
    if-ltz v2, :cond_20

    .line 346
    iget-object v0, p0, Landroid/support/v4/c/j;->a:Landroid/support/v4/c/g;

    invoke-virtual {v0, v2, v1}, Landroid/support/v4/c/g;->a(II)Ljava/lang/Object;

    move-result-object v0

    .line 347
    if-nez v0, :cond_1b

    move v0, v1

    :goto_16
    add-int/2addr v3, v0

    .line 345
    add-int/lit8 v0, v2, -0x1

    move v2, v0

    goto :goto_b

    .line 347
    :cond_1b
    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    goto :goto_16

    .line 349
    :cond_20
    return v3
.end method

.method public final isEmpty()Z
    .registers 2

    .prologue
    .line 294
    iget-object v0, p0, Landroid/support/v4/c/j;->a:Landroid/support/v4/c/g;

    invoke-virtual {v0}, Landroid/support/v4/c/g;->a()I

    move-result v0

    if-nez v0, :cond_a

    const/4 v0, 0x1

    :goto_9
    return v0

    :cond_a
    const/4 v0, 0x0

    goto :goto_9
.end method

.method public final iterator()Ljava/util/Iterator;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator",
            "<TK;>;"
        }
    .end annotation

    .prologue
    .line 299
    new-instance v0, Landroid/support/v4/c/h;

    iget-object v1, p0, Landroid/support/v4/c/j;->a:Landroid/support/v4/c/g;

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Landroid/support/v4/c/h;-><init>(Landroid/support/v4/c/g;I)V

    return-object v0
.end method

.method public final remove(Ljava/lang/Object;)Z
    .registers 4

    .prologue
    .line 304
    iget-object v0, p0, Landroid/support/v4/c/j;->a:Landroid/support/v4/c/g;

    invoke-virtual {v0, p1}, Landroid/support/v4/c/g;->a(Ljava/lang/Object;)I

    move-result v0

    .line 305
    if-ltz v0, :cond_f

    .line 306
    iget-object v1, p0, Landroid/support/v4/c/j;->a:Landroid/support/v4/c/g;

    invoke-virtual {v1, v0}, Landroid/support/v4/c/g;->a(I)V

    .line 307
    const/4 v0, 0x1

    .line 309
    :goto_e
    return v0

    :cond_f
    const/4 v0, 0x0

    goto :goto_e
.end method

.method public final removeAll(Ljava/util/Collection;)Z
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection",
            "<*>;)Z"
        }
    .end annotation

    .prologue
    .line 314
    iget-object v0, p0, Landroid/support/v4/c/j;->a:Landroid/support/v4/c/g;

    invoke-virtual {v0}, Landroid/support/v4/c/g;->b()Ljava/util/Map;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Map;->size()I

    move-result v1

    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_e
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_1c

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    invoke-interface {v0, v3}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_e

    :cond_1c
    invoke-interface {v0}, Ljava/util/Map;->size()I

    move-result v0

    if-eq v1, v0, :cond_24

    const/4 v0, 0x1

    :goto_23
    return v0

    :cond_24
    const/4 v0, 0x0

    goto :goto_23
.end method

.method public final retainAll(Ljava/util/Collection;)Z
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection",
            "<*>;)Z"
        }
    .end annotation

    .prologue
    .line 319
    iget-object v0, p0, Landroid/support/v4/c/j;->a:Landroid/support/v4/c/g;

    invoke-virtual {v0}, Landroid/support/v4/c/g;->b()Ljava/util/Map;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Map;->size()I

    move-result v1

    invoke-interface {v0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_12
    :goto_12
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_26

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    invoke-interface {p1, v3}, Ljava/util/Collection;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_12

    invoke-interface {v2}, Ljava/util/Iterator;->remove()V

    goto :goto_12

    :cond_26
    invoke-interface {v0}, Ljava/util/Map;->size()I

    move-result v0

    if-eq v1, v0, :cond_2e

    const/4 v0, 0x1

    :goto_2d
    return v0

    :cond_2e
    const/4 v0, 0x0

    goto :goto_2d
.end method

.method public final size()I
    .registers 2

    .prologue
    .line 324
    iget-object v0, p0, Landroid/support/v4/c/j;->a:Landroid/support/v4/c/g;

    invoke-virtual {v0}, Landroid/support/v4/c/g;->a()I

    move-result v0

    return v0
.end method

.method public final toArray()[Ljava/lang/Object;
    .registers 3

    .prologue
    .line 329
    iget-object v0, p0, Landroid/support/v4/c/j;->a:Landroid/support/v4/c/g;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/support/v4/c/g;->b(I)[Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;)[TT;"
        }
    .end annotation

    .prologue
    .line 334
    iget-object v0, p0, Landroid/support/v4/c/j;->a:Landroid/support/v4/c/g;

    const/4 v1, 0x0

    invoke-virtual {v0, p1, v1}, Landroid/support/v4/c/g;->a([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

###### Class android.support.v4.c.l (android.support.v4.c.l)
.class final Landroid/support/v4/c/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Collection;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Collection",
        "<TV;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Landroid/support/v4/c/g;


# direct methods
.method constructor <init>(Landroid/support/v4/c/g;)V
    .registers 2

    .prologue
    .line 353
    iput-object p1, p0, Landroid/support/v4/c/l;->a:Landroid/support/v4/c/g;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final add(Ljava/lang/Object;)Z
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TV;)Z"
        }
    .end annotation

    .prologue
    .line 357
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final addAll(Ljava/util/Collection;)Z
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection",
            "<+TV;>;)Z"
        }
    .end annotation

    .prologue
    .line 362
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    throw v0
.end method

.method public final clear()V
    .registers 2

    .prologue
    .line 367
    iget-object v0, p0, Landroid/support/v4/c/l;->a:Landroid/support/v4/c/g;

    invoke-virtual {v0}, Landroid/support/v4/c/g;->c()V

    .line 368
    return-void
.end method

.method public final contains(Ljava/lang/Object;)Z
    .registers 3

    .prologue
    .line 372
    iget-object v0, p0, Landroid/support/v4/c/l;->a:Landroid/support/v4/c/g;

    invoke-virtual {v0, p1}, Landroid/support/v4/c/g;->b(Ljava/lang/Object;)I

    move-result v0

    if-ltz v0, :cond_a

    const/4 v0, 0x1

    :goto_9
    return v0

    :cond_a
    const/4 v0, 0x0

    goto :goto_9
.end method

.method public final containsAll(Ljava/util/Collection;)Z
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection",
            "<*>;)Z"
        }
    .end annotation

    .prologue
    .line 377
    invoke-interface {p1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    .line 378
    :cond_4
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_16

    .line 379
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {p0, v1}, Landroid/support/v4/c/l;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4

    .line 380
    const/4 v0, 0x0

    .line 383
    :goto_15
    return v0

    :cond_16
    const/4 v0, 0x1

    goto :goto_15
.end method

.method public final isEmpty()Z
    .registers 2

    .prologue
    .line 388
    iget-object v0, p0, Landroid/support/v4/c/l;->a:Landroid/support/v4/c/g;

    invoke-virtual {v0}, Landroid/support/v4/c/g;->a()I

    move-result v0

    if-nez v0, :cond_a

    const/4 v0, 0x1

    :goto_9
    return v0

    :cond_a
    const/4 v0, 0x0

    goto :goto_9
.end method

.method public final iterator()Ljava/util/Iterator;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator",
            "<TV;>;"
        }
    .end annotation

    .prologue
    .line 393
    new-instance v0, Landroid/support/v4/c/h;

    iget-object v1, p0, Landroid/support/v4/c/l;->a:Landroid/support/v4/c/g;

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Landroid/support/v4/c/h;-><init>(Landroid/support/v4/c/g;I)V

    return-object v0
.end method

.method public final remove(Ljava/lang/Object;)Z
    .registers 4

    .prologue
    .line 398
    iget-object v0, p0, Landroid/support/v4/c/l;->a:Landroid/support/v4/c/g;

    invoke-virtual {v0, p1}, Landroid/support/v4/c/g;->b(Ljava/lang/Object;)I

    move-result v0

    .line 399
    if-ltz v0, :cond_f

    .line 400
    iget-object v1, p0, Landroid/support/v4/c/l;->a:Landroid/support/v4/c/g;

    invoke-virtual {v1, v0}, Landroid/support/v4/c/g;->a(I)V

    .line 401
    const/4 v0, 0x1

    .line 403
    :goto_e
    return v0

    :cond_f
    const/4 v0, 0x0

    goto :goto_e
.end method

.method public final removeAll(Ljava/util/Collection;)Z
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection",
            "<*>;)Z"
        }
    .end annotation

    .prologue
    const/4 v2, 0x1

    const/4 v0, 0x0

    .line 408
    iget-object v1, p0, Landroid/support/v4/c/l;->a:Landroid/support/v4/c/g;

    invoke-virtual {v1}, Landroid/support/v4/c/g;->a()I

    move-result v3

    move v1, v0

    .line 410
    :goto_9
    if-ge v0, v3, :cond_25

    .line 411
    iget-object v4, p0, Landroid/support/v4/c/l;->a:Landroid/support/v4/c/g;

    invoke-virtual {v4, v0, v2}, Landroid/support/v4/c/g;->a(II)Ljava/lang/Object;

    move-result-object v4

    .line 412
    invoke-interface {p1, v4}, Ljava/util/Collection;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_22

    .line 413
    iget-object v1, p0, Landroid/support/v4/c/l;->a:Landroid/support/v4/c/g;

    invoke-virtual {v1, v0}, Landroid/support/v4/c/g;->a(I)V

    .line 414
    add-int/lit8 v0, v0, -0x1

    .line 415
    add-int/lit8 v1, v3, -0x1

    move v3, v1

    move v1, v2

    .line 410
    :cond_22
    add-int/lit8 v0, v0, 0x1

    goto :goto_9

    .line 419
    :cond_25
    return v1
.end method

.method public final retainAll(Ljava/util/Collection;)Z
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Collection",
            "<*>;)Z"
        }
    .end annotation

    .prologue
    const/4 v2, 0x1

    const/4 v0, 0x0

    .line 424
    iget-object v1, p0, Landroid/support/v4/c/l;->a:Landroid/support/v4/c/g;

    invoke-virtual {v1}, Landroid/support/v4/c/g;->a()I

    move-result v3

    move v1, v0

    .line 426
    :goto_9
    if-ge v0, v3, :cond_25

    .line 427
    iget-object v4, p0, Landroid/support/v4/c/l;->a:Landroid/support/v4/c/g;

    invoke-virtual {v4, v0, v2}, Landroid/support/v4/c/g;->a(II)Ljava/lang/Object;

    move-result-object v4

    .line 428
    invoke-interface {p1, v4}, Ljava/util/Collection;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_22

    .line 429
    iget-object v1, p0, Landroid/support/v4/c/l;->a:Landroid/support/v4/c/g;

    invoke-virtual {v1, v0}, Landroid/support/v4/c/g;->a(I)V

    .line 430
    add-int/lit8 v0, v0, -0x1

    .line 431
    add-int/lit8 v1, v3, -0x1

    move v3, v1

    move v1, v2

    .line 426
    :cond_22
    add-int/lit8 v0, v0, 0x1

    goto :goto_9

    .line 435
    :cond_25
    return v1
.end method

.method public final size()I
    .registers 2

    .prologue
    .line 440
    iget-object v0, p0, Landroid/support/v4/c/l;->a:Landroid/support/v4/c/g;

    invoke-virtual {v0}, Landroid/support/v4/c/g;->a()I

    move-result v0

    return v0
.end method

.method public final toArray()[Ljava/lang/Object;
    .registers 3

    .prologue
    .line 445
    iget-object v0, p0, Landroid/support/v4/c/l;->a:Landroid/support/v4/c/g;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/support/v4/c/g;->b(I)[Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final toArray([Ljava/lang/Object;)[Ljava/lang/Object;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;)[TT;"
        }
    .end annotation

    .prologue
    .line 450
    iget-object v0, p0, Landroid/support/v4/c/l;->a:Landroid/support/v4/c/g;

    const/4 v1, 0x1

    invoke-virtual {v0, p1, v1}, Landroid/support/v4/c/g;->a([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method
