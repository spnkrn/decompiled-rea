###### Class android.support.v4.c.a (android.support.v4.c.a)
.class public Landroid/support/v4/c/a;
.super Landroid/support/v4/c/m;
.source "SourceFile"

# interfaces
.implements Ljava/util/Map;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Landroid/support/v4/c/m",
        "<TK;TV;>;",
        "Ljava/util/Map",
        "<TK;TV;>;"
    }
.end annotation


# instance fields
.field a:Landroid/support/v4/c/g;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/support/v4/c/g",
            "<TK;TV;>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 54
    invoke-direct {p0}, Landroid/support/v4/c/m;-><init>()V

    .line 55
    return-void
.end method

.method private b()Landroid/support/v4/c/g;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Landroid/support/v4/c/g",
            "<TK;TV;>;"
        }
    .end annotation

    .prologue
    .line 72
    iget-object v0, p0, Landroid/support/v4/c/a;->a:Landroid/support/v4/c/g;

    if-nez v0, :cond_b

    .line 73
    new-instance v0, Landroid/support/v4/c/a$1;

    invoke-direct {v0, p0}, Landroid/support/v4/c/a$1;-><init>(Landroid/support/v4/c/a;)V

    iput-object v0, p0, Landroid/support/v4/c/a;->a:Landroid/support/v4/c/g;

    .line 120
    :cond_b
    iget-object v0, p0, Landroid/support/v4/c/a;->a:Landroid/support/v4/c/g;

    return-object v0
.end method


# virtual methods
.method public entrySet()Ljava/util/Set;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set",
            "<",
            "Ljava/util/Map$Entry",
            "<TK;TV;>;>;"
        }
    .end annotation

    .prologue
    .line 179
    invoke-direct {p0}, Landroid/support/v4/c/a;->b()Landroid/support/v4/c/g;

    move-result-object v0

    iget-object v1, v0, Landroid/support/v4/c/g;->b:Landroid/support/v4/c/i;

    if-nez v1, :cond_f

    new-instance v1, Landroid/support/v4/c/i;

    invoke-direct {v1, v0}, Landroid/support/v4/c/i;-><init>(Landroid/support/v4/c/g;)V

    iput-object v1, v0, Landroid/support/v4/c/g;->b:Landroid/support/v4/c/i;

    :cond_f
    iget-object v0, v0, Landroid/support/v4/c/g;->b:Landroid/support/v4/c/i;

    return-object v0
.end method

.method public keySet()Ljava/util/Set;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set",
            "<TK;>;"
        }
    .end annotation

    .prologue
    .line 191
    invoke-direct {p0}, Landroid/support/v4/c/a;->b()Landroid/support/v4/c/g;

    move-result-object v0

    iget-object v1, v0, Landroid/support/v4/c/g;->c:Landroid/support/v4/c/j;

    if-nez v1, :cond_f

    new-instance v1, Landroid/support/v4/c/j;

    invoke-direct {v1, v0}, Landroid/support/v4/c/j;-><init>(Landroid/support/v4/c/g;)V

    iput-object v1, v0, Landroid/support/v4/c/g;->c:Landroid/support/v4/c/j;

    :cond_f
    iget-object v0, v0, Landroid/support/v4/c/g;->c:Landroid/support/v4/c/j;

    return-object v0
.end method

.method public putAll(Ljava/util/Map;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map",
            "<+TK;+TV;>;)V"
        }
    .end annotation

    .prologue
    .line 139
    iget v0, p0, Landroid/support/v4/c/a;->h:I

    invoke-interface {p1}, Ljava/util/Map;->size()I

    move-result v1

    add-int/2addr v0, v1

    invoke-virtual {p0, v0}, Landroid/support/v4/c/a;->a(I)V

    .line 140
    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_12
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_2a

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    .line 141
    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p0, v2, v0}, Landroid/support/v4/c/a;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_12

    .line 143
    :cond_2a
    return-void
.end method

.method public values()Ljava/util/Collection;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Collection",
            "<TV;>;"
        }
    .end annotation

    .prologue
    .line 203
    invoke-direct {p0}, Landroid/support/v4/c/a;->b()Landroid/support/v4/c/g;

    move-result-object v0

    iget-object v1, v0, Landroid/support/v4/c/g;->d:Landroid/support/v4/c/l;

    if-nez v1, :cond_f

    new-instance v1, Landroid/support/v4/c/l;

    invoke-direct {v1, v0}, Landroid/support/v4/c/l;-><init>(Landroid/support/v4/c/g;)V

    iput-object v1, v0, Landroid/support/v4/c/g;->d:Landroid/support/v4/c/l;

    :cond_f
    iget-object v0, v0, Landroid/support/v4/c/g;->d:Landroid/support/v4/c/l;

    return-object v0
.end method

###### Class android.support.v4.c.a.AnonymousClass1 (android.support.v4.c.a$1)
.class final Landroid/support/v4/c/a$1;
.super Landroid/support/v4/c/g;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Landroid/support/v4/c/a;->b()Landroid/support/v4/c/g;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/support/v4/c/g",
        "<TK;TV;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Landroid/support/v4/c/a;


# direct methods
.method constructor <init>(Landroid/support/v4/c/a;)V
    .registers 2

    .prologue
    .line 73
    iput-object p1, p0, Landroid/support/v4/c/a$1;->a:Landroid/support/v4/c/a;

    invoke-direct {p0}, Landroid/support/v4/c/g;-><init>()V

    return-void
.end method


# virtual methods
.method protected final a()I
    .registers 2

    .prologue
    .line 76
    iget-object v0, p0, Landroid/support/v4/c/a$1;->a:Landroid/support/v4/c/a;

    iget v0, v0, Landroid/support/v4/c/a;->h:I

    return v0
.end method

.method protected final a(Ljava/lang/Object;)I
    .registers 4

    .prologue
    .line 86
    if-nez p1, :cond_9

    iget-object v0, p0, Landroid/support/v4/c/a$1;->a:Landroid/support/v4/c/a;

    invoke-virtual {v0}, Landroid/support/v4/c/a;->a()I

    move-result v0

    :goto_8
    return v0

    :cond_9
    iget-object v0, p0, Landroid/support/v4/c/a$1;->a:Landroid/support/v4/c/a;

    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    invoke-virtual {v0, p1, v1}, Landroid/support/v4/c/a;->a(Ljava/lang/Object;I)I

    move-result v0

    goto :goto_8
.end method

.method protected final a(II)Ljava/lang/Object;
    .registers 5

    .prologue
    .line 81
    iget-object v0, p0, Landroid/support/v4/c/a$1;->a:Landroid/support/v4/c/a;

    iget-object v0, v0, Landroid/support/v4/c/a;->g:[Ljava/lang/Object;

    shl-int/lit8 v1, p1, 0x1

    add-int/2addr v1, p2

    aget-object v0, v0, v1

    return-object v0
.end method

.method protected final a(ILjava/lang/Object;)Ljava/lang/Object;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ITV;)TV;"
        }
    .end annotation

    .prologue
    .line 106
    iget-object v0, p0, Landroid/support/v4/c/a$1;->a:Landroid/support/v4/c/a;

    shl-int/lit8 v1, p1, 0x1

    add-int/lit8 v1, v1, 0x1

    iget-object v2, v0, Landroid/support/v4/c/m;->g:[Ljava/lang/Object;

    aget-object v2, v2, v1

    iget-object v0, v0, Landroid/support/v4/c/m;->g:[Ljava/lang/Object;

    aput-object p2, v0, v1

    return-object v2
.end method

.method protected final a(I)V
    .registers 3

    .prologue
    .line 111
    iget-object v0, p0, Landroid/support/v4/c/a$1;->a:Landroid/support/v4/c/a;

    invoke-virtual {v0, p1}, Landroid/support/v4/c/a;->c(I)Ljava/lang/Object;

    .line 112
    return-void
.end method

.method protected final a(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TK;TV;)V"
        }
    .end annotation

    .prologue
    .line 101
    iget-object v0, p0, Landroid/support/v4/c/a$1;->a:Landroid/support/v4/c/a;

    invoke-virtual {v0, p1, p2}, Landroid/support/v4/c/a;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 102
    return-void
.end method

.method protected final b(Ljava/lang/Object;)I
    .registers 3

    .prologue
    .line 91
    iget-object v0, p0, Landroid/support/v4/c/a$1;->a:Landroid/support/v4/c/a;

    invoke-virtual {v0, p1}, Landroid/support/v4/c/a;->a(Ljava/lang/Object;)I

    move-result v0

    return v0
.end method

.method protected final b()Ljava/util/Map;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map",
            "<TK;TV;>;"
        }
    .end annotation

    .prologue
    .line 96
    iget-object v0, p0, Landroid/support/v4/c/a$1;->a:Landroid/support/v4/c/a;

    return-object v0
.end method

.method protected final c()V
    .registers 2

    .prologue
    .line 116
    iget-object v0, p0, Landroid/support/v4/c/a$1;->a:Landroid/support/v4/c/a;

    invoke-virtual {v0}, Landroid/support/v4/c/a;->clear()V

    .line 117
    return-void
.end method
