###### Class android.support.v4.app.y (android.support.v4.app.y)
.class public final Landroid/support/v4/app/y;
.super Landroid/support/v4/app/ai;
.source "SourceFile"


# instance fields
.field a:Landroid/graphics/Bitmap;

.field b:Landroid/graphics/Bitmap;

.field c:Z


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 673
    invoke-direct {p0}, Landroid/support/v4/app/ai;-><init>()V

    .line 674
    return-void
.end method


# virtual methods
.method public final a(Landroid/graphics/Bitmap;)Landroid/support/v4/app/y;
    .registers 2

    .prologue
    .line 702
    iput-object p1, p0, Landroid/support/v4/app/y;->a:Landroid/graphics/Bitmap;

    .line 703
    return-object p0
.end method

.method public final a(Ljava/lang/CharSequence;)Landroid/support/v4/app/y;
    .registers 3

    .prologue
    .line 693
    iput-object p1, p0, Landroid/support/v4/app/y;->f:Ljava/lang/CharSequence;

    .line 694
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/app/y;->g:Z

    .line 695
    return-object p0
.end method
