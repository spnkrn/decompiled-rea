###### Class android.support.v4.app.l (android.support.v4.app.l)
.class public abstract Landroid/support/v4/app/l;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 26
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public abstract a()Landroid/support/v4/app/l;
.end method

.method public abstract a(IIII)Landroid/support/v4/app/l;
.end method

.method public abstract a(ILandroid/support/v4/app/Fragment;)Landroid/support/v4/app/l;
.end method

.method public abstract a(ILandroid/support/v4/app/Fragment;Ljava/lang/String;)Landroid/support/v4/app/l;
.end method

.method public abstract a(Landroid/support/v4/app/Fragment;)Landroid/support/v4/app/l;
.end method

.method public abstract a(Landroid/support/v4/app/Fragment;Ljava/lang/String;)Landroid/support/v4/app/l;
.end method

.method public abstract b()I
.end method

.method public abstract b(ILandroid/support/v4/app/Fragment;)Landroid/support/v4/app/l;
.end method

.method public abstract b(ILandroid/support/v4/app/Fragment;Ljava/lang/String;)Landroid/support/v4/app/l;
.end method

.method public abstract b(Landroid/support/v4/app/Fragment;)Landroid/support/v4/app/l;
.end method

.method public abstract c()I
.end method

.method public abstract c(Landroid/support/v4/app/Fragment;)Landroid/support/v4/app/l;
.end method
