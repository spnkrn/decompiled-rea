###### Class android.support.v4.app.ac (android.support.v4.app.ac)
.class interface abstract Landroid/support/v4/app/ac;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Landroid/support/v4/app/aa;)Landroid/app/Notification;
.end method
