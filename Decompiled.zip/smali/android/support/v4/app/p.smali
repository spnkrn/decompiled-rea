###### Class android.support.v4.app.p (android.support.v4.app.p)
.class final Landroid/support/v4/app/p;
.super Landroid/support/v4/app/n;
.source "SourceFile"


# static fields
.field static a:Z


# instance fields
.field final b:Landroid/support/v4/c/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/support/v4/c/n",
            "<",
            "Landroid/support/v4/app/q;",
            ">;"
        }
    .end annotation
.end field

.field final c:Landroid/support/v4/c/n;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/support/v4/c/n",
            "<",
            "Landroid/support/v4/app/q;",
            ">;"
        }
    .end annotation
.end field

.field final d:Ljava/lang/String;

.field e:Landroid/support/v4/app/FragmentActivity;

.field f:Z

.field g:Z

.field h:Z


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .prologue
    .line 189
    const/4 v0, 0x0

    sput-boolean v0, Landroid/support/v4/app/p;->a:Z

    return-void
.end method

.method constructor <init>(Ljava/lang/String;Landroid/support/v4/app/FragmentActivity;Z)V
    .registers 5

    .prologue
    .line 477
    invoke-direct {p0}, Landroid/support/v4/app/n;-><init>()V

    .line 194
    new-instance v0, Landroid/support/v4/c/n;

    invoke-direct {v0}, Landroid/support/v4/c/n;-><init>()V

    iput-object v0, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    .line 200
    new-instance v0, Landroid/support/v4/c/n;

    invoke-direct {v0}, Landroid/support/v4/c/n;-><init>()V

    iput-object v0, p0, Landroid/support/v4/app/p;->c:Landroid/support/v4/c/n;

    .line 478
    iput-object p1, p0, Landroid/support/v4/app/p;->d:Ljava/lang/String;

    .line 479
    iput-object p2, p0, Landroid/support/v4/app/p;->e:Landroid/support/v4/app/FragmentActivity;

    .line 480
    iput-boolean p3, p0, Landroid/support/v4/app/p;->f:Z

    .line 481
    return-void
.end method

.method private c(ILandroid/os/Bundle;Landroid/support/v4/app/o;)Landroid/support/v4/app/q;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Landroid/os/Bundle;",
            "Landroid/support/v4/app/o",
            "<",
            "Ljava/lang/Object;",
            ">;)",
            "Landroid/support/v4/app/q;"
        }
    .end annotation

    .prologue
    .line 489
    new-instance v0, Landroid/support/v4/app/q;

    invoke-direct {v0, p0, p1, p2, p3}, Landroid/support/v4/app/q;-><init>(Landroid/support/v4/app/p;ILandroid/os/Bundle;Landroid/support/v4/app/o;)V

    .line 490
    invoke-interface {p3, p1, p2}, Landroid/support/v4/app/o;->a(ILandroid/os/Bundle;)Landroid/support/v4/content/k;

    move-result-object v1

    .line 491
    iput-object v1, v0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    .line 492
    return-object v0
.end method

.method private d(ILandroid/os/Bundle;Landroid/support/v4/app/o;)Landroid/support/v4/app/q;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Landroid/os/Bundle;",
            "Landroid/support/v4/app/o",
            "<",
            "Ljava/lang/Object;",
            ">;)",
            "Landroid/support/v4/app/q;"
        }
    .end annotation

    .prologue
    const/4 v1, 0x0

    .line 498
    const/4 v0, 0x1

    :try_start_2
    iput-boolean v0, p0, Landroid/support/v4/app/p;->h:Z

    .line 499
    invoke-direct {p0, p1, p2, p3}, Landroid/support/v4/app/p;->c(ILandroid/os/Bundle;Landroid/support/v4/app/o;)Landroid/support/v4/app/q;

    move-result-object v0

    .line 500
    invoke-virtual {p0, v0}, Landroid/support/v4/app/p;->a(Landroid/support/v4/app/q;)V
    :try_end_b
    .catchall {:try_start_2 .. :try_end_b} :catchall_e

    .line 503
    iput-boolean v1, p0, Landroid/support/v4/app/p;->h:Z

    return-object v0

    :catchall_e
    move-exception v0

    iput-boolean v1, p0, Landroid/support/v4/app/p;->h:Z

    throw v0
.end method


# virtual methods
.method public final a(ILandroid/os/Bundle;Landroid/support/v4/app/o;)Landroid/support/v4/content/k;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<D:",
            "Ljava/lang/Object;",
            ">(I",
            "Landroid/os/Bundle;",
            "Landroid/support/v4/app/o",
            "<TD;>;)",
            "Landroid/support/v4/content/k",
            "<TD;>;"
        }
    .end annotation

    .prologue
    .line 543
    iget-boolean v0, p0, Landroid/support/v4/app/p;->h:Z

    if-eqz v0, :cond_c

    .line 544
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Called while creating a loader"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 547
    :cond_c
    iget-object v0, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    invoke-virtual {v0, p1}, Landroid/support/v4/c/n;->a(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/q;

    .line 549
    sget-boolean v1, Landroid/support/v4/app/p;->a:Z

    if-eqz v1, :cond_36

    const-string v1, "LoaderManager"

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "initLoader in "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ": args="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 551
    :cond_36
    if-nez v0, :cond_66

    .line 553
    invoke-direct {p0, p1, p2, p3}, Landroid/support/v4/app/p;->d(ILandroid/os/Bundle;Landroid/support/v4/app/o;)Landroid/support/v4/app/q;

    move-result-object v0

    .line 554
    sget-boolean v1, Landroid/support/v4/app/p;->a:Z

    if-eqz v1, :cond_54

    const-string v1, "LoaderManager"

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "  Created new loader "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 560
    :cond_54
    :goto_54
    iget-boolean v1, v0, Landroid/support/v4/app/q;->e:Z

    if-eqz v1, :cond_63

    iget-boolean v1, p0, Landroid/support/v4/app/p;->f:Z

    if-eqz v1, :cond_63

    .line 562
    iget-object v1, v0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    iget-object v2, v0, Landroid/support/v4/app/q;->g:Ljava/lang/Object;

    invoke-virtual {v0, v1, v2}, Landroid/support/v4/app/q;->b(Landroid/support/v4/content/k;Ljava/lang/Object;)V

    .line 565
    :cond_63
    iget-object v0, v0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    return-object v0

    .line 556
    :cond_66
    sget-boolean v1, Landroid/support/v4/app/p;->a:Z

    if-eqz v1, :cond_7e

    const-string v1, "LoaderManager"

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "  Re-using existing loader "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 557
    :cond_7e
    iput-object p3, v0, Landroid/support/v4/app/q;->c:Landroid/support/v4/app/o;

    goto :goto_54
.end method

.method public final a(I)V
    .registers 5

    .prologue
    .line 658
    iget-boolean v0, p0, Landroid/support/v4/app/p;->h:Z

    if-eqz v0, :cond_c

    .line 659
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Called while creating a loader"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 662
    :cond_c
    sget-boolean v0, Landroid/support/v4/app/p;->a:Z

    if-eqz v0, :cond_2e

    const-string v0, "LoaderManager"

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "destroyLoader in "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " of "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 663
    :cond_2e
    iget-object v0, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    invoke-virtual {v0, p1}, Landroid/support/v4/c/n;->f(I)I

    move-result v1

    .line 664
    if-ltz v1, :cond_46

    .line 665
    iget-object v0, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    invoke-virtual {v0, v1}, Landroid/support/v4/c/n;->e(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/q;

    .line 666
    iget-object v2, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    invoke-virtual {v2, v1}, Landroid/support/v4/c/n;->c(I)V

    .line 667
    invoke-virtual {v0}, Landroid/support/v4/app/q;->c()V

    .line 669
    :cond_46
    iget-object v0, p0, Landroid/support/v4/app/p;->c:Landroid/support/v4/c/n;

    invoke-virtual {v0, p1}, Landroid/support/v4/c/n;->f(I)I

    move-result v1

    .line 670
    if-ltz v1, :cond_5e

    .line 671
    iget-object v0, p0, Landroid/support/v4/app/p;->c:Landroid/support/v4/c/n;

    invoke-virtual {v0, v1}, Landroid/support/v4/c/n;->e(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/q;

    .line 672
    iget-object v2, p0, Landroid/support/v4/app/p;->c:Landroid/support/v4/c/n;

    invoke-virtual {v2, v1}, Landroid/support/v4/c/n;->c(I)V

    .line 673
    invoke-virtual {v0}, Landroid/support/v4/app/q;->c()V

    .line 675
    :cond_5e
    iget-object v0, p0, Landroid/support/v4/app/p;->e:Landroid/support/v4/app/FragmentActivity;

    if-eqz v0, :cond_6f

    invoke-virtual {p0}, Landroid/support/v4/app/p;->a()Z

    move-result v0

    if-nez v0, :cond_6f

    .line 676
    iget-object v0, p0, Landroid/support/v4/app/p;->e:Landroid/support/v4/app/FragmentActivity;

    iget-object v0, v0, Landroid/support/v4/app/FragmentActivity;->b:Landroid/support/v4/app/i;

    invoke-virtual {v0}, Landroid/support/v4/app/i;->e()V

    .line 678
    :cond_6f
    return-void
.end method

.method final a(Landroid/support/v4/app/q;)V
    .registers 4

    .prologue
    .line 508
    iget-object v0, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    iget v1, p1, Landroid/support/v4/app/q;->a:I

    invoke-virtual {v0, v1, p1}, Landroid/support/v4/c/n;->a(ILjava/lang/Object;)V

    .line 509
    iget-boolean v0, p0, Landroid/support/v4/app/p;->f:Z

    if-eqz v0, :cond_e

    .line 513
    invoke-virtual {p1}, Landroid/support/v4/app/q;->a()V

    .line 515
    :cond_e
    return-void
.end method

.method public final a(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    .registers 10

    .prologue
    const/4 v2, 0x0

    .line 801
    iget-object v0, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    invoke-virtual {v0}, Landroid/support/v4/c/n;->a()I

    move-result v0

    if-lez v0, :cond_59

    .line 802
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "Active Loaders:"

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 803
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "    "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    move v1, v2

    .line 804
    :goto_25
    iget-object v0, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    invoke-virtual {v0}, Landroid/support/v4/c/n;->a()I

    move-result v0

    if-ge v1, v0, :cond_59

    .line 805
    iget-object v0, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    invoke-virtual {v0, v1}, Landroid/support/v4/c/n;->e(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/q;

    .line 806
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v4, "  #"

    invoke-virtual {p3, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v4, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    invoke-virtual {v4, v1}, Landroid/support/v4/c/n;->d(I)I

    move-result v4

    invoke-virtual {p3, v4}, Ljava/io/PrintWriter;->print(I)V

    .line 807
    const-string v4, ": "

    invoke-virtual {p3, v4}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-virtual {v0}, Landroid/support/v4/app/q;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {p3, v4}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 808
    invoke-virtual {v0, v3, p2, p3, p4}, Landroid/support/v4/app/q;->a(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    .line 804
    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_25

    .line 811
    :cond_59
    iget-object v0, p0, Landroid/support/v4/app/p;->c:Landroid/support/v4/c/n;

    invoke-virtual {v0}, Landroid/support/v4/c/n;->a()I

    move-result v0

    if-lez v0, :cond_af

    .line 812
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "Inactive Loaders:"

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 813
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "    "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 814
    :goto_7c
    iget-object v0, p0, Landroid/support/v4/app/p;->c:Landroid/support/v4/c/n;

    invoke-virtual {v0}, Landroid/support/v4/c/n;->a()I

    move-result v0

    if-ge v2, v0, :cond_af

    .line 815
    iget-object v0, p0, Landroid/support/v4/app/p;->c:Landroid/support/v4/c/n;

    invoke-virtual {v0, v2}, Landroid/support/v4/c/n;->e(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/q;

    .line 816
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v3, "  #"

    invoke-virtual {p3, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v3, p0, Landroid/support/v4/app/p;->c:Landroid/support/v4/c/n;

    invoke-virtual {v3, v2}, Landroid/support/v4/c/n;->d(I)I

    move-result v3

    invoke-virtual {p3, v3}, Ljava/io/PrintWriter;->print(I)V

    .line 817
    const-string v3, ": "

    invoke-virtual {p3, v3}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    invoke-virtual {v0}, Landroid/support/v4/app/q;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p3, v3}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 818
    invoke-virtual {v0, v1, p2, p3, p4}, Landroid/support/v4/app/q;->a(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    .line 814
    add-int/lit8 v2, v2, 0x1

    goto :goto_7c

    .line 821
    :cond_af
    return-void
.end method

.method public final a()Z
    .registers 7

    .prologue
    const/4 v1, 0x0

    .line 825
    .line 826
    iget-object v0, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    invoke-virtual {v0}, Landroid/support/v4/c/n;->a()I

    move-result v4

    move v2, v1

    move v3, v1

    .line 827
    :goto_9
    if-ge v2, v4, :cond_23

    .line 828
    iget-object v0, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    invoke-virtual {v0, v2}, Landroid/support/v4/c/n;->e(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/q;

    .line 829
    iget-boolean v5, v0, Landroid/support/v4/app/q;->h:Z

    if-eqz v5, :cond_21

    iget-boolean v0, v0, Landroid/support/v4/app/q;->f:Z

    if-nez v0, :cond_21

    const/4 v0, 0x1

    :goto_1c
    or-int/2addr v3, v0

    .line 827
    add-int/lit8 v0, v2, 0x1

    move v2, v0

    goto :goto_9

    :cond_21
    move v0, v1

    .line 829
    goto :goto_1c

    .line 831
    :cond_23
    return v3
.end method

.method public final b(ILandroid/os/Bundle;Landroid/support/v4/app/o;)Landroid/support/v4/content/k;
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<D:",
            "Ljava/lang/Object;",
            ">(I",
            "Landroid/os/Bundle;",
            "Landroid/support/v4/app/o",
            "<TD;>;)",
            "Landroid/support/v4/content/k",
            "<TD;>;"
        }
    .end annotation

    .prologue
    const/4 v4, 0x0

    .line 593
    iget-boolean v0, p0, Landroid/support/v4/app/p;->h:Z

    if-eqz v0, :cond_d

    .line 594
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Called while creating a loader"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 597
    :cond_d
    iget-object v0, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    invoke-virtual {v0, p1}, Landroid/support/v4/c/n;->a(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/q;

    .line 598
    sget-boolean v1, Landroid/support/v4/app/p;->a:Z

    if-eqz v1, :cond_37

    const-string v1, "LoaderManager"

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "restartLoader in "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ": args="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 599
    :cond_37
    if-eqz v0, :cond_6f

    .line 600
    iget-object v1, p0, Landroid/support/v4/app/p;->c:Landroid/support/v4/c/n;

    invoke-virtual {v1, p1}, Landroid/support/v4/c/n;->a(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/support/v4/app/q;

    .line 601
    if-eqz v1, :cond_c9

    .line 602
    iget-boolean v2, v0, Landroid/support/v4/app/q;->e:Z

    if-eqz v2, :cond_76

    .line 607
    sget-boolean v2, Landroid/support/v4/app/p;->a:Z

    if-eqz v2, :cond_5f

    const-string v2, "LoaderManager"

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "  Removing last inactive loader: "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 608
    :cond_5f
    const/4 v2, 0x0

    iput-boolean v2, v1, Landroid/support/v4/app/q;->f:Z

    .line 609
    invoke-virtual {v1}, Landroid/support/v4/app/q;->c()V

    .line 641
    :cond_65
    :goto_65
    iget-object v1, v0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    invoke-virtual {v1}, Landroid/support/v4/content/k;->l()V

    .line 642
    iget-object v1, p0, Landroid/support/v4/app/p;->c:Landroid/support/v4/c/n;

    invoke-virtual {v1, p1, v0}, Landroid/support/v4/c/n;->a(ILjava/lang/Object;)V

    .line 646
    :cond_6f
    :goto_6f
    invoke-direct {p0, p1, p2, p3}, Landroid/support/v4/app/p;->d(ILandroid/os/Bundle;Landroid/support/v4/app/o;)Landroid/support/v4/app/q;

    move-result-object v0

    .line 647
    iget-object v0, v0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    :goto_75
    return-object v0

    .line 615
    :cond_76
    iget-boolean v1, v0, Landroid/support/v4/app/q;->h:Z

    if-nez v1, :cond_8e

    .line 619
    sget-boolean v1, Landroid/support/v4/app/p;->a:Z

    if-eqz v1, :cond_85

    const-string v1, "LoaderManager"

    const-string v2, "  Current loader is stopped; replacing"

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 620
    :cond_85
    iget-object v1, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    invoke-virtual {v1, p1, v4}, Landroid/support/v4/c/n;->a(ILjava/lang/Object;)V

    .line 621
    invoke-virtual {v0}, Landroid/support/v4/app/q;->c()V

    goto :goto_6f

    .line 626
    :cond_8e
    iget-object v1, v0, Landroid/support/v4/app/q;->n:Landroid/support/v4/app/q;

    if-eqz v1, :cond_b3

    .line 627
    sget-boolean v1, Landroid/support/v4/app/p;->a:Z

    if-eqz v1, :cond_ac

    const-string v1, "LoaderManager"

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "  Removing pending loader: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v3, v0, Landroid/support/v4/app/q;->n:Landroid/support/v4/app/q;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 628
    :cond_ac
    iget-object v1, v0, Landroid/support/v4/app/q;->n:Landroid/support/v4/app/q;

    invoke-virtual {v1}, Landroid/support/v4/app/q;->c()V

    .line 629
    iput-object v4, v0, Landroid/support/v4/app/q;->n:Landroid/support/v4/app/q;

    .line 631
    :cond_b3
    sget-boolean v1, Landroid/support/v4/app/p;->a:Z

    if-eqz v1, :cond_be

    const-string v1, "LoaderManager"

    const-string v2, "  Enqueuing as new pending loader"

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 632
    :cond_be
    invoke-direct {p0, p1, p2, p3}, Landroid/support/v4/app/p;->c(ILandroid/os/Bundle;Landroid/support/v4/app/o;)Landroid/support/v4/app/q;

    move-result-object v1

    iput-object v1, v0, Landroid/support/v4/app/q;->n:Landroid/support/v4/app/q;

    .line 634
    iget-object v0, v0, Landroid/support/v4/app/q;->n:Landroid/support/v4/app/q;

    iget-object v0, v0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    goto :goto_75

    .line 640
    :cond_c9
    sget-boolean v1, Landroid/support/v4/app/p;->a:Z

    if-eqz v1, :cond_65

    const-string v1, "LoaderManager"

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "  Making last loader inactive: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_65
.end method

.method final b()V
    .registers 5

    .prologue
    .line 701
    sget-boolean v0, Landroid/support/v4/app/p;->a:Z

    if-eqz v0, :cond_18

    const-string v0, "LoaderManager"

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Starting in "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 702
    :cond_18
    iget-boolean v0, p0, Landroid/support/v4/app/p;->f:Z

    if-eqz v0, :cond_3b

    .line 703
    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "here"

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 704
    invoke-virtual {v0}, Ljava/lang/RuntimeException;->fillInStackTrace()Ljava/lang/Throwable;

    .line 705
    const-string v1, "LoaderManager"

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Called doStart when already started: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 716
    :cond_3a
    return-void

    .line 709
    :cond_3b
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/app/p;->f:Z

    .line 713
    iget-object v0, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    invoke-virtual {v0}, Landroid/support/v4/c/n;->a()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    move v1, v0

    :goto_47
    if-ltz v1, :cond_3a

    .line 714
    iget-object v0, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    invoke-virtual {v0, v1}, Landroid/support/v4/c/n;->e(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/q;

    invoke-virtual {v0}, Landroid/support/v4/app/q;->a()V

    .line 713
    add-int/lit8 v0, v1, -0x1

    move v1, v0

    goto :goto_47
.end method

.method final c()V
    .registers 5

    .prologue
    .line 719
    sget-boolean v0, Landroid/support/v4/app/p;->a:Z

    if-eqz v0, :cond_18

    const-string v0, "LoaderManager"

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Stopping in "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 720
    :cond_18
    iget-boolean v0, p0, Landroid/support/v4/app/p;->f:Z

    if-nez v0, :cond_3b

    .line 721
    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "here"

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 722
    invoke-virtual {v0}, Ljava/lang/RuntimeException;->fillInStackTrace()Ljava/lang/Throwable;

    .line 723
    const-string v1, "LoaderManager"

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Called doStop when not started: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 731
    :goto_3a
    return-void

    .line 727
    :cond_3b
    iget-object v0, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    invoke-virtual {v0}, Landroid/support/v4/c/n;->a()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    move v1, v0

    :goto_44
    if-ltz v1, :cond_55

    .line 728
    iget-object v0, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    invoke-virtual {v0, v1}, Landroid/support/v4/c/n;->e(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/q;

    invoke-virtual {v0}, Landroid/support/v4/app/q;->b()V

    .line 727
    add-int/lit8 v0, v1, -0x1

    move v1, v0

    goto :goto_44

    .line 730
    :cond_55
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v4/app/p;->f:Z

    goto :goto_3a
.end method

.method final d()V
    .registers 8

    .prologue
    const/4 v6, 0x1

    const/4 v5, 0x0

    .line 734
    sget-boolean v0, Landroid/support/v4/app/p;->a:Z

    if-eqz v0, :cond_1a

    const-string v0, "LoaderManager"

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Retaining in "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 735
    :cond_1a
    iget-boolean v0, p0, Landroid/support/v4/app/p;->f:Z

    if-nez v0, :cond_3d

    .line 736
    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "here"

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 737
    invoke-virtual {v0}, Ljava/lang/RuntimeException;->fillInStackTrace()Ljava/lang/Throwable;

    .line 738
    const-string v1, "LoaderManager"

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Called doRetain when not started: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2, v0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 747
    :cond_3c
    return-void

    .line 742
    :cond_3d
    iput-boolean v6, p0, Landroid/support/v4/app/p;->g:Z

    .line 743
    iput-boolean v5, p0, Landroid/support/v4/app/p;->f:Z

    .line 744
    iget-object v0, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    invoke-virtual {v0}, Landroid/support/v4/c/n;->a()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    move v1, v0

    :goto_4a
    if-ltz v1, :cond_3c

    .line 745
    iget-object v0, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    invoke-virtual {v0, v1}, Landroid/support/v4/c/n;->e(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/q;

    sget-boolean v2, Landroid/support/v4/app/p;->a:Z

    if-eqz v2, :cond_6c

    const-string v2, "LoaderManager"

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "  Retaining: "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v3}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    :cond_6c
    iput-boolean v6, v0, Landroid/support/v4/app/q;->i:Z

    iget-boolean v2, v0, Landroid/support/v4/app/q;->h:Z

    iput-boolean v2, v0, Landroid/support/v4/app/q;->j:Z

    iput-boolean v5, v0, Landroid/support/v4/app/q;->h:Z

    const/4 v2, 0x0

    iput-object v2, v0, Landroid/support/v4/app/q;->c:Landroid/support/v4/app/o;

    .line 744
    add-int/lit8 v0, v1, -0x1

    move v1, v0

    goto :goto_4a
.end method

.method final e()V
    .registers 4

    .prologue
    .line 761
    iget-object v0, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    invoke-virtual {v0}, Landroid/support/v4/c/n;->a()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    move v1, v0

    :goto_9
    if-ltz v1, :cond_1a

    .line 762
    iget-object v0, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    invoke-virtual {v0, v1}, Landroid/support/v4/c/n;->e(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/q;

    const/4 v2, 0x1

    iput-boolean v2, v0, Landroid/support/v4/app/q;->k:Z

    .line 761
    add-int/lit8 v0, v1, -0x1

    move v1, v0

    goto :goto_9

    .line 764
    :cond_1a
    return-void
.end method

.method final f()V
    .registers 5

    .prologue
    .line 767
    iget-object v0, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    invoke-virtual {v0}, Landroid/support/v4/c/n;->a()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    move v1, v0

    :goto_9
    if-ltz v1, :cond_2d

    .line 768
    iget-object v0, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    invoke-virtual {v0, v1}, Landroid/support/v4/c/n;->e(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/q;

    iget-boolean v2, v0, Landroid/support/v4/app/q;->h:Z

    if-eqz v2, :cond_29

    iget-boolean v2, v0, Landroid/support/v4/app/q;->k:Z

    if-eqz v2, :cond_29

    const/4 v2, 0x0

    iput-boolean v2, v0, Landroid/support/v4/app/q;->k:Z

    iget-boolean v2, v0, Landroid/support/v4/app/q;->e:Z

    if-eqz v2, :cond_29

    iget-object v2, v0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    iget-object v3, v0, Landroid/support/v4/app/q;->g:Ljava/lang/Object;

    invoke-virtual {v0, v2, v3}, Landroid/support/v4/app/q;->b(Landroid/support/v4/content/k;Ljava/lang/Object;)V

    .line 767
    :cond_29
    add-int/lit8 v0, v1, -0x1

    move v1, v0

    goto :goto_9

    .line 770
    :cond_2d
    return-void
.end method

.method final g()V
    .registers 4

    .prologue
    .line 773
    iget-boolean v0, p0, Landroid/support/v4/app/p;->g:Z

    if-nez v0, :cond_3b

    .line 774
    sget-boolean v0, Landroid/support/v4/app/p;->a:Z

    if-eqz v0, :cond_1c

    const-string v0, "LoaderManager"

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Destroying Active in "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 775
    :cond_1c
    iget-object v0, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    invoke-virtual {v0}, Landroid/support/v4/c/n;->a()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    move v1, v0

    :goto_25
    if-ltz v1, :cond_36

    .line 776
    iget-object v0, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    invoke-virtual {v0, v1}, Landroid/support/v4/c/n;->e(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/q;

    invoke-virtual {v0}, Landroid/support/v4/app/q;->c()V

    .line 775
    add-int/lit8 v0, v1, -0x1

    move v1, v0

    goto :goto_25

    .line 778
    :cond_36
    iget-object v0, p0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    invoke-virtual {v0}, Landroid/support/v4/c/n;->b()V

    .line 781
    :cond_3b
    sget-boolean v0, Landroid/support/v4/app/p;->a:Z

    if-eqz v0, :cond_53

    const-string v0, "LoaderManager"

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Destroying Inactive in "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 782
    :cond_53
    iget-object v0, p0, Landroid/support/v4/app/p;->c:Landroid/support/v4/c/n;

    invoke-virtual {v0}, Landroid/support/v4/c/n;->a()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    move v1, v0

    :goto_5c
    if-ltz v1, :cond_6d

    .line 783
    iget-object v0, p0, Landroid/support/v4/app/p;->c:Landroid/support/v4/c/n;

    invoke-virtual {v0, v1}, Landroid/support/v4/c/n;->e(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/q;

    invoke-virtual {v0}, Landroid/support/v4/app/q;->c()V

    .line 782
    add-int/lit8 v0, v1, -0x1

    move v1, v0

    goto :goto_5c

    .line 785
    :cond_6d
    iget-object v0, p0, Landroid/support/v4/app/p;->c:Landroid/support/v4/c/n;

    invoke-virtual {v0}, Landroid/support/v4/c/n;->b()V

    .line 786
    return-void
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    .prologue
    .line 790
    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x80

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 791
    const-string v1, "LoaderManager{"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 792
    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 793
    const-string v1, " in "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 794
    iget-object v1, p0, Landroid/support/v4/app/p;->e:Landroid/support/v4/app/FragmentActivity;

    invoke-static {v1, v0}, Landroid/support/v4/c/c;->a(Ljava/lang/Object;Ljava/lang/StringBuilder;)V

    .line 795
    const-string v1, "}}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 796
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
