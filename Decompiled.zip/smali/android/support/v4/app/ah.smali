###### Class android.support.v4.app.ah (android.support.v4.app.ah)
.class final Landroid/support/v4/app/ah;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/support/v4/app/ac;


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 130
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/support/v4/app/aa;)Landroid/app/Notification;
    .registers 20

    .prologue
    .line 132
    new-instance v1, Landroid/support/v4/app/aj;

    move-object/from16 v0, p1

    iget-object v2, v0, Landroid/support/v4/app/aa;->a:Landroid/content/Context;

    move-object/from16 v0, p1

    iget-object v3, v0, Landroid/support/v4/app/aa;->r:Landroid/app/Notification;

    move-object/from16 v0, p1

    iget-object v4, v0, Landroid/support/v4/app/aa;->b:Ljava/lang/CharSequence;

    move-object/from16 v0, p1

    iget-object v5, v0, Landroid/support/v4/app/aa;->c:Ljava/lang/CharSequence;

    move-object/from16 v0, p1

    iget-object v6, v0, Landroid/support/v4/app/aa;->h:Ljava/lang/CharSequence;

    move-object/from16 v0, p1

    iget-object v7, v0, Landroid/support/v4/app/aa;->f:Landroid/widget/RemoteViews;

    move-object/from16 v0, p1

    iget v8, v0, Landroid/support/v4/app/aa;->i:I

    move-object/from16 v0, p1

    iget-object v9, v0, Landroid/support/v4/app/aa;->d:Landroid/app/PendingIntent;

    move-object/from16 v0, p1

    iget-object v10, v0, Landroid/support/v4/app/aa;->e:Landroid/app/PendingIntent;

    move-object/from16 v0, p1

    iget-object v11, v0, Landroid/support/v4/app/aa;->g:Landroid/graphics/Bitmap;

    move-object/from16 v0, p1

    iget v12, v0, Landroid/support/v4/app/aa;->n:I

    move-object/from16 v0, p1

    iget v13, v0, Landroid/support/v4/app/aa;->o:I

    move-object/from16 v0, p1

    iget-boolean v14, v0, Landroid/support/v4/app/aa;->p:Z

    move-object/from16 v0, p1

    iget-boolean v15, v0, Landroid/support/v4/app/aa;->k:Z

    move-object/from16 v0, p1

    iget v0, v0, Landroid/support/v4/app/aa;->j:I

    move/from16 v16, v0

    move-object/from16 v0, p1

    iget-object v0, v0, Landroid/support/v4/app/aa;->m:Ljava/lang/CharSequence;

    move-object/from16 v17, v0

    invoke-direct/range {v1 .. v17}, Landroid/support/v4/app/aj;-><init>(Landroid/content/Context;Landroid/app/Notification;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Landroid/widget/RemoteViews;ILandroid/app/PendingIntent;Landroid/app/PendingIntent;Landroid/graphics/Bitmap;IIZZILjava/lang/CharSequence;)V

    .line 137
    move-object/from16 v0, p1

    iget-object v2, v0, Landroid/support/v4/app/aa;->q:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_51
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_67

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/support/v4/app/x;

    .line 138
    iget v4, v2, Landroid/support/v4/app/x;->a:I

    iget-object v5, v2, Landroid/support/v4/app/x;->b:Ljava/lang/CharSequence;

    iget-object v2, v2, Landroid/support/v4/app/x;->c:Landroid/app/PendingIntent;

    invoke-virtual {v1, v4, v5, v2}, Landroid/support/v4/app/aj;->a(ILjava/lang/CharSequence;Landroid/app/PendingIntent;)V

    goto :goto_51

    .line 140
    :cond_67
    move-object/from16 v0, p1

    iget-object v2, v0, Landroid/support/v4/app/aa;->l:Landroid/support/v4/app/ai;

    if-eqz v2, :cond_86

    .line 141
    move-object/from16 v0, p1

    iget-object v2, v0, Landroid/support/v4/app/aa;->l:Landroid/support/v4/app/ai;

    instance-of v2, v2, Landroid/support/v4/app/z;

    if-eqz v2, :cond_8b

    .line 142
    move-object/from16 v0, p1

    iget-object v2, v0, Landroid/support/v4/app/aa;->l:Landroid/support/v4/app/ai;

    check-cast v2, Landroid/support/v4/app/z;

    .line 143
    iget-object v3, v2, Landroid/support/v4/app/z;->e:Ljava/lang/CharSequence;

    iget-boolean v4, v2, Landroid/support/v4/app/z;->g:Z

    iget-object v5, v2, Landroid/support/v4/app/z;->f:Ljava/lang/CharSequence;

    iget-object v2, v2, Landroid/support/v4/app/z;->a:Ljava/lang/CharSequence;

    invoke-virtual {v1, v3, v4, v5, v2}, Landroid/support/v4/app/aj;->a(Ljava/lang/CharSequence;ZLjava/lang/CharSequence;Ljava/lang/CharSequence;)V

    .line 163
    :cond_86
    :goto_86
    invoke-virtual {v1}, Landroid/support/v4/app/aj;->a()Landroid/app/Notification;

    move-result-object v1

    return-object v1

    .line 147
    :cond_8b
    move-object/from16 v0, p1

    iget-object v2, v0, Landroid/support/v4/app/aa;->l:Landroid/support/v4/app/ai;

    instance-of v2, v2, Landroid/support/v4/app/ab;

    if-eqz v2, :cond_a5

    .line 148
    move-object/from16 v0, p1

    iget-object v2, v0, Landroid/support/v4/app/aa;->l:Landroid/support/v4/app/ai;

    check-cast v2, Landroid/support/v4/app/ab;

    .line 149
    iget-object v3, v2, Landroid/support/v4/app/ab;->e:Ljava/lang/CharSequence;

    iget-boolean v4, v2, Landroid/support/v4/app/ab;->g:Z

    iget-object v5, v2, Landroid/support/v4/app/ab;->f:Ljava/lang/CharSequence;

    iget-object v2, v2, Landroid/support/v4/app/ab;->a:Ljava/util/ArrayList;

    invoke-virtual {v1, v3, v4, v5, v2}, Landroid/support/v4/app/aj;->a(Ljava/lang/CharSequence;ZLjava/lang/CharSequence;Ljava/util/ArrayList;)V

    goto :goto_86

    .line 153
    :cond_a5
    move-object/from16 v0, p1

    iget-object v2, v0, Landroid/support/v4/app/aa;->l:Landroid/support/v4/app/ai;

    instance-of v2, v2, Landroid/support/v4/app/y;

    if-eqz v2, :cond_86

    .line 154
    move-object/from16 v0, p1

    iget-object v2, v0, Landroid/support/v4/app/aa;->l:Landroid/support/v4/app/ai;

    move-object v7, v2

    check-cast v7, Landroid/support/v4/app/y;

    .line 155
    iget-object v2, v7, Landroid/support/v4/app/y;->e:Ljava/lang/CharSequence;

    iget-boolean v3, v7, Landroid/support/v4/app/y;->g:Z

    iget-object v4, v7, Landroid/support/v4/app/y;->f:Ljava/lang/CharSequence;

    iget-object v5, v7, Landroid/support/v4/app/y;->a:Landroid/graphics/Bitmap;

    iget-object v6, v7, Landroid/support/v4/app/y;->b:Landroid/graphics/Bitmap;

    iget-boolean v7, v7, Landroid/support/v4/app/y;->c:Z

    invoke-virtual/range {v1 .. v7}, Landroid/support/v4/app/aj;->a(Ljava/lang/CharSequence;ZLjava/lang/CharSequence;Landroid/graphics/Bitmap;Landroid/graphics/Bitmap;Z)V

    goto :goto_86
.end method
