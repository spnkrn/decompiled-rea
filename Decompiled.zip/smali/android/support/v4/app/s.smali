###### Class android.support.v4.app.s (android.support.v4.app.s)
.class interface abstract Landroid/support/v4/app/s;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Landroid/app/Activity;)Landroid/content/Intent;
.end method

.method public abstract a(Landroid/content/Context;Landroid/content/pm/ActivityInfo;)Ljava/lang/String;
.end method

.method public abstract a(Landroid/app/Activity;Landroid/content/Intent;)Z
.end method

.method public abstract b(Landroid/app/Activity;Landroid/content/Intent;)V
.end method
