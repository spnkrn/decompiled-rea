###### Class android.support.v4.app.aa (android.support.v4.app.aa)
.class public final Landroid/support/v4/app/aa;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field a:Landroid/content/Context;

.field b:Ljava/lang/CharSequence;

.field c:Ljava/lang/CharSequence;

.field d:Landroid/app/PendingIntent;

.field e:Landroid/app/PendingIntent;

.field f:Landroid/widget/RemoteViews;

.field g:Landroid/graphics/Bitmap;

.field h:Ljava/lang/CharSequence;

.field i:I

.field j:I

.field k:Z

.field l:Landroid/support/v4/app/ai;

.field m:Ljava/lang/CharSequence;

.field n:I

.field o:I

.field p:Z

.field q:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList",
            "<",
            "Landroid/support/v4/app/x;",
            ">;"
        }
    .end annotation
.end field

.field r:Landroid/app/Notification;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 5

    .prologue
    .line 234
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 219
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroid/support/v4/app/aa;->q:Ljava/util/ArrayList;

    .line 221
    new-instance v0, Landroid/app/Notification;

    invoke-direct {v0}, Landroid/app/Notification;-><init>()V

    iput-object v0, p0, Landroid/support/v4/app/aa;->r:Landroid/app/Notification;

    .line 235
    iput-object p1, p0, Landroid/support/v4/app/aa;->a:Landroid/content/Context;

    .line 238
    iget-object v0, p0, Landroid/support/v4/app/aa;->r:Landroid/app/Notification;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    iput-wide v1, v0, Landroid/app/Notification;->when:J

    .line 239
    iget-object v0, p0, Landroid/support/v4/app/aa;->r:Landroid/app/Notification;

    const/4 v1, -0x1

    iput v1, v0, Landroid/app/Notification;->audioStreamType:I

    .line 240
    const/4 v0, 0x0

    iput v0, p0, Landroid/support/v4/app/aa;->j:I

    .line 241
    return-void
.end method

.method private a(I)V
    .registers 4

    .prologue
    .line 537
    iget-object v0, p0, Landroid/support/v4/app/aa;->r:Landroid/app/Notification;

    iget v1, v0, Landroid/app/Notification;->flags:I

    or-int/2addr v1, p1

    iput v1, v0, Landroid/app/Notification;->flags:I

    return-void
.end method


# virtual methods
.method public final a()Landroid/support/v4/app/aa;
    .registers 3

    .prologue
    .line 276
    iget-object v0, p0, Landroid/support/v4/app/aa;->r:Landroid/app/Notification;

    const v1, 0x7f020181

    iput v1, v0, Landroid/app/Notification;->icon:I

    .line 277
    return-object p0
.end method

.method public final a(III)Landroid/support/v4/app/aa;
    .registers 9

    .prologue
    const/4 v1, 0x1

    const/4 v2, 0x0

    .line 473
    iget-object v0, p0, Landroid/support/v4/app/aa;->r:Landroid/app/Notification;

    iput p1, v0, Landroid/app/Notification;->ledARGB:I

    .line 474
    iget-object v0, p0, Landroid/support/v4/app/aa;->r:Landroid/app/Notification;

    iput p2, v0, Landroid/app/Notification;->ledOnMS:I

    .line 475
    iget-object v0, p0, Landroid/support/v4/app/aa;->r:Landroid/app/Notification;

    iput p3, v0, Landroid/app/Notification;->ledOffMS:I

    .line 476
    iget-object v0, p0, Landroid/support/v4/app/aa;->r:Landroid/app/Notification;

    iget v0, v0, Landroid/app/Notification;->ledOnMS:I

    if-eqz v0, :cond_2a

    iget-object v0, p0, Landroid/support/v4/app/aa;->r:Landroid/app/Notification;

    iget v0, v0, Landroid/app/Notification;->ledOffMS:I

    if-eqz v0, :cond_2a

    move v0, v1

    .line 477
    :goto_1b
    iget-object v3, p0, Landroid/support/v4/app/aa;->r:Landroid/app/Notification;

    iget-object v4, p0, Landroid/support/v4/app/aa;->r:Landroid/app/Notification;

    iget v4, v4, Landroid/app/Notification;->flags:I

    and-int/lit8 v4, v4, -0x2

    if-eqz v0, :cond_2c

    :goto_25
    or-int v0, v4, v1

    iput v0, v3, Landroid/app/Notification;->flags:I

    .line 479
    return-object p0

    :cond_2a
    move v0, v2

    .line 476
    goto :goto_1b

    :cond_2c
    move v1, v2

    .line 477
    goto :goto_25
.end method

.method public final a(J)Landroid/support/v4/app/aa;
    .registers 4

    .prologue
    .line 248
    iget-object v0, p0, Landroid/support/v4/app/aa;->r:Landroid/app/Notification;

    iput-wide p1, v0, Landroid/app/Notification;->when:J

    .line 249
    return-object p0
.end method

.method public final a(Landroid/app/PendingIntent;)Landroid/support/v4/app/aa;
    .registers 2

    .prologue
    .line 372
    iput-object p1, p0, Landroid/support/v4/app/aa;->d:Landroid/app/PendingIntent;

    .line 373
    return-object p0
.end method

.method public final a(Landroid/support/v4/app/ai;)Landroid/support/v4/app/aa;
    .registers 4

    .prologue
    .line 590
    iget-object v0, p0, Landroid/support/v4/app/aa;->l:Landroid/support/v4/app/ai;

    if-eq v0, p1, :cond_1b

    .line 591
    iput-object p1, p0, Landroid/support/v4/app/aa;->l:Landroid/support/v4/app/ai;

    .line 592
    iget-object v0, p0, Landroid/support/v4/app/aa;->l:Landroid/support/v4/app/ai;

    if-eqz v0, :cond_1b

    .line 593
    iget-object v0, p0, Landroid/support/v4/app/aa;->l:Landroid/support/v4/app/ai;

    iget-object v1, v0, Landroid/support/v4/app/ai;->d:Landroid/support/v4/app/aa;

    if-eq v1, p0, :cond_1b

    iput-object p0, v0, Landroid/support/v4/app/ai;->d:Landroid/support/v4/app/aa;

    iget-object v1, v0, Landroid/support/v4/app/ai;->d:Landroid/support/v4/app/aa;

    if-eqz v1, :cond_1b

    iget-object v1, v0, Landroid/support/v4/app/ai;->d:Landroid/support/v4/app/aa;

    invoke-virtual {v1, v0}, Landroid/support/v4/app/aa;->a(Landroid/support/v4/app/ai;)Landroid/support/v4/app/aa;

    .line 596
    :cond_1b
    return-object p0
.end method

.method public final a(Ljava/lang/CharSequence;)Landroid/support/v4/app/aa;
    .registers 2

    .prologue
    .line 300
    iput-object p1, p0, Landroid/support/v4/app/aa;->b:Ljava/lang/CharSequence;

    .line 301
    return-object p0
.end method

.method public final b()Landroid/support/v4/app/aa;
    .registers 2

    .prologue
    .line 494
    const/4 v0, 0x2

    invoke-direct {p0, v0}, Landroid/support/v4/app/aa;->a(I)V

    .line 495
    return-object p0
.end method

.method public final b(Landroid/app/PendingIntent;)Landroid/support/v4/app/aa;
    .registers 3

    .prologue
    .line 384
    iget-object v0, p0, Landroid/support/v4/app/aa;->r:Landroid/app/Notification;

    iput-object p1, v0, Landroid/app/Notification;->deleteIntent:Landroid/app/PendingIntent;

    .line 385
    return-object p0
.end method

.method public final b(Ljava/lang/CharSequence;)Landroid/support/v4/app/aa;
    .registers 2

    .prologue
    .line 308
    iput-object p1, p0, Landroid/support/v4/app/aa;->c:Ljava/lang/CharSequence;

    .line 309
    return-object p0
.end method

.method public final c()Landroid/support/v4/app/aa;
    .registers 2

    .prologue
    .line 503
    const/16 v0, 0x8

    invoke-direct {p0, v0}, Landroid/support/v4/app/aa;->a(I)V

    .line 504
    return-object p0
.end method

.method public final c(Ljava/lang/CharSequence;)Landroid/support/v4/app/aa;
    .registers 3

    .prologue
    .line 412
    iget-object v0, p0, Landroid/support/v4/app/aa;->r:Landroid/app/Notification;

    iput-object p1, v0, Landroid/app/Notification;->tickerText:Ljava/lang/CharSequence;

    .line 413
    return-object p0
.end method

.method public final d()Landroid/support/v4/app/aa;
    .registers 2

    .prologue
    .line 514
    const/16 v0, 0x10

    invoke-direct {p0, v0}, Landroid/support/v4/app/aa;->a(I)V

    .line 515
    return-object p0
.end method

.method public final e()Landroid/support/v4/app/aa;
    .registers 3

    .prologue
    .line 529
    iget-object v0, p0, Landroid/support/v4/app/aa;->r:Landroid/app/Notification;

    const/4 v1, -0x1

    iput v1, v0, Landroid/app/Notification;->defaults:I

    .line 530
    iget-object v0, p0, Landroid/support/v4/app/aa;->r:Landroid/app/Notification;

    iget v1, v0, Landroid/app/Notification;->flags:I

    or-int/lit8 v1, v1, 0x1

    iput v1, v0, Landroid/app/Notification;->flags:I

    .line 533
    return-object p0
.end method

.method public final f()Landroid/support/v4/app/aa;
    .registers 2

    .prologue
    .line 556
    const/4 v0, 0x0

    iput v0, p0, Landroid/support/v4/app/aa;->j:I

    .line 557
    return-object p0
.end method

.method public final g()Landroid/app/Notification;
    .registers 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    .prologue
    .line 604
    invoke-static {}, Landroid/support/v4/app/w;->a()Landroid/support/v4/app/ac;

    move-result-object v0

    invoke-interface {v0, p0}, Landroid/support/v4/app/ac;->a(Landroid/support/v4/app/aa;)Landroid/app/Notification;

    move-result-object v0

    return-object v0
.end method

.method public final h()Landroid/app/Notification;
    .registers 2

    .prologue
    .line 612
    invoke-static {}, Landroid/support/v4/app/w;->a()Landroid/support/v4/app/ac;

    move-result-object v0

    invoke-interface {v0, p0}, Landroid/support/v4/app/ac;->a(Landroid/support/v4/app/aa;)Landroid/app/Notification;

    move-result-object v0

    return-object v0
.end method
