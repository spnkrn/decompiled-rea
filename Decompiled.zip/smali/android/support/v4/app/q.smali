###### Class android.support.v4.app.q (android.support.v4.app.q)
.class final Landroid/support/v4/app/q;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/support/v4/content/m;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/support/v4/content/m",
        "<",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# instance fields
.field final a:I

.field final b:Landroid/os/Bundle;

.field c:Landroid/support/v4/app/o;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/support/v4/app/o",
            "<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field d:Landroid/support/v4/content/k;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/support/v4/content/k",
            "<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field e:Z

.field f:Z

.field g:Ljava/lang/Object;

.field h:Z

.field i:Z

.field j:Z

.field k:Z

.field l:Z

.field m:Z

.field n:Landroid/support/v4/app/q;

.field final synthetic o:Landroid/support/v4/app/p;


# direct methods
.method public constructor <init>(Landroid/support/v4/app/p;ILandroid/os/Bundle;Landroid/support/v4/app/o;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Landroid/os/Bundle;",
            "Landroid/support/v4/app/o",
            "<",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    .prologue
    .line 228
    iput-object p1, p0, Landroid/support/v4/app/q;->o:Landroid/support/v4/app/p;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 229
    iput p2, p0, Landroid/support/v4/app/q;->a:I

    .line 230
    iput-object p3, p0, Landroid/support/v4/app/q;->b:Landroid/os/Bundle;

    .line 231
    iput-object p4, p0, Landroid/support/v4/app/q;->c:Landroid/support/v4/app/o;

    .line 232
    return-void
.end method


# virtual methods
.method final a()V
    .registers 5

    .prologue
    const/4 v3, 0x1

    .line 235
    iget-boolean v0, p0, Landroid/support/v4/app/q;->i:Z

    if-eqz v0, :cond_c

    iget-boolean v0, p0, Landroid/support/v4/app/q;->j:Z

    if-eqz v0, :cond_c

    .line 239
    iput-boolean v3, p0, Landroid/support/v4/app/q;->h:Z

    .line 267
    :cond_b
    :goto_b
    return-void

    .line 243
    :cond_c
    iget-boolean v0, p0, Landroid/support/v4/app/q;->h:Z

    if-nez v0, :cond_b

    .line 248
    iput-boolean v3, p0, Landroid/support/v4/app/q;->h:Z

    .line 250
    sget-boolean v0, Landroid/support/v4/app/p;->a:Z

    if-eqz v0, :cond_2a

    const-string v0, "LoaderManager"

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "  Starting: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 251
    :cond_2a
    iget-object v0, p0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    if-nez v0, :cond_3e

    iget-object v0, p0, Landroid/support/v4/app/q;->c:Landroid/support/v4/app/o;

    if-eqz v0, :cond_3e

    .line 252
    iget-object v0, p0, Landroid/support/v4/app/q;->c:Landroid/support/v4/app/o;

    iget v1, p0, Landroid/support/v4/app/q;->a:I

    iget-object v2, p0, Landroid/support/v4/app/q;->b:Landroid/os/Bundle;

    invoke-interface {v0, v1, v2}, Landroid/support/v4/app/o;->a(ILandroid/os/Bundle;)Landroid/support/v4/content/k;

    move-result-object v0

    iput-object v0, p0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    .line 254
    :cond_3e
    iget-object v0, p0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    if-eqz v0, :cond_b

    .line 255
    iget-object v0, p0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->isMemberClass()Z

    move-result v0

    if-eqz v0, :cond_75

    iget-object v0, p0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getModifiers()I

    move-result v0

    invoke-static {v0}, Ljava/lang/reflect/Modifier;->isStatic(I)Z

    move-result v0

    if-nez v0, :cond_75

    .line 257
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Object returned from onCreateLoader must not be a non-static inner member class: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 261
    :cond_75
    iget-boolean v0, p0, Landroid/support/v4/app/q;->m:Z

    if-nez v0, :cond_82

    .line 262
    iget-object v0, p0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    iget v1, p0, Landroid/support/v4/app/q;->a:I

    invoke-virtual {v0, v1, p0}, Landroid/support/v4/content/k;->a(ILandroid/support/v4/content/m;)V

    .line 263
    iput-boolean v3, p0, Landroid/support/v4/app/q;->m:Z

    .line 265
    :cond_82
    iget-object v0, p0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    invoke-virtual {v0}, Landroid/support/v4/content/k;->i()V

    goto :goto_b
.end method

.method public final a(Landroid/support/v4/content/k;Ljava/lang/Object;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/support/v4/content/k",
            "<",
            "Ljava/lang/Object;",
            ">;",
            "Ljava/lang/Object;",
            ")V"
        }
    .end annotation

    .prologue
    const/4 v4, 0x0

    .line 362
    sget-boolean v0, Landroid/support/v4/app/p;->a:Z

    if-eqz v0, :cond_19

    const-string v0, "LoaderManager"

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "onLoadComplete: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 364
    :cond_19
    iget-boolean v0, p0, Landroid/support/v4/app/q;->l:Z

    if-eqz v0, :cond_29

    .line 365
    sget-boolean v0, Landroid/support/v4/app/p;->a:Z

    if-eqz v0, :cond_28

    const-string v0, "LoaderManager"

    const-string v1, "  Ignoring load complete -- destroyed"

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 415
    :cond_28
    :goto_28
    return-void

    .line 369
    :cond_29
    iget-object v0, p0, Landroid/support/v4/app/q;->o:Landroid/support/v4/app/p;

    iget-object v0, v0, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    iget v1, p0, Landroid/support/v4/app/q;->a:I

    invoke-virtual {v0, v1}, Landroid/support/v4/c/n;->a(I)Ljava/lang/Object;

    move-result-object v0

    if-eq v0, p0, :cond_41

    .line 372
    sget-boolean v0, Landroid/support/v4/app/p;->a:Z

    if-eqz v0, :cond_28

    const-string v0, "LoaderManager"

    const-string v1, "  Ignoring load complete -- not active"

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_28

    .line 376
    :cond_41
    iget-object v0, p0, Landroid/support/v4/app/q;->n:Landroid/support/v4/app/q;

    .line 377
    if-eqz v0, :cond_71

    .line 381
    sget-boolean v1, Landroid/support/v4/app/p;->a:Z

    if-eqz v1, :cond_5d

    const-string v1, "LoaderManager"

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "  Switching to pending loader: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 382
    :cond_5d
    iput-object v4, p0, Landroid/support/v4/app/q;->n:Landroid/support/v4/app/q;

    .line 383
    iget-object v1, p0, Landroid/support/v4/app/q;->o:Landroid/support/v4/app/p;

    iget-object v1, v1, Landroid/support/v4/app/p;->b:Landroid/support/v4/c/n;

    iget v2, p0, Landroid/support/v4/app/q;->a:I

    invoke-virtual {v1, v2, v4}, Landroid/support/v4/c/n;->a(ILjava/lang/Object;)V

    .line 384
    invoke-virtual {p0}, Landroid/support/v4/app/q;->c()V

    .line 385
    iget-object v1, p0, Landroid/support/v4/app/q;->o:Landroid/support/v4/app/p;

    invoke-virtual {v1, v0}, Landroid/support/v4/app/p;->a(Landroid/support/v4/app/q;)V

    goto :goto_28

    .line 391
    :cond_71
    iget-object v0, p0, Landroid/support/v4/app/q;->g:Ljava/lang/Object;

    if-ne v0, p2, :cond_79

    iget-boolean v0, p0, Landroid/support/v4/app/q;->e:Z

    if-nez v0, :cond_85

    .line 392
    :cond_79
    iput-object p2, p0, Landroid/support/v4/app/q;->g:Ljava/lang/Object;

    .line 393
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/app/q;->e:Z

    .line 394
    iget-boolean v0, p0, Landroid/support/v4/app/q;->h:Z

    if-eqz v0, :cond_85

    .line 395
    invoke-virtual {p0, p1, p2}, Landroid/support/v4/app/q;->b(Landroid/support/v4/content/k;Ljava/lang/Object;)V

    .line 405
    :cond_85
    iget-object v0, p0, Landroid/support/v4/app/q;->o:Landroid/support/v4/app/p;

    iget-object v0, v0, Landroid/support/v4/app/p;->c:Landroid/support/v4/c/n;

    iget v1, p0, Landroid/support/v4/app/q;->a:I

    invoke-virtual {v0, v1}, Landroid/support/v4/c/n;->a(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/support/v4/app/q;

    .line 406
    if-eqz v0, :cond_a4

    if-eq v0, p0, :cond_a4

    .line 407
    const/4 v1, 0x0

    iput-boolean v1, v0, Landroid/support/v4/app/q;->f:Z

    .line 408
    invoke-virtual {v0}, Landroid/support/v4/app/q;->c()V

    .line 409
    iget-object v0, p0, Landroid/support/v4/app/q;->o:Landroid/support/v4/app/p;

    iget-object v0, v0, Landroid/support/v4/app/p;->c:Landroid/support/v4/c/n;

    iget v1, p0, Landroid/support/v4/app/q;->a:I

    invoke-virtual {v0, v1}, Landroid/support/v4/c/n;->b(I)V

    .line 412
    :cond_a4
    iget-object v0, p0, Landroid/support/v4/app/q;->o:Landroid/support/v4/app/p;

    iget-object v0, v0, Landroid/support/v4/app/p;->e:Landroid/support/v4/app/FragmentActivity;

    if-eqz v0, :cond_28

    iget-object v0, p0, Landroid/support/v4/app/q;->o:Landroid/support/v4/app/p;

    invoke-virtual {v0}, Landroid/support/v4/app/p;->a()Z

    move-result v0

    if-nez v0, :cond_28

    .line 413
    iget-object v0, p0, Landroid/support/v4/app/q;->o:Landroid/support/v4/app/p;

    iget-object v0, v0, Landroid/support/v4/app/p;->e:Landroid/support/v4/app/FragmentActivity;

    iget-object v0, v0, Landroid/support/v4/app/FragmentActivity;->b:Landroid/support/v4/app/i;

    invoke-virtual {v0}, Landroid/support/v4/app/i;->e()V

    goto/16 :goto_28
.end method

.method public final a(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    .registers 8

    .prologue
    .line 451
    :goto_0
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mId="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v0, p0, Landroid/support/v4/app/q;->a:I

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(I)V

    .line 452
    const-string v0, " mArgs="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v0, p0, Landroid/support/v4/app/q;->b:Landroid/os/Bundle;

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    .line 453
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mCallbacks="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v0, p0, Landroid/support/v4/app/q;->c:Landroid/support/v4/app/o;

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    .line 454
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mLoader="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v0, p0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    .line 455
    iget-object v0, p0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    if-eqz v0, :cond_4d

    .line 456
    iget-object v0, p0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "  "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1, p2, p3, p4}, Landroid/support/v4/content/k;->a(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    .line 458
    :cond_4d
    iget-boolean v0, p0, Landroid/support/v4/app/q;->e:Z

    if-nez v0, :cond_55

    iget-boolean v0, p0, Landroid/support/v4/app/q;->f:Z

    if-eqz v0, :cond_79

    .line 459
    :cond_55
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mHaveData="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/app/q;->e:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    .line 460
    const-string v0, "  mDeliveredData="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/app/q;->f:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Z)V

    .line 461
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mData="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v0, p0, Landroid/support/v4/app/q;->g:Ljava/lang/Object;

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    .line 463
    :cond_79
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mStarted="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/app/q;->h:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    .line 464
    const-string v0, " mReportNextStart="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/app/q;->k:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    .line 465
    const-string v0, " mDestroyed="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/app/q;->l:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Z)V

    .line 466
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mRetaining="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/app/q;->i:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    .line 467
    const-string v0, " mRetainingStarted="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/app/q;->j:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    .line 468
    const-string v0, " mListenerRegistered="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/app/q;->m:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Z)V

    .line 469
    iget-object v0, p0, Landroid/support/v4/app/q;->n:Landroid/support/v4/app/q;

    if-eqz v0, :cond_e8

    .line 470
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "Pending Loader "

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 471
    iget-object v0, p0, Landroid/support/v4/app/q;->n:Landroid/support/v4/app/q;

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/Object;)V

    const-string v0, ":"

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/String;)V

    .line 472
    iget-object p0, p0, Landroid/support/v4/app/q;->n:Landroid/support/v4/app/q;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "  "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    goto/16 :goto_0

    .line 474
    :cond_e8
    return-void
.end method

.method final b()V
    .registers 5

    .prologue
    const/4 v3, 0x0

    .line 314
    sget-boolean v0, Landroid/support/v4/app/p;->a:Z

    if-eqz v0, :cond_19

    const-string v0, "LoaderManager"

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "  Stopping: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 315
    :cond_19
    iput-boolean v3, p0, Landroid/support/v4/app/q;->h:Z

    .line 316
    iget-boolean v0, p0, Landroid/support/v4/app/q;->i:Z

    if-nez v0, :cond_33

    .line 317
    iget-object v0, p0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    if-eqz v0, :cond_33

    iget-boolean v0, p0, Landroid/support/v4/app/q;->m:Z

    if-eqz v0, :cond_33

    .line 319
    iput-boolean v3, p0, Landroid/support/v4/app/q;->m:Z

    .line 320
    iget-object v0, p0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    invoke-virtual {v0, p0}, Landroid/support/v4/content/k;->a(Landroid/support/v4/content/m;)V

    .line 321
    iget-object v0, p0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    invoke-virtual {v0}, Landroid/support/v4/content/k;->k()V

    .line 324
    :cond_33
    return-void
.end method

.method final b(Landroid/support/v4/content/k;Ljava/lang/Object;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/support/v4/content/k",
            "<",
            "Ljava/lang/Object;",
            ">;",
            "Ljava/lang/Object;",
            ")V"
        }
    .end annotation

    .prologue
    .line 418
    iget-object v0, p0, Landroid/support/v4/app/q;->c:Landroid/support/v4/app/o;

    if-eqz v0, :cond_69

    .line 419
    const/4 v0, 0x0

    .line 420
    iget-object v1, p0, Landroid/support/v4/app/q;->o:Landroid/support/v4/app/p;

    iget-object v1, v1, Landroid/support/v4/app/p;->e:Landroid/support/v4/app/FragmentActivity;

    if-eqz v1, :cond_7a

    .line 421
    iget-object v0, p0, Landroid/support/v4/app/q;->o:Landroid/support/v4/app/p;

    iget-object v0, v0, Landroid/support/v4/app/p;->e:Landroid/support/v4/app/FragmentActivity;

    iget-object v0, v0, Landroid/support/v4/app/FragmentActivity;->b:Landroid/support/v4/app/i;

    iget-object v0, v0, Landroid/support/v4/app/i;->u:Ljava/lang/String;

    .line 422
    iget-object v1, p0, Landroid/support/v4/app/q;->o:Landroid/support/v4/app/p;

    iget-object v1, v1, Landroid/support/v4/app/p;->e:Landroid/support/v4/app/FragmentActivity;

    iget-object v1, v1, Landroid/support/v4/app/FragmentActivity;->b:Landroid/support/v4/app/i;

    const-string v2, "onLoadFinished"

    iput-object v2, v1, Landroid/support/v4/app/i;->u:Ljava/lang/String;

    move-object v1, v0

    .line 425
    :goto_1e
    :try_start_1e
    sget-boolean v0, Landroid/support/v4/app/p;->a:Z

    if-eqz v0, :cond_53

    const-string v0, "LoaderManager"

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "  onLoadFinished in "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, ": "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    const/16 v4, 0x40

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(I)V

    invoke-static {p2, v3}, Landroid/support/v4/c/c;->a(Ljava/lang/Object;Ljava/lang/StringBuilder;)V

    const-string v4, "}"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 427
    :cond_53
    iget-object v0, p0, Landroid/support/v4/app/q;->c:Landroid/support/v4/app/o;

    invoke-interface {v0, p1, p2}, Landroid/support/v4/app/o;->a(Landroid/support/v4/content/k;Ljava/lang/Object;)V
    :try_end_58
    .catchall {:try_start_1e .. :try_end_58} :catchall_6a

    .line 429
    iget-object v0, p0, Landroid/support/v4/app/q;->o:Landroid/support/v4/app/p;

    iget-object v0, v0, Landroid/support/v4/app/p;->e:Landroid/support/v4/app/FragmentActivity;

    if-eqz v0, :cond_66

    .line 430
    iget-object v0, p0, Landroid/support/v4/app/q;->o:Landroid/support/v4/app/p;

    iget-object v0, v0, Landroid/support/v4/app/p;->e:Landroid/support/v4/app/FragmentActivity;

    iget-object v0, v0, Landroid/support/v4/app/FragmentActivity;->b:Landroid/support/v4/app/i;

    iput-object v1, v0, Landroid/support/v4/app/i;->u:Ljava/lang/String;

    .line 433
    :cond_66
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/app/q;->f:Z

    .line 435
    :cond_69
    return-void

    .line 429
    :catchall_6a
    move-exception v0

    iget-object v2, p0, Landroid/support/v4/app/q;->o:Landroid/support/v4/app/p;

    iget-object v2, v2, Landroid/support/v4/app/p;->e:Landroid/support/v4/app/FragmentActivity;

    if-eqz v2, :cond_79

    .line 430
    iget-object v2, p0, Landroid/support/v4/app/q;->o:Landroid/support/v4/app/p;

    iget-object v2, v2, Landroid/support/v4/app/p;->e:Landroid/support/v4/app/FragmentActivity;

    iget-object v2, v2, Landroid/support/v4/app/FragmentActivity;->b:Landroid/support/v4/app/i;

    iput-object v1, v2, Landroid/support/v4/app/i;->u:Ljava/lang/String;

    :cond_79
    throw v0

    :cond_7a
    move-object v1, v0

    goto :goto_1e
.end method

.method final c()V
    .registers 6

    .prologue
    const/4 v2, 0x0

    const/4 v4, 0x0

    .line 327
    :goto_2
    sget-boolean v0, Landroid/support/v4/app/p;->a:Z

    if-eqz v0, :cond_1a

    const-string v0, "LoaderManager"

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "  Destroying: "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 328
    :cond_1a
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/app/q;->l:Z

    .line 329
    iget-boolean v0, p0, Landroid/support/v4/app/q;->f:Z

    .line 330
    iput-boolean v4, p0, Landroid/support/v4/app/q;->f:Z

    .line 331
    iget-object v1, p0, Landroid/support/v4/app/q;->c:Landroid/support/v4/app/o;

    if-eqz v1, :cond_75

    iget-object v1, p0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    if-eqz v1, :cond_75

    iget-boolean v1, p0, Landroid/support/v4/app/q;->e:Z

    if-eqz v1, :cond_75

    if-eqz v0, :cond_75

    .line 332
    sget-boolean v0, Landroid/support/v4/app/p;->a:Z

    if-eqz v0, :cond_47

    const-string v0, "LoaderManager"

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "  Reseting: "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->v(Ljava/lang/String;Ljava/lang/String;)I

    .line 334
    :cond_47
    iget-object v0, p0, Landroid/support/v4/app/q;->o:Landroid/support/v4/app/p;

    iget-object v0, v0, Landroid/support/v4/app/p;->e:Landroid/support/v4/app/FragmentActivity;

    if-eqz v0, :cond_a8

    .line 335
    iget-object v0, p0, Landroid/support/v4/app/q;->o:Landroid/support/v4/app/p;

    iget-object v0, v0, Landroid/support/v4/app/p;->e:Landroid/support/v4/app/FragmentActivity;

    iget-object v0, v0, Landroid/support/v4/app/FragmentActivity;->b:Landroid/support/v4/app/i;

    iget-object v0, v0, Landroid/support/v4/app/i;->u:Ljava/lang/String;

    .line 336
    iget-object v1, p0, Landroid/support/v4/app/q;->o:Landroid/support/v4/app/p;

    iget-object v1, v1, Landroid/support/v4/app/p;->e:Landroid/support/v4/app/FragmentActivity;

    iget-object v1, v1, Landroid/support/v4/app/FragmentActivity;->b:Landroid/support/v4/app/i;

    const-string v3, "onLoaderReset"

    iput-object v3, v1, Landroid/support/v4/app/i;->u:Ljava/lang/String;

    move-object v1, v0

    .line 339
    :goto_60
    :try_start_60
    iget-object v0, p0, Landroid/support/v4/app/q;->c:Landroid/support/v4/app/o;

    iget-object v3, p0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    invoke-interface {v0, v3}, Landroid/support/v4/app/o;->a(Landroid/support/v4/content/k;)V
    :try_end_67
    .catchall {:try_start_60 .. :try_end_67} :catchall_97

    .line 341
    iget-object v0, p0, Landroid/support/v4/app/q;->o:Landroid/support/v4/app/p;

    iget-object v0, v0, Landroid/support/v4/app/p;->e:Landroid/support/v4/app/FragmentActivity;

    if-eqz v0, :cond_75

    .line 342
    iget-object v0, p0, Landroid/support/v4/app/q;->o:Landroid/support/v4/app/p;

    iget-object v0, v0, Landroid/support/v4/app/p;->e:Landroid/support/v4/app/FragmentActivity;

    iget-object v0, v0, Landroid/support/v4/app/FragmentActivity;->b:Landroid/support/v4/app/i;

    iput-object v1, v0, Landroid/support/v4/app/i;->u:Ljava/lang/String;

    .line 346
    :cond_75
    iput-object v2, p0, Landroid/support/v4/app/q;->c:Landroid/support/v4/app/o;

    .line 347
    iput-object v2, p0, Landroid/support/v4/app/q;->g:Ljava/lang/Object;

    .line 348
    iput-boolean v4, p0, Landroid/support/v4/app/q;->e:Z

    .line 349
    iget-object v0, p0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    if-eqz v0, :cond_8f

    .line 350
    iget-boolean v0, p0, Landroid/support/v4/app/q;->m:Z

    if-eqz v0, :cond_8a

    .line 351
    iput-boolean v4, p0, Landroid/support/v4/app/q;->m:Z

    .line 352
    iget-object v0, p0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    invoke-virtual {v0, p0}, Landroid/support/v4/content/k;->a(Landroid/support/v4/content/m;)V

    .line 354
    :cond_8a
    iget-object v0, p0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    invoke-virtual {v0}, Landroid/support/v4/content/k;->m()V

    .line 356
    :cond_8f
    iget-object v0, p0, Landroid/support/v4/app/q;->n:Landroid/support/v4/app/q;

    if-eqz v0, :cond_a7

    .line 357
    iget-object p0, p0, Landroid/support/v4/app/q;->n:Landroid/support/v4/app/q;

    goto/16 :goto_2

    .line 341
    :catchall_97
    move-exception v0

    iget-object v2, p0, Landroid/support/v4/app/q;->o:Landroid/support/v4/app/p;

    iget-object v2, v2, Landroid/support/v4/app/p;->e:Landroid/support/v4/app/FragmentActivity;

    if-eqz v2, :cond_a6

    .line 342
    iget-object v2, p0, Landroid/support/v4/app/q;->o:Landroid/support/v4/app/p;

    iget-object v2, v2, Landroid/support/v4/app/p;->e:Landroid/support/v4/app/FragmentActivity;

    iget-object v2, v2, Landroid/support/v4/app/FragmentActivity;->b:Landroid/support/v4/app/i;

    iput-object v1, v2, Landroid/support/v4/app/i;->u:Ljava/lang/String;

    :cond_a6
    throw v0

    .line 359
    :cond_a7
    return-void

    :cond_a8
    move-object v1, v2

    goto :goto_60
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    .prologue
    .line 439
    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x40

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 440
    const-string v1, "LoaderInfo{"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 441
    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 442
    const-string v1, " #"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 443
    iget v1, p0, Landroid/support/v4/app/q;->a:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 444
    const-string v1, " : "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 445
    iget-object v1, p0, Landroid/support/v4/app/q;->d:Landroid/support/v4/content/k;

    invoke-static {v1, v0}, Landroid/support/v4/c/c;->a(Ljava/lang/Object;Ljava/lang/StringBuilder;)V

    .line 446
    const-string v1, "}}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 447
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
