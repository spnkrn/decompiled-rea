###### Class android.support.v4.app.ab (android.support.v4.app.ab)
.class public final Landroid/support/v4/app/ab;
.super Landroid/support/v4/app/ai;
.source "SourceFile"


# instance fields
.field a:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList",
            "<",
            "Ljava/lang/CharSequence;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 2

    .prologue
    .line 802
    invoke-direct {p0}, Landroid/support/v4/app/ai;-><init>()V

    .line 800
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroid/support/v4/app/ab;->a:Ljava/util/ArrayList;

    .line 803
    return-void
.end method
