###### Class android.support.v4.app.ai (android.support.v4.app.ai)
.class public abstract Landroid/support/v4/app/ai;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field d:Landroid/support/v4/app/aa;

.field e:Ljava/lang/CharSequence;

.field f:Ljava/lang/CharSequence;

.field g:Z


# direct methods
.method public constructor <init>()V
    .registers 2

    .prologue
    .line 623
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 628
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v4/app/ai;->g:Z

    return-void
.end method
