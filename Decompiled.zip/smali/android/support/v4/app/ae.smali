###### Class android.support.v4.app.ae (android.support.v4.app.ae)
.class final Landroid/support/v4/app/ae;
.super Landroid/support/v4/app/ad;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 98
    invoke-direct {p0}, Landroid/support/v4/app/ad;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/support/v4/app/aa;)Landroid/app/Notification;
    .registers 8

    .prologue
    .line 100
    iget-object v0, p1, Landroid/support/v4/app/aa;->r:Landroid/app/Notification;

    .line 101
    iget-object v1, p1, Landroid/support/v4/app/aa;->a:Landroid/content/Context;

    iget-object v2, p1, Landroid/support/v4/app/aa;->b:Ljava/lang/CharSequence;

    iget-object v3, p1, Landroid/support/v4/app/aa;->c:Ljava/lang/CharSequence;

    iget-object v4, p1, Landroid/support/v4/app/aa;->d:Landroid/app/PendingIntent;

    invoke-virtual {v0, v1, v2, v3, v4}, Landroid/app/Notification;->setLatestEventInfo(Landroid/content/Context;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Landroid/app/PendingIntent;)V

    .line 103
    iget-object v1, p1, Landroid/support/v4/app/aa;->a:Landroid/content/Context;

    iget-object v2, p1, Landroid/support/v4/app/aa;->b:Ljava/lang/CharSequence;

    iget-object v3, p1, Landroid/support/v4/app/aa;->c:Ljava/lang/CharSequence;

    iget-object v4, p1, Landroid/support/v4/app/aa;->d:Landroid/app/PendingIntent;

    iget-object v5, p1, Landroid/support/v4/app/aa;->e:Landroid/app/PendingIntent;

    invoke-virtual {v0, v1, v2, v3, v4}, Landroid/app/Notification;->setLatestEventInfo(Landroid/content/Context;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Landroid/app/PendingIntent;)V

    iput-object v5, v0, Landroid/app/Notification;->fullScreenIntent:Landroid/app/PendingIntent;

    .line 106
    iget v1, p1, Landroid/support/v4/app/aa;->j:I

    if-lez v1, :cond_26

    .line 107
    iget v1, v0, Landroid/app/Notification;->flags:I

    or-int/lit16 v1, v1, 0x80

    iput v1, v0, Landroid/app/Notification;->flags:I

    .line 109
    :cond_26
    return-object v0
.end method
