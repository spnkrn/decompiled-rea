###### Class android.support.v4.app.w (android.support.v4.app.w)
.class public final Landroid/support/v4/app/w;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static final a:Landroid/support/v4/app/ac;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .prologue
    .line 168
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x10

    if-lt v0, v1, :cond_e

    .line 169
    new-instance v0, Landroid/support/v4/app/ah;

    invoke-direct {v0}, Landroid/support/v4/app/ah;-><init>()V

    sput-object v0, Landroid/support/v4/app/w;->a:Landroid/support/v4/app/ac;

    .line 179
    :goto_d
    return-void

    .line 170
    :cond_e
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0xe

    if-lt v0, v1, :cond_1c

    .line 171
    new-instance v0, Landroid/support/v4/app/ag;

    invoke-direct {v0}, Landroid/support/v4/app/ag;-><init>()V

    sput-object v0, Landroid/support/v4/app/w;->a:Landroid/support/v4/app/ac;

    goto :goto_d

    .line 172
    :cond_1c
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0xb

    if-lt v0, v1, :cond_2a

    .line 173
    new-instance v0, Landroid/support/v4/app/af;

    invoke-direct {v0}, Landroid/support/v4/app/af;-><init>()V

    sput-object v0, Landroid/support/v4/app/w;->a:Landroid/support/v4/app/ac;

    goto :goto_d

    .line 174
    :cond_2a
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x9

    if-lt v0, v1, :cond_38

    .line 175
    new-instance v0, Landroid/support/v4/app/ae;

    invoke-direct {v0}, Landroid/support/v4/app/ae;-><init>()V

    sput-object v0, Landroid/support/v4/app/w;->a:Landroid/support/v4/app/ac;

    goto :goto_d

    .line 177
    :cond_38
    new-instance v0, Landroid/support/v4/app/ad;

    invoke-direct {v0}, Landroid/support/v4/app/ad;-><init>()V

    sput-object v0, Landroid/support/v4/app/w;->a:Landroid/support/v4/app/ac;

    goto :goto_d
.end method

.method static synthetic a()Landroid/support/v4/app/ac;
    .registers 1

    .prologue
    .line 34
    sget-object v0, Landroid/support/v4/app/w;->a:Landroid/support/v4/app/ac;

    return-object v0
.end method
