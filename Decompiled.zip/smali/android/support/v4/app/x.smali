###### Class android.support.v4.app.x (android.support.v4.app.x)
.class public final Landroid/support/v4/app/x;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:I

.field public b:Ljava/lang/CharSequence;

.field public c:Landroid/app/PendingIntent;
