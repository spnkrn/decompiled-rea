###### Class android.support.v4.app.ad (android.support.v4.app.ad)
.class Landroid/support/v4/app/ad;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/support/v4/app/ac;


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 85
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroid/support/v4/app/aa;)Landroid/app/Notification;
    .registers 7

    .prologue
    .line 87
    iget-object v0, p1, Landroid/support/v4/app/aa;->r:Landroid/app/Notification;

    .line 88
    iget-object v1, p1, Landroid/support/v4/app/aa;->a:Landroid/content/Context;

    iget-object v2, p1, Landroid/support/v4/app/aa;->b:Ljava/lang/CharSequence;

    iget-object v3, p1, Landroid/support/v4/app/aa;->c:Ljava/lang/CharSequence;

    iget-object v4, p1, Landroid/support/v4/app/aa;->d:Landroid/app/PendingIntent;

    invoke-virtual {v0, v1, v2, v3, v4}, Landroid/app/Notification;->setLatestEventInfo(Landroid/content/Context;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Landroid/app/PendingIntent;)V

    .line 91
    iget v1, p1, Landroid/support/v4/app/aa;->j:I

    if-lez v1, :cond_17

    .line 92
    iget v1, v0, Landroid/app/Notification;->flags:I

    or-int/lit16 v1, v1, 0x80

    iput v1, v0, Landroid/app/Notification;->flags:I

    .line 94
    :cond_17
    return-object v0
.end method
