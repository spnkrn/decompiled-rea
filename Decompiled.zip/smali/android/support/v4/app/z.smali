###### Class android.support.v4.app.z (android.support.v4.app.z)
.class public final Landroid/support/v4/app/z;
.super Landroid/support/v4/app/ai;
.source "SourceFile"


# instance fields
.field a:Ljava/lang/CharSequence;


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 740
    invoke-direct {p0}, Landroid/support/v4/app/ai;-><init>()V

    .line 741
    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/CharSequence;)Landroid/support/v4/app/z;
    .registers 2

    .prologue
    .line 770
    iput-object p1, p0, Landroid/support/v4/app/z;->a:Ljava/lang/CharSequence;

    .line 771
    return-object p0
.end method
