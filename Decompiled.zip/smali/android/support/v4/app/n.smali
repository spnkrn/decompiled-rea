###### Class android.support.v4.app.n (android.support.v4.app.n)
.class public abstract Landroid/support/v4/app/n;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 39
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 43
    return-void
.end method


# virtual methods
.method public abstract a(ILandroid/os/Bundle;Landroid/support/v4/app/o;)Landroid/support/v4/content/k;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<D:",
            "Ljava/lang/Object;",
            ">(I",
            "Landroid/os/Bundle;",
            "Landroid/support/v4/app/o",
            "<TD;>;)",
            "Landroid/support/v4/content/k",
            "<TD;>;"
        }
    .end annotation
.end method

.method public abstract a(I)V
.end method

.method public a()Z
    .registers 2

    .prologue
    .line 184
    const/4 v0, 0x0

    return v0
.end method

.method public abstract b(ILandroid/os/Bundle;Landroid/support/v4/app/o;)Landroid/support/v4/content/k;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<D:",
            "Ljava/lang/Object;",
            ">(I",
            "Landroid/os/Bundle;",
            "Landroid/support/v4/app/o",
            "<TD;>;)",
            "Landroid/support/v4/content/k",
            "<TD;>;"
        }
    .end annotation
.end method
