###### Class android.support.v4.content.j (android.support.v4.content.j)
.class final Landroid/support/v4/content/j;
.super Landroid/support/v4/content/i;
.source "SourceFile"


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 76
    invoke-direct {p0}, Landroid/support/v4/content/i;-><init>()V

    return-void
.end method
