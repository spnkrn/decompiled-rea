###### Class android.support.v4.content.k (android.support.v4.content.k)
.class public Landroid/support/v4/content/k;
.super Ljava/lang/Object;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<D:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# instance fields
.field m:I

.field n:Landroid/support/v4/content/m;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/support/v4/content/m",
            "<TD;>;"
        }
    .end annotation
.end field

.field o:Landroid/content/Context;

.field p:Z

.field q:Z

.field r:Z

.field s:Z

.field t:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 4

    .prologue
    const/4 v1, 0x0

    .line 91
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 38
    iput-boolean v1, p0, Landroid/support/v4/content/k;->p:Z

    .line 39
    iput-boolean v1, p0, Landroid/support/v4/content/k;->q:Z

    .line 40
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/content/k;->r:Z

    .line 41
    iput-boolean v1, p0, Landroid/support/v4/content/k;->s:Z

    .line 42
    iput-boolean v1, p0, Landroid/support/v4/content/k;->t:Z

    .line 92
    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    iput-object v0, p0, Landroid/support/v4/content/k;->o:Landroid/content/Context;

    .line 93
    return-void
.end method


# virtual methods
.method protected a()V
    .registers 1

    .prologue
    .line 226
    return-void
.end method

.method public final a(ILandroid/support/v4/content/m;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Landroid/support/v4/content/m",
            "<TD;>;)V"
        }
    .end annotation

    .prologue
    .line 130
    iget-object v0, p0, Landroid/support/v4/content/k;->n:Landroid/support/v4/content/m;

    if-eqz v0, :cond_c

    .line 131
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "There is already a listener registered"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 133
    :cond_c
    iput-object p2, p0, Landroid/support/v4/content/k;->n:Landroid/support/v4/content/m;

    .line 134
    iput p1, p0, Landroid/support/v4/content/k;->m:I

    .line 135
    return-void
.end method

.method public final a(Landroid/support/v4/content/m;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/support/v4/content/m",
            "<TD;>;)V"
        }
    .end annotation

    .prologue
    .line 143
    iget-object v0, p0, Landroid/support/v4/content/k;->n:Landroid/support/v4/content/m;

    if-nez v0, :cond_c

    .line 144
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "No listener register"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 146
    :cond_c
    iget-object v0, p0, Landroid/support/v4/content/k;->n:Landroid/support/v4/content/m;

    if-eq v0, p1, :cond_18

    .line 147
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Attempting to unregister the wrong listener"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 149
    :cond_18
    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v4/content/k;->n:Landroid/support/v4/content/m;

    .line 150
    return-void
.end method

.method public a(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    .registers 6

    .prologue
    .line 393
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mId="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget v0, p0, Landroid/support/v4/content/k;->m:I

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(I)V

    .line 394
    const-string v0, " mListener="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v0, p0, Landroid/support/v4/content/k;->n:Landroid/support/v4/content/m;

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Ljava/lang/Object;)V

    .line 395
    iget-boolean v0, p0, Landroid/support/v4/content/k;->p:Z

    if-nez v0, :cond_23

    iget-boolean v0, p0, Landroid/support/v4/content/k;->s:Z

    if-nez v0, :cond_23

    iget-boolean v0, p0, Landroid/support/v4/content/k;->t:Z

    if-eqz v0, :cond_44

    .line 396
    :cond_23
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mStarted="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/content/k;->p:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    .line 397
    const-string v0, " mContentChanged="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/content/k;->s:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    .line 398
    const-string v0, " mProcessingChange="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/content/k;->t:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Z)V

    .line 400
    :cond_44
    iget-boolean v0, p0, Landroid/support/v4/content/k;->q:Z

    if-nez v0, :cond_4c

    iget-boolean v0, p0, Landroid/support/v4/content/k;->r:Z

    if-eqz v0, :cond_63

    .line 401
    :cond_4c
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mAbandoned="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/content/k;->q:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Z)V

    .line 402
    const-string v0, " mReset="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroid/support/v4/content/k;->r:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Z)V

    .line 404
    :cond_63
    return-void
.end method

.method public b(Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TD;)V"
        }
    .end annotation

    .prologue
    .line 103
    iget-object v0, p0, Landroid/support/v4/content/k;->n:Landroid/support/v4/content/m;

    if-eqz v0, :cond_9

    .line 104
    iget-object v0, p0, Landroid/support/v4/content/k;->n:Landroid/support/v4/content/m;

    invoke-interface {v0, p0, p1}, Landroid/support/v4/content/m;->a(Landroid/support/v4/content/k;Ljava/lang/Object;)V

    .line 106
    :cond_9
    return-void
.end method

.method protected e()V
    .registers 1

    .prologue
    .line 207
    return-void
.end method

.method protected f()V
    .registers 1

    .prologue
    .line 254
    return-void
.end method

.method protected g()V
    .registers 1

    .prologue
    .line 306
    return-void
.end method

.method public final h()I
    .registers 2

    .prologue
    .line 119
    iget v0, p0, Landroid/support/v4/content/k;->m:I

    return v0
.end method

.method public final i()V
    .registers 3

    .prologue
    const/4 v1, 0x0

    .line 195
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/content/k;->p:Z

    .line 196
    iput-boolean v1, p0, Landroid/support/v4/content/k;->r:Z

    .line 197
    iput-boolean v1, p0, Landroid/support/v4/content/k;->q:Z

    .line 198
    invoke-virtual {p0}, Landroid/support/v4/content/k;->e()V

    .line 199
    return-void
.end method

.method public final j()V
    .registers 1

    .prologue
    .line 218
    invoke-virtual {p0}, Landroid/support/v4/content/k;->a()V

    .line 219
    return-void
.end method

.method public final k()V
    .registers 2

    .prologue
    .line 243
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v4/content/k;->p:Z

    .line 244
    invoke-virtual {p0}, Landroid/support/v4/content/k;->f()V

    .line 245
    return-void
.end method

.method public final l()V
    .registers 2

    .prologue
    .line 262
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/content/k;->q:Z

    .line 263
    return-void
.end method

.method public final m()V
    .registers 3

    .prologue
    const/4 v1, 0x0

    .line 291
    invoke-virtual {p0}, Landroid/support/v4/content/k;->g()V

    .line 292
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/content/k;->r:Z

    .line 293
    iput-boolean v1, p0, Landroid/support/v4/content/k;->p:Z

    .line 294
    iput-boolean v1, p0, Landroid/support/v4/content/k;->q:Z

    .line 295
    iput-boolean v1, p0, Landroid/support/v4/content/k;->s:Z

    .line 296
    iput-boolean v1, p0, Landroid/support/v4/content/k;->t:Z

    .line 297
    return-void
.end method

.method public final n()V
    .registers 2

    .prologue
    .line 353
    iget-boolean v0, p0, Landroid/support/v4/content/k;->p:Z

    if-eqz v0, :cond_8

    .line 354
    invoke-virtual {p0}, Landroid/support/v4/content/k;->a()V

    .line 361
    :goto_7
    return-void

    .line 359
    :cond_8
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/content/k;->s:Z

    goto :goto_7
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    .prologue
    .line 376
    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x40

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    .line 377
    invoke-static {p0, v0}, Landroid/support/v4/c/c;->a(Ljava/lang/Object;Ljava/lang/StringBuilder;)V

    .line 378
    const-string v1, " id="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 379
    iget v1, p0, Landroid/support/v4/content/k;->m:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 380
    const-string v1, "}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 381
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

###### Class android.support.v4.content.l (android.support.v4.content.l)
.class public final Landroid/support/v4/content/l;
.super Landroid/database/ContentObserver;
.source "SourceFile"


# instance fields
.field final synthetic a:Landroid/support/v4/content/k;


# direct methods
.method public constructor <init>(Landroid/support/v4/content/k;)V
    .registers 3

    .prologue
    .line 52
    iput-object p1, p0, Landroid/support/v4/content/l;->a:Landroid/support/v4/content/k;

    .line 53
    new-instance v0, Landroid/os/Handler;

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    invoke-direct {p0, v0}, Landroid/database/ContentObserver;-><init>(Landroid/os/Handler;)V

    .line 54
    return-void
.end method


# virtual methods
.method public final deliverSelfNotifications()Z
    .registers 2

    .prologue
    .line 58
    const/4 v0, 0x1

    return v0
.end method

.method public final onChange(Z)V
    .registers 3

    .prologue
    .line 63
    iget-object v0, p0, Landroid/support/v4/content/l;->a:Landroid/support/v4/content/k;

    invoke-virtual {v0}, Landroid/support/v4/content/k;->n()V

    .line 64
    return-void
.end method
