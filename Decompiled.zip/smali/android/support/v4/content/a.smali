###### Class android.support.v4.content.a (android.support.v4.content.a)
.class public abstract Landroid/support/v4/content/a;
.super Landroid/support/v4/content/k;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<D:",
        "Ljava/lang/Object;",
        ">",
        "Landroid/support/v4/content/k",
        "<TD;>;"
    }
.end annotation


# instance fields
.field volatile a:Landroid/support/v4/content/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/support/v4/content/a",
            "<TD;>.android/support/v4/content/b;"
        }
    .end annotation
.end field

.field volatile b:Landroid/support/v4/content/b;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/support/v4/content/a",
            "<TD;>.android/support/v4/content/b;"
        }
    .end annotation
.end field

.field c:J

.field d:J

.field e:Landroid/os/Handler;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 4

    .prologue
    .line 92
    invoke-direct {p0, p1}, Landroid/support/v4/content/k;-><init>(Landroid/content/Context;)V

    .line 88
    const-wide/16 v0, -0x2710

    iput-wide v0, p0, Landroid/support/v4/content/a;->d:J

    .line 93
    return-void
.end method


# virtual methods
.method protected final a()V
    .registers 2

    .prologue
    .line 111
    invoke-super {p0}, Landroid/support/v4/content/k;->a()V

    .line 112
    invoke-virtual {p0}, Landroid/support/v4/content/a;->b()Z

    .line 113
    new-instance v0, Landroid/support/v4/content/b;

    invoke-direct {v0, p0}, Landroid/support/v4/content/b;-><init>(Landroid/support/v4/content/a;)V

    iput-object v0, p0, Landroid/support/v4/content/a;->a:Landroid/support/v4/content/b;

    .line 115
    invoke-virtual {p0}, Landroid/support/v4/content/a;->c()V

    .line 116
    return-void
.end method

.method final a(Landroid/support/v4/content/b;Ljava/lang/Object;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/support/v4/content/a",
            "<TD;>.android/support/v4/content/b;TD;)V"
        }
    .end annotation

    .prologue
    .line 200
    invoke-virtual {p0, p2}, Landroid/support/v4/content/a;->a(Ljava/lang/Object;)V

    .line 201
    iget-object v0, p0, Landroid/support/v4/content/a;->b:Landroid/support/v4/content/b;

    if-ne v0, p1, :cond_1a

    .line 203
    iget-boolean v0, p0, Landroid/support/v4/content/k;->t:Z

    if-eqz v0, :cond_e

    const/4 v0, 0x1

    iput-boolean v0, p0, Landroid/support/v4/content/k;->s:Z

    .line 204
    :cond_e
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Landroid/support/v4/content/a;->d:J

    .line 205
    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v4/content/a;->b:Landroid/support/v4/content/b;

    .line 206
    invoke-virtual {p0}, Landroid/support/v4/content/a;->c()V

    .line 208
    :cond_1a
    return-void
.end method

.method public a(Ljava/lang/Object;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TD;)V"
        }
    .end annotation

    .prologue
    .line 174
    return-void
.end method

.method public a(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    .registers 9

    .prologue
    .line 268
    invoke-super {p0, p1, p2, p3, p4}, Landroid/support/v4/content/k;->a(Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V

    .line 269
    iget-object v0, p0, Landroid/support/v4/content/a;->a:Landroid/support/v4/content/b;

    if-eqz v0, :cond_20

    .line 270
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mTask="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v0, p0, Landroid/support/v4/content/a;->a:Landroid/support/v4/content/b;

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/Object;)V

    .line 271
    const-string v0, " waiting="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v0, p0, Landroid/support/v4/content/a;->a:Landroid/support/v4/content/b;

    iget-boolean v0, v0, Landroid/support/v4/content/b;->b:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Z)V

    .line 273
    :cond_20
    iget-object v0, p0, Landroid/support/v4/content/a;->b:Landroid/support/v4/content/b;

    if-eqz v0, :cond_3d

    .line 274
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mCancellingTask="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v0, p0, Landroid/support/v4/content/a;->b:Landroid/support/v4/content/b;

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/Object;)V

    .line 275
    const-string v0, " waiting="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    iget-object v0, p0, Landroid/support/v4/content/a;->b:Landroid/support/v4/content/b;

    iget-boolean v0, v0, Landroid/support/v4/content/b;->b:Z

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->println(Z)V

    .line 277
    :cond_3d
    iget-wide v0, p0, Landroid/support/v4/content/a;->c:J

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    if-eqz v0, :cond_63

    .line 278
    invoke-virtual {p3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const-string v0, "mUpdateThrottle="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 279
    iget-wide v0, p0, Landroid/support/v4/content/a;->c:J

    invoke-static {v0, v1, p3}, Landroid/support/v4/c/o;->a(JLjava/io/PrintWriter;)V

    .line 280
    const-string v0, " mLastLoadCompleteTime="

    invoke-virtual {p3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    .line 281
    iget-wide v0, p0, Landroid/support/v4/content/a;->d:J

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v2

    invoke-static {v0, v1, v2, v3, p3}, Landroid/support/v4/c/o;->a(JJLjava/io/PrintWriter;)V

    .line 283
    invoke-virtual {p3}, Ljava/io/PrintWriter;->println()V

    .line 285
    :cond_63
    return-void
.end method

.method public final b()Z
    .registers 5

    .prologue
    const/4 v3, 0x0

    const/4 v0, 0x0

    .line 136
    iget-object v1, p0, Landroid/support/v4/content/a;->a:Landroid/support/v4/content/b;

    if-eqz v1, :cond_1d

    .line 137
    iget-object v1, p0, Landroid/support/v4/content/a;->b:Landroid/support/v4/content/b;

    if-eqz v1, :cond_1e

    .line 142
    iget-object v1, p0, Landroid/support/v4/content/a;->a:Landroid/support/v4/content/b;

    iget-boolean v1, v1, Landroid/support/v4/content/b;->b:Z

    if-eqz v1, :cond_1b

    .line 143
    iget-object v1, p0, Landroid/support/v4/content/a;->a:Landroid/support/v4/content/b;

    iput-boolean v0, v1, Landroid/support/v4/content/b;->b:Z

    .line 144
    iget-object v1, p0, Landroid/support/v4/content/a;->e:Landroid/os/Handler;

    iget-object v2, p0, Landroid/support/v4/content/a;->a:Landroid/support/v4/content/b;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 146
    :cond_1b
    iput-object v3, p0, Landroid/support/v4/content/a;->a:Landroid/support/v4/content/b;

    .line 166
    :cond_1d
    :goto_1d
    return v0

    .line 148
    :cond_1e
    iget-object v1, p0, Landroid/support/v4/content/a;->a:Landroid/support/v4/content/b;

    iget-boolean v1, v1, Landroid/support/v4/content/b;->b:Z

    if-eqz v1, :cond_32

    .line 152
    iget-object v1, p0, Landroid/support/v4/content/a;->a:Landroid/support/v4/content/b;

    iput-boolean v0, v1, Landroid/support/v4/content/b;->b:Z

    .line 153
    iget-object v1, p0, Landroid/support/v4/content/a;->e:Landroid/os/Handler;

    iget-object v2, p0, Landroid/support/v4/content/a;->a:Landroid/support/v4/content/b;

    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 154
    iput-object v3, p0, Landroid/support/v4/content/a;->a:Landroid/support/v4/content/b;

    goto :goto_1d

    .line 157
    :cond_32
    iget-object v0, p0, Landroid/support/v4/content/a;->a:Landroid/support/v4/content/b;

    invoke-virtual {v0}, Landroid/support/v4/content/b;->d()Z

    move-result v0

    .line 159
    if-eqz v0, :cond_3e

    .line 160
    iget-object v1, p0, Landroid/support/v4/content/a;->a:Landroid/support/v4/content/b;

    iput-object v1, p0, Landroid/support/v4/content/a;->b:Landroid/support/v4/content/b;

    .line 162
    :cond_3e
    iput-object v3, p0, Landroid/support/v4/content/a;->a:Landroid/support/v4/content/b;

    goto :goto_1d
.end method

.method final c()V
    .registers 7

    .prologue
    .line 177
    iget-object v0, p0, Landroid/support/v4/content/a;->b:Landroid/support/v4/content/b;

    if-nez v0, :cond_40

    iget-object v0, p0, Landroid/support/v4/content/a;->a:Landroid/support/v4/content/b;

    if-eqz v0, :cond_40

    .line 178
    iget-object v0, p0, Landroid/support/v4/content/a;->a:Landroid/support/v4/content/b;

    iget-boolean v0, v0, Landroid/support/v4/content/b;->b:Z

    if-eqz v0, :cond_1a

    .line 179
    iget-object v0, p0, Landroid/support/v4/content/a;->a:Landroid/support/v4/content/b;

    const/4 v1, 0x0

    iput-boolean v1, v0, Landroid/support/v4/content/b;->b:Z

    .line 180
    iget-object v0, p0, Landroid/support/v4/content/a;->e:Landroid/os/Handler;

    iget-object v1, p0, Landroid/support/v4/content/a;->a:Landroid/support/v4/content/b;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 182
    :cond_1a
    iget-wide v0, p0, Landroid/support/v4/content/a;->c:J

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    if-lez v0, :cond_41

    .line 183
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v0

    .line 184
    iget-wide v2, p0, Landroid/support/v4/content/a;->d:J

    iget-wide v4, p0, Landroid/support/v4/content/a;->c:J

    add-long/2addr v2, v4

    cmp-long v0, v0, v2

    if-gez v0, :cond_41

    .line 189
    iget-object v0, p0, Landroid/support/v4/content/a;->a:Landroid/support/v4/content/b;

    const/4 v1, 0x1

    iput-boolean v1, v0, Landroid/support/v4/content/b;->b:Z

    .line 190
    iget-object v0, p0, Landroid/support/v4/content/a;->e:Landroid/os/Handler;

    iget-object v1, p0, Landroid/support/v4/content/a;->a:Landroid/support/v4/content/b;

    iget-wide v2, p0, Landroid/support/v4/content/a;->d:J

    iget-wide v4, p0, Landroid/support/v4/content/a;->c:J

    add-long/2addr v2, v4

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postAtTime(Ljava/lang/Runnable;J)Z

    .line 197
    :cond_40
    :goto_40
    return-void

    .line 195
    :cond_41
    iget-object v0, p0, Landroid/support/v4/content/a;->a:Landroid/support/v4/content/b;

    sget-object v1, Landroid/support/v4/content/ModernAsyncTask;->d:Ljava/util/concurrent/Executor;

    invoke-virtual {v0, v1}, Landroid/support/v4/content/b;->a(Ljava/util/concurrent/Executor;)Landroid/support/v4/content/ModernAsyncTask;

    goto :goto_40
.end method

.method public abstract d()Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TD;"
        }
    .end annotation
.end method

###### Class android.support.v4.content.b (android.support.v4.content.b)
.class final Landroid/support/v4/content/b;
.super Landroid/support/v4/content/ModernAsyncTask;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/support/v4/content/ModernAsyncTask",
        "<",
        "Ljava/lang/Void;",
        "Ljava/lang/Void;",
        "TD;>;",
        "Ljava/lang/Runnable;"
    }
.end annotation


# instance fields
.field a:Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "TD;"
        }
    .end annotation
.end field

.field b:Z

.field final synthetic c:Landroid/support/v4/content/a;

.field private e:Ljava/util/concurrent/CountDownLatch;


# direct methods
.method constructor <init>(Landroid/support/v4/content/a;)V
    .registers 4

    .prologue
    .line 40
    iput-object p1, p0, Landroid/support/v4/content/b;->c:Landroid/support/v4/content/a;

    invoke-direct {p0}, Landroid/support/v4/content/ModernAsyncTask;-><init>()V

    .line 45
    new-instance v0, Ljava/util/concurrent/CountDownLatch;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Ljava/util/concurrent/CountDownLatch;-><init>(I)V

    iput-object v0, p0, Landroid/support/v4/content/b;->e:Ljava/util/concurrent/CountDownLatch;

    return-void
.end method


# virtual methods
.method protected final a()V
    .registers 3

    .prologue
    .line 71
    :try_start_0
    iget-object v0, p0, Landroid/support/v4/content/b;->c:Landroid/support/v4/content/a;

    iget-object v1, p0, Landroid/support/v4/content/b;->a:Ljava/lang/Object;

    invoke-virtual {v0, p0, v1}, Landroid/support/v4/content/a;->a(Landroid/support/v4/content/b;Ljava/lang/Object;)V
    :try_end_7
    .catchall {:try_start_0 .. :try_end_7} :catchall_d

    .line 73
    iget-object v0, p0, Landroid/support/v4/content/b;->e:Ljava/util/concurrent/CountDownLatch;

    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    .line 74
    return-void

    .line 73
    :catchall_d
    move-exception v0

    iget-object v1, p0, Landroid/support/v4/content/b;->e:Ljava/util/concurrent/CountDownLatch;

    invoke-virtual {v1}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    throw v0
.end method

.method protected final a(Ljava/lang/Object;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TD;)V"
        }
    .end annotation

    .prologue
    .line 61
    :try_start_0
    iget-object v0, p0, Landroid/support/v4/content/b;->c:Landroid/support/v4/content/a;

    iget-object v1, v0, Landroid/support/v4/content/a;->a:Landroid/support/v4/content/b;

    if-eq v1, p0, :cond_f

    invoke-virtual {v0, p0, p1}, Landroid/support/v4/content/a;->a(Landroid/support/v4/content/b;Ljava/lang/Object;)V
    :try_end_9
    .catchall {:try_start_0 .. :try_end_9} :catchall_17

    .line 63
    :goto_9
    iget-object v0, p0, Landroid/support/v4/content/b;->e:Ljava/util/concurrent/CountDownLatch;

    invoke-virtual {v0}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    .line 64
    return-void

    .line 61
    :cond_f
    :try_start_f
    iget-boolean v1, v0, Landroid/support/v4/content/k;->q:Z

    if-eqz v1, :cond_1e

    invoke-virtual {v0, p1}, Landroid/support/v4/content/a;->a(Ljava/lang/Object;)V
    :try_end_16
    .catchall {:try_start_f .. :try_end_16} :catchall_17

    goto :goto_9

    .line 63
    :catchall_17
    move-exception v0

    iget-object v1, p0, Landroid/support/v4/content/b;->e:Ljava/util/concurrent/CountDownLatch;

    invoke-virtual {v1}, Ljava/util/concurrent/CountDownLatch;->countDown()V

    throw v0

    .line 61
    :cond_1e
    const/4 v1, 0x0

    :try_start_1f
    iput-boolean v1, v0, Landroid/support/v4/content/k;->t:Z

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v1

    iput-wide v1, v0, Landroid/support/v4/content/a;->d:J

    const/4 v1, 0x0

    iput-object v1, v0, Landroid/support/v4/content/a;->a:Landroid/support/v4/content/b;

    invoke-virtual {v0, p1}, Landroid/support/v4/content/a;->b(Ljava/lang/Object;)V
    :try_end_2d
    .catchall {:try_start_1f .. :try_end_2d} :catchall_17

    goto :goto_9
.end method

.method protected final synthetic b()Ljava/lang/Object;
    .registers 2

    .prologue
    .line 40
    iget-object v0, p0, Landroid/support/v4/content/b;->c:Landroid/support/v4/content/a;

    invoke-virtual {v0}, Landroid/support/v4/content/a;->d()Ljava/lang/Object;

    move-result-object v0

    iput-object v0, p0, Landroid/support/v4/content/b;->a:Ljava/lang/Object;

    iget-object v0, p0, Landroid/support/v4/content/b;->a:Ljava/lang/Object;

    return-object v0
.end method

.method public final run()V
    .registers 2

    .prologue
    .line 79
    const/4 v0, 0x0

    iput-boolean v0, p0, Landroid/support/v4/content/b;->b:Z

    .line 80
    iget-object v0, p0, Landroid/support/v4/content/b;->c:Landroid/support/v4/content/a;

    invoke-virtual {v0}, Landroid/support/v4/content/a;->c()V

    .line 81
    return-void
.end method
