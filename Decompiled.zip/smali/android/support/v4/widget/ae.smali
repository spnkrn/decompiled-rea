###### Class android.support.v4.widget.ae (android.support.v4.widget.ae)
.class public abstract Landroid/support/v4/widget/ae;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 148
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(I)V
    .registers 2

    .prologue
    .line 159
    return-void
.end method

.method public a(II)V
    .registers 3

    .prologue
    .line 240
    return-void
.end method

.method public a(Landroid/view/View;F)V
    .registers 3

    .prologue
    .line 201
    return-void
.end method

.method public a(Landroid/view/View;I)V
    .registers 3

    .prologue
    .line 170
    return-void
.end method

.method public abstract a(Landroid/view/View;)Z
.end method

.method public b(Landroid/view/View;I)I
    .registers 4

    .prologue
    .line 304
    const/4 v0, 0x0

    return v0
.end method

.method public b()V
    .registers 1

    .prologue
    .line 214
    return-void
.end method

.method public b(Landroid/view/View;)V
    .registers 2

    .prologue
    .line 181
    return-void
.end method

.method public c(Landroid/view/View;)I
    .registers 3

    .prologue
    .line 260
    const/4 v0, 0x0

    return v0
.end method

.method public d(Landroid/view/View;)I
    .registers 3

    .prologue
    .line 319
    const/4 v0, 0x0

    return v0
.end method
