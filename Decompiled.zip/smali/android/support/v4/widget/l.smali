###### Class android.support.v4.widget.l (android.support.v4.widget.l)
.class interface abstract Landroid/support/v4/widget/l;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Landroid/content/Context;)Ljava/lang/Object;
.end method

.method public abstract a(Ljava/lang/Object;II)V
.end method

.method public abstract a(Ljava/lang/Object;)Z
.end method

.method public abstract a(Ljava/lang/Object;F)Z
.end method

.method public abstract a(Ljava/lang/Object;Landroid/graphics/Canvas;)Z
.end method

.method public abstract b(Ljava/lang/Object;)V
.end method

.method public abstract c(Ljava/lang/Object;)Z
.end method
