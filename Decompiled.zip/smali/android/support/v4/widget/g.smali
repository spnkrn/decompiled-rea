###### Class android.support.v4.widget.g (android.support.v4.widget.g)
.class public interface abstract Landroid/support/v4/widget/g;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()V
.end method

.method public abstract a(F)V
.end method

.method public abstract b()V
.end method
