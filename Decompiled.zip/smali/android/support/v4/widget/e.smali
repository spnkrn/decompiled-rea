###### Class android.support.v4.widget.e (android.support.v4.widget.e)
.class interface abstract Landroid/support/v4/widget/e;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()Landroid/database/Cursor;
.end method

.method public abstract a(Ljava/lang/CharSequence;)Landroid/database/Cursor;
.end method

.method public abstract a(Landroid/database/Cursor;)V
.end method

.method public abstract c(Landroid/database/Cursor;)Ljava/lang/CharSequence;
.end method
