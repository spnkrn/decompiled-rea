###### Class android.support.v4.widget.ad (android.support.v4.widget.ad)
.class public final Landroid/support/v4/widget/ad;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field private static final v:Landroid/view/animation/Interpolator;


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:[F

.field private e:[F

.field private f:[F

.field private g:[F

.field private h:[I

.field private i:[I

.field private j:[I

.field private k:I

.field private l:Landroid/view/VelocityTracker;

.field private m:F

.field private n:F

.field private o:I

.field private p:I

.field private q:Landroid/support/v4/widget/n;

.field private final r:Landroid/support/v4/widget/ae;

.field private s:Landroid/view/View;

.field private t:Z

.field private final u:Landroid/view/ViewGroup;

.field private final w:Ljava/lang/Runnable;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .prologue
    .line 326
    new-instance v0, Landroid/support/v4/widget/ad$1;

    invoke-direct {v0}, Landroid/support/v4/widget/ad$1;-><init>()V

    sput-object v0, Landroid/support/v4/widget/ad;->v:Landroid/view/animation/Interpolator;

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;Landroid/view/ViewGroup;Landroid/support/v4/widget/ae;)V
    .registers 7

    .prologue
    .line 373
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 115
    const/4 v0, -0x1

    iput v0, p0, Landroid/support/v4/widget/ad;->c:I

    .line 333
    new-instance v0, Landroid/support/v4/widget/ad$2;

    invoke-direct {v0, p0}, Landroid/support/v4/widget/ad$2;-><init>(Landroid/support/v4/widget/ad;)V

    iput-object v0, p0, Landroid/support/v4/widget/ad;->w:Ljava/lang/Runnable;

    .line 374
    if-nez p2, :cond_17

    .line 375
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Parent view may not be null"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 377
    :cond_17
    if-nez p3, :cond_21

    .line 378
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Callback may not be null"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 381
    :cond_21
    iput-object p2, p0, Landroid/support/v4/widget/ad;->u:Landroid/view/ViewGroup;

    .line 382
    iput-object p3, p0, Landroid/support/v4/widget/ad;->r:Landroid/support/v4/widget/ae;

    .line 384
    invoke-static {p1}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v0

    .line 385
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    invoke-virtual {v1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    iget v1, v1, Landroid/util/DisplayMetrics;->density:F

    .line 386
    const/high16 v2, 0x41a00000    # 20.0f

    mul-float/2addr v1, v2

    const/high16 v2, 0x3f000000    # 0.5f

    add-float/2addr v1, v2

    float-to-int v1, v1

    iput v1, p0, Landroid/support/v4/widget/ad;->o:I

    .line 388
    invoke-virtual {v0}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result v1

    iput v1, p0, Landroid/support/v4/widget/ad;->b:I

    .line 389
    invoke-virtual {v0}, Landroid/view/ViewConfiguration;->getScaledMaximumFlingVelocity()I

    move-result v1

    int-to-float v1, v1

    iput v1, p0, Landroid/support/v4/widget/ad;->m:F

    .line 390
    invoke-virtual {v0}, Landroid/view/ViewConfiguration;->getScaledMinimumFlingVelocity()I

    move-result v0

    int-to-float v0, v0

    iput v0, p0, Landroid/support/v4/widget/ad;->n:F

    .line 391
    sget-object v0, Landroid/support/v4/widget/ad;->v:Landroid/view/animation/Interpolator;

    invoke-static {p1, v0}, Landroid/support/v4/widget/n;->a(Landroid/content/Context;Landroid/view/animation/Interpolator;)Landroid/support/v4/widget/n;

    move-result-object v0

    iput-object v0, p0, Landroid/support/v4/widget/ad;->q:Landroid/support/v4/widget/n;

    .line 392
    return-void
.end method

.method private static a(FFF)F
    .registers 6

    .prologue
    const/4 v0, 0x0

    .line 667
    invoke-static {p0}, Ljava/lang/Math;->abs(F)F

    move-result v1

    .line 668
    cmpg-float v2, v1, p1

    if-gez v2, :cond_b

    move p2, v0

    .line 670
    :cond_a
    :goto_a
    return p2

    .line 669
    :cond_b
    cmpl-float v1, v1, p2

    if-lez v1, :cond_15

    cmpl-float v0, p0, v0

    if-gtz v0, :cond_a

    neg-float p2, p2

    goto :goto_a

    :cond_15
    move p2, p0

    .line 670
    goto :goto_a
.end method

.method private a(III)I
    .registers 12

    .prologue
    const/high16 v7, 0x3f800000    # 1.0f

    .line 618
    if-nez p1, :cond_6

    .line 619
    const/4 v0, 0x0

    .line 636
    :goto_5
    return v0

    .line 622
    :cond_6
    iget-object v0, p0, Landroid/support/v4/widget/ad;->u:Landroid/view/ViewGroup;

    invoke-virtual {v0}, Landroid/view/ViewGroup;->getWidth()I

    move-result v0

    .line 623
    div-int/lit8 v1, v0, 0x2

    .line 624
    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    move-result v2

    int-to-float v2, v2

    int-to-float v0, v0

    div-float v0, v2, v0

    invoke-static {v7, v0}, Ljava/lang/Math;->min(FF)F

    move-result v0

    .line 625
    int-to-float v2, v1

    int-to-float v1, v1

    const/high16 v3, 0x3f000000    # 0.5f

    sub-float/2addr v0, v3

    float-to-double v3, v0

    const-wide v5, 0x3fde28c7460698c7L    # 0.4712389167638204

    mul-double/2addr v3, v5

    double-to-float v0, v3

    float-to-double v3, v0

    invoke-static {v3, v4}, Ljava/lang/Math;->sin(D)D

    move-result-wide v3

    double-to-float v0, v3

    mul-float/2addr v0, v1

    add-float/2addr v0, v2

    .line 629
    invoke-static {p2}, Ljava/lang/Math;->abs(I)I

    move-result v1

    .line 630
    if-lez v1, :cond_4b

    .line 631
    const/high16 v2, 0x447a0000    # 1000.0f

    int-to-float v1, v1

    div-float/2addr v0, v1

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v0

    mul-float/2addr v0, v2

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    mul-int/lit8 v0, v0, 0x4

    .line 636
    :goto_44
    const/16 v1, 0x258

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    goto :goto_5

    .line 633
    :cond_4b
    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    move-result v0

    int-to-float v0, v0

    int-to-float v1, p3

    div-float/2addr v0, v1

    .line 634
    add-float/2addr v0, v7

    const/high16 v1, 0x43800000    # 256.0f

    mul-float/2addr v0, v1

    float-to-int v0, v0

    goto :goto_44
.end method

.method public static a(Landroid/view/ViewGroup;FLandroid/support/v4/widget/ae;)Landroid/support/v4/widget/ad;
    .registers 6

    .prologue
    .line 360
    new-instance v0, Landroid/support/v4/widget/ad;

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1, p0, p2}, Landroid/support/v4/widget/ad;-><init>(Landroid/content/Context;Landroid/view/ViewGroup;Landroid/support/v4/widget/ae;)V

    .line 361
    iget v1, v0, Landroid/support/v4/widget/ad;->b:I

    int-to-float v1, v1

    const/high16 v2, 0x3f800000    # 1.0f

    div-float/2addr v2, p1

    mul-float/2addr v1, v2

    float-to-int v1, v1

    iput v1, v0, Landroid/support/v4/widget/ad;->b:I

    .line 362
    return-object v0
.end method

.method private a(FFI)V
    .registers 15

    .prologue
    const/4 v1, 0x1

    const/4 v0, 0x0

    .line 828
    iget-object v2, p0, Landroid/support/v4/widget/ad;->d:[F

    if-eqz v2, :cond_b

    iget-object v2, p0, Landroid/support/v4/widget/ad;->d:[F

    array-length v2, v2

    if-gt v2, p3, :cond_71

    :cond_b
    add-int/lit8 v2, p3, 0x1

    new-array v2, v2, [F

    add-int/lit8 v3, p3, 0x1

    new-array v3, v3, [F

    add-int/lit8 v4, p3, 0x1

    new-array v4, v4, [F

    add-int/lit8 v5, p3, 0x1

    new-array v5, v5, [F

    add-int/lit8 v6, p3, 0x1

    new-array v6, v6, [I

    add-int/lit8 v7, p3, 0x1

    new-array v7, v7, [I

    add-int/lit8 v8, p3, 0x1

    new-array v8, v8, [I

    iget-object v9, p0, Landroid/support/v4/widget/ad;->d:[F

    if-eqz v9, :cond_63

    iget-object v9, p0, Landroid/support/v4/widget/ad;->d:[F

    iget-object v10, p0, Landroid/support/v4/widget/ad;->d:[F

    array-length v10, v10

    invoke-static {v9, v0, v2, v0, v10}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v9, p0, Landroid/support/v4/widget/ad;->e:[F

    iget-object v10, p0, Landroid/support/v4/widget/ad;->e:[F

    array-length v10, v10

    invoke-static {v9, v0, v3, v0, v10}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v9, p0, Landroid/support/v4/widget/ad;->f:[F

    iget-object v10, p0, Landroid/support/v4/widget/ad;->f:[F

    array-length v10, v10

    invoke-static {v9, v0, v4, v0, v10}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v9, p0, Landroid/support/v4/widget/ad;->g:[F

    iget-object v10, p0, Landroid/support/v4/widget/ad;->g:[F

    array-length v10, v10

    invoke-static {v9, v0, v5, v0, v10}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v9, p0, Landroid/support/v4/widget/ad;->h:[I

    iget-object v10, p0, Landroid/support/v4/widget/ad;->h:[I

    array-length v10, v10

    invoke-static {v9, v0, v6, v0, v10}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v9, p0, Landroid/support/v4/widget/ad;->i:[I

    iget-object v10, p0, Landroid/support/v4/widget/ad;->i:[I

    array-length v10, v10

    invoke-static {v9, v0, v7, v0, v10}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v9, p0, Landroid/support/v4/widget/ad;->j:[I

    iget-object v10, p0, Landroid/support/v4/widget/ad;->j:[I

    array-length v10, v10

    invoke-static {v9, v0, v8, v0, v10}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :cond_63
    iput-object v2, p0, Landroid/support/v4/widget/ad;->d:[F

    iput-object v3, p0, Landroid/support/v4/widget/ad;->e:[F

    iput-object v4, p0, Landroid/support/v4/widget/ad;->f:[F

    iput-object v5, p0, Landroid/support/v4/widget/ad;->g:[F

    iput-object v6, p0, Landroid/support/v4/widget/ad;->h:[I

    iput-object v7, p0, Landroid/support/v4/widget/ad;->i:[I

    iput-object v8, p0, Landroid/support/v4/widget/ad;->j:[I

    .line 829
    :cond_71
    iget-object v2, p0, Landroid/support/v4/widget/ad;->d:[F

    iget-object v3, p0, Landroid/support/v4/widget/ad;->f:[F

    aput p1, v3, p3

    aput p1, v2, p3

    .line 830
    iget-object v2, p0, Landroid/support/v4/widget/ad;->e:[F

    iget-object v3, p0, Landroid/support/v4/widget/ad;->g:[F

    aput p2, v3, p3

    aput p2, v2, p3

    .line 831
    iget-object v2, p0, Landroid/support/v4/widget/ad;->h:[I

    float-to-int v3, p1

    float-to-int v4, p2

    iget-object v5, p0, Landroid/support/v4/widget/ad;->u:Landroid/view/ViewGroup;

    invoke-virtual {v5}, Landroid/view/ViewGroup;->getLeft()I

    move-result v5

    iget v6, p0, Landroid/support/v4/widget/ad;->o:I

    add-int/2addr v5, v6

    if-ge v3, v5, :cond_91

    move v0, v1

    :cond_91
    iget-object v5, p0, Landroid/support/v4/widget/ad;->u:Landroid/view/ViewGroup;

    invoke-virtual {v5}, Landroid/view/ViewGroup;->getTop()I

    move-result v5

    iget v6, p0, Landroid/support/v4/widget/ad;->o:I

    add-int/2addr v5, v6

    if-ge v4, v5, :cond_9e

    or-int/lit8 v0, v0, 0x4

    :cond_9e
    iget-object v5, p0, Landroid/support/v4/widget/ad;->u:Landroid/view/ViewGroup;

    invoke-virtual {v5}, Landroid/view/ViewGroup;->getRight()I

    move-result v5

    iget v6, p0, Landroid/support/v4/widget/ad;->o:I

    sub-int/2addr v5, v6

    if-le v3, v5, :cond_ab

    or-int/lit8 v0, v0, 0x2

    :cond_ab
    iget-object v3, p0, Landroid/support/v4/widget/ad;->u:Landroid/view/ViewGroup;

    invoke-virtual {v3}, Landroid/view/ViewGroup;->getBottom()I

    move-result v3

    iget v5, p0, Landroid/support/v4/widget/ad;->o:I

    sub-int/2addr v3, v5

    if-le v4, v3, :cond_b8

    or-int/lit8 v0, v0, 0x8

    :cond_b8
    aput v0, v2, p3

    .line 832
    iget v0, p0, Landroid/support/v4/widget/ad;->k:I

    shl-int/2addr v1, p3

    or-int/2addr v0, v1

    iput v0, p0, Landroid/support/v4/widget/ad;->k:I

    .line 833
    return-void
.end method

.method private a(FFII)Z
    .registers 9

    .prologue
    const/4 v0, 0x0

    .line 1218
    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    move-result v1

    .line 1219
    invoke-static {p2}, Ljava/lang/Math;->abs(F)F

    move-result v2

    .line 1221
    iget-object v3, p0, Landroid/support/v4/widget/ad;->h:[I

    aget v3, v3, p3

    and-int/2addr v3, p4

    if-ne v3, p4, :cond_31

    iget v3, p0, Landroid/support/v4/widget/ad;->p:I

    and-int/2addr v3, p4

    if-eqz v3, :cond_31

    iget-object v3, p0, Landroid/support/v4/widget/ad;->j:[I

    aget v3, v3, p3

    and-int/2addr v3, p4

    if-eq v3, p4, :cond_31

    iget-object v3, p0, Landroid/support/v4/widget/ad;->i:[I

    aget v3, v3, p3

    and-int/2addr v3, p4

    if-eq v3, p4, :cond_31

    iget v3, p0, Landroid/support/v4/widget/ad;->b:I

    int-to-float v3, v3

    cmpg-float v3, v1, v3

    if-gtz v3, :cond_32

    iget v3, p0, Landroid/support/v4/widget/ad;->b:I

    int-to-float v3, v3

    cmpg-float v3, v2, v3

    if-gtz v3, :cond_32

    .line 1228
    :cond_31
    :goto_31
    return v0

    .line 1227
    :cond_32
    const/high16 v3, 0x3f000000    # 0.5f

    mul-float/2addr v2, v3

    cmpg-float v2, v1, v2

    if-gez v2, :cond_3b

    iget-object v2, p0, Landroid/support/v4/widget/ad;->r:Landroid/support/v4/widget/ae;

    .line 1228
    :cond_3b
    iget-object v2, p0, Landroid/support/v4/widget/ad;->i:[I

    aget v2, v2, p3

    and-int/2addr v2, p4

    if-nez v2, :cond_31

    iget v2, p0, Landroid/support/v4/widget/ad;->b:I

    int-to-float v2, v2

    cmpl-float v1, v1, v2

    if-lez v1, :cond_31

    const/4 v0, 0x1

    goto :goto_31
.end method

.method private a(IIII)Z
    .registers 19

    .prologue
    .line 577
    iget-object v1, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getLeft()I

    move-result v3

    .line 578
    iget-object v1, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getTop()I

    move-result v4

    .line 579
    sub-int v5, p1, v3

    .line 580
    sub-int v6, p2, v4

    .line 582
    if-nez v5, :cond_1f

    if-nez v6, :cond_1f

    .line 584
    iget-object v1, p0, Landroid/support/v4/widget/ad;->q:Landroid/support/v4/widget/n;

    invoke-virtual {v1}, Landroid/support/v4/widget/n;->c()V

    .line 585
    const/4 v1, 0x0

    invoke-virtual {p0, v1}, Landroid/support/v4/widget/ad;->b(I)V

    .line 586
    const/4 v1, 0x0

    .line 593
    :goto_1e
    return v1

    .line 589
    :cond_1f
    iget-object v7, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    iget v1, p0, Landroid/support/v4/widget/ad;->n:F

    float-to-int v1, v1

    iget v2, p0, Landroid/support/v4/widget/ad;->m:F

    float-to-int v2, v2

    move/from16 v0, p3

    invoke-static {v0, v1, v2}, Landroid/support/v4/widget/ad;->b(III)I

    move-result v8

    iget v1, p0, Landroid/support/v4/widget/ad;->n:F

    float-to-int v1, v1

    iget v2, p0, Landroid/support/v4/widget/ad;->m:F

    float-to-int v2, v2

    move/from16 v0, p4

    invoke-static {v0, v1, v2}, Landroid/support/v4/widget/ad;->b(III)I

    move-result v9

    invoke-static {v5}, Ljava/lang/Math;->abs(I)I

    move-result v1

    invoke-static {v6}, Ljava/lang/Math;->abs(I)I

    move-result v10

    invoke-static {v8}, Ljava/lang/Math;->abs(I)I

    move-result v2

    invoke-static {v9}, Ljava/lang/Math;->abs(I)I

    move-result v11

    add-int v12, v2, v11

    add-int v13, v1, v10

    if-eqz v8, :cond_7e

    int-to-float v1, v2

    int-to-float v2, v12

    div-float/2addr v1, v2

    move v2, v1

    :goto_53
    if-eqz v9, :cond_83

    int-to-float v1, v11

    int-to-float v10, v12

    div-float/2addr v1, v10

    :goto_58
    iget-object v10, p0, Landroid/support/v4/widget/ad;->r:Landroid/support/v4/widget/ae;

    invoke-virtual {v10, v7}, Landroid/support/v4/widget/ae;->c(Landroid/view/View;)I

    move-result v7

    invoke-direct {p0, v5, v8, v7}, Landroid/support/v4/widget/ad;->a(III)I

    move-result v7

    iget-object v8, p0, Landroid/support/v4/widget/ad;->r:Landroid/support/v4/widget/ae;

    const/4 v8, 0x0

    invoke-direct {p0, v6, v9, v8}, Landroid/support/v4/widget/ad;->a(III)I

    move-result v8

    int-to-float v7, v7

    mul-float/2addr v2, v7

    int-to-float v7, v8

    mul-float/2addr v1, v7

    add-float/2addr v1, v2

    float-to-int v7, v1

    .line 590
    iget-object v2, p0, Landroid/support/v4/widget/ad;->q:Landroid/support/v4/widget/n;

    sget-object v1, Landroid/support/v4/widget/n;->b:Landroid/support/v4/widget/o;

    iget-object v2, v2, Landroid/support/v4/widget/n;->a:Ljava/lang/Object;

    invoke-interface/range {v1 .. v7}, Landroid/support/v4/widget/o;->a(Ljava/lang/Object;IIIII)V

    .line 592
    const/4 v1, 0x2

    invoke-virtual {p0, v1}, Landroid/support/v4/widget/ad;->b(I)V

    .line 593
    const/4 v1, 0x1

    goto :goto_1e

    .line 589
    :cond_7e
    int-to-float v1, v1

    int-to-float v2, v13

    div-float/2addr v1, v2

    move v2, v1

    goto :goto_53

    :cond_83
    int-to-float v1, v10

    int-to-float v10, v13

    div-float/2addr v1, v10

    goto :goto_58
.end method

.method private a(Landroid/view/View;F)Z
    .registers 7

    .prologue
    const/4 v1, 0x1

    const/4 v2, 0x0

    .line 1245
    if-nez p1, :cond_5

    .line 1255
    :cond_4
    :goto_4
    return v2

    .line 1248
    :cond_5
    iget-object v0, p0, Landroid/support/v4/widget/ad;->r:Landroid/support/v4/widget/ae;

    invoke-virtual {v0, p1}, Landroid/support/v4/widget/ae;->c(Landroid/view/View;)I

    move-result v0

    if-lez v0, :cond_1f

    move v0, v1

    .line 1249
    :goto_e
    iget-object v3, p0, Landroid/support/v4/widget/ad;->r:Landroid/support/v4/widget/ae;

    .line 1251
    if-eqz v0, :cond_4

    .line 1254
    invoke-static {p2}, Ljava/lang/Math;->abs(F)F

    move-result v0

    iget v3, p0, Landroid/support/v4/widget/ad;->b:I

    int-to-float v3, v3

    cmpl-float v0, v0, v3

    if-lez v0, :cond_4

    move v2, v1

    goto :goto_4

    :cond_1f
    move v0, v2

    .line 1248
    goto :goto_e
.end method

.method private static b(III)I
    .registers 4

    .prologue
    .line 650
    invoke-static {p0}, Ljava/lang/Math;->abs(I)I

    move-result v0

    .line 651
    if-ge v0, p1, :cond_8

    const/4 p2, 0x0

    .line 653
    :cond_7
    :goto_7
    return p2

    .line 652
    :cond_8
    if-le v0, p2, :cond_e

    if-gtz p0, :cond_7

    neg-int p2, p2

    goto :goto_7

    :cond_e
    move p2, p0

    .line 653
    goto :goto_7
.end method

.method private b(F)V
    .registers 6

    .prologue
    const/4 v3, 0x1

    const/4 v2, 0x0

    .line 759
    iput-boolean v3, p0, Landroid/support/v4/widget/ad;->t:Z

    .line 760
    iget-object v0, p0, Landroid/support/v4/widget/ad;->r:Landroid/support/v4/widget/ae;

    iget-object v1, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    invoke-virtual {v0, v1, p1}, Landroid/support/v4/widget/ae;->a(Landroid/view/View;F)V

    .line 761
    iput-boolean v2, p0, Landroid/support/v4/widget/ad;->t:Z

    .line 763
    iget v0, p0, Landroid/support/v4/widget/ad;->a:I

    if-ne v0, v3, :cond_14

    .line 765
    invoke-virtual {p0, v2}, Landroid/support/v4/widget/ad;->b(I)V

    .line 767
    :cond_14
    return-void
.end method

.method private b(FFI)V
    .registers 7

    .prologue
    const/4 v0, 0x1

    .line 1197
    const/4 v1, 0x0

    .line 1198
    invoke-direct {p0, p1, p2, p3, v0}, Landroid/support/v4/widget/ad;->a(FFII)Z

    move-result v2

    if-eqz v2, :cond_33

    .line 1201
    :goto_8
    const/4 v1, 0x4

    invoke-direct {p0, p2, p1, p3, v1}, Landroid/support/v4/widget/ad;->a(FFII)Z

    move-result v1

    if-eqz v1, :cond_11

    .line 1202
    or-int/lit8 v0, v0, 0x4

    .line 1204
    :cond_11
    const/4 v1, 0x2

    invoke-direct {p0, p1, p2, p3, v1}, Landroid/support/v4/widget/ad;->a(FFII)Z

    move-result v1

    if-eqz v1, :cond_1a

    .line 1205
    or-int/lit8 v0, v0, 0x2

    .line 1207
    :cond_1a
    const/16 v1, 0x8

    invoke-direct {p0, p2, p1, p3, v1}, Landroid/support/v4/widget/ad;->a(FFII)Z

    move-result v1

    if-eqz v1, :cond_24

    .line 1208
    or-int/lit8 v0, v0, 0x8

    .line 1211
    :cond_24
    if-eqz v0, :cond_32

    .line 1212
    iget-object v1, p0, Landroid/support/v4/widget/ad;->i:[I

    aget v2, v1, p3

    or-int/2addr v2, v0

    aput v2, v1, p3

    .line 1213
    iget-object v1, p0, Landroid/support/v4/widget/ad;->r:Landroid/support/v4/widget/ae;

    invoke-virtual {v1, v0, p3}, Landroid/support/v4/widget/ae;->a(II)V

    .line 1215
    :cond_32
    return-void

    :cond_33
    move v0, v1

    goto :goto_8
.end method

.method private b(Landroid/view/View;I)Z
    .registers 5

    .prologue
    const/4 v0, 0x1

    .line 883
    iget-object v1, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    if-ne p1, v1, :cond_a

    iget v1, p0, Landroid/support/v4/widget/ad;->c:I

    if-ne v1, p2, :cond_a

    .line 892
    :goto_9
    return v0

    .line 887
    :cond_a
    if-eqz p1, :cond_1a

    iget-object v1, p0, Landroid/support/v4/widget/ad;->r:Landroid/support/v4/widget/ae;

    invoke-virtual {v1, p1}, Landroid/support/v4/widget/ae;->a(Landroid/view/View;)Z

    move-result v1

    if-eqz v1, :cond_1a

    .line 888
    iput p2, p0, Landroid/support/v4/widget/ad;->c:I

    .line 889
    invoke-virtual {p0, p1, p2}, Landroid/support/v4/widget/ad;->a(Landroid/view/View;I)V

    goto :goto_9

    .line 892
    :cond_1a
    const/4 v0, 0x0

    goto :goto_9
.end method

.method public static b(Landroid/view/View;II)Z
    .registers 5

    .prologue
    const/4 v0, 0x0

    .line 1410
    if-nez p0, :cond_4

    .line 1413
    :cond_3
    :goto_3
    return v0

    :cond_4
    invoke-virtual {p0}, Landroid/view/View;->getLeft()I

    move-result v1

    if-lt p1, v1, :cond_3

    invoke-virtual {p0}, Landroid/view/View;->getRight()I

    move-result v1

    if-ge p1, v1, :cond_3

    invoke-virtual {p0}, Landroid/view/View;->getTop()I

    move-result v1

    if-lt p2, v1, :cond_3

    invoke-virtual {p0}, Landroid/view/View;->getBottom()I

    move-result v1

    if-ge p2, v1, :cond_3

    const/4 v0, 0x1

    goto :goto_3
.end method

.method private c(I)V
    .registers 5

    .prologue
    const/4 v2, 0x0

    const/4 v1, 0x0

    .line 784
    iget-object v0, p0, Landroid/support/v4/widget/ad;->d:[F

    if-nez v0, :cond_7

    .line 795
    :goto_6
    return-void

    .line 787
    :cond_7
    iget-object v0, p0, Landroid/support/v4/widget/ad;->d:[F

    aput v1, v0, p1

    .line 788
    iget-object v0, p0, Landroid/support/v4/widget/ad;->e:[F

    aput v1, v0, p1

    .line 789
    iget-object v0, p0, Landroid/support/v4/widget/ad;->f:[F

    aput v1, v0, p1

    .line 790
    iget-object v0, p0, Landroid/support/v4/widget/ad;->g:[F

    aput v1, v0, p1

    .line 791
    iget-object v0, p0, Landroid/support/v4/widget/ad;->h:[I

    aput v2, v0, p1

    .line 792
    iget-object v0, p0, Landroid/support/v4/widget/ad;->i:[I

    aput v2, v0, p1

    .line 793
    iget-object v0, p0, Landroid/support/v4/widget/ad;->j:[I

    aput v2, v0, p1

    .line 794
    iget v0, p0, Landroid/support/v4/widget/ad;->k:I

    const/4 v1, 0x1

    shl-int/2addr v1, p1

    xor-int/lit8 v1, v1, -0x1

    and-int/2addr v0, v1

    iput v0, p0, Landroid/support/v4/widget/ad;->k:I

    goto :goto_6
.end method

.method private c(Landroid/view/MotionEvent;)V
    .registers 8

    .prologue
    .line 836
    invoke-static {p1}, Landroid/support/v4/view/ad;->c(Landroid/view/MotionEvent;)I

    move-result v1

    .line 837
    const/4 v0, 0x0

    :goto_5
    if-ge v0, v1, :cond_1e

    .line 838
    invoke-static {p1, v0}, Landroid/support/v4/view/ad;->b(Landroid/view/MotionEvent;I)I

    move-result v2

    .line 839
    invoke-static {p1, v0}, Landroid/support/v4/view/ad;->c(Landroid/view/MotionEvent;I)F

    move-result v3

    .line 840
    invoke-static {p1, v0}, Landroid/support/v4/view/ad;->d(Landroid/view/MotionEvent;I)F

    move-result v4

    .line 841
    iget-object v5, p0, Landroid/support/v4/widget/ad;->f:[F

    aput v3, v5, v2

    .line 842
    iget-object v3, p0, Landroid/support/v4/widget/ad;->g:[F

    aput v4, v3, v2

    .line 837
    add-int/lit8 v0, v0, 0x1

    goto :goto_5

    .line 844
    :cond_1e
    return-void
.end method

.method private i()V
    .registers 5

    .prologue
    .line 1355
    iget-object v0, p0, Landroid/support/v4/widget/ad;->l:Landroid/view/VelocityTracker;

    const/16 v1, 0x3e8

    iget v2, p0, Landroid/support/v4/widget/ad;->m:F

    invoke-virtual {v0, v1, v2}, Landroid/view/VelocityTracker;->computeCurrentVelocity(IF)V

    .line 1356
    iget-object v0, p0, Landroid/support/v4/widget/ad;->l:Landroid/view/VelocityTracker;

    iget v1, p0, Landroid/support/v4/widget/ad;->c:I

    invoke-static {v0, v1}, Landroid/support/v4/view/ap;->a(Landroid/view/VelocityTracker;I)F

    move-result v0

    iget v1, p0, Landroid/support/v4/widget/ad;->n:F

    iget v2, p0, Landroid/support/v4/widget/ad;->m:F

    invoke-static {v0, v1, v2}, Landroid/support/v4/widget/ad;->a(FFF)F

    move-result v0

    .line 1359
    iget-object v1, p0, Landroid/support/v4/widget/ad;->l:Landroid/view/VelocityTracker;

    iget v2, p0, Landroid/support/v4/widget/ad;->c:I

    invoke-static {v1, v2}, Landroid/support/v4/view/ap;->b(Landroid/view/VelocityTracker;I)F

    move-result v1

    iget v2, p0, Landroid/support/v4/widget/ad;->n:F

    iget v3, p0, Landroid/support/v4/widget/ad;->m:F

    invoke-static {v1, v2, v3}, Landroid/support/v4/widget/ad;->a(FFF)F

    .line 1362
    invoke-direct {p0, v0}, Landroid/support/v4/widget/ad;->b(F)V

    .line 1363
    return-void
.end method


# virtual methods
.method public final a()I
    .registers 2

    .prologue
    .line 421
    iget v0, p0, Landroid/support/v4/widget/ad;->a:I

    return v0
.end method

.method public final a(F)V
    .registers 2

    .prologue
    .line 401
    iput p1, p0, Landroid/support/v4/widget/ad;->n:F

    .line 402
    return-void
.end method

.method public final a(I)V
    .registers 2

    .prologue
    .line 437
    iput p1, p0, Landroid/support/v4/widget/ad;->p:I

    .line 438
    return-void
.end method

.method public final a(Landroid/view/View;I)V
    .registers 6

    .prologue
    .line 460
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    iget-object v1, p0, Landroid/support/v4/widget/ad;->u:Landroid/view/ViewGroup;

    if-eq v0, v1, :cond_25

    .line 461
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "captureChildView: parameter must be a descendant of the ViewDragHelper\'s tracked parent view ("

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Landroid/support/v4/widget/ad;->u:Landroid/view/ViewGroup;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ")"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 465
    :cond_25
    iput-object p1, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    .line 466
    iput p2, p0, Landroid/support/v4/widget/ad;->c:I

    .line 467
    iget-object v0, p0, Landroid/support/v4/widget/ad;->r:Landroid/support/v4/widget/ae;

    invoke-virtual {v0, p1}, Landroid/support/v4/widget/ae;->b(Landroid/view/View;)V

    .line 468
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroid/support/v4/widget/ad;->b(I)V

    .line 469
    return-void
.end method

.method public final a(II)Z
    .registers 6

    .prologue
    .line 557
    iget-boolean v0, p0, Landroid/support/v4/widget/ad;->t:Z

    if-nez v0, :cond_c

    .line 558
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Cannot settleCapturedViewAt outside of a call to Callback#onViewReleased"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 562
    :cond_c
    iget-object v0, p0, Landroid/support/v4/widget/ad;->l:Landroid/view/VelocityTracker;

    iget v1, p0, Landroid/support/v4/widget/ad;->c:I

    invoke-static {v0, v1}, Landroid/support/v4/view/ap;->a(Landroid/view/VelocityTracker;I)F

    move-result v0

    float-to-int v0, v0

    iget-object v1, p0, Landroid/support/v4/widget/ad;->l:Landroid/view/VelocityTracker;

    iget v2, p0, Landroid/support/v4/widget/ad;->c:I

    invoke-static {v1, v2}, Landroid/support/v4/view/ap;->b(Landroid/view/VelocityTracker;I)F

    move-result v1

    float-to-int v1, v1

    invoke-direct {p0, p1, p2, v0, v1}, Landroid/support/v4/widget/ad;->a(IIII)Z

    move-result v0

    return v0
.end method

.method public final a(Landroid/view/MotionEvent;)Z
    .registers 11

    .prologue
    const/4 v6, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    .line 939
    invoke-static {p1}, Landroid/support/v4/view/ad;->a(Landroid/view/MotionEvent;)I

    move-result v2

    .line 940
    invoke-static {p1}, Landroid/support/v4/view/ad;->b(Landroid/view/MotionEvent;)I

    move-result v3

    .line 942
    if-nez v2, :cond_10

    .line 945
    invoke-virtual {p0}, Landroid/support/v4/widget/ad;->e()V

    .line 948
    :cond_10
    iget-object v4, p0, Landroid/support/v4/widget/ad;->l:Landroid/view/VelocityTracker;

    if-nez v4, :cond_1a

    .line 949
    invoke-static {}, Landroid/view/VelocityTracker;->obtain()Landroid/view/VelocityTracker;

    move-result-object v4

    iput-object v4, p0, Landroid/support/v4/widget/ad;->l:Landroid/view/VelocityTracker;

    .line 951
    :cond_1a
    iget-object v4, p0, Landroid/support/v4/widget/ad;->l:Landroid/view/VelocityTracker;

    invoke-virtual {v4, p1}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    .line 953
    packed-switch v2, :pswitch_data_e2

    .line 1036
    :cond_22
    :goto_22
    :pswitch_22
    iget v2, p0, Landroid/support/v4/widget/ad;->a:I

    if-ne v2, v0, :cond_de

    :goto_26
    return v0

    .line 955
    :pswitch_27
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v2

    .line 956
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v3

    .line 957
    invoke-static {p1, v1}, Landroid/support/v4/view/ad;->b(Landroid/view/MotionEvent;I)I

    move-result v4

    .line 958
    invoke-direct {p0, v2, v3, v4}, Landroid/support/v4/widget/ad;->a(FFI)V

    .line 960
    float-to-int v2, v2

    float-to-int v3, v3

    invoke-virtual {p0, v2, v3}, Landroid/support/v4/widget/ad;->b(II)Landroid/view/View;

    move-result-object v2

    .line 963
    iget-object v3, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    if-ne v2, v3, :cond_47

    iget v3, p0, Landroid/support/v4/widget/ad;->a:I

    if-ne v3, v6, :cond_47

    .line 964
    invoke-direct {p0, v2, v4}, Landroid/support/v4/widget/ad;->b(Landroid/view/View;I)Z

    .line 967
    :cond_47
    iget-object v2, p0, Landroid/support/v4/widget/ad;->h:[I

    aget v2, v2, v4

    .line 968
    iget v3, p0, Landroid/support/v4/widget/ad;->p:I

    and-int/2addr v2, v3

    if-eqz v2, :cond_22

    .line 969
    iget-object v2, p0, Landroid/support/v4/widget/ad;->r:Landroid/support/v4/widget/ae;

    iget v3, p0, Landroid/support/v4/widget/ad;->p:I

    invoke-virtual {v2}, Landroid/support/v4/widget/ae;->b()V

    goto :goto_22

    .line 975
    :pswitch_58
    invoke-static {p1, v3}, Landroid/support/v4/view/ad;->b(Landroid/view/MotionEvent;I)I

    move-result v2

    .line 976
    invoke-static {p1, v3}, Landroid/support/v4/view/ad;->c(Landroid/view/MotionEvent;I)F

    move-result v4

    .line 977
    invoke-static {p1, v3}, Landroid/support/v4/view/ad;->d(Landroid/view/MotionEvent;I)F

    move-result v3

    .line 979
    invoke-direct {p0, v4, v3, v2}, Landroid/support/v4/widget/ad;->a(FFI)V

    .line 982
    iget v5, p0, Landroid/support/v4/widget/ad;->a:I

    if-nez v5, :cond_7c

    .line 983
    iget-object v3, p0, Landroid/support/v4/widget/ad;->h:[I

    aget v2, v3, v2

    .line 984
    iget v3, p0, Landroid/support/v4/widget/ad;->p:I

    and-int/2addr v2, v3

    if-eqz v2, :cond_22

    .line 985
    iget-object v2, p0, Landroid/support/v4/widget/ad;->r:Landroid/support/v4/widget/ae;

    iget v3, p0, Landroid/support/v4/widget/ad;->p:I

    invoke-virtual {v2}, Landroid/support/v4/widget/ae;->b()V

    goto :goto_22

    .line 987
    :cond_7c
    iget v5, p0, Landroid/support/v4/widget/ad;->a:I

    if-ne v5, v6, :cond_22

    .line 989
    float-to-int v4, v4

    float-to-int v3, v3

    invoke-virtual {p0, v4, v3}, Landroid/support/v4/widget/ad;->b(II)Landroid/view/View;

    move-result-object v3

    .line 990
    iget-object v4, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    if-ne v3, v4, :cond_22

    .line 991
    invoke-direct {p0, v3, v2}, Landroid/support/v4/widget/ad;->b(Landroid/view/View;I)Z

    goto :goto_22

    .line 999
    :pswitch_8e
    invoke-static {p1}, Landroid/support/v4/view/ad;->c(Landroid/view/MotionEvent;)I

    move-result v3

    move v2, v1

    .line 1000
    :goto_93
    if-ge v2, v3, :cond_cb

    .line 1001
    invoke-static {p1, v2}, Landroid/support/v4/view/ad;->b(Landroid/view/MotionEvent;I)I

    move-result v4

    .line 1002
    invoke-static {p1, v2}, Landroid/support/v4/view/ad;->c(Landroid/view/MotionEvent;I)F

    move-result v5

    .line 1003
    invoke-static {p1, v2}, Landroid/support/v4/view/ad;->d(Landroid/view/MotionEvent;I)F

    move-result v6

    .line 1004
    iget-object v7, p0, Landroid/support/v4/widget/ad;->d:[F

    aget v7, v7, v4

    sub-float v7, v5, v7

    .line 1005
    iget-object v8, p0, Landroid/support/v4/widget/ad;->e:[F

    aget v8, v8, v4

    sub-float v8, v6, v8

    .line 1007
    invoke-direct {p0, v7, v8, v4}, Landroid/support/v4/widget/ad;->b(FFI)V

    .line 1008
    iget v8, p0, Landroid/support/v4/widget/ad;->a:I

    if-eq v8, v0, :cond_cb

    .line 1010
    float-to-int v5, v5

    float-to-int v6, v6

    invoke-virtual {p0, v5, v6}, Landroid/support/v4/widget/ad;->b(II)Landroid/view/View;

    move-result-object v5

    .line 1014
    if-eqz v5, :cond_c8

    invoke-direct {p0, v5, v7}, Landroid/support/v4/widget/ad;->a(Landroid/view/View;F)Z

    move-result v6

    if-eqz v6, :cond_c8

    invoke-direct {p0, v5, v4}, Landroid/support/v4/widget/ad;->b(Landroid/view/View;I)Z

    move-result v4

    if-nez v4, :cond_cb

    .line 1016
    :cond_c8
    add-int/lit8 v2, v2, 0x1

    goto :goto_93

    .line 1019
    :cond_cb
    invoke-direct {p0, p1}, Landroid/support/v4/widget/ad;->c(Landroid/view/MotionEvent;)V

    goto/16 :goto_22

    .line 1024
    :pswitch_d0
    invoke-static {p1, v3}, Landroid/support/v4/view/ad;->b(Landroid/view/MotionEvent;I)I

    move-result v2

    .line 1025
    invoke-direct {p0, v2}, Landroid/support/v4/widget/ad;->c(I)V

    goto/16 :goto_22

    .line 1031
    :pswitch_d9
    invoke-virtual {p0}, Landroid/support/v4/widget/ad;->e()V

    goto/16 :goto_22

    :cond_de
    move v0, v1

    .line 1036
    goto/16 :goto_26

    .line 953
    nop

    :pswitch_data_e2
    .packed-switch 0x0
        :pswitch_27
        :pswitch_d9
        :pswitch_8e
        :pswitch_d9
        :pswitch_22
        :pswitch_58
        :pswitch_d0
    .end packed-switch
.end method

.method public final a(Landroid/view/View;II)Z
    .registers 6

    .prologue
    const/4 v1, 0x0

    .line 539
    iput-object p1, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    .line 540
    const/4 v0, -0x1

    iput v0, p0, Landroid/support/v4/widget/ad;->c:I

    .line 542
    invoke-direct {p0, p2, p3, v1, v1}, Landroid/support/v4/widget/ad;->a(IIII)Z

    move-result v0

    return v0
.end method

.method public final b()I
    .registers 2

    .prologue
    .line 448
    iget v0, p0, Landroid/support/v4/widget/ad;->o:I

    return v0
.end method

.method public final b(II)Landroid/view/View;
    .registers 6

    .prologue
    .line 1428
    iget-object v0, p0, Landroid/support/v4/widget/ad;->u:Landroid/view/ViewGroup;

    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    .line 1429
    add-int/lit8 v0, v0, -0x1

    move v1, v0

    :goto_9
    if-ltz v1, :cond_30

    .line 1430
    iget-object v0, p0, Landroid/support/v4/widget/ad;->u:Landroid/view/ViewGroup;

    iget-object v2, p0, Landroid/support/v4/widget/ad;->r:Landroid/support/v4/widget/ae;

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    .line 1431
    invoke-virtual {v0}, Landroid/view/View;->getLeft()I

    move-result v2

    if-lt p1, v2, :cond_2c

    invoke-virtual {v0}, Landroid/view/View;->getRight()I

    move-result v2

    if-ge p1, v2, :cond_2c

    invoke-virtual {v0}, Landroid/view/View;->getTop()I

    move-result v2

    if-lt p2, v2, :cond_2c

    invoke-virtual {v0}, Landroid/view/View;->getBottom()I

    move-result v2

    if-ge p2, v2, :cond_2c

    .line 1436
    :goto_2b
    return-object v0

    .line 1429
    :cond_2c
    add-int/lit8 v0, v1, -0x1

    move v1, v0

    goto :goto_9

    .line 1436
    :cond_30
    const/4 v0, 0x0

    goto :goto_2b
.end method

.method final b(I)V
    .registers 3

    .prologue
    .line 864
    iget v0, p0, Landroid/support/v4/widget/ad;->a:I

    if-eq v0, p1, :cond_10

    .line 865
    iput p1, p0, Landroid/support/v4/widget/ad;->a:I

    .line 866
    iget-object v0, p0, Landroid/support/v4/widget/ad;->r:Landroid/support/v4/widget/ae;

    invoke-virtual {v0, p1}, Landroid/support/v4/widget/ae;->a(I)V

    .line 867
    if-nez p1, :cond_10

    .line 868
    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    .line 871
    :cond_10
    return-void
.end method

.method public final b(Landroid/view/MotionEvent;)V
    .registers 10

    .prologue
    const/4 v1, -0x1

    const/4 v0, 0x0

    const/4 v7, 0x1

    .line 1046
    invoke-static {p1}, Landroid/support/v4/view/ad;->a(Landroid/view/MotionEvent;)I

    move-result v2

    .line 1047
    invoke-static {p1}, Landroid/support/v4/view/ad;->b(Landroid/view/MotionEvent;)I

    move-result v3

    .line 1049
    if-nez v2, :cond_10

    .line 1052
    invoke-virtual {p0}, Landroid/support/v4/widget/ad;->e()V

    .line 1055
    :cond_10
    iget-object v4, p0, Landroid/support/v4/widget/ad;->l:Landroid/view/VelocityTracker;

    if-nez v4, :cond_1a

    .line 1056
    invoke-static {}, Landroid/view/VelocityTracker;->obtain()Landroid/view/VelocityTracker;

    move-result-object v4

    iput-object v4, p0, Landroid/support/v4/widget/ad;->l:Landroid/view/VelocityTracker;

    .line 1058
    :cond_1a
    iget-object v4, p0, Landroid/support/v4/widget/ad;->l:Landroid/view/VelocityTracker;

    invoke-virtual {v4, p1}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    .line 1060
    packed-switch v2, :pswitch_data_192

    .line 1194
    :cond_22
    :goto_22
    :pswitch_22
    return-void

    .line 1062
    :pswitch_23
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    .line 1063
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v2

    .line 1064
    invoke-static {p1, v0}, Landroid/support/v4/view/ad;->b(Landroid/view/MotionEvent;I)I

    move-result v0

    .line 1065
    float-to-int v3, v1

    float-to-int v4, v2

    invoke-virtual {p0, v3, v4}, Landroid/support/v4/widget/ad;->b(II)Landroid/view/View;

    move-result-object v3

    .line 1067
    invoke-direct {p0, v1, v2, v0}, Landroid/support/v4/widget/ad;->a(FFI)V

    .line 1072
    invoke-direct {p0, v3, v0}, Landroid/support/v4/widget/ad;->b(Landroid/view/View;I)Z

    .line 1074
    iget-object v1, p0, Landroid/support/v4/widget/ad;->h:[I

    aget v0, v1, v0

    .line 1075
    iget v1, p0, Landroid/support/v4/widget/ad;->p:I

    and-int/2addr v0, v1

    if-eqz v0, :cond_22

    .line 1076
    iget-object v0, p0, Landroid/support/v4/widget/ad;->r:Landroid/support/v4/widget/ae;

    iget v1, p0, Landroid/support/v4/widget/ad;->p:I

    invoke-virtual {v0}, Landroid/support/v4/widget/ae;->b()V

    goto :goto_22

    .line 1082
    :pswitch_4c
    invoke-static {p1, v3}, Landroid/support/v4/view/ad;->b(Landroid/view/MotionEvent;I)I

    move-result v0

    .line 1083
    invoke-static {p1, v3}, Landroid/support/v4/view/ad;->c(Landroid/view/MotionEvent;I)F

    move-result v1

    .line 1084
    invoke-static {p1, v3}, Landroid/support/v4/view/ad;->d(Landroid/view/MotionEvent;I)F

    move-result v2

    .line 1086
    invoke-direct {p0, v1, v2, v0}, Landroid/support/v4/widget/ad;->a(FFI)V

    .line 1089
    iget v3, p0, Landroid/support/v4/widget/ad;->a:I

    if-nez v3, :cond_79

    .line 1092
    float-to-int v1, v1

    float-to-int v2, v2

    invoke-virtual {p0, v1, v2}, Landroid/support/v4/widget/ad;->b(II)Landroid/view/View;

    move-result-object v1

    .line 1093
    invoke-direct {p0, v1, v0}, Landroid/support/v4/widget/ad;->b(Landroid/view/View;I)Z

    .line 1095
    iget-object v1, p0, Landroid/support/v4/widget/ad;->h:[I

    aget v0, v1, v0

    .line 1096
    iget v1, p0, Landroid/support/v4/widget/ad;->p:I

    and-int/2addr v0, v1

    if-eqz v0, :cond_22

    .line 1097
    iget-object v0, p0, Landroid/support/v4/widget/ad;->r:Landroid/support/v4/widget/ae;

    iget v1, p0, Landroid/support/v4/widget/ad;->p:I

    invoke-virtual {v0}, Landroid/support/v4/widget/ae;->b()V

    goto :goto_22

    .line 1099
    :cond_79
    float-to-int v1, v1

    float-to-int v2, v2

    iget-object v3, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    invoke-static {v3, v1, v2}, Landroid/support/v4/widget/ad;->b(Landroid/view/View;II)Z

    move-result v1

    if-eqz v1, :cond_22

    .line 1104
    iget-object v1, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    invoke-direct {p0, v1, v0}, Landroid/support/v4/widget/ad;->b(Landroid/view/View;I)Z

    goto :goto_22

    .line 1110
    :pswitch_89
    iget v1, p0, Landroid/support/v4/widget/ad;->a:I

    if-ne v1, v7, :cond_f4

    .line 1111
    iget v0, p0, Landroid/support/v4/widget/ad;->c:I

    invoke-static {p1, v0}, Landroid/support/v4/view/ad;->a(Landroid/view/MotionEvent;I)I

    move-result v0

    .line 1112
    invoke-static {p1, v0}, Landroid/support/v4/view/ad;->c(Landroid/view/MotionEvent;I)F

    move-result v1

    .line 1113
    invoke-static {p1, v0}, Landroid/support/v4/view/ad;->d(Landroid/view/MotionEvent;I)F

    move-result v0

    .line 1114
    iget-object v2, p0, Landroid/support/v4/widget/ad;->f:[F

    iget v3, p0, Landroid/support/v4/widget/ad;->c:I

    aget v2, v2, v3

    sub-float/2addr v1, v2

    float-to-int v1, v1

    .line 1115
    iget-object v2, p0, Landroid/support/v4/widget/ad;->g:[F

    iget v3, p0, Landroid/support/v4/widget/ad;->c:I

    aget v2, v2, v3

    sub-float/2addr v0, v2

    float-to-int v2, v0

    .line 1117
    iget-object v0, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->getLeft()I

    move-result v0

    add-int/2addr v0, v1

    iget-object v3, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    invoke-virtual {v3}, Landroid/view/View;->getTop()I

    iget-object v3, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    invoke-virtual {v3}, Landroid/view/View;->getLeft()I

    move-result v3

    iget-object v4, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    invoke-virtual {v4}, Landroid/view/View;->getTop()I

    move-result v4

    if-eqz v1, :cond_d4

    iget-object v5, p0, Landroid/support/v4/widget/ad;->r:Landroid/support/v4/widget/ae;

    iget-object v6, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    invoke-virtual {v5, v6, v0}, Landroid/support/v4/widget/ae;->b(Landroid/view/View;I)I

    move-result v0

    iget-object v5, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    sub-int v3, v0, v3

    invoke-virtual {v5, v3}, Landroid/view/View;->offsetLeftAndRight(I)V

    :cond_d4
    if-eqz v2, :cond_e4

    iget-object v3, p0, Landroid/support/v4/widget/ad;->r:Landroid/support/v4/widget/ae;

    iget-object v5, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    invoke-virtual {v3, v5}, Landroid/support/v4/widget/ae;->d(Landroid/view/View;)I

    move-result v3

    iget-object v5, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    sub-int/2addr v3, v4

    invoke-virtual {v5, v3}, Landroid/view/View;->offsetTopAndBottom(I)V

    :cond_e4
    if-nez v1, :cond_e8

    if-eqz v2, :cond_ef

    :cond_e8
    iget-object v1, p0, Landroid/support/v4/widget/ad;->r:Landroid/support/v4/widget/ae;

    iget-object v2, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    invoke-virtual {v1, v2, v0}, Landroid/support/v4/widget/ae;->a(Landroid/view/View;I)V

    .line 1119
    :cond_ef
    invoke-direct {p0, p1}, Landroid/support/v4/widget/ad;->c(Landroid/view/MotionEvent;)V

    goto/16 :goto_22

    .line 1122
    :cond_f4
    invoke-static {p1}, Landroid/support/v4/view/ad;->c(Landroid/view/MotionEvent;)I

    move-result v1

    .line 1123
    :goto_f8
    if-ge v0, v1, :cond_12e

    .line 1124
    invoke-static {p1, v0}, Landroid/support/v4/view/ad;->b(Landroid/view/MotionEvent;I)I

    move-result v2

    .line 1125
    invoke-static {p1, v0}, Landroid/support/v4/view/ad;->c(Landroid/view/MotionEvent;I)F

    move-result v3

    .line 1126
    invoke-static {p1, v0}, Landroid/support/v4/view/ad;->d(Landroid/view/MotionEvent;I)F

    move-result v4

    .line 1127
    iget-object v5, p0, Landroid/support/v4/widget/ad;->d:[F

    aget v5, v5, v2

    sub-float v5, v3, v5

    .line 1128
    iget-object v6, p0, Landroid/support/v4/widget/ad;->e:[F

    aget v6, v6, v2

    sub-float v6, v4, v6

    .line 1130
    invoke-direct {p0, v5, v6, v2}, Landroid/support/v4/widget/ad;->b(FFI)V

    .line 1131
    iget v6, p0, Landroid/support/v4/widget/ad;->a:I

    if-eq v6, v7, :cond_12e

    .line 1133
    float-to-int v3, v3

    float-to-int v4, v4

    invoke-virtual {p0, v3, v4}, Landroid/support/v4/widget/ad;->b(II)Landroid/view/View;

    move-result-object v3

    .line 1137
    invoke-direct {p0, v3, v5}, Landroid/support/v4/widget/ad;->a(Landroid/view/View;F)Z

    move-result v4

    if-eqz v4, :cond_12b

    invoke-direct {p0, v3, v2}, Landroid/support/v4/widget/ad;->b(Landroid/view/View;I)Z

    move-result v2

    if-nez v2, :cond_12e

    .line 1139
    :cond_12b
    add-int/lit8 v0, v0, 0x1

    goto :goto_f8

    .line 1142
    :cond_12e
    invoke-direct {p0, p1}, Landroid/support/v4/widget/ad;->c(Landroid/view/MotionEvent;)V

    goto/16 :goto_22

    .line 1148
    :pswitch_133
    invoke-static {p1, v3}, Landroid/support/v4/view/ad;->b(Landroid/view/MotionEvent;I)I

    move-result v2

    .line 1149
    iget v3, p0, Landroid/support/v4/widget/ad;->a:I

    if-ne v3, v7, :cond_16e

    iget v3, p0, Landroid/support/v4/widget/ad;->c:I

    if-ne v2, v3, :cond_16e

    .line 1152
    invoke-static {p1}, Landroid/support/v4/view/ad;->c(Landroid/view/MotionEvent;)I

    move-result v3

    .line 1153
    :goto_143
    if-ge v0, v3, :cond_18f

    .line 1154
    invoke-static {p1, v0}, Landroid/support/v4/view/ad;->b(Landroid/view/MotionEvent;I)I

    move-result v4

    .line 1155
    iget v5, p0, Landroid/support/v4/widget/ad;->c:I

    if-eq v4, v5, :cond_173

    .line 1157
    invoke-static {p1, v0}, Landroid/support/v4/view/ad;->c(Landroid/view/MotionEvent;I)F

    move-result v5

    .line 1161
    invoke-static {p1, v0}, Landroid/support/v4/view/ad;->d(Landroid/view/MotionEvent;I)F

    move-result v6

    .line 1162
    float-to-int v5, v5

    float-to-int v6, v6

    invoke-virtual {p0, v5, v6}, Landroid/support/v4/widget/ad;->b(II)Landroid/view/View;

    move-result-object v5

    iget-object v6, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    if-ne v5, v6, :cond_173

    iget-object v5, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    invoke-direct {p0, v5, v4}, Landroid/support/v4/widget/ad;->b(Landroid/view/View;I)Z

    move-result v4

    if-eqz v4, :cond_173

    .line 1164
    iget v0, p0, Landroid/support/v4/widget/ad;->c:I

    .line 1169
    :goto_169
    if-ne v0, v1, :cond_16e

    .line 1171
    invoke-direct {p0}, Landroid/support/v4/widget/ad;->i()V

    .line 1174
    :cond_16e
    invoke-direct {p0, v2}, Landroid/support/v4/widget/ad;->c(I)V

    goto/16 :goto_22

    .line 1153
    :cond_173
    add-int/lit8 v0, v0, 0x1

    goto :goto_143

    .line 1179
    :pswitch_176
    iget v0, p0, Landroid/support/v4/widget/ad;->a:I

    if-ne v0, v7, :cond_17d

    .line 1180
    invoke-direct {p0}, Landroid/support/v4/widget/ad;->i()V

    .line 1182
    :cond_17d
    invoke-virtual {p0}, Landroid/support/v4/widget/ad;->e()V

    goto/16 :goto_22

    .line 1187
    :pswitch_182
    iget v0, p0, Landroid/support/v4/widget/ad;->a:I

    if-ne v0, v7, :cond_18a

    .line 1188
    const/4 v0, 0x0

    invoke-direct {p0, v0}, Landroid/support/v4/widget/ad;->b(F)V

    .line 1190
    :cond_18a
    invoke-virtual {p0}, Landroid/support/v4/widget/ad;->e()V

    goto/16 :goto_22

    :cond_18f
    move v0, v1

    goto :goto_169

    .line 1060
    nop

    :pswitch_data_192
    .packed-switch 0x0
        :pswitch_23
        :pswitch_176
        :pswitch_89
        :pswitch_182
        :pswitch_22
        :pswitch_4c
        :pswitch_133
    .end packed-switch
.end method

.method public final c()Landroid/view/View;
    .registers 2

    .prologue
    .line 475
    iget-object v0, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    return-object v0
.end method

.method public final d()I
    .registers 2

    .prologue
    .line 490
    iget v0, p0, Landroid/support/v4/widget/ad;->b:I

    return v0
.end method

.method public final e()V
    .registers 4

    .prologue
    const/4 v2, 0x0

    const/4 v1, 0x0

    .line 498
    const/4 v0, -0x1

    iput v0, p0, Landroid/support/v4/widget/ad;->c:I

    .line 499
    iget-object v0, p0, Landroid/support/v4/widget/ad;->d:[F

    if-eqz v0, :cond_2e

    iget-object v0, p0, Landroid/support/v4/widget/ad;->d:[F

    invoke-static {v0, v1}, Ljava/util/Arrays;->fill([FF)V

    iget-object v0, p0, Landroid/support/v4/widget/ad;->e:[F

    invoke-static {v0, v1}, Ljava/util/Arrays;->fill([FF)V

    iget-object v0, p0, Landroid/support/v4/widget/ad;->f:[F

    invoke-static {v0, v1}, Ljava/util/Arrays;->fill([FF)V

    iget-object v0, p0, Landroid/support/v4/widget/ad;->g:[F

    invoke-static {v0, v1}, Ljava/util/Arrays;->fill([FF)V

    iget-object v0, p0, Landroid/support/v4/widget/ad;->h:[I

    invoke-static {v0, v2}, Ljava/util/Arrays;->fill([II)V

    iget-object v0, p0, Landroid/support/v4/widget/ad;->i:[I

    invoke-static {v0, v2}, Ljava/util/Arrays;->fill([II)V

    iget-object v0, p0, Landroid/support/v4/widget/ad;->j:[I

    invoke-static {v0, v2}, Ljava/util/Arrays;->fill([II)V

    iput v2, p0, Landroid/support/v4/widget/ad;->k:I

    .line 501
    :cond_2e
    iget-object v0, p0, Landroid/support/v4/widget/ad;->l:Landroid/view/VelocityTracker;

    if-eqz v0, :cond_3a

    .line 502
    iget-object v0, p0, Landroid/support/v4/widget/ad;->l:Landroid/view/VelocityTracker;

    invoke-virtual {v0}, Landroid/view/VelocityTracker;->recycle()V

    .line 503
    const/4 v0, 0x0

    iput-object v0, p0, Landroid/support/v4/widget/ad;->l:Landroid/view/VelocityTracker;

    .line 505
    :cond_3a
    return-void
.end method

.method public final f()V
    .registers 4

    .prologue
    .line 512
    invoke-virtual {p0}, Landroid/support/v4/widget/ad;->e()V

    .line 513
    iget v0, p0, Landroid/support/v4/widget/ad;->a:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_29

    .line 514
    iget-object v0, p0, Landroid/support/v4/widget/ad;->q:Landroid/support/v4/widget/n;

    invoke-virtual {v0}, Landroid/support/v4/widget/n;->a()I

    .line 515
    iget-object v0, p0, Landroid/support/v4/widget/ad;->q:Landroid/support/v4/widget/n;

    invoke-virtual {v0}, Landroid/support/v4/widget/n;->b()I

    .line 516
    iget-object v0, p0, Landroid/support/v4/widget/ad;->q:Landroid/support/v4/widget/n;

    invoke-virtual {v0}, Landroid/support/v4/widget/n;->c()V

    .line 517
    iget-object v0, p0, Landroid/support/v4/widget/ad;->q:Landroid/support/v4/widget/n;

    invoke-virtual {v0}, Landroid/support/v4/widget/n;->a()I

    move-result v0

    .line 518
    iget-object v1, p0, Landroid/support/v4/widget/ad;->q:Landroid/support/v4/widget/n;

    invoke-virtual {v1}, Landroid/support/v4/widget/n;->b()I

    .line 519
    iget-object v1, p0, Landroid/support/v4/widget/ad;->r:Landroid/support/v4/widget/ae;

    iget-object v2, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    invoke-virtual {v1, v2, v0}, Landroid/support/v4/widget/ae;->a(Landroid/view/View;I)V

    .line 521
    :cond_29
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/support/v4/widget/ad;->b(I)V

    .line 522
    return-void
.end method

.method public final g()Z
    .registers 8

    .prologue
    const/4 v6, 0x2

    .line 715
    iget v0, p0, Landroid/support/v4/widget/ad;->a:I

    if-ne v0, v6, :cond_76

    .line 716
    iget-object v0, p0, Landroid/support/v4/widget/ad;->q:Landroid/support/v4/widget/n;

    sget-object v1, Landroid/support/v4/widget/n;->b:Landroid/support/v4/widget/o;

    iget-object v0, v0, Landroid/support/v4/widget/n;->a:Ljava/lang/Object;

    invoke-interface {v1, v0}, Landroid/support/v4/widget/o;->d(Ljava/lang/Object;)Z

    move-result v0

    .line 717
    iget-object v1, p0, Landroid/support/v4/widget/ad;->q:Landroid/support/v4/widget/n;

    invoke-virtual {v1}, Landroid/support/v4/widget/n;->a()I

    move-result v1

    .line 718
    iget-object v2, p0, Landroid/support/v4/widget/ad;->q:Landroid/support/v4/widget/n;

    invoke-virtual {v2}, Landroid/support/v4/widget/n;->b()I

    move-result v2

    .line 719
    iget-object v3, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    invoke-virtual {v3}, Landroid/view/View;->getLeft()I

    move-result v3

    sub-int v3, v1, v3

    .line 720
    iget-object v4, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    invoke-virtual {v4}, Landroid/view/View;->getTop()I

    move-result v4

    sub-int v4, v2, v4

    .line 722
    if-eqz v3, :cond_32

    .line 723
    iget-object v5, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    invoke-virtual {v5, v3}, Landroid/view/View;->offsetLeftAndRight(I)V

    .line 725
    :cond_32
    if-eqz v4, :cond_39

    .line 726
    iget-object v5, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    invoke-virtual {v5, v4}, Landroid/view/View;->offsetTopAndBottom(I)V

    .line 729
    :cond_39
    if-nez v3, :cond_3d

    if-eqz v4, :cond_44

    .line 730
    :cond_3d
    iget-object v3, p0, Landroid/support/v4/widget/ad;->r:Landroid/support/v4/widget/ae;

    iget-object v4, p0, Landroid/support/v4/widget/ad;->s:Landroid/view/View;

    invoke-virtual {v3, v4, v1}, Landroid/support/v4/widget/ae;->a(Landroid/view/View;I)V

    .line 733
    :cond_44
    if-eqz v0, :cond_6d

    iget-object v3, p0, Landroid/support/v4/widget/ad;->q:Landroid/support/v4/widget/n;

    sget-object v4, Landroid/support/v4/widget/n;->b:Landroid/support/v4/widget/o;

    iget-object v3, v3, Landroid/support/v4/widget/n;->a:Ljava/lang/Object;

    invoke-interface {v4, v3}, Landroid/support/v4/widget/o;->f(Ljava/lang/Object;)I

    move-result v3

    if-ne v1, v3, :cond_6d

    iget-object v1, p0, Landroid/support/v4/widget/ad;->q:Landroid/support/v4/widget/n;

    sget-object v3, Landroid/support/v4/widget/n;->b:Landroid/support/v4/widget/o;

    iget-object v1, v1, Landroid/support/v4/widget/n;->a:Ljava/lang/Object;

    invoke-interface {v3, v1}, Landroid/support/v4/widget/o;->g(Ljava/lang/Object;)I

    move-result v1

    if-ne v2, v1, :cond_6d

    .line 736
    iget-object v0, p0, Landroid/support/v4/widget/ad;->q:Landroid/support/v4/widget/n;

    invoke-virtual {v0}, Landroid/support/v4/widget/n;->c()V

    .line 737
    iget-object v0, p0, Landroid/support/v4/widget/ad;->q:Landroid/support/v4/widget/n;

    sget-object v1, Landroid/support/v4/widget/n;->b:Landroid/support/v4/widget/o;

    iget-object v0, v0, Landroid/support/v4/widget/n;->a:Ljava/lang/Object;

    invoke-interface {v1, v0}, Landroid/support/v4/widget/o;->a(Ljava/lang/Object;)Z

    move-result v0

    .line 740
    :cond_6d
    if-nez v0, :cond_76

    .line 741
    iget-object v0, p0, Landroid/support/v4/widget/ad;->u:Landroid/view/ViewGroup;

    iget-object v1, p0, Landroid/support/v4/widget/ad;->w:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->post(Ljava/lang/Runnable;)Z

    .line 744
    :cond_76
    iget v0, p0, Landroid/support/v4/widget/ad;->a:I

    if-ne v0, v6, :cond_7c

    const/4 v0, 0x1

    :goto_7b
    return v0

    :cond_7c
    const/4 v0, 0x0

    goto :goto_7b
.end method

.method public final h()Z
    .registers 8

    .prologue
    const/4 v0, 0x1

    const/4 v1, 0x0

    .line 1276
    iget-object v2, p0, Landroid/support/v4/widget/ad;->d:[F

    array-length v4, v2

    move v3, v1

    .line 1277
    :goto_6
    if-ge v3, v4, :cond_3f

    .line 1278
    iget v2, p0, Landroid/support/v4/widget/ad;->k:I

    shl-int v5, v0, v3

    and-int/2addr v2, v5

    if-eqz v2, :cond_35

    move v2, v0

    :goto_10
    if-eqz v2, :cond_39

    iget-object v2, p0, Landroid/support/v4/widget/ad;->f:[F

    aget v2, v2, v3

    iget-object v5, p0, Landroid/support/v4/widget/ad;->d:[F

    aget v5, v5, v3

    sub-float/2addr v2, v5

    iget-object v5, p0, Landroid/support/v4/widget/ad;->g:[F

    aget v5, v5, v3

    iget-object v6, p0, Landroid/support/v4/widget/ad;->e:[F

    aget v6, v6, v3

    sub-float/2addr v5, v6

    mul-float/2addr v2, v2

    mul-float/2addr v5, v5

    add-float/2addr v2, v5

    iget v5, p0, Landroid/support/v4/widget/ad;->b:I

    iget v6, p0, Landroid/support/v4/widget/ad;->b:I

    mul-int/2addr v5, v6

    int-to-float v5, v5

    cmpl-float v2, v2, v5

    if-lez v2, :cond_37

    move v2, v0

    :goto_32
    if-eqz v2, :cond_3b

    .line 1282
    :goto_34
    return v0

    :cond_35
    move v2, v1

    .line 1278
    goto :goto_10

    :cond_37
    move v2, v1

    goto :goto_32

    :cond_39
    move v2, v1

    goto :goto_32

    .line 1277
    :cond_3b
    add-int/lit8 v2, v3, 0x1

    move v3, v2

    goto :goto_6

    :cond_3f
    move v0, v1

    .line 1282
    goto :goto_34
.end method

###### Class android.support.v4.widget.ad.AnonymousClass1 (android.support.v4.widget.ad$1)
.class final Landroid/support/v4/widget/ad$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/animation/Interpolator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/v4/widget/ad;
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 326
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final getInterpolation(F)F
    .registers 5

    .prologue
    const/high16 v2, 0x3f800000    # 1.0f

    .line 328
    sub-float v0, p1, v2

    .line 329
    mul-float v1, v0, v0

    mul-float/2addr v1, v0

    mul-float/2addr v1, v0

    mul-float/2addr v0, v1

    add-float/2addr v0, v2

    return v0
.end method

###### Class android.support.v4.widget.ad.AnonymousClass2 (android.support.v4.widget.ad$2)
.class final Landroid/support/v4/widget/ad$2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/v4/widget/ad;
.end annotation


# instance fields
.field final synthetic a:Landroid/support/v4/widget/ad;


# direct methods
.method constructor <init>(Landroid/support/v4/widget/ad;)V
    .registers 2

    .prologue
    .line 333
    iput-object p1, p0, Landroid/support/v4/widget/ad$2;->a:Landroid/support/v4/widget/ad;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 3

    .prologue
    .line 335
    iget-object v0, p0, Landroid/support/v4/widget/ad$2;->a:Landroid/support/v4/widget/ad;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/support/v4/widget/ad;->b(I)V

    .line 336
    return-void
.end method
