###### Class android.support.v4.widget.w (android.support.v4.widget.w)
.class interface abstract Landroid/support/v4/widget/w;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Landroid/support/v4/widget/SlidingPaneLayout;Landroid/view/View;)V
.end method
