###### Class android.support.v4.widget.j (android.support.v4.widget.j)
.class final Landroid/support/v4/widget/j;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/support/v4/widget/l;


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 58
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Landroid/content/Context;)Ljava/lang/Object;
    .registers 3

    .prologue
    .line 60
    const/4 v0, 0x0

    return-object v0
.end method

.method public final a(Ljava/lang/Object;II)V
    .registers 4

    .prologue
    .line 64
    return-void
.end method

.method public final a(Ljava/lang/Object;)Z
    .registers 3

    .prologue
    .line 67
    const/4 v0, 0x1

    return v0
.end method

.method public final a(Ljava/lang/Object;F)Z
    .registers 4

    .prologue
    .line 74
    const/4 v0, 0x0

    return v0
.end method

.method public final a(Ljava/lang/Object;Landroid/graphics/Canvas;)Z
    .registers 4

    .prologue
    .line 86
    const/4 v0, 0x0

    return v0
.end method

.method public final b(Ljava/lang/Object;)V
    .registers 2

    .prologue
    .line 71
    return-void
.end method

.method public final c(Ljava/lang/Object;)Z
    .registers 3

    .prologue
    .line 78
    const/4 v0, 0x0

    return v0
.end method
