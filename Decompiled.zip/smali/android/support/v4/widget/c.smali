###### Class android.support.v4.widget.c (android.support.v4.widget.c)
.class final Landroid/support/v4/widget/c;
.super Landroid/database/ContentObserver;
.source "SourceFile"


# instance fields
.field final synthetic a:Landroid/support/v4/widget/b;


# virtual methods
.method public final deliverSelfNotifications()Z
    .registers 2

    .prologue
    .line 460
    const/4 v0, 0x1

    return v0
.end method

.method public final onChange(Z)V
    .registers 3

    .prologue
    .line 465
    iget-object v0, p0, Landroid/support/v4/widget/c;->a:Landroid/support/v4/widget/b;

    invoke-virtual {v0}, Landroid/support/v4/widget/b;->b()V

    .line 466
    return-void
.end method
