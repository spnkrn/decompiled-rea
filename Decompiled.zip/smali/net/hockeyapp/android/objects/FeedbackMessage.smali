###### Class net.hockeyapp.android.objects.FeedbackMessage (net.hockeyapp.android.objects.FeedbackMessage)
.class public Lnet/hockeyapp/android/objects/FeedbackMessage;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = -0x79c0036a37b8b480L


# instance fields
.field private appId:Ljava/lang/String;

.field private cleanText:Ljava/lang/String;

.field private createdAt:Ljava/lang/String;

.field private id:I

.field private model:Ljava/lang/String;

.field private name:Ljava/lang/String;

.field private oem:Ljava/lang/String;

.field private osVersion:Ljava/lang/String;

.field private subject:Ljava/lang/String;

.field private text:Ljava/lang/String;

.field private token:Ljava/lang/String;

.field private userString:Ljava/lang/String;

.field private via:I


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .registers 2

    .prologue
    .line 36
    iget-object v0, p0, Lnet/hockeyapp/android/objects/FeedbackMessage;->text:Ljava/lang/String;

    return-object v0
.end method

.method public final a(I)V
    .registers 2

    .prologue
    .line 80
    iput p1, p0, Lnet/hockeyapp/android/objects/FeedbackMessage;->id:I

    .line 81
    return-void
.end method

.method public final a(Ljava/lang/String;)V
    .registers 2

    .prologue
    .line 32
    iput-object p1, p0, Lnet/hockeyapp/android/objects/FeedbackMessage;->subject:Ljava/lang/String;

    .line 33
    return-void
.end method

.method public final b()Ljava/lang/String;
    .registers 2

    .prologue
    .line 68
    iget-object v0, p0, Lnet/hockeyapp/android/objects/FeedbackMessage;->createdAt:Ljava/lang/String;

    return-object v0
.end method

.method public final b(I)V
    .registers 2

    .prologue
    .line 96
    iput p1, p0, Lnet/hockeyapp/android/objects/FeedbackMessage;->via:I

    .line 97
    return-void
.end method

.method public final b(Ljava/lang/String;)V
    .registers 2

    .prologue
    .line 40
    iput-object p1, p0, Lnet/hockeyapp/android/objects/FeedbackMessage;->text:Ljava/lang/String;

    .line 41
    return-void
.end method

.method public final c()Ljava/lang/String;
    .registers 2

    .prologue
    .line 116
    iget-object v0, p0, Lnet/hockeyapp/android/objects/FeedbackMessage;->name:Ljava/lang/String;

    return-object v0
.end method

.method public final c(Ljava/lang/String;)V
    .registers 2

    .prologue
    .line 48
    iput-object p1, p0, Lnet/hockeyapp/android/objects/FeedbackMessage;->oem:Ljava/lang/String;

    .line 49
    return-void
.end method

.method public final d(Ljava/lang/String;)V
    .registers 2

    .prologue
    .line 56
    iput-object p1, p0, Lnet/hockeyapp/android/objects/FeedbackMessage;->model:Ljava/lang/String;

    .line 57
    return-void
.end method

.method public final e(Ljava/lang/String;)V
    .registers 2

    .prologue
    .line 64
    iput-object p1, p0, Lnet/hockeyapp/android/objects/FeedbackMessage;->osVersion:Ljava/lang/String;

    .line 65
    return-void
.end method

.method public final f(Ljava/lang/String;)V
    .registers 2

    .prologue
    .line 72
    iput-object p1, p0, Lnet/hockeyapp/android/objects/FeedbackMessage;->createdAt:Ljava/lang/String;

    .line 73
    return-void
.end method

.method public final g(Ljava/lang/String;)V
    .registers 2

    .prologue
    .line 88
    iput-object p1, p0, Lnet/hockeyapp/android/objects/FeedbackMessage;->token:Ljava/lang/String;

    .line 89
    return-void
.end method

.method public final h(Ljava/lang/String;)V
    .registers 2

    .prologue
    .line 104
    iput-object p1, p0, Lnet/hockeyapp/android/objects/FeedbackMessage;->userString:Ljava/lang/String;

    .line 105
    return-void
.end method

.method public final i(Ljava/lang/String;)V
    .registers 2

    .prologue
    .line 112
    iput-object p1, p0, Lnet/hockeyapp/android/objects/FeedbackMessage;->cleanText:Ljava/lang/String;

    .line 113
    return-void
.end method

.method public final j(Ljava/lang/String;)V
    .registers 2

    .prologue
    .line 120
    iput-object p1, p0, Lnet/hockeyapp/android/objects/FeedbackMessage;->name:Ljava/lang/String;

    .line 121
    return-void
.end method

.method public final k(Ljava/lang/String;)V
    .registers 2

    .prologue
    .line 128
    iput-object p1, p0, Lnet/hockeyapp/android/objects/FeedbackMessage;->appId:Ljava/lang/String;

    .line 129
    return-void
.end method
