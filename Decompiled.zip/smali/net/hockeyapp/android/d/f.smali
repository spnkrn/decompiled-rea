###### Class net.hockeyapp.android.d.f (net.hockeyapp.android.d.f)
.class final Lnet/hockeyapp/android/d/f;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lnet/hockeyapp/android/d/e;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .prologue
    .line 27
    new-instance v0, Lnet/hockeyapp/android/d/e;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lnet/hockeyapp/android/d/e;-><init>(B)V

    sput-object v0, Lnet/hockeyapp/android/d/f;->a:Lnet/hockeyapp/android/d/e;

    return-void
.end method
