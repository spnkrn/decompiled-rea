###### Class net.hockeyapp.android.d.b (net.hockeyapp.android.d.b)
.class final Lnet/hockeyapp/android/d/b;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:Lnet/hockeyapp/android/d/a;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .prologue
    .line 49
    new-instance v0, Lnet/hockeyapp/android/d/a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lnet/hockeyapp/android/d/a;-><init>(B)V

    sput-object v0, Lnet/hockeyapp/android/d/b;->a:Lnet/hockeyapp/android/d/a;

    return-void
.end method
