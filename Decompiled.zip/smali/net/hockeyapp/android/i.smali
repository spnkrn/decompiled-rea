###### Class net.hockeyapp.android.i (net.hockeyapp.android.i)
.class public abstract Lnet/hockeyapp/android/i;
.super Lnet/hockeyapp/android/e;
.source "SourceFile"
