###### Class okio.f (okio.f)
.class public interface abstract Lokio/f;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Closeable;
