###### Class it.sephiroth.android.library.a.a.a (it.sephiroth.android.library.a.a.a)
.class public interface abstract Lit/sephiroth/android/library/a/a/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/ActionMode$Callback;


# annotations
.annotation build Landroid/annotation/TargetApi;
    value = 0xb
.end annotation


# virtual methods
.method public abstract a(Landroid/view/ActionMode;IJZ)V
.end method
