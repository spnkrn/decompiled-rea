###### Class it.sephiroth.android.library.widget.c (it.sephiroth.android.library.widget.c)
.class final Lit/sephiroth/android/library/widget/c;
.super Lit/sephiroth/android/library/widget/l;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lit/sephiroth/android/library/widget/AbsHListView;


# direct methods
.method private constructor <init>(Lit/sephiroth/android/library/widget/AbsHListView;)V
    .registers 3

    .prologue
    .line 2441
    iput-object p1, p0, Lit/sephiroth/android/library/widget/c;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Lit/sephiroth/android/library/widget/l;-><init>(Lit/sephiroth/android/library/widget/AbsHListView;B)V

    return-void
.end method

.method synthetic constructor <init>(Lit/sephiroth/android/library/widget/AbsHListView;B)V
    .registers 3

    .prologue
    .line 2441
    invoke-direct {p0, p1}, Lit/sephiroth/android/library/widget/c;-><init>(Lit/sephiroth/android/library/widget/AbsHListView;)V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 7

    .prologue
    const/4 v1, 0x0

    .line 2445
    iget-object v0, p0, Lit/sephiroth/android/library/widget/c;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget v0, v0, Lit/sephiroth/android/library/widget/AbsHListView;->A:I

    .line 2446
    iget-object v2, p0, Lit/sephiroth/android/library/widget/c;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget-object v3, p0, Lit/sephiroth/android/library/widget/c;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget v3, v3, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    sub-int/2addr v0, v3

    invoke-virtual {v2, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    .line 2447
    if-eqz v2, :cond_43

    .line 2448
    iget-object v0, p0, Lit/sephiroth/android/library/widget/c;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget v0, v0, Lit/sephiroth/android/library/widget/AbsHListView;->A:I

    .line 2449
    iget-object v3, p0, Lit/sephiroth/android/library/widget/c;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget-object v3, v3, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    iget-object v4, p0, Lit/sephiroth/android/library/widget/c;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget v4, v4, Lit/sephiroth/android/library/widget/AbsHListView;->A:I

    invoke-interface {v3, v4}, Landroid/widget/ListAdapter;->getItemId(I)J

    move-result-wide v3

    .line 2452
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/c;->b()Z

    move-result v5

    if-eqz v5, :cond_4a

    iget-object v5, p0, Lit/sephiroth/android/library/widget/c;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget-boolean v5, v5, Lit/sephiroth/android/library/widget/AbsHListView;->ai:Z

    if-nez v5, :cond_4a

    .line 2453
    iget-object v5, p0, Lit/sephiroth/android/library/widget/c;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v5, v2, v0, v3, v4}, Lit/sephiroth/android/library/widget/AbsHListView;->b(Landroid/view/View;IJ)Z

    move-result v0

    .line 2455
    :goto_34
    if-eqz v0, :cond_44

    .line 2456
    iget-object v0, p0, Lit/sephiroth/android/library/widget/c;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    const/4 v3, -0x1

    iput v3, v0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 2457
    iget-object v0, p0, Lit/sephiroth/android/library/widget/c;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->setPressed(Z)V

    .line 2458
    invoke-virtual {v2, v1}, Landroid/view/View;->setPressed(Z)V

    .line 2463
    :cond_43
    :goto_43
    return-void

    .line 2460
    :cond_44
    iget-object v0, p0, Lit/sephiroth/android/library/widget/c;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    const/4 v1, 0x2

    iput v1, v0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    goto :goto_43

    :cond_4a
    move v0, v1

    goto :goto_34
.end method
