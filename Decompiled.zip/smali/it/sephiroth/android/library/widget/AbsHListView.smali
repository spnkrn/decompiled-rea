###### Class it.sephiroth.android.library.widget.AbsHListView (it.sephiroth.android.library.widget.AbsHListView)
.class public abstract Lit/sephiroth/android/library/widget/AbsHListView;
.super Lit/sephiroth/android/library/widget/AdapterView;
.source "SourceFile"

# interfaces
.implements Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;
.implements Landroid/view/ViewTreeObserver$OnTouchModeChangeListener;


# annotations
.annotation build Landroid/annotation/TargetApi;
    value = 0xb
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lit/sephiroth/android/library/widget/AdapterView",
        "<",
        "Landroid/widget/ListAdapter;",
        ">;",
        "Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;",
        "Landroid/view/ViewTreeObserver$OnTouchModeChangeListener;"
    }
.end annotation


# static fields
.field static final T:Landroid/view/animation/Interpolator;

.field public static final U:[I


# instance fields
.field protected A:I

.field B:I

.field C:I

.field D:I

.field E:I

.field protected F:I

.field G:I

.field H:I

.field protected I:Lit/sephiroth/android/library/widget/i;

.field protected J:I

.field protected K:Z

.field L:Z

.field protected M:I

.field protected N:I

.field protected O:Ljava/lang/Runnable;

.field protected final P:[Z

.field Q:I

.field R:I

.field protected S:Z

.field a:Lit/sephiroth/android/library/a/b;

.field private aA:Lit/sephiroth/android/library/widget/c;

.field private aB:Ljava/lang/Runnable;

.field private aC:Lit/sephiroth/android/library/widget/b;

.field private aD:Lit/sephiroth/android/library/widget/h;

.field private aE:Ljava/lang/Runnable;

.field private aF:I

.field private aG:I

.field private aH:Z

.field private aI:I

.field private aJ:I

.field private aK:Ljava/lang/Runnable;

.field private aL:I

.field private aM:I

.field private aN:F

.field private aO:I

.field private aP:Lit/sephiroth/android/library/widget/s;

.field private aQ:Lit/sephiroth/android/library/widget/s;

.field private aR:I

.field private aS:I

.field private aT:I

.field private aU:Z

.field private aV:I

.field private aW:I

.field private aX:Lit/sephiroth/android/library/widget/f;

.field private aY:I

.field private aZ:I

.field private at:Landroid/view/VelocityTracker;

.field private au:Lit/sephiroth/android/library/widget/e;

.field private av:Lit/sephiroth/android/library/widget/g;

.field private aw:Z

.field private ax:Landroid/graphics/Rect;

.field private ay:Landroid/view/ContextMenu$ContextMenuInfo;

.field private az:I

.field protected b:I

.field private ba:I

.field private bb:Lit/sephiroth/android/library/widget/AbsHListView$SavedState;

.field private bc:F

.field public c:Ljava/lang/Object;

.field d:Ljava/lang/Object;

.field e:I

.field protected f:Landroid/util/SparseBooleanArray;

.field g:Landroid/support/v4/c/e;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/support/v4/c/e",
            "<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field protected h:I

.field protected i:Lit/sephiroth/android/library/widget/a;

.field protected j:Landroid/widget/ListAdapter;

.field k:Z

.field l:Z

.field m:Landroid/graphics/drawable/Drawable;

.field n:I

.field protected o:Landroid/graphics/Rect;

.field protected final p:Lit/sephiroth/android/library/widget/j;

.field q:I

.field r:I

.field s:I

.field t:I

.field protected u:Landroid/graphics/Rect;

.field protected v:I

.field w:Landroid/view/View;

.field x:Landroid/view/View;

.field protected y:Z

.field protected z:Z


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .prologue
    const/4 v1, 0x0

    .line 545
    new-instance v0, Landroid/view/animation/LinearInterpolator;

    invoke-direct {v0}, Landroid/view/animation/LinearInterpolator;-><init>()V

    sput-object v0, Lit/sephiroth/android/library/widget/AbsHListView;->T:Landroid/view/animation/Interpolator;

    .line 2211
    const/4 v0, 0x1

    new-array v0, v0, [I

    aput v1, v0, v1

    sput-object v0, Lit/sephiroth/android/library/widget/AbsHListView;->U:[I

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 7

    .prologue
    .line 626
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const-string v1, "sephiroth_absHListViewStyle"

    const-string v2, "attr"

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    invoke-direct {p0, p1, p2, v0}, Lit/sephiroth/android/library/widget/AbsHListView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 627
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 14

    .prologue
    .line 630
    invoke-direct {p0, p1, p2, p3}, Lit/sephiroth/android/library/widget/AdapterView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 166
    const/4 v0, 0x0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->b:I

    .line 200
    const/4 v0, 0x0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->h:I

    .line 220
    const/4 v0, 0x0

    iput-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->l:Z

    .line 230
    const/4 v0, -0x1

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->n:I

    .line 235
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->o:Landroid/graphics/Rect;

    .line 240
    new-instance v0, Lit/sephiroth/android/library/widget/j;

    invoke-direct {v0, p0}, Lit/sephiroth/android/library/widget/j;-><init>(Lit/sephiroth/android/library/widget/AbsHListView;)V

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->p:Lit/sephiroth/android/library/widget/j;

    .line 245
    const/4 v0, 0x0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->q:I

    .line 250
    const/4 v0, 0x0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->r:I

    .line 255
    const/4 v0, 0x0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->s:I

    .line 260
    const/4 v0, 0x0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->t:I

    .line 265
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->u:Landroid/graphics/Rect;

    .line 270
    const/4 v0, 0x0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->v:I

    .line 316
    const/4 v0, -0x1

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 347
    const/4 v0, 0x0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->J:I

    .line 372
    const/4 v0, 0x1

    iput-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aw:Z

    .line 382
    const/4 v0, -0x1

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->M:I

    .line 384
    const/4 v0, 0x0

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ay:Landroid/view/ContextMenu$ContextMenuInfo;

    .line 409
    const/4 v0, -0x1

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->az:I

    .line 454
    const/4 v0, 0x0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aI:I

    .line 462
    const/high16 v0, 0x3f800000    # 1.0f

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aN:F

    .line 464
    const/4 v0, 0x1

    new-array v0, v0, [Z

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->P:[Z

    .line 469
    const/4 v0, -0x1

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aO:I

    .line 514
    const/4 v0, 0x0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aT:I

    .line 631
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->setClickable(Z)V

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->setFocusableInTouchMode(Z)V

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->setWillNotDraw(Z)V

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->setAlwaysDrawnWithCacheEnabled(Z)V

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->b(Z)V

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result v1

    iput v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aJ:I

    invoke-virtual {v0}, Landroid/view/ViewConfiguration;->getScaledMinimumFlingVelocity()I

    move-result v1

    iput v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aL:I

    invoke-virtual {v0}, Landroid/view/ViewConfiguration;->getScaledMaximumFlingVelocity()I

    move-result v1

    iput v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aM:I

    invoke-virtual {v0}, Landroid/view/ViewConfiguration;->getScaledOverscrollDistance()I

    move-result v1

    iput v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->Q:I

    invoke-virtual {v0}, Landroid/view/ViewConfiguration;->getScaledOverflingDistance()I

    move-result v0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->R:I

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x10

    if-lt v0, v1, :cond_166

    new-instance v0, Lit/sephiroth/android/library/a/c/a;

    invoke-direct {v0, p0}, Lit/sephiroth/android/library/a/c/a;-><init>(Landroid/view/View;)V

    :goto_9c
    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->a:Lit/sephiroth/android/library/a/b;

    .line 633
    const/4 v1, 0x0

    .line 635
    const-string v0, "AbsHListView"

    invoke-static {p1, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [I

    .line 637
    if-eqz v0, :cond_178

    .line 638
    const/4 v1, 0x0

    invoke-virtual {p1, p2, v0, p3, v1}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object v0

    move-object v8, v0

    .line 641
    :goto_af
    const/4 v7, 0x0

    .line 642
    const/4 v6, 0x0

    .line 643
    const/4 v5, 0x0

    .line 644
    const/4 v4, 0x1

    .line 645
    const/4 v3, 0x0

    .line 646
    const/4 v2, 0x0

    .line 647
    const/4 v1, 0x1

    .line 648
    const/4 v0, 0x0

    .line 650
    if-eqz v8, :cond_eb

    .line 677
    const/4 v0, 0x0

    invoke-virtual {v8, v0}, Landroid/content/res/TypedArray;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v7

    .line 678
    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {v8, v0, v1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v6

    .line 679
    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {v8, v0, v1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v5

    .line 680
    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {v8, v0, v1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v4

    .line 681
    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {v8, v0, v1}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v3

    .line 682
    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {v8, v0, v1}, Landroid/content/res/TypedArray;->getColor(II)I

    move-result v2

    .line 683
    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {v8, v0, v1}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v1

    .line 684
    const/4 v0, 0x4

    const/4 v9, 0x0

    invoke-virtual {v8, v0, v9}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v0

    .line 685
    invoke-virtual {v8}, Landroid/content/res/TypedArray;->recycle()V

    .line 689
    :cond_eb
    if-eqz v7, :cond_f0

    .line 690
    invoke-direct {p0, v7}, Lit/sephiroth/android/library/widget/AbsHListView;->a(Landroid/graphics/drawable/Drawable;)V

    .line 693
    :cond_f0
    iput-boolean v6, p0, Lit/sephiroth/android/library/widget/AbsHListView;->l:Z

    .line 694
    iget-boolean v6, p0, Lit/sephiroth/android/library/widget/AbsHListView;->K:Z

    if-eq v6, v5, :cond_107

    iput-boolean v5, p0, Lit/sephiroth/android/library/widget/AbsHListView;->K:Z

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v5

    if-lez v5, :cond_107

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->d()V

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->requestLayout()V

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->invalidate()V

    .line 695
    :cond_107
    invoke-direct {p0, v4}, Lit/sephiroth/android/library/widget/AbsHListView;->b(Z)V

    .line 696
    iput v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aF:I

    .line 697
    invoke-virtual {p0, v2}, Lit/sephiroth/android/library/widget/AbsHListView;->e(I)V

    .line 698
    iput-boolean v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aw:Z

    .line 699
    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->b:I

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0xb

    if-lt v0, v1, :cond_12d

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->c:Ljava/lang/Object;

    if-eqz v0, :cond_12d

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0xb

    if-lt v0, v1, :cond_12a

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->c:Ljava/lang/Object;

    check-cast v0, Landroid/view/ActionMode;

    invoke-virtual {v0}, Landroid/view/ActionMode;->finish()V

    :cond_12a
    const/4 v0, 0x0

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->c:Ljava/lang/Object;

    :cond_12d
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->b:I

    if-eqz v0, :cond_165

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->f:Landroid/util/SparseBooleanArray;

    if-nez v0, :cond_13c

    new-instance v0, Landroid/util/SparseBooleanArray;

    invoke-direct {v0}, Landroid/util/SparseBooleanArray;-><init>()V

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->f:Landroid/util/SparseBooleanArray;

    :cond_13c
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    if-nez v0, :cond_153

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    if-eqz v0, :cond_153

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    invoke-interface {v0}, Landroid/widget/ListAdapter;->hasStableIds()Z

    move-result v0

    if-eqz v0, :cond_153

    new-instance v0, Landroid/support/v4/c/e;

    invoke-direct {v0}, Landroid/support/v4/c/e;-><init>()V

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    :cond_153
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0xb

    if-lt v0, v1, :cond_165

    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->b:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_165

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->b()V

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->setLongClickable(Z)V

    .line 700
    :cond_165
    return-void

    .line 631
    :cond_166
    const/16 v1, 0xe

    if-lt v0, v1, :cond_171

    new-instance v0, Lit/sephiroth/android/library/a/b/a;

    invoke-direct {v0, p0}, Lit/sephiroth/android/library/a/b/a;-><init>(Landroid/view/View;)V

    goto/16 :goto_9c

    :cond_171
    new-instance v0, Lit/sephiroth/android/library/a/c;

    invoke-direct {v0, p0}, Lit/sephiroth/android/library/a/c;-><init>(Landroid/view/View;)V

    goto/16 :goto_9c

    :cond_178
    move-object v8, v1

    goto/16 :goto_af
.end method

.method private A()Z
    .registers 6

    .prologue
    const/4 v0, 0x1

    const/4 v1, 0x0

    .line 1087
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v2

    .line 1088
    if-nez v2, :cond_9

    .line 1091
    :cond_8
    :goto_8
    return v0

    .line 1089
    :cond_9
    iget v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    if-eq v2, v3, :cond_f

    move v0, v1

    goto :goto_8

    .line 1091
    :cond_f
    invoke-virtual {p0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/View;->getLeft()I

    move-result v3

    iget-object v4, p0, Lit/sephiroth/android/library/widget/AbsHListView;->u:Landroid/graphics/Rect;

    iget v4, v4, Landroid/graphics/Rect;->left:I

    if-lt v3, v4, :cond_32

    add-int/lit8 v2, v2, -0x1

    invoke-virtual {p0, v2}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/View;->getRight()I

    move-result v2

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v3

    iget-object v4, p0, Lit/sephiroth/android/library/widget/AbsHListView;->u:Landroid/graphics/Rect;

    iget v4, v4, Landroid/graphics/Rect;->right:I

    sub-int/2addr v3, v4

    if-le v2, v3, :cond_8

    :cond_32
    move v0, v1

    goto :goto_8
.end method

.method private B()Z
    .registers 2

    .prologue
    .line 2089
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    packed-switch v0, :pswitch_data_a

    .line 2094
    const/4 v0, 0x0

    :goto_6
    return v0

    .line 2092
    :pswitch_7
    const/4 v0, 0x1

    goto :goto_6

    .line 2089
    nop

    :pswitch_data_a
    .packed-switch 0x1
        :pswitch_7
        :pswitch_7
    .end packed-switch
.end method

.method private C()V
    .registers 3

    .prologue
    .line 2214
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->m:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_13

    .line 2215
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->h()Z

    move-result v0

    if-eqz v0, :cond_14

    .line 2216
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->m:Landroid/graphics/drawable/Drawable;

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getDrawableState()[I

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    .line 2221
    :cond_13
    :goto_13
    return-void

    .line 2218
    :cond_14
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->m:Landroid/graphics/drawable/Drawable;

    sget-object v1, Lit/sephiroth/android/library/widget/AbsHListView;->U:[I

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setState([I)Z

    goto :goto_13
.end method

.method private D()V
    .registers 2
    .annotation build Landroid/annotation/TargetApi;
        value = 0xb
    .end annotation

    .prologue
    .line 2883
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->a:Lit/sephiroth/android/library/a/b;

    invoke-virtual {v0}, Lit/sephiroth/android/library/a/b;->a()Z

    move-result v0

    if-eqz v0, :cond_19

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    instance-of v0, v0, Landroid/view/View;

    if-eqz v0, :cond_19

    .line 2884
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-virtual {v0}, Landroid/view/View;->invalidate()V

    .line 2886
    :cond_19
    return-void
.end method

.method private E()V
    .registers 2

    .prologue
    .line 3435
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->at:Landroid/view/VelocityTracker;

    if-nez v0, :cond_a

    .line 3436
    invoke-static {}, Landroid/view/VelocityTracker;->obtain()Landroid/view/VelocityTracker;

    move-result-object v0

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->at:Landroid/view/VelocityTracker;

    .line 3438
    :cond_a
    return-void
.end method

.method private F()V
    .registers 2

    .prologue
    .line 3441
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->at:Landroid/view/VelocityTracker;

    if-eqz v0, :cond_c

    .line 3442
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->at:Landroid/view/VelocityTracker;

    invoke-virtual {v0}, Landroid/view/VelocityTracker;->recycle()V

    .line 3443
    const/4 v0, 0x0

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->at:Landroid/view/VelocityTracker;

    .line 3445
    :cond_c
    return-void
.end method

.method private G()V
    .registers 3

    .prologue
    const/4 v1, 0x1

    .line 4443
    iget-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->L:Z

    if-eqz v0, :cond_1b

    iget-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->y:Z

    if-nez v0, :cond_1b

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->a:Lit/sephiroth/android/library/a/b;

    invoke-virtual {v0}, Lit/sephiroth/android/library/a/b;->a()Z

    move-result v0

    if-nez v0, :cond_1b

    .line 4444
    invoke-virtual {p0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->setChildrenDrawnWithCacheEnabled(Z)V

    .line 4445
    invoke-virtual {p0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->setChildrenDrawingCacheEnabled(Z)V

    .line 4446
    iput-boolean v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->z:Z

    iput-boolean v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->y:Z

    .line 4448
    :cond_1b
    return-void
.end method

.method private H()V
    .registers 2

    .prologue
    .line 4451
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->a:Lit/sephiroth/android/library/a/b;

    invoke-virtual {v0}, Lit/sephiroth/android/library/a/b;->a()Z

    move-result v0

    if-nez v0, :cond_18

    .line 4452
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aK:Ljava/lang/Runnable;

    if-nez v0, :cond_13

    .line 4453
    new-instance v0, Lit/sephiroth/android/library/widget/AbsHListView$2;

    invoke-direct {v0, p0}, Lit/sephiroth/android/library/widget/AbsHListView$2;-><init>(Lit/sephiroth/android/library/widget/AbsHListView;)V

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aK:Ljava/lang/Runnable;

    .line 4470
    :cond_13
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aK:Ljava/lang/Runnable;

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->post(Ljava/lang/Runnable;)Z

    .line 4472
    :cond_18
    return-void
.end method

.method private I()Z
    .registers 15

    .prologue
    const/4 v1, 0x1

    const/4 v6, -0x1

    const/4 v2, 0x0

    .line 4775
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v9

    .line 4777
    if-gtz v9, :cond_a

    .line 4872
    :cond_9
    :goto_9
    return v2

    .line 4783
    :cond_a
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->u:Landroid/graphics/Rect;

    iget v5, v0, Landroid/graphics/Rect;->left:I

    .line 4784
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getRight()I

    move-result v0

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getLeft()I

    move-result v3

    sub-int/2addr v0, v3

    iget-object v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->u:Landroid/graphics/Rect;

    iget v3, v3, Landroid/graphics/Rect;->right:I

    sub-int v7, v0, v3

    .line 4785
    iget v4, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    .line 4786
    iget v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->M:I

    .line 4789
    if-lt v3, v4, :cond_86

    add-int v0, v4, v9

    if-ge v3, v0, :cond_86

    .line 4792
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    sub-int v0, v3, v0

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v8

    .line 4793
    invoke-virtual {v8}, Landroid/view/View;->getLeft()I

    move-result v0

    .line 4794
    invoke-virtual {v8}, Landroid/view/View;->getRight()I

    move-result v9

    .line 4797
    if-ge v0, v5, :cond_76

    .line 4798
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getHorizontalFadingEdgeLength()I

    move-result v0

    add-int/2addr v0, v5

    move v5, v0

    move v0, v1

    .line 4853
    :goto_40
    iput v6, p0, Lit/sephiroth/android/library/widget/AbsHListView;->M:I

    .line 4854
    iget-object v7, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    invoke-virtual {p0, v7}, Lit/sephiroth/android/library/widget/AbsHListView;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 4855
    iget-object v7, p0, Lit/sephiroth/android/library/widget/AbsHListView;->I:Lit/sephiroth/android/library/widget/i;

    if-eqz v7, :cond_50

    .line 4856
    iget-object v7, p0, Lit/sephiroth/android/library/widget/AbsHListView;->I:Lit/sephiroth/android/library/widget/i;

    invoke-virtual {v7}, Lit/sephiroth/android/library/widget/i;->a()V

    .line 4858
    :cond_50
    iput v6, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 4859
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->H()V

    .line 4860
    iput v5, p0, Lit/sephiroth/android/library/widget/AbsHListView;->W:I

    .line 4861
    invoke-virtual {p0, v3, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->a(IZ)I

    move-result v0

    .line 4862
    if-lt v0, v4, :cond_ec

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->v()I

    move-result v3

    if-gt v0, v3, :cond_ec

    .line 4863
    const/4 v3, 0x4

    iput v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->h:I

    .line 4864
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->C()V

    .line 4865
    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->d(I)V

    .line 4866
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->c()V

    .line 4870
    :goto_6f
    invoke-virtual {p0, v2}, Lit/sephiroth/android/library/widget/AbsHListView;->a(I)V

    .line 4872
    if-ltz v0, :cond_9

    move v2, v1

    goto :goto_9

    .line 4799
    :cond_76
    if-le v9, v7, :cond_83

    .line 4800
    invoke-virtual {v8}, Landroid/view/View;->getMeasuredWidth()I

    move-result v0

    sub-int v0, v7, v0

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getHorizontalFadingEdgeLength()I

    move-result v5

    sub-int/2addr v0, v5

    :cond_83
    move v5, v0

    move v0, v1

    .line 4802
    goto :goto_40

    .line 4803
    :cond_86
    if-ge v3, v4, :cond_b3

    move v7, v2

    move v0, v2

    .line 4806
    :goto_8a
    if-ge v7, v9, :cond_af

    .line 4807
    invoke-virtual {p0, v7}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    .line 4808
    invoke-virtual {v3}, Landroid/view/View;->getLeft()I

    move-result v3

    .line 4810
    if-nez v7, :cond_fc

    .line 4814
    if-gtz v4, :cond_9a

    if-ge v3, v5, :cond_f9

    .line 4817
    :cond_9a
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getHorizontalFadingEdgeLength()I

    move-result v0

    add-int/2addr v0, v5

    move v5, v3

    .line 4820
    :goto_a0
    if-lt v3, v0, :cond_a8

    .line 4822
    add-int v0, v4, v7

    move v5, v3

    move v3, v0

    move v0, v1

    .line 4824
    goto :goto_40

    .line 4806
    :cond_a8
    add-int/lit8 v3, v7, 0x1

    move v7, v3

    move v13, v0

    move v0, v5

    move v5, v13

    goto :goto_8a

    :cond_af
    move v3, v4

    move v5, v0

    move v0, v1

    goto :goto_40

    .line 4828
    :cond_b3
    iget v10, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    .line 4830
    add-int v0, v4, v9

    add-int/lit8 v0, v0, -0x1

    .line 4832
    add-int/lit8 v3, v9, -0x1

    move v8, v3

    move v5, v2

    :goto_bd
    if-ltz v8, :cond_f5

    .line 4833
    invoke-virtual {p0, v8}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v11

    .line 4834
    invoke-virtual {v11}, Landroid/view/View;->getLeft()I

    move-result v3

    .line 4835
    invoke-virtual {v11}, Landroid/view/View;->getRight()I

    move-result v11

    .line 4837
    add-int/lit8 v12, v9, -0x1

    if-ne v8, v12, :cond_f1

    .line 4839
    add-int v5, v4, v9

    if-lt v5, v10, :cond_d5

    if-le v11, v7, :cond_ee

    .line 4840
    :cond_d5
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getHorizontalFadingEdgeLength()I

    move-result v5

    sub-int v5, v7, v5

    move v7, v3

    .line 4844
    :goto_dc
    if-gt v11, v5, :cond_e5

    .line 4845
    add-int v0, v4, v8

    move v5, v3

    move v3, v0

    move v0, v2

    .line 4847
    goto/16 :goto_40

    .line 4832
    :cond_e5
    add-int/lit8 v3, v8, -0x1

    move v8, v3

    move v13, v5

    move v5, v7

    move v7, v13

    goto :goto_bd

    :cond_ec
    move v0, v6

    .line 4868
    goto :goto_6f

    :cond_ee
    move v5, v7

    move v7, v3

    goto :goto_dc

    :cond_f1
    move v13, v7

    move v7, v5

    move v5, v13

    goto :goto_dc

    :cond_f5
    move v3, v0

    move v0, v2

    goto/16 :goto_40

    :cond_f9
    move v0, v5

    move v5, v3

    goto :goto_a0

    :cond_fc
    move v13, v5

    move v5, v0

    move v0, v13

    goto :goto_a0
.end method

.method private J()V
    .registers 2

    .prologue
    .line 5258
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aP:Lit/sephiroth/android/library/widget/s;

    if-eqz v0, :cond_e

    .line 5259
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aP:Lit/sephiroth/android/library/widget/s;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/s;->b()V

    .line 5260
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aQ:Lit/sephiroth/android/library/widget/s;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/s;->b()V

    .line 5262
    :cond_e
    return-void
.end method

.method static synthetic a(Lit/sephiroth/android/library/widget/AbsHListView;)I
    .registers 2

    .prologue
    .line 60
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWindowAttachCount()I

    move-result v0

    return v0
.end method

.method static a(Ljava/util/ArrayList;I)Landroid/view/View;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList",
            "<",
            "Landroid/view/View;",
            ">;I)",
            "Landroid/view/View;"
        }
    .end annotation

    .prologue
    .line 5764
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v3

    .line 5765
    if-lez v3, :cond_2b

    .line 5767
    const/4 v0, 0x0

    move v2, v0

    :goto_8
    if-ge v2, v3, :cond_22

    .line 5768
    invoke-virtual {p0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    .line 5769
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    check-cast v1, Lit/sephiroth/android/library/widget/AbsHListView$LayoutParams;

    iget v1, v1, Lit/sephiroth/android/library/widget/AbsHListView$LayoutParams;->d:I

    if-ne v1, p1, :cond_1e

    .line 5770
    invoke-virtual {p0, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 5776
    :goto_1d
    return-object v0

    .line 5767
    :cond_1e
    add-int/lit8 v0, v2, 0x1

    move v2, v0

    goto :goto_8

    .line 5774
    :cond_22
    add-int/lit8 v0, v3, -0x1

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    goto :goto_1d

    .line 5776
    :cond_2b
    const/4 v0, 0x0

    goto :goto_1d
.end method

.method static synthetic a(Lit/sephiroth/android/library/widget/AbsHListView;Lit/sephiroth/android/library/widget/c;)Lit/sephiroth/android/library/widget/c;
    .registers 2

    .prologue
    .line 60
    iput-object p1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aA:Lit/sephiroth/android/library/widget/c;

    return-object p1
.end method

.method public static final a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/Object;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            ")TT;"
        }
    .end annotation

    .prologue
    const/4 v0, 0x0

    .line 5794
    :try_start_1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ".R$styleable"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/Class;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v1

    .line 5795
    if-eqz v1, :cond_27

    .line 5796
    const/4 v2, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_26
    .catch Ljava/lang/Throwable; {:try_start_1 .. :try_end_26} :catch_28

    move-result-object v0

    .line 5801
    :cond_27
    :goto_27
    return-object v0

    .line 5798
    :catch_28
    move-exception v1

    invoke-virtual {v1}, Ljava/lang/Throwable;->printStackTrace()V

    goto :goto_27
.end method

.method private a(Landroid/graphics/Canvas;)V
    .registers 4

    .prologue
    .line 2109
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->o:Landroid/graphics/Rect;

    invoke-virtual {v0}, Landroid/graphics/Rect;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_12

    .line 2110
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->m:Landroid/graphics/drawable/Drawable;

    .line 2111
    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->o:Landroid/graphics/Rect;

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setBounds(Landroid/graphics/Rect;)V

    .line 2112
    invoke-virtual {v0, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    .line 2114
    :cond_12
    return-void
.end method

.method private a(Landroid/graphics/drawable/Drawable;)V
    .registers 4

    .prologue
    .line 2141
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->m:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_f

    .line 2142
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->m:Landroid/graphics/drawable/Drawable;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    .line 2143
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->m:Landroid/graphics/drawable/Drawable;

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->unscheduleDrawable(Landroid/graphics/drawable/Drawable;)V

    .line 2145
    :cond_f
    iput-object p1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->m:Landroid/graphics/drawable/Drawable;

    .line 2146
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    .line 2147
    invoke-virtual {p1, v0}, Landroid/graphics/drawable/Drawable;->getPadding(Landroid/graphics/Rect;)Z

    .line 2148
    iget v1, v0, Landroid/graphics/Rect;->left:I

    iput v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->q:I

    .line 2149
    iget v1, v0, Landroid/graphics/Rect;->top:I

    iput v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->r:I

    .line 2150
    iget v1, v0, Landroid/graphics/Rect;->right:I

    iput v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->s:I

    .line 2151
    iget v0, v0, Landroid/graphics/Rect;->bottom:I

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->t:I

    .line 2152
    invoke-virtual {p1, p0}, Landroid/graphics/drawable/Drawable;->setCallback(Landroid/graphics/drawable/Drawable$Callback;)V

    .line 2153
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->C()V

    .line 2154
    return-void
.end method

.method private a(Landroid/view/MotionEvent;)V
    .registers 6

    .prologue
    const/4 v1, 0x0

    .line 3543
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const v2, 0xff00

    and-int/2addr v0, v2

    shr-int/lit8 v0, v0, 0x8

    .line 3545
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v2

    .line 3546
    iget v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aO:I

    if-ne v2, v3, :cond_2c

    .line 3550
    if-nez v0, :cond_2d

    const/4 v0, 0x1

    .line 3551
    :goto_16
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    move-result v2

    float-to-int v2, v2

    iput v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->D:I

    .line 3552
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    move-result v2

    float-to-int v2, v2

    iput v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->E:I

    .line 3553
    iput v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->H:I

    .line 3554
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aO:I

    .line 3556
    :cond_2c
    return-void

    :cond_2d
    move v0, v1

    .line 3550
    goto :goto_16
.end method

.method static synthetic a(Lit/sephiroth/android/library/widget/AbsHListView;Landroid/view/View;)V
    .registers 3

    .prologue
    .line 60
    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->removeDetachedView(Landroid/view/View;Z)V

    return-void
.end method

.method static synthetic a(Lit/sephiroth/android/library/widget/AbsHListView;III)Z
    .registers 14

    .prologue
    const/4 v2, 0x0

    .line 60
    move-object v0, p0

    move v1, p1

    move v3, p2

    move v4, v2

    move v5, v2

    move v6, v2

    move v7, p3

    move v8, v2

    move v9, v2

    invoke-virtual/range {v0 .. v9}, Lit/sephiroth/android/library/widget/AbsHListView;->overScrollBy(IIIIIIIIZ)Z

    move-result v0

    return v0
.end method

.method private b(II)I
    .registers 7

    .prologue
    .line 2608
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ax:Landroid/graphics/Rect;

    .line 2609
    if-nez v0, :cond_d

    .line 2610
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ax:Landroid/graphics/Rect;

    .line 2611
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ax:Landroid/graphics/Rect;

    .line 2614
    :cond_d
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v1

    .line 2615
    add-int/lit8 v1, v1, -0x1

    :goto_13
    if-ltz v1, :cond_2f

    .line 2616
    invoke-virtual {p0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    .line 2617
    invoke-virtual {v2}, Landroid/view/View;->getVisibility()I

    move-result v3

    if-nez v3, :cond_2c

    .line 2618
    invoke-virtual {v2, v0}, Landroid/view/View;->getHitRect(Landroid/graphics/Rect;)V

    .line 2619
    invoke-virtual {v0, p1, p2}, Landroid/graphics/Rect;->contains(II)Z

    move-result v2

    if-eqz v2, :cond_2c

    .line 2620
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    add-int/2addr v0, v1

    .line 2624
    :goto_2b
    return v0

    .line 2615
    :cond_2c
    add-int/lit8 v1, v1, -0x1

    goto :goto_13

    .line 2624
    :cond_2f
    const/4 v0, -0x1

    goto :goto_2b
.end method

.method static synthetic b(Lit/sephiroth/android/library/widget/AbsHListView;)I
    .registers 2

    .prologue
    .line 60
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWindowAttachCount()I

    move-result v0

    return v0
.end method

.method static synthetic b(Lit/sephiroth/android/library/widget/AbsHListView;Landroid/view/View;)V
    .registers 3

    .prologue
    .line 60
    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->removeDetachedView(Landroid/view/View;Z)V

    return-void
.end method

.method private b(Z)V
    .registers 3

    .prologue
    .line 1249
    iget-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->L:Z

    if-eqz v0, :cond_9

    if-nez p1, :cond_9

    .line 1250
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->H()V

    .line 1252
    :cond_9
    iput-boolean p1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->L:Z

    .line 1253
    return-void
.end method

.method static synthetic b(Lit/sephiroth/android/library/widget/AbsHListView;III)Z
    .registers 14

    .prologue
    const/4 v2, 0x0

    .line 60
    move-object v0, p0

    move v1, p1

    move v3, p2

    move v4, v2

    move v5, v2

    move v6, v2

    move v7, p3

    move v8, v2

    move v9, v2

    invoke-virtual/range {v0 .. v9}, Lit/sephiroth/android/library/widget/AbsHListView;->overScrollBy(IIIIIIIIZ)Z

    move-result v0

    return v0
.end method

.method private static c(Landroid/view/View;IJ)Landroid/view/ContextMenu$ContextMenuInfo;
    .registers 5

    .prologue
    .line 2395
    new-instance v0, Lit/sephiroth/android/library/widget/m;

    invoke-direct {v0, p0, p1, p2, p3}, Lit/sephiroth/android/library/widget/m;-><init>(Landroid/view/View;IJ)V

    return-object v0
.end method

.method static synthetic c(Lit/sephiroth/android/library/widget/AbsHListView;)Lit/sephiroth/android/library/widget/c;
    .registers 2

    .prologue
    .line 60
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aA:Lit/sephiroth/android/library/widget/c;

    return-object v0
.end method

.method static synthetic c(Lit/sephiroth/android/library/widget/AbsHListView;Landroid/view/View;)V
    .registers 3

    .prologue
    .line 60
    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->removeDetachedView(Landroid/view/View;Z)V

    return-void
.end method

.method static synthetic d(Lit/sephiroth/android/library/widget/AbsHListView;)I
    .registers 2

    .prologue
    .line 60
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aO:I

    return v0
.end method

.method static synthetic d(Lit/sephiroth/android/library/widget/AbsHListView;Landroid/view/View;)V
    .registers 3

    .prologue
    .line 60
    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->removeDetachedView(Landroid/view/View;Z)V

    return-void
.end method

.method static synthetic e(Lit/sephiroth/android/library/widget/AbsHListView;)Landroid/view/VelocityTracker;
    .registers 2

    .prologue
    .line 60
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->at:Landroid/view/VelocityTracker;

    return-object v0
.end method

.method static synthetic e(Lit/sephiroth/android/library/widget/AbsHListView;Landroid/view/View;)V
    .registers 3

    .prologue
    .line 60
    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->removeDetachedView(Landroid/view/View;Z)V

    return-void
.end method

.method static synthetic f(Lit/sephiroth/android/library/widget/AbsHListView;)I
    .registers 2

    .prologue
    .line 60
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aM:I

    return v0
.end method

.method static synthetic g(Lit/sephiroth/android/library/widget/AbsHListView;)I
    .registers 2

    .prologue
    .line 60
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aL:I

    return v0
.end method

.method static synthetic h(Lit/sephiroth/android/library/widget/AbsHListView;)Z
    .registers 2

    .prologue
    .line 60
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->A()Z

    move-result v0

    return v0
.end method

.method static synthetic i(Lit/sephiroth/android/library/widget/AbsHListView;)Lit/sephiroth/android/library/widget/s;
    .registers 2

    .prologue
    .line 60
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aP:Lit/sephiroth/android/library/widget/s;

    return-object v0
.end method

.method static synthetic j(Lit/sephiroth/android/library/widget/AbsHListView;)Lit/sephiroth/android/library/widget/s;
    .registers 2

    .prologue
    .line 60
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aQ:Lit/sephiroth/android/library/widget/s;

    return-object v0
.end method

.method private j(I)Z
    .registers 8

    .prologue
    const/4 v3, 0x1

    const/4 v1, 0x0

    .line 2696
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->D:I

    sub-int v2, p1, v0

    .line 2697
    invoke-static {v2}, Ljava/lang/Math;->abs(I)I

    move-result v4

    .line 2698
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getScrollX()I

    move-result v0

    if-eqz v0, :cond_50

    move v0, v3

    .line 2699
    :goto_11
    if-nez v0, :cond_17

    iget v5, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aJ:I

    if-le v4, v5, :cond_4f

    .line 2700
    :cond_17
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->G()V

    .line 2701
    if-eqz v0, :cond_52

    .line 2702
    const/4 v0, 0x5

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    move v0, v1

    move-object v2, p0

    .line 2706
    :goto_21
    iput v0, v2, Lit/sephiroth/android/library/widget/AbsHListView;->H:I

    .line 2708
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getHandler()Landroid/os/Handler;

    move-result-object v0

    .line 2712
    if-eqz v0, :cond_2e

    .line 2713
    iget-object v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aA:Lit/sephiroth/android/library/widget/c;

    invoke-virtual {v0, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 2715
    :cond_2e
    invoke-virtual {p0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->setPressed(Z)V

    .line 2716
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->A:I

    iget v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    sub-int/2addr v0, v2

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    .line 2717
    if-eqz v0, :cond_3f

    .line 2718
    invoke-virtual {v0, v1}, Landroid/view/View;->setPressed(Z)V

    .line 2720
    :cond_3f
    invoke-virtual {p0, v3}, Lit/sephiroth/android/library/widget/AbsHListView;->a(I)V

    .line 2723
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    .line 2724
    if-eqz v0, :cond_4b

    .line 2725
    invoke-interface {v0, v3}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 2727
    :cond_4b
    invoke-direct {p0, p1}, Lit/sephiroth/android/library/widget/AbsHListView;->k(I)V

    move v1, v3

    .line 2731
    :cond_4f
    return v1

    :cond_50
    move v0, v1

    .line 2698
    goto :goto_11

    .line 2705
    :cond_52
    const/4 v0, 0x3

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 2706
    if-lez v2, :cond_5b

    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aJ:I

    move-object v2, p0

    goto :goto_21

    :cond_5b
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aJ:I

    neg-int v0, v0

    move-object v2, p0

    goto :goto_21
.end method

.method private k(I)V
    .registers 15

    .prologue
    .line 2735
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->D:I

    sub-int v12, p1, v0

    .line 2736
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->H:I

    sub-int v1, v12, v0

    .line 2737
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->G:I

    const/high16 v2, -0x80000000

    if-eq v0, v2, :cond_c2

    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->G:I

    sub-int v0, p1, v0

    .line 2739
    :goto_12
    iget v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    const/4 v3, 0x3

    if-ne v2, v3, :cond_f3

    .line 2741
    iget v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->G:I

    if-eq p1, v2, :cond_c1

    .line 2745
    invoke-static {v12}, Ljava/lang/Math;->abs(I)I

    move-result v2

    iget v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aJ:I

    if-le v2, v3, :cond_2d

    .line 2746
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    .line 2747
    if-eqz v2, :cond_2d

    .line 2748
    const/4 v3, 0x1

    invoke-interface {v2, v3}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 2753
    :cond_2d
    iget v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->A:I

    if-ltz v2, :cond_c5

    .line 2754
    iget v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->A:I

    iget v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    sub-int/2addr v2, v3

    .line 2761
    :goto_36
    const/4 v3, 0x0

    .line 2762
    invoke-virtual {p0, v2}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    .line 2763
    if-eqz v4, :cond_1db

    .line 2764
    invoke-virtual {v4}, Landroid/view/View;->getLeft()I

    move-result v3

    move v4, v3

    .line 2768
    :goto_42
    const/4 v3, 0x0

    .line 2769
    if-eqz v0, :cond_1d8

    .line 2770
    invoke-virtual {p0, v1, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->a(II)Z

    move-result v1

    .line 2774
    :goto_49
    invoke-virtual {p0, v2}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    .line 2775
    if-eqz v2, :cond_bf

    .line 2778
    invoke-virtual {v2}, Landroid/view/View;->getLeft()I

    move-result v2

    .line 2779
    if-eqz v1, :cond_bd

    .line 2782
    neg-int v0, v0

    sub-int v1, v2, v4

    sub-int v1, v0, v1

    .line 2783
    const/4 v2, 0x0

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getScrollX()I

    move-result v3

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget v7, p0, Lit/sephiroth/android/library/widget/AbsHListView;->Q:I

    const/4 v8, 0x0

    const/4 v9, 0x1

    move-object v0, p0

    invoke-virtual/range {v0 .. v9}, Lit/sephiroth/android/library/widget/AbsHListView;->overScrollBy(IIIIIIIIZ)Z

    .line 2784
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->Q:I

    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result v0

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getScrollX()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Math;->abs(I)I

    move-result v2

    if-ne v0, v2, :cond_83

    .line 2786
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->at:Landroid/view/VelocityTracker;

    if-eqz v0, :cond_83

    .line 2787
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->at:Landroid/view/VelocityTracker;

    invoke-virtual {v0}, Landroid/view/VelocityTracker;->clear()V

    .line 2791
    :cond_83
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getOverScrollMode()I

    move-result v0

    .line 2793
    if-eqz v0, :cond_92

    const/4 v2, 0x1

    if-ne v0, v2, :cond_bd

    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->A()Z

    move-result v0

    if-nez v0, :cond_bd

    .line 2795
    :cond_92
    const/4 v0, 0x0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aT:I

    .line 2796
    const/4 v0, 0x5

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 2797
    if-lez v12, :cond_cd

    .line 2798
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aP:Lit/sephiroth/android/library/widget/s;

    int-to-float v1, v1

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v1, v2

    invoke-virtual {v0, v1}, Lit/sephiroth/android/library/widget/s;->a(F)V

    .line 2799
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aQ:Lit/sephiroth/android/library/widget/s;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/s;->a()Z

    move-result v0

    if-nez v0, :cond_b3

    .line 2800
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aQ:Lit/sephiroth/android/library/widget/s;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/s;->c()V

    .line 2802
    :cond_b3
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aP:Lit/sephiroth/android/library/widget/s;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lit/sephiroth/android/library/widget/s;->a(Z)Landroid/graphics/Rect;

    move-result-object v0

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->invalidate(Landroid/graphics/Rect;)V

    .line 2812
    :cond_bd
    :goto_bd
    iput p1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->D:I

    .line 2814
    :cond_bf
    iput p1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->G:I

    .line 2879
    :cond_c1
    :goto_c1
    return-void

    :cond_c2
    move v0, v1

    .line 2737
    goto/16 :goto_12

    .line 2758
    :cond_c5
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v2

    div-int/lit8 v2, v2, 0x2

    goto/16 :goto_36

    .line 2803
    :cond_cd
    if-gez v12, :cond_bd

    .line 2804
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aQ:Lit/sephiroth/android/library/widget/s;

    int-to-float v1, v1

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v1, v2

    invoke-virtual {v0, v1}, Lit/sephiroth/android/library/widget/s;->a(F)V

    .line 2805
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aP:Lit/sephiroth/android/library/widget/s;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/s;->a()Z

    move-result v0

    if-nez v0, :cond_e8

    .line 2806
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aP:Lit/sephiroth/android/library/widget/s;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/s;->c()V

    .line 2808
    :cond_e8
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aQ:Lit/sephiroth/android/library/widget/s;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lit/sephiroth/android/library/widget/s;->a(Z)Landroid/graphics/Rect;

    move-result-object v0

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->invalidate(Landroid/graphics/Rect;)V

    goto :goto_bd

    .line 2816
    :cond_f3
    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    const/4 v2, 0x5

    if-ne v1, v2, :cond_c1

    .line 2817
    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->G:I

    if-eq p1, v1, :cond_c1

    .line 2818
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getScrollX()I

    move-result v2

    .line 2819
    sub-int v3, v2, v0

    .line 2820
    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->G:I

    if-le p1, v1, :cond_19b

    const/4 v1, 0x1

    move v10, v1

    .line 2822
    :goto_108
    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aT:I

    if-nez v1, :cond_10e

    .line 2823
    iput v10, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aT:I

    .line 2826
    :cond_10e
    neg-int v1, v0

    .line 2827
    if-gez v3, :cond_113

    if-gez v2, :cond_117

    :cond_113
    if-lez v3, :cond_19f

    if-gtz v2, :cond_19f

    .line 2828
    :cond_117
    neg-int v1, v2

    .line 2829
    add-int/2addr v0, v1

    move v11, v0

    .line 2834
    :goto_11a
    if-eqz v1, :cond_160

    .line 2835
    const/4 v2, 0x0

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getScrollX()I

    move-result v3

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget v7, p0, Lit/sephiroth/android/library/widget/AbsHListView;->Q:I

    const/4 v8, 0x0

    const/4 v9, 0x1

    move-object v0, p0

    invoke-virtual/range {v0 .. v9}, Lit/sephiroth/android/library/widget/AbsHListView;->overScrollBy(IIIIIIIIZ)Z

    .line 2836
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getOverScrollMode()I

    move-result v0

    .line 2837
    if-eqz v0, :cond_13b

    const/4 v2, 0x1

    if-ne v0, v2, :cond_160

    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->A()Z

    move-result v0

    if-nez v0, :cond_160

    .line 2838
    :cond_13b
    if-lez v12, :cond_1a3

    .line 2839
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aP:Lit/sephiroth/android/library/widget/s;

    int-to-float v1, v1

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v1, v2

    invoke-virtual {v0, v1}, Lit/sephiroth/android/library/widget/s;->a(F)V

    .line 2840
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aQ:Lit/sephiroth/android/library/widget/s;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/s;->a()Z

    move-result v0

    if-nez v0, :cond_156

    .line 2841
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aQ:Lit/sephiroth/android/library/widget/s;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/s;->c()V

    .line 2843
    :cond_156
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aP:Lit/sephiroth/android/library/widget/s;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lit/sephiroth/android/library/widget/s;->a(Z)Landroid/graphics/Rect;

    move-result-object v0

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->invalidate(Landroid/graphics/Rect;)V

    .line 2854
    :cond_160
    :goto_160
    if-eqz v11, :cond_195

    .line 2856
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getScrollX()I

    move-result v0

    if-eqz v0, :cond_171

    .line 2857
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->a:Lit/sephiroth/android/library/a/b;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lit/sephiroth/android/library/a/b;->a(I)V

    .line 2858
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->D()V

    .line 2861
    :cond_171
    invoke-virtual {p0, v11, v11}, Lit/sephiroth/android/library/widget/AbsHListView;->a(II)Z

    .line 2863
    const/4 v0, 0x3

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 2867
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v1

    if-nez v1, :cond_1c9

    const/4 v0, -0x1

    .line 2869
    :cond_17e
    :goto_17e
    const/4 v1, 0x0

    iput v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->H:I

    .line 2870
    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    sub-int v1, v0, v1

    invoke-virtual {p0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    .line 2871
    if-eqz v1, :cond_1d6

    invoke-virtual {v1}, Landroid/view/View;->getLeft()I

    move-result v1

    :goto_18f
    iput v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->B:I

    .line 2872
    iput p1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->D:I

    .line 2873
    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->A:I

    .line 2875
    :cond_195
    iput p1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->G:I

    .line 2876
    iput v10, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aT:I

    goto/16 :goto_c1

    .line 2820
    :cond_19b
    const/4 v1, -0x1

    move v10, v1

    goto/16 :goto_108

    .line 2831
    :cond_19f
    const/4 v0, 0x0

    move v11, v0

    goto/16 :goto_11a

    .line 2844
    :cond_1a3
    if-gez v12, :cond_160

    .line 2845
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aQ:Lit/sephiroth/android/library/widget/s;

    int-to-float v1, v1

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v1, v2

    invoke-virtual {v0, v1}, Lit/sephiroth/android/library/widget/s;->a(F)V

    .line 2846
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aP:Lit/sephiroth/android/library/widget/s;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/s;->a()Z

    move-result v0

    if-nez v0, :cond_1be

    .line 2847
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aP:Lit/sephiroth/android/library/widget/s;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/s;->c()V

    .line 2849
    :cond_1be
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aQ:Lit/sephiroth/android/library/widget/s;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lit/sephiroth/android/library/widget/s;->a(Z)Landroid/graphics/Rect;

    move-result-object v0

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->invalidate(Landroid/graphics/Rect;)V

    goto :goto_160

    .line 2867
    :cond_1c9
    invoke-virtual {p0, p1}, Lit/sephiroth/android/library/widget/AbsHListView;->c(I)I

    move-result v0

    const/4 v2, -0x1

    if-ne v0, v2, :cond_17e

    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    add-int/2addr v0, v1

    add-int/lit8 v0, v0, -0x1

    goto :goto_17e

    .line 2871
    :cond_1d6
    const/4 v1, 0x0

    goto :goto_18f

    :cond_1d8
    move v1, v3

    goto/16 :goto_49

    :cond_1db
    move v4, v3

    goto/16 :goto_42
.end method

.method static synthetic k(Lit/sephiroth/android/library/widget/AbsHListView;)V
    .registers 1

    .prologue
    .line 60
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->H()V

    return-void
.end method

.method private l(I)V
    .registers 4

    .prologue
    .line 4377
    const/16 v0, 0xc8

    const/4 v1, 0x0

    invoke-virtual {p0, p1, v0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->a(IIZ)V

    .line 4378
    return-void
.end method

.method static synthetic l(Lit/sephiroth/android/library/widget/AbsHListView;)Z
    .registers 11

    .prologue
    const/4 v1, 0x0

    .line 60
    move-object v0, p0

    move v2, v1

    move v3, v1

    move v4, v1

    move v5, v1

    move v6, v1

    move v7, v1

    move v8, v1

    move v9, v1

    invoke-virtual/range {v0 .. v9}, Lit/sephiroth/android/library/widget/AbsHListView;->overScrollBy(IIIIIIIIZ)Z

    move-result v0

    return v0
.end method

.method static synthetic m(Lit/sephiroth/android/library/widget/AbsHListView;)V
    .registers 2

    .prologue
    .line 60
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->setChildrenDrawnWithCacheEnabled(Z)V

    return-void
.end method

.method static synthetic n(Lit/sephiroth/android/library/widget/AbsHListView;)V
    .registers 2

    .prologue
    .line 60
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->setChildrenDrawingCacheEnabled(Z)V

    return-void
.end method


# virtual methods
.method public final a()I
    .registers 2

    .prologue
    .line 769
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->e:I

    return v0
.end method

.method protected final a(I[Z)Landroid/view/View;
    .registers 9
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "NewApi"
        }
    .end annotation

    .prologue
    const/16 v5, 0x10

    const/4 v4, 0x1

    const/4 v3, 0x0

    .line 1845
    aput-boolean v3, p2, v3

    .line 1848
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->p:Lit/sephiroth/android/library/widget/j;

    invoke-virtual {v0, p1}, Lit/sephiroth/android/library/widget/j;->c(I)Landroid/view/View;

    move-result-object v1

    .line 1849
    if-eqz v1, :cond_f

    .line 1913
    :cond_e
    :goto_e
    return-object v1

    .line 1853
    :cond_f
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->p:Lit/sephiroth/android/library/widget/j;

    invoke-virtual {v0, p1}, Lit/sephiroth/android/library/widget/j;->d(I)Landroid/view/View;

    move-result-object v1

    .line 1856
    if-eqz v1, :cond_71

    .line 1857
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    invoke-interface {v0, p1, v1, p0}, Landroid/widget/ListAdapter;->getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    .line 1859
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v2, v5, :cond_2a

    .line 1860
    invoke-virtual {v0}, Landroid/view/View;->getImportantForAccessibility()I

    move-result v2

    if-nez v2, :cond_2a

    .line 1861
    invoke-virtual {v0, v4}, Landroid/view/View;->setImportantForAccessibility(I)V

    .line 1865
    :cond_2a
    if-eq v0, v1, :cond_6a

    .line 1866
    iget-object v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->p:Lit/sephiroth/android/library/widget/j;

    invoke-virtual {v2, v1, p1}, Lit/sephiroth/android/library/widget/j;->a(Landroid/view/View;I)V

    .line 1867
    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aG:I

    if-eqz v1, :cond_8e

    .line 1868
    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aG:I

    invoke-virtual {v0, v1}, Landroid/view/View;->setDrawingCacheBackgroundColor(I)V

    move-object v1, v0

    .line 1888
    :goto_3b
    iget-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->k:Z

    if-eqz v0, :cond_56

    .line 1889
    invoke-virtual {v1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    .line 1891
    if-nez v0, :cond_90

    .line 1892
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Lit/sephiroth/android/library/widget/AbsHListView$LayoutParams;

    .line 1898
    :goto_4b
    iget-object v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    invoke-interface {v2, p1}, Landroid/widget/ListAdapter;->getItemId(I)J

    move-result-wide v2

    iput-wide v2, v0, Lit/sephiroth/android/library/widget/AbsHListView$LayoutParams;->e:J

    .line 1899
    invoke-virtual {v1, v0}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1902
    :cond_56
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ap:Landroid/view/accessibility/AccessibilityManager;

    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityManager;->isEnabled()Z

    move-result v0

    if-eqz v0, :cond_e

    .line 1903
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aX:Lit/sephiroth/android/library/widget/f;

    if-nez v0, :cond_e

    .line 1904
    new-instance v0, Lit/sephiroth/android/library/widget/f;

    invoke-direct {v0, p0}, Lit/sephiroth/android/library/widget/f;-><init>(Lit/sephiroth/android/library/widget/AbsHListView;)V

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aX:Lit/sephiroth/android/library/widget/f;

    goto :goto_e

    .line 1871
    :cond_6a
    aput-boolean v4, p2, v3

    .line 1872
    invoke-virtual {v0}, Landroid/view/View;->onFinishTemporaryDetach()V

    move-object v1, v0

    goto :goto_3b

    .line 1875
    :cond_71
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    const/4 v1, 0x0

    invoke-interface {v0, p1, v1, p0}, Landroid/widget/ListAdapter;->getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    .line 1877
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v1, v5, :cond_85

    .line 1878
    invoke-virtual {v0}, Landroid/view/View;->getImportantForAccessibility()I

    move-result v1

    if-nez v1, :cond_85

    .line 1879
    invoke-virtual {v0, v4}, Landroid/view/View;->setImportantForAccessibility(I)V

    .line 1883
    :cond_85
    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aG:I

    if-eqz v1, :cond_8e

    .line 1884
    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aG:I

    invoke-virtual {v0, v1}, Landroid/view/View;->setDrawingCacheBackgroundColor(I)V

    :cond_8e
    move-object v1, v0

    goto :goto_3b

    .line 1893
    :cond_90
    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z

    move-result v2

    if-nez v2, :cond_9d

    .line 1894
    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    check-cast v0, Lit/sephiroth/android/library/widget/AbsHListView$LayoutParams;

    goto :goto_4b

    .line 1896
    :cond_9d
    check-cast v0, Lit/sephiroth/android/library/widget/AbsHListView$LayoutParams;

    goto :goto_4b
.end method

.method final a(I)V
    .registers 3

    .prologue
    .line 3588
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aI:I

    if-eq p1, v0, :cond_c

    .line 3589
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->av:Lit/sephiroth/android/library/widget/g;

    if-eqz v0, :cond_c

    .line 3590
    iput p1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aI:I

    .line 3591
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->av:Lit/sephiroth/android/library/widget/g;

    .line 3594
    :cond_c
    return-void
.end method

.method public final a(IIZ)V
    .registers 10

    .prologue
    .line 4381
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    if-nez v0, :cond_b

    .line 4382
    new-instance v0, Lit/sephiroth/android/library/widget/e;

    invoke-direct {v0, p0}, Lit/sephiroth/android/library/widget/e;-><init>(Lit/sephiroth/android/library/widget/AbsHListView;)V

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    .line 4386
    :cond_b
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    .line 4387
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v1

    .line 4388
    add-int v2, v0, v1

    .line 4389
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getPaddingLeft()I

    move-result v3

    .line 4390
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v4

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getPaddingRight()I

    move-result v5

    sub-int/2addr v4, v5

    .line 4392
    if-eqz p1, :cond_49

    iget v5, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    if-eqz v5, :cond_49

    if-eqz v1, :cond_49

    if-nez v0, :cond_37

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->getLeft()I

    move-result v0

    if-ne v0, v3, :cond_37

    if-ltz p1, :cond_49

    :cond_37
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    if-ne v2, v0, :cond_58

    add-int/lit8 v0, v1, -0x1

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    invoke-virtual {v0}, Landroid/view/View;->getRight()I

    move-result v0

    if-ne v0, v4, :cond_58

    if-lez p1, :cond_58

    .line 4396
    :cond_49
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/e;->b()V

    .line 4397
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->I:Lit/sephiroth/android/library/widget/i;

    if-eqz v0, :cond_57

    .line 4398
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->I:Lit/sephiroth/android/library/widget/i;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/i;->a()V

    .line 4404
    :cond_57
    :goto_57
    return-void

    .line 4401
    :cond_58
    const/4 v0, 0x2

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->a(I)V

    .line 4402
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    invoke-virtual {v0, p1, p2, p3}, Lit/sephiroth/android/library/widget/e;->a(IIZ)V

    goto :goto_57
.end method

.method protected final a(ILandroid/view/View;)V
    .registers 10

    .prologue
    const/4 v6, -0x1

    .line 2008
    if-eq p1, v6, :cond_5

    .line 2009
    iput p1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->n:I

    .line 2012
    :cond_5
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->o:Landroid/graphics/Rect;

    .line 2013
    invoke-virtual {p2}, Landroid/view/View;->getLeft()I

    move-result v1

    invoke-virtual {p2}, Landroid/view/View;->getTop()I

    move-result v2

    invoke-virtual {p2}, Landroid/view/View;->getRight()I

    move-result v3

    invoke-virtual {p2}, Landroid/view/View;->getBottom()I

    move-result v4

    invoke-virtual {v0, v1, v2, v3, v4}, Landroid/graphics/Rect;->set(IIII)V

    .line 2014
    iget v1, v0, Landroid/graphics/Rect;->left:I

    iget v2, v0, Landroid/graphics/Rect;->top:I

    iget v3, v0, Landroid/graphics/Rect;->right:I

    iget v0, v0, Landroid/graphics/Rect;->bottom:I

    iget-object v4, p0, Lit/sephiroth/android/library/widget/AbsHListView;->o:Landroid/graphics/Rect;

    iget v5, p0, Lit/sephiroth/android/library/widget/AbsHListView;->q:I

    sub-int/2addr v1, v5

    iget v5, p0, Lit/sephiroth/android/library/widget/AbsHListView;->r:I

    sub-int/2addr v2, v5

    iget v5, p0, Lit/sephiroth/android/library/widget/AbsHListView;->s:I

    add-int/2addr v3, v5

    iget v5, p0, Lit/sephiroth/android/library/widget/AbsHListView;->t:I

    add-int/2addr v0, v5

    invoke-virtual {v4, v1, v2, v3, v0}, Landroid/graphics/Rect;->set(IIII)V

    .line 2020
    iget-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aH:Z

    .line 2021
    invoke-virtual {p2}, Landroid/view/View;->isEnabled()Z

    move-result v1

    if-eq v1, v0, :cond_49

    .line 2022
    if-nez v0, :cond_4a

    const/4 v0, 0x1

    :goto_3e
    iput-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aH:Z

    .line 2023
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->r()I

    move-result v0

    if-eq v0, v6, :cond_49

    .line 2024
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->refreshDrawableState()V

    .line 2027
    :cond_49
    return-void

    .line 2022
    :cond_4a
    const/4 v0, 0x0

    goto :goto_3e
.end method

.method public a(Landroid/widget/ListAdapter;)V
    .registers 3

    .prologue
    .line 738
    if-eqz p1, :cond_1d

    .line 739
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    invoke-interface {v0}, Landroid/widget/ListAdapter;->hasStableIds()Z

    move-result v0

    iput-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->k:Z

    .line 740
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->b:I

    if-eqz v0, :cond_1d

    iget-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->k:Z

    if-eqz v0, :cond_1d

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    if-nez v0, :cond_1d

    .line 742
    new-instance v0, Landroid/support/v4/c/e;

    invoke-direct {v0}, Landroid/support/v4/c/e;-><init>()V

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    .line 746
    :cond_1d
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->f:Landroid/util/SparseBooleanArray;

    if-eqz v0, :cond_26

    .line 747
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->f:Landroid/util/SparseBooleanArray;

    invoke-virtual {v0}, Landroid/util/SparseBooleanArray;->clear()V

    .line 750
    :cond_26
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    if-eqz v0, :cond_2f

    .line 751
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    invoke-virtual {v0}, Landroid/support/v4/c/e;->b()V

    .line 753
    :cond_2f
    return-void
.end method

.method protected abstract a(Z)V
.end method

.method final a(II)Z
    .registers 23

    .prologue
    .line 4485
    invoke-virtual/range {p0 .. p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v9

    .line 4486
    if-nez v9, :cond_8

    .line 4487
    const/4 v2, 0x1

    .line 4642
    :goto_7
    return v2

    .line 4490
    :cond_8
    const/4 v2, 0x0

    move-object/from16 v0, p0

    invoke-virtual {v0, v2}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/View;->getLeft()I

    move-result v3

    .line 4491
    add-int/lit8 v2, v9, -0x1

    move-object/from16 v0, p0

    invoke-virtual {v0, v2}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/View;->getRight()I

    move-result v4

    .line 4493
    move-object/from16 v0, p0

    iget-object v5, v0, Lit/sephiroth/android/library/widget/AbsHListView;->u:Landroid/graphics/Rect;

    .line 4498
    rsub-int/lit8 v10, v3, 0x0

    .line 4508
    invoke-virtual/range {p0 .. p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v2

    add-int/lit8 v2, v2, 0x0

    .line 4509
    sub-int v11, v4, v2

    .line 4511
    invoke-virtual/range {p0 .. p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v2

    invoke-virtual/range {p0 .. p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getPaddingRight()I

    move-result v6

    sub-int/2addr v2, v6

    invoke-virtual/range {p0 .. p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getPaddingLeft()I

    move-result v6

    sub-int v6, v2, v6

    .line 4512
    if-gez p1, :cond_97

    .line 4513
    add-int/lit8 v2, v6, -0x1

    neg-int v2, v2

    move/from16 v0, p1

    invoke-static {v2, v0}, Ljava/lang/Math;->max(II)I

    move-result v2

    move v8, v2

    .line 4518
    :goto_48
    if-gez p2, :cond_a1

    .line 4519
    add-int/lit8 v2, v6, -0x1

    neg-int v2, v2

    move/from16 v0, p2

    invoke-static {v2, v0}, Ljava/lang/Math;->max(II)I

    move-result v2

    .line 4524
    :goto_53
    move-object/from16 v0, p0

    iget v12, v0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    .line 4527
    if-nez v12, :cond_aa

    .line 4528
    iget v6, v5, Landroid/graphics/Rect;->left:I

    sub-int v6, v3, v6

    move-object/from16 v0, p0

    iput v6, v0, Lit/sephiroth/android/library/widget/AbsHListView;->aR:I

    .line 4532
    :goto_61
    add-int v6, v12, v9

    move-object/from16 v0, p0

    iget v7, v0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    if-ne v6, v7, :cond_b4

    .line 4533
    iget v6, v5, Landroid/graphics/Rect;->right:I

    add-int/2addr v6, v4

    move-object/from16 v0, p0

    iput v6, v0, Lit/sephiroth/android/library/widget/AbsHListView;->aS:I

    .line 4538
    :goto_70
    if-nez v12, :cond_be

    iget v6, v5, Landroid/graphics/Rect;->left:I

    if-lt v3, v6, :cond_be

    if-ltz v2, :cond_be

    const/4 v3, 0x1

    .line 4539
    :goto_79
    add-int v6, v12, v9

    move-object/from16 v0, p0

    iget v7, v0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    if-ne v6, v7, :cond_c0

    invoke-virtual/range {p0 .. p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v6

    iget v5, v5, Landroid/graphics/Rect;->right:I

    sub-int v5, v6, v5

    if-gt v4, v5, :cond_c0

    if-gtz v2, :cond_c0

    const/4 v4, 0x1

    .line 4541
    :goto_8e
    if-nez v3, :cond_92

    if-eqz v4, :cond_c5

    .line 4542
    :cond_92
    if-eqz v2, :cond_c2

    const/4 v2, 0x1

    goto/16 :goto_7

    .line 4515
    :cond_97
    add-int/lit8 v2, v6, -0x1

    move/from16 v0, p1

    invoke-static {v2, v0}, Ljava/lang/Math;->min(II)I

    move-result v2

    move v8, v2

    goto :goto_48

    .line 4521
    :cond_a1
    add-int/lit8 v2, v6, -0x1

    move/from16 v0, p2

    invoke-static {v2, v0}, Ljava/lang/Math;->min(II)I

    move-result v2

    goto :goto_53

    .line 4530
    :cond_aa
    move-object/from16 v0, p0

    iget v6, v0, Lit/sephiroth/android/library/widget/AbsHListView;->aR:I

    add-int/2addr v6, v2

    move-object/from16 v0, p0

    iput v6, v0, Lit/sephiroth/android/library/widget/AbsHListView;->aR:I

    goto :goto_61

    .line 4535
    :cond_b4
    move-object/from16 v0, p0

    iget v6, v0, Lit/sephiroth/android/library/widget/AbsHListView;->aS:I

    add-int/2addr v6, v2

    move-object/from16 v0, p0

    iput v6, v0, Lit/sephiroth/android/library/widget/AbsHListView;->aS:I

    goto :goto_70

    .line 4538
    :cond_be
    const/4 v3, 0x0

    goto :goto_79

    .line 4539
    :cond_c0
    const/4 v4, 0x0

    goto :goto_8e

    .line 4542
    :cond_c2
    const/4 v2, 0x0

    goto/16 :goto_7

    .line 4545
    :cond_c5
    if-gez v2, :cond_116

    const/4 v3, 0x1

    .line 4547
    :goto_c8
    invoke-virtual/range {p0 .. p0}, Lit/sephiroth/android/library/widget/AbsHListView;->isInTouchMode()Z

    move-result v13

    .line 4548
    if-eqz v13, :cond_d1

    .line 4549
    invoke-virtual/range {p0 .. p0}, Lit/sephiroth/android/library/widget/AbsHListView;->l()V

    .line 4552
    :cond_d1
    invoke-virtual/range {p0 .. p0}, Lit/sephiroth/android/library/widget/AbsHListView;->j()I

    move-result v14

    .line 4553
    move-object/from16 v0, p0

    iget v4, v0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    invoke-virtual/range {p0 .. p0}, Lit/sephiroth/android/library/widget/AbsHListView;->k()I

    move-result v5

    sub-int v15, v4, v5

    .line 4555
    const/4 v5, 0x0

    .line 4556
    const/4 v6, 0x0

    .line 4558
    if-eqz v3, :cond_118

    .line 4559
    neg-int v0, v2

    move/from16 v16, v0

    .line 4565
    const/4 v4, 0x0

    move/from16 v19, v4

    move v4, v6

    move/from16 v6, v19

    :goto_ec
    if-ge v6, v9, :cond_151

    .line 4566
    move-object/from16 v0, p0

    invoke-virtual {v0, v6}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v17

    .line 4567
    invoke-virtual/range {v17 .. v17}, Landroid/view/View;->getRight()I

    move-result v7

    move/from16 v0, v16

    if-ge v7, v0, :cond_151

    .line 4568
    add-int/lit8 v7, v4, 0x1

    .line 4571
    add-int v4, v12, v6

    .line 4572
    if-lt v4, v14, :cond_111

    if-ge v4, v15, :cond_111

    .line 4573
    move-object/from16 v0, p0

    iget-object v0, v0, Lit/sephiroth/android/library/widget/AbsHListView;->p:Lit/sephiroth/android/library/widget/j;

    move-object/from16 v18, v0

    move-object/from16 v0, v18

    move-object/from16 v1, v17

    invoke-virtual {v0, v1, v4}, Lit/sephiroth/android/library/widget/j;->a(Landroid/view/View;I)V

    .line 4565
    :cond_111
    add-int/lit8 v4, v6, 0x1

    move v6, v4

    move v4, v7

    goto :goto_ec

    .line 4545
    :cond_116
    const/4 v3, 0x0

    goto :goto_c8

    .line 4578
    :cond_118
    invoke-virtual/range {p0 .. p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v4

    sub-int v7, v4, v2

    .line 4583
    add-int/lit8 v4, v9, -0x1

    move/from16 v19, v4

    move v4, v6

    move/from16 v6, v19

    :goto_125
    if-ltz v6, :cond_151

    .line 4584
    move-object/from16 v0, p0

    invoke-virtual {v0, v6}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v9

    .line 4585
    invoke-virtual {v9}, Landroid/view/View;->getLeft()I

    move-result v16

    move/from16 v0, v16

    if-le v0, v7, :cond_151

    .line 4589
    add-int/lit8 v5, v4, 0x1

    .line 4590
    add-int v4, v12, v6

    .line 4591
    if-lt v4, v14, :cond_148

    if-ge v4, v15, :cond_148

    .line 4592
    move-object/from16 v0, p0

    iget-object v0, v0, Lit/sephiroth/android/library/widget/AbsHListView;->p:Lit/sephiroth/android/library/widget/j;

    move-object/from16 v16, v0

    move-object/from16 v0, v16

    invoke-virtual {v0, v9, v4}, Lit/sephiroth/android/library/widget/j;->a(Landroid/view/View;I)V

    .line 4583
    :cond_148
    add-int/lit8 v4, v6, -0x1

    move/from16 v19, v4

    move v4, v5

    move v5, v6

    move/from16 v6, v19

    goto :goto_125

    .line 4598
    :cond_151
    move-object/from16 v0, p0

    iget v6, v0, Lit/sephiroth/android/library/widget/AbsHListView;->B:I

    add-int/2addr v6, v8

    move-object/from16 v0, p0

    iput v6, v0, Lit/sephiroth/android/library/widget/AbsHListView;->C:I

    .line 4600
    const/4 v6, 0x1

    move-object/from16 v0, p0

    iput-boolean v6, v0, Lit/sephiroth/android/library/widget/AbsHListView;->as:Z

    .line 4602
    if-lez v4, :cond_16d

    .line 4603
    move-object/from16 v0, p0

    invoke-virtual {v0, v5, v4}, Lit/sephiroth/android/library/widget/AbsHListView;->detachViewsFromParent(II)V

    .line 4604
    move-object/from16 v0, p0

    iget-object v5, v0, Lit/sephiroth/android/library/widget/AbsHListView;->p:Lit/sephiroth/android/library/widget/j;

    invoke-virtual {v5}, Lit/sephiroth/android/library/widget/j;->d()V

    .line 4609
    :cond_16d
    invoke-virtual/range {p0 .. p0}, Lit/sephiroth/android/library/widget/AbsHListView;->awakenScrollBars()Z

    move-result v5

    if-nez v5, :cond_176

    .line 4610
    invoke-virtual/range {p0 .. p0}, Lit/sephiroth/android/library/widget/AbsHListView;->invalidate()V

    .line 4613
    :cond_176
    move-object/from16 v0, p0

    invoke-virtual {v0, v2}, Lit/sephiroth/android/library/widget/AbsHListView;->b(I)V

    .line 4615
    if-eqz v3, :cond_186

    .line 4616
    move-object/from16 v0, p0

    iget v5, v0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    add-int/2addr v4, v5

    move-object/from16 v0, p0

    iput v4, v0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    .line 4619
    :cond_186
    invoke-static {v2}, Ljava/lang/Math;->abs(I)I

    move-result v2

    .line 4620
    if-lt v10, v2, :cond_18e

    if-ge v11, v2, :cond_193

    .line 4621
    :cond_18e
    move-object/from16 v0, p0

    invoke-virtual {v0, v3}, Lit/sephiroth/android/library/widget/AbsHListView;->a(Z)V

    .line 4624
    :cond_193
    if-nez v13, :cond_1c7

    move-object/from16 v0, p0

    iget v2, v0, Lit/sephiroth/android/library/widget/AbsHListView;->al:I

    const/4 v3, -0x1

    if-eq v2, v3, :cond_1c7

    .line 4625
    move-object/from16 v0, p0

    iget v2, v0, Lit/sephiroth/android/library/widget/AbsHListView;->al:I

    move-object/from16 v0, p0

    iget v3, v0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    sub-int/2addr v2, v3

    .line 4626
    if-ltz v2, :cond_1bc

    invoke-virtual/range {p0 .. p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v3

    if-ge v2, v3, :cond_1bc

    .line 4627
    move-object/from16 v0, p0

    iget v3, v0, Lit/sephiroth/android/library/widget/AbsHListView;->al:I

    move-object/from16 v0, p0

    invoke-virtual {v0, v2}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    move-object/from16 v0, p0

    invoke-virtual {v0, v3, v2}, Lit/sephiroth/android/library/widget/AbsHListView;->a(ILandroid/view/View;)V

    .line 4638
    :cond_1bc
    :goto_1bc
    const/4 v2, 0x0

    move-object/from16 v0, p0

    iput-boolean v2, v0, Lit/sephiroth/android/library/widget/AbsHListView;->as:Z

    .line 4640
    invoke-virtual/range {p0 .. p0}, Lit/sephiroth/android/library/widget/AbsHListView;->c()V

    .line 4642
    const/4 v2, 0x0

    goto/16 :goto_7

    .line 4629
    :cond_1c7
    move-object/from16 v0, p0

    iget v2, v0, Lit/sephiroth/android/library/widget/AbsHListView;->n:I

    const/4 v3, -0x1

    if-eq v2, v3, :cond_1ec

    .line 4630
    move-object/from16 v0, p0

    iget v2, v0, Lit/sephiroth/android/library/widget/AbsHListView;->n:I

    move-object/from16 v0, p0

    iget v3, v0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    sub-int/2addr v2, v3

    .line 4631
    if-ltz v2, :cond_1bc

    invoke-virtual/range {p0 .. p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v3

    if-ge v2, v3, :cond_1bc

    .line 4632
    const/4 v3, -0x1

    move-object/from16 v0, p0

    invoke-virtual {v0, v2}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    move-object/from16 v0, p0

    invoke-virtual {v0, v3, v2}, Lit/sephiroth/android/library/widget/AbsHListView;->a(ILandroid/view/View;)V

    goto :goto_1bc

    .line 4635
    :cond_1ec
    move-object/from16 v0, p0

    iget-object v2, v0, Lit/sephiroth/android/library/widget/AbsHListView;->o:Landroid/graphics/Rect;

    invoke-virtual {v2}, Landroid/graphics/Rect;->setEmpty()V

    goto :goto_1bc
.end method

.method public final a(Landroid/view/View;IJ)Z
    .registers 14

    .prologue
    const/16 v8, 0xb

    const/4 v6, 0x1

    const/4 v7, 0x0

    .line 936
    .line 939
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->b:I

    if-eqz v0, :cond_110

    .line 943
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->b:I

    const/4 v1, 0x2

    if-eq v0, v1, :cond_1a

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v0, v8, :cond_9d

    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->b:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_9d

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->c:Ljava/lang/Object;

    if-eqz v0, :cond_9d

    .line 945
    :cond_1a
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->f:Landroid/util/SparseBooleanArray;

    invoke-virtual {v0, p2, v7}, Landroid/util/SparseBooleanArray;->get(IZ)Z

    move-result v0

    if-nez v0, :cond_88

    move v5, v6

    .line 946
    :goto_23
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->f:Landroid/util/SparseBooleanArray;

    invoke-virtual {v0, p2, v5}, Landroid/util/SparseBooleanArray;->put(IZ)V

    .line 947
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    if-eqz v0, :cond_45

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    invoke-interface {v0}, Landroid/widget/ListAdapter;->hasStableIds()Z

    move-result v0

    if-eqz v0, :cond_45

    .line 948
    if-eqz v5, :cond_8a

    .line 949
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    invoke-interface {v1, p2}, Landroid/widget/ListAdapter;->getItemId(I)J

    move-result-wide v1

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v0, v1, v2, v3}, Landroid/support/v4/c/e;->a(JLjava/lang/Object;)V

    .line 954
    :cond_45
    :goto_45
    if-eqz v5, :cond_96

    .line 955
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->e:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->e:I

    .line 960
    :goto_4d
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->c:Ljava/lang/Object;

    if-eqz v0, :cond_10d

    .line 961
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->d:Ljava/lang/Object;

    check-cast v0, Lit/sephiroth/android/library/a/a/b;

    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->c:Ljava/lang/Object;

    check-cast v1, Landroid/view/ActionMode;

    move v2, p2

    move-wide v3, p3

    invoke-virtual/range {v0 .. v5}, Lit/sephiroth/android/library/a/a/b;->a(Landroid/view/ActionMode;IJZ)V

    move v0, v7

    :goto_5f
    move v2, v0

    move v0, v6

    .line 982
    :goto_61
    if-eqz v0, :cond_ff

    .line 983
    iget v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v4

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v0, v8, :cond_f0

    move v1, v6

    :goto_6e
    if-ge v7, v4, :cond_ff

    invoke-virtual {p0, v7}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    add-int v5, v3, v7

    instance-of v8, v0, Landroid/widget/Checkable;

    if-eqz v8, :cond_f3

    check-cast v0, Landroid/widget/Checkable;

    iget-object v8, p0, Lit/sephiroth/android/library/widget/AbsHListView;->f:Landroid/util/SparseBooleanArray;

    invoke-virtual {v8, v5}, Landroid/util/SparseBooleanArray;->get(I)Z

    move-result v5

    invoke-interface {v0, v5}, Landroid/widget/Checkable;->setChecked(Z)V

    :cond_85
    :goto_85
    add-int/lit8 v7, v7, 0x1

    goto :goto_6e

    :cond_88
    move v5, v7

    .line 945
    goto :goto_23

    .line 951
    :cond_8a
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    invoke-interface {v1, p2}, Landroid/widget/ListAdapter;->getItemId(I)J

    move-result-wide v1

    invoke-virtual {v0, v1, v2}, Landroid/support/v4/c/e;->a(J)V

    goto :goto_45

    .line 957
    :cond_96
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->e:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->e:I

    goto :goto_4d

    .line 966
    :cond_9d
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->b:I

    if-ne v0, v6, :cond_109

    .line 967
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->f:Landroid/util/SparseBooleanArray;

    invoke-virtual {v0, p2, v7}, Landroid/util/SparseBooleanArray;->get(IZ)Z

    move-result v0

    if-nez v0, :cond_db

    move v0, v6

    .line 968
    :goto_aa
    if-eqz v0, :cond_dd

    .line 969
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->f:Landroid/util/SparseBooleanArray;

    invoke-virtual {v0}, Landroid/util/SparseBooleanArray;->clear()V

    .line 970
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->f:Landroid/util/SparseBooleanArray;

    invoke-virtual {v0, p2, v6}, Landroid/util/SparseBooleanArray;->put(IZ)V

    .line 971
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    if-eqz v0, :cond_d6

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    invoke-interface {v0}, Landroid/widget/ListAdapter;->hasStableIds()Z

    move-result v0

    if-eqz v0, :cond_d6

    .line 972
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    invoke-virtual {v0}, Landroid/support/v4/c/e;->b()V

    .line 973
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    invoke-interface {v1, p2}, Landroid/widget/ListAdapter;->getItemId(I)J

    move-result-wide v1

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v0, v1, v2, v3}, Landroid/support/v4/c/e;->a(JLjava/lang/Object;)V

    .line 975
    :cond_d6
    iput v6, p0, Lit/sephiroth/android/library/widget/AbsHListView;->e:I

    :cond_d8
    :goto_d8
    move v0, v6

    move v2, v6

    .line 979
    goto :goto_61

    :cond_db
    move v0, v7

    .line 967
    goto :goto_aa

    .line 976
    :cond_dd
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->f:Landroid/util/SparseBooleanArray;

    invoke-virtual {v0}, Landroid/util/SparseBooleanArray;->size()I

    move-result v0

    if-eqz v0, :cond_ed

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->f:Landroid/util/SparseBooleanArray;

    invoke-virtual {v0, v7}, Landroid/util/SparseBooleanArray;->valueAt(I)Z

    move-result v0

    if-nez v0, :cond_d8

    .line 977
    :cond_ed
    iput v7, p0, Lit/sephiroth/android/library/widget/AbsHListView;->e:I

    goto :goto_d8

    :cond_f0
    move v1, v7

    .line 983
    goto/16 :goto_6e

    :cond_f3
    if-eqz v1, :cond_85

    iget-object v8, p0, Lit/sephiroth/android/library/widget/AbsHListView;->f:Landroid/util/SparseBooleanArray;

    invoke-virtual {v8, v5}, Landroid/util/SparseBooleanArray;->get(I)Z

    move-result v5

    invoke-virtual {v0, v5}, Landroid/view/View;->setActivated(Z)V

    goto :goto_85

    :cond_ff
    move v0, v6

    move v6, v2

    .line 987
    :goto_101
    if-eqz v6, :cond_108

    .line 988
    invoke-super {p0, p1, p2, p3, p4}, Lit/sephiroth/android/library/widget/AdapterView;->a(Landroid/view/View;IJ)Z

    move-result v1

    or-int/2addr v0, v1

    .line 991
    :cond_108
    return v0

    :cond_109
    move v0, v7

    move v2, v6

    goto/16 :goto_61

    :cond_10d
    move v0, v6

    goto/16 :goto_5f

    :cond_110
    move v0, v7

    goto :goto_101
.end method

.method public addTouchables(Ljava/util/ArrayList;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList",
            "<",
            "Landroid/view/View;",
            ">;)V"
        }
    .end annotation

    .prologue
    .line 3563
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v1

    .line 3564
    iget v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    .line 3565
    iget-object v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    .line 3567
    if-nez v3, :cond_b

    .line 3578
    :cond_a
    return-void

    .line 3571
    :cond_b
    const/4 v0, 0x0

    :goto_c
    if-ge v0, v1, :cond_a

    .line 3572
    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    .line 3573
    add-int v5, v2, v0

    invoke-interface {v3, v5}, Landroid/widget/ListAdapter;->isEnabled(I)Z

    move-result v5

    if-eqz v5, :cond_1d

    .line 3574
    invoke-virtual {p1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 3576
    :cond_1d
    invoke-virtual {v4, p1}, Landroid/view/View;->addTouchables(Ljava/util/ArrayList;)V

    .line 3571
    add-int/lit8 v0, v0, 0x1

    goto :goto_c
.end method

.method public final b()V
    .registers 2

    .prologue
    .line 845
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->f:Landroid/util/SparseBooleanArray;

    if-eqz v0, :cond_9

    .line 846
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->f:Landroid/util/SparseBooleanArray;

    invoke-virtual {v0}, Landroid/util/SparseBooleanArray;->clear()V

    .line 848
    :cond_9
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    if-eqz v0, :cond_12

    .line 849
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    invoke-virtual {v0}, Landroid/support/v4/c/e;->b()V

    .line 851
    :cond_12
    const/4 v0, 0x0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->e:I

    .line 852
    return-void
.end method

.method public final b(I)V
    .registers 5

    .prologue
    .line 4649
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v1

    .line 4651
    const/4 v0, 0x0

    :goto_5
    if-ge v0, v1, :cond_11

    .line 4652
    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    .line 4653
    invoke-virtual {v2, p1}, Landroid/view/View;->offsetLeftAndRight(I)V

    .line 4651
    add-int/lit8 v0, v0, 0x1

    goto :goto_5

    .line 4655
    :cond_11
    return-void
.end method

.method final b(Landroid/view/View;IJ)Z
    .registers 12

    .prologue
    const/16 v3, 0xb

    const/4 v2, 0x3

    const/4 v6, 0x0

    const/4 v5, 0x1

    .line 2494
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v0, v3, :cond_e6

    .line 2495
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->b:I

    if-ne v0, v2, :cond_e6

    .line 2496
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->c:Ljava/lang/Object;

    if-nez v0, :cond_b1

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->d:Ljava/lang/Object;

    check-cast v0, Lit/sephiroth/android/library/a/a/b;

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->startActionMode(Landroid/view/ActionMode$Callback;)Landroid/view/ActionMode;

    move-result-object v0

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->c:Ljava/lang/Object;

    if-eqz v0, :cond_b1

    .line 2498
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->b:I

    if-eqz v0, :cond_ae

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v0, v3, :cond_4d

    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->b:I

    if-ne v0, v2, :cond_4d

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->c:Ljava/lang/Object;

    if-nez v0, :cond_4d

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->d:Ljava/lang/Object;

    if-eqz v0, :cond_3b

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->d:Ljava/lang/Object;

    check-cast v0, Lit/sephiroth/android/library/a/a/b;

    invoke-virtual {v0}, Lit/sephiroth/android/library/a/a/b;->a()Z

    move-result v0

    if-nez v0, :cond_43

    :cond_3b
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "AbsListView: attempted to start selection mode for CHOICE_MODE_MULTIPLE_MODAL but no choice mode callback was supplied. Call setMultiChoiceModeListener to set a callback."

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_43
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->d:Ljava/lang/Object;

    check-cast v0, Lit/sephiroth/android/library/a/a/b;

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->startActionMode(Landroid/view/ActionMode$Callback;)Landroid/view/ActionMode;

    move-result-object v0

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->c:Ljava/lang/Object;

    :cond_4d
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->b:I

    const/4 v1, 0x2

    if-eq v0, v1, :cond_5a

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v0, v3, :cond_b2

    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->b:I

    if-ne v0, v2, :cond_b2

    :cond_5a
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->f:Landroid/util/SparseBooleanArray;

    invoke-virtual {v0, p2}, Landroid/util/SparseBooleanArray;->get(I)Z

    move-result v0

    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->f:Landroid/util/SparseBooleanArray;

    invoke-virtual {v1, p2, v5}, Landroid/util/SparseBooleanArray;->put(IZ)V

    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    if-eqz v1, :cond_80

    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    invoke-interface {v1}, Landroid/widget/ListAdapter;->hasStableIds()Z

    move-result v1

    if-eqz v1, :cond_80

    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    iget-object v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    invoke-interface {v2, p2}, Landroid/widget/ListAdapter;->getItemId(I)J

    move-result-wide v2

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v1, v2, v3, v4}, Landroid/support/v4/c/e;->a(JLjava/lang/Object;)V

    :cond_80
    if-eq v0, v5, :cond_88

    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->e:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->e:I

    :cond_88
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->c:Ljava/lang/Object;

    if-eqz v0, :cond_9e

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    invoke-interface {v0, p2}, Landroid/widget/ListAdapter;->getItemId(I)J

    move-result-wide v3

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->d:Ljava/lang/Object;

    check-cast v0, Lit/sephiroth/android/library/a/a/b;

    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->c:Ljava/lang/Object;

    check-cast v1, Landroid/view/ActionMode;

    move v2, p2

    invoke-virtual/range {v0 .. v5}, Lit/sephiroth/android/library/a/a/b;->a(Landroid/view/ActionMode;IJZ)V

    :cond_9e
    :goto_9e
    iget-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ae:Z

    if-nez v0, :cond_ae

    iget-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->as:Z

    if-nez v0, :cond_ae

    iput-boolean v5, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ai:Z

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->z()V

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->requestLayout()V

    .line 2499
    :cond_ae
    invoke-virtual {p0, v6}, Lit/sephiroth/android/library/widget/AbsHListView;->performHapticFeedback(I)Z

    .line 2517
    :cond_b1
    :goto_b1
    return v5

    .line 2498
    :cond_b2
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    if-eqz v0, :cond_e4

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    invoke-interface {v0}, Landroid/widget/ListAdapter;->hasStableIds()Z

    move-result v0

    if-eqz v0, :cond_e4

    move v0, v5

    :goto_bf
    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->f:Landroid/util/SparseBooleanArray;

    invoke-virtual {v1}, Landroid/util/SparseBooleanArray;->clear()V

    if-eqz v0, :cond_cb

    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    invoke-virtual {v1}, Landroid/support/v4/c/e;->b()V

    :cond_cb
    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->f:Landroid/util/SparseBooleanArray;

    invoke-virtual {v1, p2, v5}, Landroid/util/SparseBooleanArray;->put(IZ)V

    if-eqz v0, :cond_e1

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    invoke-interface {v1, p2}, Landroid/widget/ListAdapter;->getItemId(I)J

    move-result-wide v1

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v0, v1, v2, v3}, Landroid/support/v4/c/e;->a(JLjava/lang/Object;)V

    :cond_e1
    iput v5, p0, Lit/sephiroth/android/library/widget/AbsHListView;->e:I

    goto :goto_9e

    :cond_e4
    move v0, v6

    goto :goto_bf

    .line 2506
    :cond_e6
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ah:Lit/sephiroth/android/library/widget/p;

    if-eqz v0, :cond_102

    .line 2507
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ah:Lit/sephiroth/android/library/widget/p;

    invoke-interface {v0}, Lit/sephiroth/android/library/widget/p;->a()Z

    move-result v5

    .line 2510
    :goto_f0
    if-nez v5, :cond_fc

    .line 2511
    invoke-static {p1, p2, p3, p4}, Lit/sephiroth/android/library/widget/AbsHListView;->c(Landroid/view/View;IJ)Landroid/view/ContextMenu$ContextMenuInfo;

    move-result-object v0

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ay:Landroid/view/ContextMenu$ContextMenuInfo;

    .line 2512
    invoke-super {p0, p0}, Lit/sephiroth/android/library/widget/AdapterView;->showContextMenuForChild(Landroid/view/View;)Z

    move-result v5

    .line 2514
    :cond_fc
    if-eqz v5, :cond_b1

    .line 2515
    invoke-virtual {p0, v6}, Lit/sephiroth/android/library/widget/AbsHListView;->performHapticFeedback(I)Z

    goto :goto_b1

    :cond_102
    move v5, v6

    goto :goto_f0
.end method

.method protected abstract c(I)I
.end method

.method protected final c()V
    .registers 3

    .prologue
    const/4 v1, 0x0

    .line 1147
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->av:Lit/sephiroth/android/library/widget/g;

    if-eqz v0, :cond_e

    .line 1148
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->av:Lit/sephiroth/android/library/widget/g;

    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    .line 1150
    :cond_e
    invoke-virtual {p0, v1, v1, v1, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->onScrollChanged(IIII)V

    .line 1151
    return-void
.end method

.method public checkInputConnectionProxy(Landroid/view/View;)Z
    .registers 3

    .prologue
    .line 5139
    const/4 v0, 0x0

    return v0
.end method

.method protected checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z
    .registers 3

    .prologue
    .line 5160
    instance-of v0, p1, Lit/sephiroth/android/library/widget/AbsHListView$LayoutParams;

    return v0
.end method

.method protected computeHorizontalScrollExtent()I
    .registers 5

    .prologue
    const/4 v1, 0x0

    .line 1573
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v2

    .line 1574
    if-lez v2, :cond_3d

    .line 1575
    iget-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aw:Z

    if-eqz v0, :cond_3b

    .line 1576
    mul-int/lit8 v0, v2, 0x64

    .line 1578
    invoke-virtual {p0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    .line 1579
    invoke-virtual {v1}, Landroid/view/View;->getLeft()I

    move-result v3

    .line 1580
    invoke-virtual {v1}, Landroid/view/View;->getWidth()I

    move-result v1

    .line 1581
    if-lez v1, :cond_20

    .line 1582
    mul-int/lit8 v3, v3, 0x64

    div-int v1, v3, v1

    add-int/2addr v0, v1

    .line 1585
    :cond_20
    add-int/lit8 v1, v2, -0x1

    invoke-virtual {p0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    .line 1586
    invoke-virtual {v1}, Landroid/view/View;->getRight()I

    move-result v2

    .line 1587
    invoke-virtual {v1}, Landroid/view/View;->getWidth()I

    move-result v1

    .line 1588
    if-lez v1, :cond_3a

    .line 1589
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v3

    sub-int/2addr v2, v3

    mul-int/lit8 v2, v2, 0x64

    div-int v1, v2, v1

    sub-int/2addr v0, v1

    .line 1597
    :cond_3a
    :goto_3a
    return v0

    .line 1594
    :cond_3b
    const/4 v0, 0x1

    goto :goto_3a

    :cond_3d
    move v0, v1

    .line 1597
    goto :goto_3a
.end method

.method protected computeHorizontalScrollOffset()I
    .registers 5

    .prologue
    const/4 v0, 0x0

    .line 1602
    iget v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    .line 1603
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v3

    .line 1604
    if-ltz v2, :cond_3d

    if-lez v3, :cond_3d

    .line 1605
    iget-boolean v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aw:Z

    if-eqz v1, :cond_3e

    .line 1606
    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    .line 1607
    invoke-virtual {v1}, Landroid/view/View;->getLeft()I

    move-result v3

    .line 1608
    invoke-virtual {v1}, Landroid/view/View;->getWidth()I

    move-result v1

    .line 1609
    if-lez v1, :cond_3d

    .line 1610
    mul-int/lit8 v2, v2, 0x64

    mul-int/lit8 v3, v3, 0x64

    div-int v1, v3, v1

    sub-int v1, v2, v1

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getScrollX()I

    move-result v2

    int-to-float v2, v2

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v3

    int-to-float v3, v3

    div-float/2addr v2, v3

    iget v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    int-to-float v3, v3

    mul-float/2addr v2, v3

    const/high16 v3, 0x42c80000    # 100.0f

    mul-float/2addr v2, v3

    float-to-int v2, v2

    add-int/2addr v1, v2

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 1626
    :cond_3d
    :goto_3d
    return v0

    .line 1615
    :cond_3e
    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    .line 1616
    if-nez v2, :cond_4b

    .line 1623
    :goto_42
    int-to-float v2, v2

    int-to-float v3, v3

    int-to-float v0, v0

    int-to-float v1, v1

    div-float/2addr v0, v1

    mul-float/2addr v0, v3

    add-float/2addr v0, v2

    float-to-int v0, v0

    goto :goto_3d

    .line 1618
    :cond_4b
    add-int v0, v2, v3

    if-ne v0, v1, :cond_51

    move v0, v1

    .line 1619
    goto :goto_42

    .line 1621
    :cond_51
    div-int/lit8 v0, v3, 0x2

    add-int/2addr v0, v2

    goto :goto_42
.end method

.method protected computeHorizontalScrollRange()I
    .registers 4

    .prologue
    .line 1632
    iget-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aw:Z

    if-eqz v0, :cond_2c

    .line 1633
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    mul-int/lit8 v0, v0, 0x64

    const/4 v1, 0x0

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 1634
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getScrollX()I

    move-result v1

    if-eqz v1, :cond_2b

    .line 1636
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getScrollX()I

    move-result v1

    int-to-float v1, v1

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v2

    int-to-float v2, v2

    div-float/2addr v1, v2

    iget v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    int-to-float v2, v2

    mul-float/2addr v1, v2

    const/high16 v2, 0x42c80000    # 100.0f

    mul-float/2addr v1, v2

    float-to-int v1, v1

    invoke-static {v1}, Ljava/lang/Math;->abs(I)I

    move-result v1

    add-int/2addr v0, v1

    .line 1641
    :cond_2b
    :goto_2b
    return v0

    .line 1639
    :cond_2c
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    goto :goto_2b
.end method

.method protected d()V
    .registers 5

    .prologue
    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, -0x1

    .line 1555
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->removeAllViewsInLayout()V

    .line 1556
    iput v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    .line 1557
    iput-boolean v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ai:Z

    .line 1558
    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->O:Ljava/lang/Runnable;

    .line 1559
    iput-boolean v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ac:Z

    .line 1560
    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->bb:Lit/sephiroth/android/library/widget/AbsHListView$SavedState;

    .line 1561
    iput v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aq:I

    .line 1562
    const-wide/high16 v0, -0x8000000000000000L

    iput-wide v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ar:J

    .line 1563
    invoke-virtual {p0, v2}, Lit/sephiroth/android/library/widget/AbsHListView;->h(I)V

    .line 1564
    invoke-virtual {p0, v2}, Lit/sephiroth/android/library/widget/AbsHListView;->i(I)V

    .line 1565
    iput v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->J:I

    .line 1566
    iput v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->n:I

    .line 1567
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->o:Landroid/graphics/Rect;

    invoke-virtual {v0}, Landroid/graphics/Rect;->setEmpty()V

    .line 1568
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->invalidate()V

    .line 1569
    return-void
.end method

.method public abstract d(I)V
.end method

.method protected dispatchDraw(Landroid/graphics/Canvas;)V
    .registers 3

    .prologue
    .line 2043
    iget-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->l:Z

    .line 2044
    if-nez v0, :cond_7

    .line 2045
    invoke-direct {p0, p1}, Lit/sephiroth/android/library/widget/AbsHListView;->a(Landroid/graphics/Canvas;)V

    .line 2048
    :cond_7
    invoke-super {p0, p1}, Lit/sephiroth/android/library/widget/AdapterView;->dispatchDraw(Landroid/graphics/Canvas;)V

    .line 2050
    if-eqz v0, :cond_f

    .line 2051
    invoke-direct {p0, p1}, Lit/sephiroth/android/library/widget/AbsHListView;->a(Landroid/graphics/Canvas;)V

    .line 2057
    :cond_f
    return-void
.end method

.method protected dispatchSetPressed(Z)V
    .registers 2

    .prologue
    .line 2595
    return-void
.end method

.method public draw(Landroid/graphics/Canvas;)V
    .registers 9

    .prologue
    .line 3372
    invoke-super {p0, p1}, Lit/sephiroth/android/library/widget/AdapterView;->draw(Landroid/graphics/Canvas;)V

    .line 3373
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aP:Lit/sephiroth/android/library/widget/s;

    if-eqz v0, :cond_aa

    .line 3374
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getScrollX()I

    move-result v0

    .line 3375
    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aP:Lit/sephiroth/android/library/widget/s;

    invoke-virtual {v1}, Lit/sephiroth/android/library/widget/s;->a()Z

    move-result v1

    if-nez v1, :cond_5f

    .line 3376
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    move-result v1

    .line 3377
    iget-object v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->u:Landroid/graphics/Rect;

    iget v2, v2, Landroid/graphics/Rect;->top:I

    iget v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aV:I

    add-int/2addr v2, v3

    .line 3378
    iget-object v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->u:Landroid/graphics/Rect;

    iget v3, v3, Landroid/graphics/Rect;->bottom:I

    iget v4, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aW:I

    add-int/2addr v3, v4

    .line 3379
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getHeight()I

    move-result v4

    sub-int/2addr v4, v2

    sub-int v3, v4, v3

    .line 3380
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    .line 3382
    const/4 v4, 0x0

    iget v5, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aR:I

    add-int/2addr v5, v0

    invoke-static {v4, v5}, Ljava/lang/Math;->min(II)I

    move-result v4

    .line 3386
    const/high16 v5, -0x3d4c0000    # -90.0f

    invoke-virtual {p1, v5}, Landroid/graphics/Canvas;->rotate(F)V

    .line 3387
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getHeight()I

    move-result v5

    neg-int v5, v5

    add-int/2addr v5, v2

    int-to-float v5, v5

    int-to-float v6, v4

    invoke-virtual {p1, v5, v6}, Landroid/graphics/Canvas;->translate(FF)V

    .line 3388
    iget-object v5, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aP:Lit/sephiroth/android/library/widget/s;

    invoke-virtual {v5, v3, v3}, Lit/sephiroth/android/library/widget/s;->a(II)V

    .line 3390
    iget-object v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aP:Lit/sephiroth/android/library/widget/s;

    invoke-virtual {v3, p1}, Lit/sephiroth/android/library/widget/s;->a(Landroid/graphics/Canvas;)Z

    move-result v3

    if-eqz v3, :cond_5c

    .line 3391
    iget-object v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aP:Lit/sephiroth/android/library/widget/s;

    invoke-virtual {v3, v4, v2}, Lit/sephiroth/android/library/widget/s;->b(II)V

    .line 3393
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->invalidate()V

    .line 3395
    :cond_5c
    invoke-virtual {p1, v1}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 3397
    :cond_5f
    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aQ:Lit/sephiroth/android/library/widget/s;

    invoke-virtual {v1}, Lit/sephiroth/android/library/widget/s;->a()Z

    move-result v1

    if-nez v1, :cond_aa

    .line 3398
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    move-result v1

    .line 3399
    iget-object v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->u:Landroid/graphics/Rect;

    iget v2, v2, Landroid/graphics/Rect;->left:I

    iget v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aV:I

    add-int/2addr v2, v3

    .line 3400
    iget-object v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->u:Landroid/graphics/Rect;

    iget v3, v3, Landroid/graphics/Rect;->right:I

    iget v4, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aW:I

    add-int/2addr v3, v4

    .line 3401
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getHeight()I

    move-result v4

    sub-int/2addr v4, v2

    sub-int v3, v4, v3

    .line 3402
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v4

    .line 3404
    iget v5, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aS:I

    add-int/2addr v0, v5

    invoke-static {v4, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 3405
    const/high16 v4, 0x42b40000    # 90.0f

    invoke-virtual {p1, v4}, Landroid/graphics/Canvas;->rotate(F)V

    .line 3406
    neg-int v2, v2

    int-to-float v2, v2

    neg-int v0, v0

    int-to-float v0, v0

    invoke-virtual {p1, v2, v0}, Landroid/graphics/Canvas;->translate(FF)V

    .line 3408
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aQ:Lit/sephiroth/android/library/widget/s;

    invoke-virtual {v0, v3, v3}, Lit/sephiroth/android/library/widget/s;->a(II)V

    .line 3410
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aQ:Lit/sephiroth/android/library/widget/s;

    invoke-virtual {v0, p1}, Lit/sephiroth/android/library/widget/s;->a(Landroid/graphics/Canvas;)Z

    move-result v0

    if-eqz v0, :cond_a7

    .line 3414
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->invalidate()V

    .line 3416
    :cond_a7
    invoke-virtual {p1, v1}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 3419
    :cond_aa
    return-void
.end method

.method protected drawableStateChanged()V
    .registers 1

    .prologue
    .line 2225
    invoke-super {p0}, Lit/sephiroth/android/library/widget/AdapterView;->drawableStateChanged()V

    .line 2226
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->C()V

    .line 2227
    return-void
.end method

.method protected e()V
    .registers 1

    .prologue
    .line 1736
    return-void
.end method

.method public e(I)V
    .registers 5

    .prologue
    .line 5202
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aG:I

    if-eq p1, v0, :cond_1c

    .line 5203
    iput p1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aG:I

    .line 5204
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v1

    .line 5205
    const/4 v0, 0x0

    :goto_b
    if-ge v0, v1, :cond_17

    .line 5206
    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2, p1}, Landroid/view/View;->setDrawingCacheBackgroundColor(I)V

    .line 5205
    add-int/lit8 v0, v0, 0x1

    goto :goto_b

    .line 5208
    :cond_17
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->p:Lit/sephiroth/android/library/widget/j;

    invoke-virtual {v0, p1}, Lit/sephiroth/android/library/widget/j;->e(I)V

    .line 5210
    :cond_1c
    return-void
.end method

.method protected final f()V
    .registers 7

    .prologue
    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    .line 1739
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->w:Landroid/view/View;

    if-eqz v0, :cond_2b

    .line 1742
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    if-lez v0, :cond_5c

    move v0, v1

    .line 1745
    :goto_c
    if-nez v0, :cond_23

    .line 1746
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v4

    if-lez v4, :cond_23

    .line 1747
    invoke-virtual {p0, v2}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    .line 1748
    invoke-virtual {v0}, Landroid/view/View;->getLeft()I

    move-result v0

    iget-object v4, p0, Lit/sephiroth/android/library/widget/AbsHListView;->u:Landroid/graphics/Rect;

    iget v4, v4, Landroid/graphics/Rect;->left:I

    if-ge v0, v4, :cond_5e

    move v0, v1

    .line 1752
    :cond_23
    :goto_23
    iget-object v4, p0, Lit/sephiroth/android/library/widget/AbsHListView;->w:Landroid/view/View;

    if-eqz v0, :cond_60

    move v0, v2

    :goto_28
    invoke-virtual {v4, v0}, Landroid/view/View;->setVisibility(I)V

    .line 1755
    :cond_2b
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->x:Landroid/view/View;

    if-eqz v0, :cond_5b

    .line 1757
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v4

    .line 1760
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    add-int/2addr v0, v4

    iget v5, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    if-ge v0, v5, :cond_62

    move v0, v1

    .line 1763
    :goto_3b
    if-nez v0, :cond_68

    if-lez v4, :cond_68

    .line 1764
    add-int/lit8 v0, v4, -0x1

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    .line 1765
    invoke-virtual {v0}, Landroid/view/View;->getRight()I

    move-result v0

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getRight()I

    move-result v4

    iget-object v5, p0, Lit/sephiroth/android/library/widget/AbsHListView;->u:Landroid/graphics/Rect;

    iget v5, v5, Landroid/graphics/Rect;->right:I

    sub-int/2addr v4, v5

    if-le v0, v4, :cond_64

    .line 1768
    :goto_54
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->x:Landroid/view/View;

    if-eqz v1, :cond_66

    :goto_58
    invoke-virtual {v0, v2}, Landroid/view/View;->setVisibility(I)V

    .line 1770
    :cond_5b
    return-void

    :cond_5c
    move v0, v2

    .line 1742
    goto :goto_c

    :cond_5e
    move v0, v2

    .line 1748
    goto :goto_23

    :cond_60
    move v0, v3

    .line 1752
    goto :goto_28

    :cond_62
    move v0, v2

    .line 1760
    goto :goto_3b

    :cond_64
    move v1, v2

    .line 1765
    goto :goto_54

    :cond_66
    move v2, v3

    .line 1768
    goto :goto_58

    :cond_68
    move v1, v0

    goto :goto_54
.end method

.method public final g()Landroid/view/View;
    .registers 3
    .annotation runtime Landroid/view/ViewDebug$ExportedProperty;
    .end annotation

    .prologue
    .line 1775
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    if-lez v0, :cond_12

    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->al:I

    if-ltz v0, :cond_12

    .line 1776
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->al:I

    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    sub-int/2addr v0, v1

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    .line 1778
    :goto_11
    return-object v0

    :cond_12
    const/4 v0, 0x0

    goto :goto_11
.end method

.method protected generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    .registers 2

    .prologue
    .line 5144
    new-instance v0, Lit/sephiroth/android/library/widget/AbsHListView$LayoutParams;

    invoke-direct {v0}, Lit/sephiroth/android/library/widget/AbsHListView$LayoutParams;-><init>()V

    return-object v0
.end method

.method public synthetic generateLayoutParams(Landroid/util/AttributeSet;)Landroid/view/ViewGroup$LayoutParams;
    .registers 4

    .prologue
    .line 59
    new-instance v0, Lit/sephiroth/android/library/widget/AbsHListView$LayoutParams;

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1, p1}, Lit/sephiroth/android/library/widget/AbsHListView$LayoutParams;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-object v0
.end method

.method protected generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
    .registers 3

    .prologue
    .line 5150
    new-instance v0, Lit/sephiroth/android/library/widget/AbsHListView$LayoutParams;

    invoke-direct {v0, p1}, Lit/sephiroth/android/library/widget/AbsHListView$LayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    return-object v0
.end method

.method protected getContextMenuInfo()Landroid/view/ContextMenu$ContextMenuInfo;
    .registers 2

    .prologue
    .line 2522
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ay:Landroid/view/ContextMenu$ContextMenuInfo;

    return-object v0
.end method

.method public getFocusedRect(Landroid/graphics/Rect;)V
    .registers 4

    .prologue
    .line 1257
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->g()Landroid/view/View;

    move-result-object v0

    .line 1258
    if-eqz v0, :cond_13

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    if-ne v1, p0, :cond_13

    .line 1261
    invoke-virtual {v0, p1}, Landroid/view/View;->getFocusedRect(Landroid/graphics/Rect;)V

    .line 1262
    invoke-virtual {p0, v0, p1}, Lit/sephiroth/android/library/widget/AbsHListView;->offsetDescendantRectToMyCoords(Landroid/view/View;Landroid/graphics/Rect;)V

    .line 1267
    :goto_12
    return-void

    .line 1265
    :cond_13
    invoke-super {p0, p1}, Lit/sephiroth/android/library/widget/AdapterView;->getFocusedRect(Landroid/graphics/Rect;)V

    goto :goto_12
.end method

.method protected getHorizontalScrollbarHeight()I
    .registers 2

    .prologue
    .line 1097
    invoke-super {p0}, Lit/sephiroth/android/library/widget/AdapterView;->getHorizontalScrollbarHeight()I

    move-result v0

    return v0
.end method

.method protected getLeftFadingEdgeStrength()F
    .registers 5

    .prologue
    .line 1646
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v1

    .line 1647
    invoke-super {p0}, Lit/sephiroth/android/library/widget/AdapterView;->getLeftFadingEdgeStrength()F

    move-result v0

    .line 1648
    if-nez v1, :cond_b

    .line 1657
    :cond_a
    :goto_a
    return v0

    .line 1651
    :cond_b
    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    if-lez v1, :cond_12

    .line 1652
    const/high16 v0, 0x3f800000    # 1.0f

    goto :goto_a

    .line 1655
    :cond_12
    const/4 v1, 0x0

    invoke-virtual {p0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->getLeft()I

    move-result v1

    .line 1656
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getHorizontalFadingEdgeLength()I

    move-result v2

    int-to-float v2, v2

    .line 1657
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getPaddingLeft()I

    move-result v3

    if-ge v1, v3, :cond_a

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getPaddingLeft()I

    move-result v0

    sub-int v0, v1, v0

    neg-int v0, v0

    int-to-float v0, v0

    div-float/2addr v0, v2

    goto :goto_a
.end method

.method protected getRightFadingEdgeStrength()F
    .registers 6

    .prologue
    .line 1663
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v1

    .line 1664
    invoke-super {p0}, Lit/sephiroth/android/library/widget/AdapterView;->getRightFadingEdgeStrength()F

    move-result v0

    .line 1665
    if-nez v1, :cond_b

    .line 1675
    :cond_a
    :goto_a
    return v0

    .line 1668
    :cond_b
    iget v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    add-int/2addr v2, v1

    add-int/lit8 v2, v2, -0x1

    iget v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    add-int/lit8 v3, v3, -0x1

    if-ge v2, v3, :cond_19

    .line 1669
    const/high16 v0, 0x3f800000    # 1.0f

    goto :goto_a

    .line 1672
    :cond_19
    add-int/lit8 v1, v1, -0x1

    invoke-virtual {p0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->getRight()I

    move-result v1

    .line 1673
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v2

    .line 1674
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getHorizontalFadingEdgeLength()I

    move-result v3

    int-to-float v3, v3

    .line 1675
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getPaddingRight()I

    move-result v4

    sub-int v4, v2, v4

    if-le v1, v4, :cond_a

    sub-int v0, v1, v2

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getPaddingRight()I

    move-result v1

    add-int/2addr v0, v1

    int-to-float v0, v0

    div-float/2addr v0, v3

    goto :goto_a
.end method

.method public getSolidColor()I
    .registers 2

    .prologue
    .line 5188
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aG:I

    return v0
.end method

.method protected final h()Z
    .registers 2

    .prologue
    .line 2105
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->hasFocus()Z

    move-result v0

    if-eqz v0, :cond_c

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->isInTouchMode()Z

    move-result v0

    if-eqz v0, :cond_12

    :cond_c
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->B()Z

    move-result v0

    if-eqz v0, :cond_14

    :cond_12
    const/4 v0, 0x1

    :goto_13
    return v0

    :cond_14
    const/4 v0, 0x0

    goto :goto_13
.end method

.method protected final i()V
    .registers 5

    .prologue
    const/4 v3, 0x1

    .line 2169
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->isEnabled()Z

    move-result v0

    if-eqz v0, :cond_d

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->isClickable()Z

    move-result v0

    if-nez v0, :cond_e

    .line 2204
    :cond_d
    :goto_d
    return-void

    .line 2173
    :cond_e
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->m:Landroid/graphics/drawable/Drawable;

    .line 2174
    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->o:Landroid/graphics/Rect;

    .line 2175
    if-eqz v0, :cond_d

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->isFocused()Z

    move-result v2

    if-nez v2, :cond_20

    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->B()Z

    move-result v2

    if-eqz v2, :cond_d

    :cond_20
    invoke-virtual {v1}, Landroid/graphics/Rect;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_d

    .line 2178
    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->al:I

    iget v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    sub-int/2addr v1, v2

    invoke-virtual {p0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    .line 2180
    if-eqz v1, :cond_3a

    .line 2181
    invoke-virtual {v1}, Landroid/view/View;->hasFocusable()Z

    move-result v2

    if-nez v2, :cond_d

    .line 2182
    invoke-virtual {v1, v3}, Landroid/view/View;->setPressed(Z)V

    .line 2184
    :cond_3a
    invoke-virtual {p0, v3}, Lit/sephiroth/android/library/widget/AbsHListView;->setPressed(Z)V

    .line 2186
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->isLongClickable()Z

    move-result v1

    .line 2187
    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getCurrent()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    .line 2188
    if-eqz v0, :cond_56

    instance-of v2, v0, Landroid/graphics/drawable/TransitionDrawable;

    if-eqz v2, :cond_56

    .line 2189
    if-eqz v1, :cond_78

    .line 2190
    check-cast v0, Landroid/graphics/drawable/TransitionDrawable;

    invoke-static {}, Landroid/view/ViewConfiguration;->getLongPressTimeout()I

    move-result v2

    invoke-virtual {v0, v2}, Landroid/graphics/drawable/TransitionDrawable;->startTransition(I)V

    .line 2196
    :cond_56
    :goto_56
    if-eqz v1, :cond_d

    iget-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ai:Z

    if-nez v0, :cond_d

    .line 2197
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aC:Lit/sephiroth/android/library/widget/b;

    if-nez v0, :cond_68

    .line 2198
    new-instance v0, Lit/sephiroth/android/library/widget/b;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lit/sephiroth/android/library/widget/b;-><init>(Lit/sephiroth/android/library/widget/AbsHListView;B)V

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aC:Lit/sephiroth/android/library/widget/b;

    .line 2200
    :cond_68
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aC:Lit/sephiroth/android/library/widget/b;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/b;->a()V

    .line 2201
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aC:Lit/sephiroth/android/library/widget/b;

    invoke-static {}, Landroid/view/ViewConfiguration;->getLongPressTimeout()I

    move-result v1

    int-to-long v1, v1

    invoke-virtual {p0, v0, v1, v2}, Lit/sephiroth/android/library/widget/AbsHListView;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_d

    .line 2193
    :cond_78
    check-cast v0, Landroid/graphics/drawable/TransitionDrawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/TransitionDrawable;->resetTransition()V

    goto :goto_56
.end method

.method protected j()I
    .registers 2

    .prologue
    .line 4664
    const/4 v0, 0x0

    return v0
.end method

.method public jumpDrawablesToCurrentState()V
    .registers 2
    .annotation build Landroid/annotation/TargetApi;
        value = 0xb
    .end annotation

    .prologue
    .line 2271
    invoke-super {p0}, Lit/sephiroth/android/library/widget/AdapterView;->jumpDrawablesToCurrentState()V

    .line 2272
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->m:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_c

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->m:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->jumpToCurrentState()V

    .line 2273
    :cond_c
    return-void
.end method

.method protected k()I
    .registers 2

    .prologue
    .line 4674
    const/4 v0, 0x0

    return v0
.end method

.method protected final l()V
    .registers 4

    .prologue
    const/4 v2, -0x1

    .line 4687
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->al:I

    if-eq v0, v2, :cond_25

    .line 4688
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->h:I

    const/4 v1, 0x4

    if-eq v0, v1, :cond_e

    .line 4689
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->al:I

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->M:I

    .line 4691
    :cond_e
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aj:I

    if-ltz v0, :cond_1c

    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aj:I

    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->al:I

    if-eq v0, v1, :cond_1c

    .line 4692
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aj:I

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->M:I

    .line 4694
    :cond_1c
    invoke-virtual {p0, v2}, Lit/sephiroth/android/library/widget/AbsHListView;->h(I)V

    .line 4695
    invoke-virtual {p0, v2}, Lit/sephiroth/android/library/widget/AbsHListView;->i(I)V

    .line 4696
    const/4 v0, 0x0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->J:I

    .line 4698
    :cond_25
    return-void
.end method

.method protected final m()I
    .registers 3

    .prologue
    .line 4705
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->al:I

    .line 4706
    if-gez v0, :cond_6

    .line 4707
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->M:I

    .line 4709
    :cond_6
    const/4 v1, 0x0

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    .line 4710
    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    add-int/lit8 v1, v1, -0x1

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    .line 4711
    return v0
.end method

.method protected final n()Z
    .registers 2

    .prologue
    .line 4754
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->al:I

    if-gez v0, :cond_f

    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->I()Z

    move-result v0

    if-eqz v0, :cond_f

    .line 4755
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->C()V

    .line 4756
    const/4 v0, 0x1

    .line 4758
    :goto_e
    return v0

    :cond_f
    const/4 v0, 0x0

    goto :goto_e
.end method

.method protected final o()V
    .registers 13

    .prologue
    .line 4925
    iget v8, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    .line 4926
    iget v9, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ba:I

    .line 4927
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ba:I

    .line 4929
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x10

    if-lt v0, v1, :cond_c4

    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->b:I

    if-eqz v0, :cond_c4

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    if-eqz v0, :cond_c4

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    invoke-interface {v0}, Landroid/widget/ListAdapter;->hasStableIds()Z

    move-result v0

    if-eqz v0, :cond_c4

    .line 4931
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->f:Landroid/util/SparseBooleanArray;

    invoke-virtual {v0}, Landroid/util/SparseBooleanArray;->clear()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    move v5, v1

    move v1, v0

    :goto_27
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    invoke-virtual {v0}, Landroid/support/v4/c/e;->a()I

    move-result v0

    if-ge v1, v0, :cond_b7

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    invoke-virtual {v0, v1}, Landroid/support/v4/c/e;->a(I)J

    move-result-wide v3

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    invoke-virtual {v0, v1}, Landroid/support/v4/c/e;->b(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v2

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    invoke-interface {v0, v2}, Landroid/widget/ListAdapter;->getItemId(I)J

    move-result-wide v6

    cmp-long v0, v3, v6

    if-eqz v0, :cond_ae

    const/4 v0, 0x0

    add-int/lit8 v6, v2, -0x14

    invoke-static {v0, v6}, Ljava/lang/Math;->max(II)I

    move-result v6

    add-int/lit8 v0, v2, 0x14

    iget v7, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    invoke-static {v0, v7}, Ljava/lang/Math;->min(II)I

    move-result v7

    const/4 v0, 0x0

    :goto_5b
    if-ge v6, v7, :cond_77

    iget-object v10, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    invoke-interface {v10, v6}, Landroid/widget/ListAdapter;->getItemId(I)J

    move-result-wide v10

    cmp-long v10, v3, v10

    if-nez v10, :cond_ab

    const/4 v0, 0x1

    iget-object v7, p0, Lit/sephiroth/android/library/widget/AbsHListView;->f:Landroid/util/SparseBooleanArray;

    const/4 v10, 0x1

    invoke-virtual {v7, v6, v10}, Landroid/util/SparseBooleanArray;->put(IZ)V

    iget-object v7, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v7, v1, v6}, Landroid/support/v4/c/e;->a(ILjava/lang/Object;)V

    :cond_77
    if-nez v0, :cond_a3

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    invoke-virtual {v0, v3, v4}, Landroid/support/v4/c/e;->a(J)V

    add-int/lit8 v6, v1, -0x1

    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->e:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->e:I

    const/4 v7, 0x1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0xb

    if-le v0, v1, :cond_a1

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->c:Ljava/lang/Object;

    if-eqz v0, :cond_a1

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->d:Ljava/lang/Object;

    if-eqz v0, :cond_a1

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->d:Ljava/lang/Object;

    check-cast v0, Lit/sephiroth/android/library/a/a/b;

    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->c:Ljava/lang/Object;

    check-cast v1, Landroid/view/ActionMode;

    const/4 v5, 0x0

    invoke-virtual/range {v0 .. v5}, Lit/sephiroth/android/library/a/a/b;->a(Landroid/view/ActionMode;IJZ)V

    :cond_a1
    move v1, v6

    move v5, v7

    :cond_a3
    move v0, v1

    move v1, v5

    :goto_a5
    add-int/lit8 v0, v0, 0x1

    move v5, v1

    move v1, v0

    goto/16 :goto_27

    :cond_ab
    add-int/lit8 v6, v6, 0x1

    goto :goto_5b

    :cond_ae
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->f:Landroid/util/SparseBooleanArray;

    const/4 v3, 0x1

    invoke-virtual {v0, v2, v3}, Landroid/util/SparseBooleanArray;->put(IZ)V

    move v0, v1

    move v1, v5

    goto :goto_a5

    :cond_b7
    if-eqz v5, :cond_c4

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->c:Ljava/lang/Object;

    if-eqz v0, :cond_c4

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->c:Ljava/lang/Object;

    check-cast v0, Landroid/view/ActionMode;

    invoke-virtual {v0}, Landroid/view/ActionMode;->invalidate()V

    .line 4935
    :cond_c4
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->p:Lit/sephiroth/android/library/widget/j;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/j;->c()V

    .line 4937
    if-lez v8, :cond_19c

    .line 4942
    iget-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ac:Z

    if-eqz v0, :cond_11d

    .line 4944
    const/4 v0, 0x0

    iput-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ac:Z

    .line 4945
    const/4 v0, 0x0

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->bb:Lit/sephiroth/android/library/widget/AbsHListView$SavedState;

    .line 4947
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aF:I

    const/4 v1, 0x2

    if-ne v0, v1, :cond_de

    .line 4948
    const/4 v0, 0x3

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->h:I

    .line 5064
    :cond_dd
    :goto_dd
    return-void

    .line 4950
    :cond_de
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aF:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_118

    .line 4951
    iget-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aU:Z

    if-eqz v0, :cond_ee

    .line 4952
    const/4 v0, 0x0

    iput-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aU:Z

    .line 4953
    const/4 v0, 0x3

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->h:I

    goto :goto_dd

    .line 4956
    :cond_ee
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v2

    .line 4957
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v0

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getPaddingRight()I

    move-result v1

    sub-int v1, v0, v1

    .line 4958
    add-int/lit8 v0, v2, -0x1

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    .line 4959
    if-eqz v0, :cond_113

    invoke-virtual {v0}, Landroid/view/View;->getBottom()I

    move-result v0

    .line 4960
    :goto_108
    iget v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    add-int/2addr v2, v3

    if-lt v2, v9, :cond_115

    if-gt v0, v1, :cond_115

    .line 4962
    const/4 v0, 0x3

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->h:I

    goto :goto_dd

    :cond_113
    move v0, v1

    .line 4959
    goto :goto_108

    .line 4967
    :cond_115
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->awakenScrollBars()Z

    .line 4970
    :cond_118
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ad:I

    packed-switch v0, :pswitch_data_1c2

    .line 5018
    :cond_11d
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->isInTouchMode()Z

    move-result v0

    if-nez v0, :cond_198

    .line 5020
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->r()I

    move-result v0

    .line 5023
    if-lt v0, v8, :cond_12b

    .line 5024
    add-int/lit8 v0, v8, -0x1

    .line 5026
    :cond_12b
    if-gez v0, :cond_12e

    .line 5027
    const/4 v0, 0x0

    .line 5031
    :cond_12e
    const/4 v1, 0x1

    invoke-virtual {p0, v0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->a(IZ)I

    move-result v1

    .line 5033
    if-ltz v1, :cond_18c

    .line 5034
    invoke-virtual {p0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->i(I)V

    goto :goto_dd

    .line 4972
    :pswitch_139
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->isInTouchMode()Z

    move-result v0

    if-eqz v0, :cond_152

    .line 4977
    const/4 v0, 0x5

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->h:I

    .line 4978
    const/4 v0, 0x0

    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->Z:I

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    add-int/lit8 v1, v8, -0x1

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->Z:I

    goto :goto_dd

    .line 4984
    :cond_152
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->y()I

    move-result v0

    .line 4985
    if-ltz v0, :cond_11d

    .line 4987
    const/4 v1, 0x1

    invoke-virtual {p0, v0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->a(IZ)I

    move-result v1

    .line 4988
    if-ne v1, v0, :cond_11d

    .line 4990
    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->Z:I

    .line 4992
    iget-wide v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ab:J

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v3

    int-to-long v3, v3

    cmp-long v1, v1, v3

    if-nez v1, :cond_174

    .line 4995
    const/4 v1, 0x5

    iput v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->h:I

    .line 5003
    :goto_16f
    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->i(I)V

    goto/16 :goto_dd

    .line 4999
    :cond_174
    const/4 v1, 0x2

    iput v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->h:I

    goto :goto_16f

    .line 5011
    :pswitch_178
    const/4 v0, 0x5

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->h:I

    .line 5012
    const/4 v0, 0x0

    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->Z:I

    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    move-result v0

    add-int/lit8 v1, v8, -0x1

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->Z:I

    goto/16 :goto_dd

    .line 5038
    :cond_18c
    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->a(IZ)I

    move-result v0

    .line 5039
    if-ltz v0, :cond_19c

    .line 5040
    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->i(I)V

    goto/16 :goto_dd

    .line 5047
    :cond_198
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->M:I

    if-gez v0, :cond_dd

    .line 5055
    :cond_19c
    iget-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->K:Z

    if-eqz v0, :cond_1bf

    const/4 v0, 0x3

    :goto_1a1
    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->h:I

    .line 5056
    const/4 v0, -0x1

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->al:I

    .line 5057
    const-wide/high16 v0, -0x8000000000000000L

    iput-wide v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->am:J

    .line 5058
    const/4 v0, -0x1

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aj:I

    .line 5059
    const-wide/high16 v0, -0x8000000000000000L

    iput-wide v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ak:J

    .line 5060
    const/4 v0, 0x0

    iput-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ac:Z

    .line 5061
    const/4 v0, 0x0

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->bb:Lit/sephiroth/android/library/widget/AbsHListView$SavedState;

    .line 5062
    const/4 v0, -0x1

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->n:I

    .line 5063
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->x()V

    goto/16 :goto_dd

    .line 5055
    :cond_1bf
    const/4 v0, 0x1

    goto :goto_1a1

    .line 4970
    nop

    :pswitch_data_1c2
    .packed-switch 0x0
        :pswitch_139
        :pswitch_178
    .end packed-switch
.end method

.method protected onAttachedToWindow()V
    .registers 4

    .prologue
    const/4 v2, 0x1

    .line 2277
    invoke-super {p0}, Lit/sephiroth/android/library/widget/AdapterView;->onAttachedToWindow()V

    .line 2279
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    .line 2280
    invoke-virtual {v0, p0}, Landroid/view/ViewTreeObserver;->addOnTouchModeChangeListener(Landroid/view/ViewTreeObserver$OnTouchModeChangeListener;)V

    .line 2282
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    if-eqz v0, :cond_2f

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->i:Lit/sephiroth/android/library/widget/a;

    if-nez v0, :cond_2f

    .line 2283
    new-instance v0, Lit/sephiroth/android/library/widget/a;

    invoke-direct {v0, p0}, Lit/sephiroth/android/library/widget/a;-><init>(Lit/sephiroth/android/library/widget/AbsHListView;)V

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->i:Lit/sephiroth/android/library/widget/a;

    .line 2284
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->i:Lit/sephiroth/android/library/widget/a;

    invoke-interface {v0, v1}, Landroid/widget/ListAdapter;->registerDataSetObserver(Landroid/database/DataSetObserver;)V

    .line 2287
    iput-boolean v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ai:Z

    .line 2288
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ao:I

    .line 2289
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    invoke-interface {v0}, Landroid/widget/ListAdapter;->getCount()I

    move-result v0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    .line 2291
    :cond_2f
    iput-boolean v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->S:Z

    .line 2292
    return-void
.end method

.method protected onCreateDrawableState(I)[I
    .registers 7

    .prologue
    .line 2232
    iget-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aH:Z

    if-eqz v0, :cond_9

    .line 2234
    invoke-super {p0, p1}, Lit/sephiroth/android/library/widget/AdapterView;->onCreateDrawableState(I)[I

    move-result-object v0

    .line 2260
    :cond_8
    :goto_8
    return-object v0

    .line 2240
    :cond_9
    sget-object v0, Lit/sephiroth/android/library/widget/AbsHListView;->ENABLED_STATE_SET:[I

    const/4 v1, 0x0

    aget v3, v0, v1

    .line 2245
    add-int/lit8 v0, p1, 0x1

    invoke-super {p0, v0}, Lit/sephiroth/android/library/widget/AdapterView;->onCreateDrawableState(I)[I

    move-result-object v0

    .line 2246
    const/4 v2, -0x1

    .line 2247
    array-length v1, v0

    add-int/lit8 v1, v1, -0x1

    :goto_18
    if-ltz v1, :cond_2d

    .line 2248
    aget v4, v0, v1

    if-ne v4, v3, :cond_2a

    .line 2255
    :goto_1e
    if-ltz v1, :cond_8

    .line 2256
    add-int/lit8 v2, v1, 0x1

    array-length v3, v0

    sub-int/2addr v3, v1

    add-int/lit8 v3, v3, -0x1

    invoke-static {v0, v2, v0, v1, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    goto :goto_8

    .line 2247
    :cond_2a
    add-int/lit8 v1, v1, -0x1

    goto :goto_18

    :cond_2d
    move v1, v2

    goto :goto_1e
.end method

.method public onCreateInputConnection(Landroid/view/inputmethod/EditorInfo;)Landroid/view/inputmethod/InputConnection;
    .registers 3

    .prologue
    .line 5131
    const/4 v0, 0x0

    return-object v0
.end method

.method protected onDetachedFromWindow()V
    .registers 4

    .prologue
    const/4 v2, 0x0

    .line 2296
    invoke-super {p0}, Lit/sephiroth/android/library/widget/AdapterView;->onDetachedFromWindow()V

    .line 2301
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->p:Lit/sephiroth/android/library/widget/j;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/j;->b()V

    .line 2303
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object v0

    .line 2304
    invoke-virtual {v0, p0}, Landroid/view/ViewTreeObserver;->removeOnTouchModeChangeListener(Landroid/view/ViewTreeObserver$OnTouchModeChangeListener;)V

    .line 2306
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    if-eqz v0, :cond_21

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->i:Lit/sephiroth/android/library/widget/a;

    if-eqz v0, :cond_21

    .line 2307
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->i:Lit/sephiroth/android/library/widget/a;

    invoke-interface {v0, v1}, Landroid/widget/ListAdapter;->unregisterDataSetObserver(Landroid/database/DataSetObserver;)V

    .line 2308
    iput-object v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->i:Lit/sephiroth/android/library/widget/a;

    .line 2311
    :cond_21
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    if-eqz v0, :cond_2a

    .line 2312
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 2315
    :cond_2a
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->I:Lit/sephiroth/android/library/widget/i;

    if-eqz v0, :cond_33

    .line 2316
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->I:Lit/sephiroth/android/library/widget/i;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/i;->a()V

    .line 2319
    :cond_33
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aK:Ljava/lang/Runnable;

    if-eqz v0, :cond_3c

    .line 2320
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aK:Ljava/lang/Runnable;

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 2323
    :cond_3c
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aD:Lit/sephiroth/android/library/widget/h;

    if-eqz v0, :cond_45

    .line 2324
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aD:Lit/sephiroth/android/library/widget/h;

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 2327
    :cond_45
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aE:Ljava/lang/Runnable;

    if-eqz v0, :cond_50

    .line 2328
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aE:Ljava/lang/Runnable;

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 2329
    iput-object v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aE:Ljava/lang/Runnable;

    .line 2331
    :cond_50
    const/4 v0, 0x0

    iput-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->S:Z

    .line 2332
    return-void
.end method

.method protected onFocusChanged(ZILandroid/graphics/Rect;)V
    .registers 5

    .prologue
    .line 1531
    invoke-super {p0, p1, p2, p3}, Lit/sephiroth/android/library/widget/AdapterView;->onFocusChanged(ZILandroid/graphics/Rect;)V

    .line 1532
    if-eqz p1, :cond_29

    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->al:I

    if-gez v0, :cond_29

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->isInTouchMode()Z

    move-result v0

    if-nez v0, :cond_29

    .line 1533
    iget-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->S:Z

    if-nez v0, :cond_26

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    if-eqz v0, :cond_26

    .line 1536
    const/4 v0, 0x1

    iput-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ai:Z

    .line 1537
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ao:I

    .line 1538
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    invoke-interface {v0}, Landroid/widget/ListAdapter;->getCount()I

    move-result v0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    .line 1540
    :cond_26
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->I()Z

    .line 1542
    :cond_29
    return-void
.end method

.method public onGenericMotionEvent(Landroid/view/MotionEvent;)Z
    .registers 8
    .annotation build Landroid/annotation/TargetApi;
        value = 0xc
    .end annotation

    .prologue
    const/4 v0, 0x1

    const/4 v3, 0x0

    .line 3320
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getSource()I

    move-result v1

    and-int/lit8 v1, v1, 0x2

    if-eqz v1, :cond_11

    .line 3321
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v1

    packed-switch v1, :pswitch_data_82

    .line 3335
    :cond_11
    invoke-super {p0, p1}, Lit/sephiroth/android/library/widget/AdapterView;->onGenericMotionEvent(Landroid/view/MotionEvent;)Z

    move-result v0

    :goto_15
    return v0

    .line 3323
    :pswitch_16
    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    const/4 v2, -0x1

    if-ne v1, v2, :cond_11

    .line 3324
    const/16 v1, 0xa

    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getAxisValue(I)F

    move-result v1

    .line 3325
    cmpl-float v2, v1, v3

    if-eqz v2, :cond_11

    .line 3326
    iget v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->bc:F

    cmpl-float v2, v2, v3

    if-nez v2, :cond_66

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const-string v3, "sephiroth_listPreferredItemWidth"

    const-string v4, "attr"

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getContext()Landroid/content/Context;

    move-result-object v5

    invoke-virtual {v5}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v3, v4, v5}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v2

    if-eqz v2, :cond_79

    new-instance v3, Landroid/util/TypedValue;

    invoke-direct {v3}, Landroid/util/TypedValue;-><init>()V

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getContext()Landroid/content/Context;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v4

    invoke-virtual {v4, v2, v3, v0}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    move-result v2

    if-eqz v2, :cond_71

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    invoke-virtual {v3, v2}, Landroid/util/TypedValue;->getDimension(Landroid/util/DisplayMetrics;)F

    move-result v2

    iput v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->bc:F

    :cond_66
    iget v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->bc:F

    mul-float/2addr v1, v2

    float-to-int v1, v1

    .line 3327
    invoke-virtual {p0, v1, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->a(II)Z

    move-result v1

    if-nez v1, :cond_11

    goto :goto_15

    .line 3326
    :cond_71
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Expected theme to define sephiroth_listPreferredItemWidth."

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_79
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "Expected theme to define sephiroth_listPreferredItemWidth."

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 3321
    nop

    :pswitch_data_82
    .packed-switch 0x8
        :pswitch_16
    .end packed-switch
.end method

.method public onInitializeAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V
    .registers 3

    .prologue
    .line 1174
    invoke-super {p0, p1}, Lit/sephiroth/android/library/widget/AdapterView;->onInitializeAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V

    .line 1175
    const-class v0, Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityEvent;->setClassName(Ljava/lang/CharSequence;)V

    .line 1176
    return-void
.end method

.method public onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .registers 4
    .annotation build Landroid/annotation/TargetApi;
        value = 0xe
    .end annotation

    .prologue
    .line 1181
    invoke-super {p0, p1}, Lit/sephiroth/android/library/widget/AdapterView;->onInitializeAccessibilityNodeInfo(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    .line 1183
    const-class v0, Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->setClassName(Ljava/lang/CharSequence;)V

    .line 1184
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->isEnabled()Z

    move-result v0

    if-eqz v0, :cond_2e

    .line 1185
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->u()I

    move-result v0

    if-lez v0, :cond_1d

    .line 1186
    const/16 v0, 0x2000

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->addAction(I)V

    .line 1188
    :cond_1d
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->v()I

    move-result v0

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->t()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    if-ge v0, v1, :cond_2e

    .line 1189
    const/16 v0, 0x1000

    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityNodeInfo;->addAction(I)V

    .line 1192
    :cond_2e
    return-void
.end method

.method public onInterceptTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 10

    .prologue
    const/4 v7, 0x4

    const/4 v2, 0x1

    const/4 v4, -0x1

    const/4 v1, 0x0

    .line 3457
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    .line 3460
    iget-object v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->I:Lit/sephiroth/android/library/widget/i;

    if-eqz v3, :cond_11

    .line 3461
    iget-object v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->I:Lit/sephiroth/android/library/widget/i;

    invoke-virtual {v3}, Lit/sephiroth/android/library/widget/i;->a()V

    .line 3464
    :cond_11
    iget-boolean v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->S:Z

    if-nez v3, :cond_16

    .line 3539
    :cond_15
    :goto_15
    return v1

    .line 3472
    :cond_16
    and-int/lit16 v0, v0, 0xff

    packed-switch v0, :pswitch_data_b2

    :pswitch_1b
    goto :goto_15

    .line 3474
    :pswitch_1c
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 3475
    const/4 v3, 0x6

    if-eq v0, v3, :cond_24

    const/4 v3, 0x5

    if-ne v0, v3, :cond_28

    .line 3476
    :cond_24
    iput v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->H:I

    move v1, v2

    .line 3477
    goto :goto_15

    .line 3480
    :cond_28
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v3

    float-to-int v3, v3

    .line 3481
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v4

    float-to-int v4, v4

    .line 3482
    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v5

    iput v5, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aO:I

    .line 3484
    invoke-virtual {p0, v3}, Lit/sephiroth/android/library/widget/AbsHListView;->c(I)I

    move-result v5

    .line 3485
    if-eq v0, v7, :cond_59

    if-ltz v5, :cond_59

    .line 3488
    iget v6, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    sub-int v6, v5, v6

    invoke-virtual {p0, v6}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v6

    .line 3489
    invoke-virtual {v6}, Landroid/view/View;->getLeft()I

    move-result v6

    iput v6, p0, Lit/sephiroth/android/library/widget/AbsHListView;->B:I

    .line 3490
    iput v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->D:I

    .line 3491
    iput v4, p0, Lit/sephiroth/android/library/widget/AbsHListView;->E:I

    .line 3492
    iput v5, p0, Lit/sephiroth/android/library/widget/AbsHListView;->A:I

    .line 3493
    iput v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 3494
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->H()V

    .line 3496
    :cond_59
    const/high16 v3, -0x80000000

    iput v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->G:I

    .line 3497
    iget-object v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->at:Landroid/view/VelocityTracker;

    if-nez v3, :cond_70

    invoke-static {}, Landroid/view/VelocityTracker;->obtain()Landroid/view/VelocityTracker;

    move-result-object v3

    iput-object v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->at:Landroid/view/VelocityTracker;

    .line 3498
    :goto_67
    iget-object v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->at:Landroid/view/VelocityTracker;

    invoke-virtual {v3, p1}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    .line 3499
    if-ne v0, v7, :cond_15

    move v1, v2

    .line 3500
    goto :goto_15

    .line 3497
    :cond_70
    iget-object v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->at:Landroid/view/VelocityTracker;

    invoke-virtual {v3}, Landroid/view/VelocityTracker;->clear()V

    goto :goto_67

    .line 3506
    :pswitch_76
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    packed-switch v0, :pswitch_data_c4

    goto :goto_15

    .line 3508
    :pswitch_7c
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aO:I

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    move-result v0

    .line 3509
    if-ne v0, v4, :cond_8b

    .line 3511
    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aO:I

    move v0, v1

    .line 3513
    :cond_8b
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    move-result v0

    float-to-int v0, v0

    .line 3514
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->E()V

    .line 3515
    iget-object v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->at:Landroid/view/VelocityTracker;

    invoke-virtual {v3, p1}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    .line 3516
    invoke-direct {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->j(I)Z

    move-result v0

    if-eqz v0, :cond_15

    move v1, v2

    .line 3517
    goto/16 :goto_15

    .line 3526
    :pswitch_a1
    iput v4, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 3527
    iput v4, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aO:I

    .line 3528
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->F()V

    .line 3529
    invoke-virtual {p0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->a(I)V

    goto/16 :goto_15

    .line 3534
    :pswitch_ad
    invoke-direct {p0, p1}, Lit/sephiroth/android/library/widget/AbsHListView;->a(Landroid/view/MotionEvent;)V

    goto/16 :goto_15

    .line 3472
    :pswitch_data_b2
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_a1
        :pswitch_76
        :pswitch_a1
        :pswitch_1b
        :pswitch_1b
        :pswitch_ad
    .end packed-switch

    .line 3506
    :pswitch_data_c4
    .packed-switch 0x0
        :pswitch_7c
    .end packed-switch
.end method

.method public onKeyDown(ILandroid/view/KeyEvent;)Z
    .registers 4

    .prologue
    .line 2563
    const/4 v0, 0x0

    return v0
.end method

.method public onKeyUp(ILandroid/view/KeyEvent;)Z
    .registers 9

    .prologue
    const/4 v0, 0x1

    const/4 v5, 0x0

    .line 2568
    sparse-switch p1, :sswitch_data_48

    .line 2588
    :cond_5
    invoke-super {p0, p1, p2}, Lit/sephiroth/android/library/widget/AdapterView;->onKeyUp(ILandroid/view/KeyEvent;)Z

    move-result v0

    :cond_9
    :goto_9
    return v0

    .line 2571
    :sswitch_a
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->isEnabled()Z

    move-result v1

    if-eqz v1, :cond_9

    .line 2574
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->isClickable()Z

    move-result v1

    if-eqz v1, :cond_5

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->isPressed()Z

    move-result v1

    if-eqz v1, :cond_5

    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->al:I

    if-ltz v1, :cond_5

    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    if-eqz v1, :cond_5

    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->al:I

    iget-object v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    invoke-interface {v2}, Landroid/widget/ListAdapter;->getCount()I

    move-result v2

    if-ge v1, v2, :cond_5

    .line 2578
    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->al:I

    iget v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    sub-int/2addr v1, v2

    invoke-virtual {p0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    .line 2579
    if-eqz v1, :cond_43

    .line 2580
    iget v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->al:I

    iget-wide v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->am:J

    invoke-virtual {p0, v1, v2, v3, v4}, Lit/sephiroth/android/library/widget/AbsHListView;->a(Landroid/view/View;IJ)Z

    .line 2581
    invoke-virtual {v1, v5}, Landroid/view/View;->setPressed(Z)V

    .line 2583
    :cond_43
    invoke-virtual {p0, v5}, Lit/sephiroth/android/library/widget/AbsHListView;->setPressed(Z)V

    goto :goto_9

    .line 2568
    nop

    :sswitch_data_48
    .sparse-switch
        0x17 -> :sswitch_a
        0x42 -> :sswitch_a
    .end sparse-switch
.end method

.method protected onLayout(ZIIII)V
    .registers 10

    .prologue
    const/4 v1, 0x0

    .line 1706
    invoke-super/range {p0 .. p5}, Lit/sephiroth/android/library/widget/AdapterView;->onLayout(ZIIII)V

    .line 1707
    const/4 v0, 0x1

    iput-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ae:Z

    .line 1708
    if-eqz p1, :cond_1f

    .line 1709
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v2

    move v0, v1

    .line 1710
    :goto_e
    if-ge v0, v2, :cond_1a

    .line 1711
    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/View;->forceLayout()V

    .line 1710
    add-int/lit8 v0, v0, 0x1

    goto :goto_e

    .line 1713
    :cond_1a
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->p:Lit/sephiroth/android/library/widget/j;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/j;->a()V

    .line 1716
    :cond_1f
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->e()V

    .line 1717
    iput-boolean v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ae:Z

    .line 1719
    sub-int v0, p4, p2

    div-int/lit8 v0, v0, 0x3

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->N:I

    .line 1720
    return-void
.end method

.method protected onMeasure(II)V
    .registers 8

    .prologue
    const/4 v2, 0x1

    .line 1682
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->m:Landroid/graphics/drawable/Drawable;

    if-nez v0, :cond_13

    .line 1683
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const v1, 0x1080062

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    move-result-object v0

    invoke-direct {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->a(Landroid/graphics/drawable/Drawable;)V

    .line 1685
    :cond_13
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->u:Landroid/graphics/Rect;

    .line 1686
    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->q:I

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getPaddingLeft()I

    move-result v3

    add-int/2addr v1, v3

    iput v1, v0, Landroid/graphics/Rect;->left:I

    .line 1687
    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->r:I

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getPaddingTop()I

    move-result v3

    add-int/2addr v1, v3

    iput v1, v0, Landroid/graphics/Rect;->top:I

    .line 1688
    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->s:I

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getPaddingRight()I

    move-result v3

    add-int/2addr v1, v3

    iput v1, v0, Landroid/graphics/Rect;->right:I

    .line 1689
    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->t:I

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getPaddingBottom()I

    move-result v3

    add-int/2addr v1, v3

    iput v1, v0, Landroid/graphics/Rect;->bottom:I

    .line 1692
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aF:I

    if-ne v0, v2, :cond_63

    .line 1693
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v3

    .line 1694
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v0

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getPaddingRight()I

    move-result v1

    sub-int v1, v0, v1

    .line 1695
    add-int/lit8 v0, v3, -0x1

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    .line 1696
    if-eqz v0, :cond_64

    invoke-virtual {v0}, Landroid/view/View;->getRight()I

    move-result v0

    .line 1697
    :goto_57
    iget v4, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    add-int/2addr v3, v4

    iget v4, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ba:I

    if-lt v3, v4, :cond_66

    if-gt v0, v1, :cond_66

    move v0, v2

    :goto_61
    iput-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aU:Z

    .line 1699
    :cond_63
    return-void

    :cond_64
    move v0, v1

    .line 1696
    goto :goto_57

    .line 1697
    :cond_66
    const/4 v0, 0x0

    goto :goto_61
.end method

.method protected onOverScrolled(IIZZ)V
    .registers 8

    .prologue
    .line 3308
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getScrollX()I

    move-result v0

    if-eq v0, p1, :cond_20

    .line 3309
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getScrollY()I

    move-result v0

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getScrollX()I

    move-result v1

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getScrollY()I

    move-result v2

    invoke-virtual {p0, p1, v0, v1, v2}, Lit/sephiroth/android/library/widget/AbsHListView;->onScrollChanged(IIII)V

    .line 3310
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->a:Lit/sephiroth/android/library/a/b;

    invoke-virtual {v0, p1}, Lit/sephiroth/android/library/a/b;->a(I)V

    .line 3311
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->D()V

    .line 3313
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->awakenScrollBars()Z

    .line 3315
    :cond_20
    return-void
.end method

.method public onRestoreInstanceState(Landroid/os/Parcelable;)V
    .registers 8

    .prologue
    const-wide/16 v4, 0x0

    const/4 v3, -0x1

    const/4 v2, 0x1

    .line 1483
    check-cast p1, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;

    .line 1485
    invoke-virtual {p1}, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->getSuperState()Landroid/os/Parcelable;

    move-result-object v0

    invoke-super {p0, v0}, Lit/sephiroth/android/library/widget/AdapterView;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    .line 1486
    iput-boolean v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ai:Z

    .line 1488
    iget v0, p1, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->e:I

    int-to-long v0, v0

    iput-wide v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ab:J

    .line 1490
    iget-wide v0, p1, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->a:J

    cmp-long v0, v0, v4

    if-ltz v0, :cond_62

    .line 1491
    iput-boolean v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ac:Z

    .line 1492
    iput-object p1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->bb:Lit/sephiroth/android/library/widget/AbsHListView$SavedState;

    .line 1493
    iget-wide v0, p1, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->a:J

    iput-wide v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aa:J

    .line 1494
    iget v0, p1, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->d:I

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->Z:I

    .line 1495
    iget v0, p1, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->c:I

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->W:I

    .line 1496
    const/4 v0, 0x0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ad:I

    .line 1510
    :cond_2d
    :goto_2d
    iget-object v0, p1, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->i:Landroid/util/SparseBooleanArray;

    if-eqz v0, :cond_35

    .line 1511
    iget-object v0, p1, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->i:Landroid/util/SparseBooleanArray;

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->f:Landroid/util/SparseBooleanArray;

    .line 1514
    :cond_35
    iget-object v0, p1, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->j:Landroid/support/v4/c/e;

    if-eqz v0, :cond_3d

    .line 1515
    iget-object v0, p1, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->j:Landroid/support/v4/c/e;

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    .line 1518
    :cond_3d
    iget v0, p1, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->h:I

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->e:I

    .line 1520
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0xb

    if-lt v0, v1, :cond_5e

    .line 1521
    iget-boolean v0, p1, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->g:Z

    if-eqz v0, :cond_5e

    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->b:I

    const/4 v1, 0x3

    if-ne v0, v1, :cond_5e

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->d:Ljava/lang/Object;

    if-eqz v0, :cond_5e

    .line 1522
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->d:Ljava/lang/Object;

    check-cast v0, Lit/sephiroth/android/library/a/a/b;

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->startActionMode(Landroid/view/ActionMode$Callback;)Landroid/view/ActionMode;

    move-result-object v0

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->c:Ljava/lang/Object;

    .line 1526
    :cond_5e
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->requestLayout()V

    .line 1527
    return-void

    .line 1497
    :cond_62
    iget-wide v0, p1, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->b:J

    cmp-long v0, v0, v4

    if-ltz v0, :cond_2d

    .line 1498
    invoke-virtual {p0, v3}, Lit/sephiroth/android/library/widget/AbsHListView;->h(I)V

    .line 1500
    invoke-virtual {p0, v3}, Lit/sephiroth/android/library/widget/AbsHListView;->i(I)V

    .line 1501
    iput v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->n:I

    .line 1502
    iput-boolean v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ac:Z

    .line 1503
    iput-object p1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->bb:Lit/sephiroth/android/library/widget/AbsHListView$SavedState;

    .line 1504
    iget-wide v0, p1, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->b:J

    iput-wide v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aa:J

    .line 1505
    iget v0, p1, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->d:I

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->Z:I

    .line 1506
    iget v0, p1, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->c:I

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->W:I

    .line 1507
    iput v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ad:I

    goto :goto_2d
.end method

.method public onSaveInstanceState()Landroid/os/Parcelable;
    .registers 11

    .prologue
    const-wide/16 v8, -0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    .line 1401
    invoke-super {p0}, Lit/sephiroth/android/library/widget/AdapterView;->onSaveInstanceState()Landroid/os/Parcelable;

    move-result-object v0

    .line 1403
    new-instance v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;

    invoke-direct {v3, v0}, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;-><init>(Landroid/os/Parcelable;)V

    .line 1405
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->bb:Lit/sephiroth/android/library/widget/AbsHListView$SavedState;

    if-eqz v0, :cond_4f

    .line 1407
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->bb:Lit/sephiroth/android/library/widget/AbsHListView$SavedState;

    iget-wide v0, v0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->a:J

    iput-wide v0, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->a:J

    .line 1408
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->bb:Lit/sephiroth/android/library/widget/AbsHListView$SavedState;

    iget-wide v0, v0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->b:J

    iput-wide v0, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->b:J

    .line 1409
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->bb:Lit/sephiroth/android/library/widget/AbsHListView$SavedState;

    iget v0, v0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->c:I

    iput v0, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->c:I

    .line 1410
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->bb:Lit/sephiroth/android/library/widget/AbsHListView$SavedState;

    iget v0, v0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->d:I

    iput v0, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->d:I

    .line 1411
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->bb:Lit/sephiroth/android/library/widget/AbsHListView$SavedState;

    iget v0, v0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->e:I

    iput v0, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->e:I

    .line 1412
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->bb:Lit/sephiroth/android/library/widget/AbsHListView$SavedState;

    iget-object v0, v0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->f:Ljava/lang/String;

    iput-object v0, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->f:Ljava/lang/String;

    .line 1413
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->bb:Lit/sephiroth/android/library/widget/AbsHListView$SavedState;

    iget-boolean v0, v0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->g:Z

    iput-boolean v0, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->g:Z

    .line 1414
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->bb:Lit/sephiroth/android/library/widget/AbsHListView$SavedState;

    iget v0, v0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->h:I

    iput v0, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->h:I

    .line 1415
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->bb:Lit/sephiroth/android/library/widget/AbsHListView$SavedState;

    iget-object v0, v0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->i:Landroid/util/SparseBooleanArray;

    iput-object v0, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->i:Landroid/util/SparseBooleanArray;

    .line 1416
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->bb:Lit/sephiroth/android/library/widget/AbsHListView$SavedState;

    iget-object v0, v0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->j:Landroid/support/v4/c/e;

    iput-object v0, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->j:Landroid/support/v4/c/e;

    move-object v0, v3

    .line 1478
    :goto_4e
    return-object v0

    .line 1420
    :cond_4f
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v0

    if-lez v0, :cond_bb

    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    if-lez v0, :cond_bb

    move v0, v1

    .line 1421
    :goto_5a
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->s()J

    move-result-wide v4

    .line 1422
    iput-wide v4, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->a:J

    .line 1423
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v6

    iput v6, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->e:I

    .line 1425
    const-wide/16 v6, 0x0

    cmp-long v4, v4, v6

    if-ltz v4, :cond_bd

    .line 1427
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->J:I

    iput v0, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->c:I

    .line 1428
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->r()I

    move-result v0

    iput v0, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->d:I

    .line 1429
    iput-wide v8, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->b:J

    .line 1456
    :goto_78
    const/4 v0, 0x0

    iput-object v0, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->f:Ljava/lang/String;

    .line 1457
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0xb

    if-lt v0, v4, :cond_e9

    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->b:I

    const/4 v4, 0x3

    if-ne v0, v4, :cond_e9

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->c:Ljava/lang/Object;

    if-eqz v0, :cond_e9

    :goto_8a
    iput-boolean v1, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->g:Z

    .line 1460
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->f:Landroid/util/SparseBooleanArray;

    if-eqz v0, :cond_98

    .line 1462
    :try_start_90
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->f:Landroid/util/SparseBooleanArray;

    invoke-virtual {v0}, Landroid/util/SparseBooleanArray;->clone()Landroid/util/SparseBooleanArray;

    move-result-object v0

    iput-object v0, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->i:Landroid/util/SparseBooleanArray;
    :try_end_98
    .catch Ljava/lang/NoSuchMethodError; {:try_start_90 .. :try_end_98} :catch_eb

    .line 1468
    :cond_98
    :goto_98
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    if-eqz v0, :cond_f9

    .line 1469
    new-instance v0, Landroid/support/v4/c/e;

    invoke-direct {v0}, Landroid/support/v4/c/e;-><init>()V

    .line 1470
    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    invoke-virtual {v1}, Landroid/support/v4/c/e;->a()I

    move-result v1

    .line 1471
    :goto_a7
    if-ge v2, v1, :cond_f7

    .line 1472
    iget-object v4, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    invoke-virtual {v4, v2}, Landroid/support/v4/c/e;->a(I)J

    move-result-wide v4

    iget-object v6, p0, Lit/sephiroth/android/library/widget/AbsHListView;->g:Landroid/support/v4/c/e;

    invoke-virtual {v6, v2}, Landroid/support/v4/c/e;->b(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v0, v4, v5, v6}, Landroid/support/v4/c/e;->a(JLjava/lang/Object;)V

    .line 1471
    add-int/lit8 v2, v2, 0x1

    goto :goto_a7

    :cond_bb
    move v0, v2

    .line 1420
    goto :goto_5a

    .line 1431
    :cond_bd
    if-eqz v0, :cond_e2

    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    if-lez v0, :cond_e2

    .line 1441
    invoke-virtual {p0, v2}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    .line 1442
    invoke-virtual {v0}, Landroid/view/View;->getLeft()I

    move-result v0

    iput v0, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->c:I

    .line 1443
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    .line 1444
    iget v4, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    if-lt v0, v4, :cond_d7

    .line 1445
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    add-int/lit8 v0, v0, -0x1

    .line 1447
    :cond_d7
    iput v0, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->d:I

    .line 1448
    iget-object v4, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    invoke-interface {v4, v0}, Landroid/widget/ListAdapter;->getItemId(I)J

    move-result-wide v4

    iput-wide v4, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->b:J

    goto :goto_78

    .line 1450
    :cond_e2
    iput v2, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->c:I

    .line 1451
    iput-wide v8, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->b:J

    .line 1452
    iput v2, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->d:I

    goto :goto_78

    :cond_e9
    move v1, v2

    .line 1457
    goto :goto_8a

    .line 1463
    :catch_eb
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/NoSuchMethodError;->printStackTrace()V

    .line 1465
    new-instance v0, Landroid/util/SparseBooleanArray;

    invoke-direct {v0}, Landroid/util/SparseBooleanArray;-><init>()V

    iput-object v0, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->i:Landroid/util/SparseBooleanArray;

    goto :goto_98

    .line 1474
    :cond_f7
    iput-object v0, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->j:Landroid/support/v4/c/e;

    .line 1476
    :cond_f9
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->e:I

    iput v0, v3, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->h:I

    move-object v0, v3

    .line 1478
    goto/16 :goto_4e
.end method

.method protected onSizeChanged(IIII)V
    .registers 6

    .prologue
    .line 2078
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v0

    if-lez v0, :cond_c

    .line 2079
    const/4 v0, 0x1

    iput-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ai:Z

    .line 2080
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->z()V

    .line 2082
    :cond_c
    return-void
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 14

    .prologue
    const/4 v6, 0x4

    const/4 v11, 0x2

    const/4 v2, 0x1

    const/4 v10, -0x1

    const/4 v1, 0x0

    .line 2943
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->isEnabled()Z

    move-result v0

    if-nez v0, :cond_19

    .line 2946
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->isClickable()Z

    move-result v0

    if-nez v0, :cond_17

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->isLongClickable()Z

    move-result v0

    if-eqz v0, :cond_18

    :cond_17
    move v1, v2

    .line 3299
    :cond_18
    :goto_18
    return v1

    .line 2949
    :cond_19
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->I:Lit/sephiroth/android/library/widget/i;

    if-eqz v0, :cond_22

    .line 2950
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->I:Lit/sephiroth/android/library/widget/i;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/i;->a()V

    .line 2953
    :cond_22
    iget-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->S:Z

    if-eqz v0, :cond_18

    .line 2961
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    .line 2965
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->E()V

    .line 2966
    iget-object v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->at:Landroid/view/VelocityTracker;

    invoke-virtual {v3, p1}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    .line 2968
    and-int/lit16 v0, v0, 0xff

    packed-switch v0, :pswitch_data_3da

    :cond_37
    :goto_37
    :pswitch_37
    move v1, v2

    .line 3299
    goto :goto_18

    .line 2970
    :pswitch_39
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    packed-switch v0, :pswitch_data_3ec

    .line 2986
    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aO:I

    .line 2987
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    float-to-int v4, v0

    .line 2988
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v0

    float-to-int v5, v0

    .line 2989
    invoke-direct {p0, v4, v5}, Lit/sephiroth/android/library/widget/AbsHListView;->b(II)I

    move-result v3

    .line 2990
    iget-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ai:Z

    if-nez v0, :cond_3d6

    .line 2991
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    if-eq v0, v6, :cond_111

    if-ltz v3, :cond_111

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->q()Landroid/widget/Adapter;

    move-result-object v0

    check-cast v0, Landroid/widget/ListAdapter;

    invoke-interface {v0, v3}, Landroid/widget/ListAdapter;->isEnabled(I)Z

    move-result v0

    if-eqz v0, :cond_111

    .line 2996
    iput v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 2998
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aB:Ljava/lang/Runnable;

    if-nez v0, :cond_75

    .line 2999
    new-instance v0, Lit/sephiroth/android/library/widget/d;

    invoke-direct {v0, p0}, Lit/sephiroth/android/library/widget/d;-><init>(Lit/sephiroth/android/library/widget/AbsHListView;)V

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aB:Ljava/lang/Runnable;

    .line 3001
    :cond_75
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aB:Ljava/lang/Runnable;

    invoke-static {}, Landroid/view/ViewConfiguration;->getTapTimeout()I

    move-result v6

    int-to-long v6, v6

    invoke-virtual {p0, v0, v6, v7}, Lit/sephiroth/android/library/widget/AbsHListView;->postDelayed(Ljava/lang/Runnable;J)Z

    move v0, v3

    .line 3014
    :goto_80
    if-ltz v0, :cond_90

    .line 3016
    iget v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    sub-int v3, v0, v3

    invoke-virtual {p0, v3}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    .line 3017
    invoke-virtual {v3}, Landroid/view/View;->getLeft()I

    move-result v3

    iput v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->B:I

    .line 3019
    :cond_90
    iput v4, p0, Lit/sephiroth/android/library/widget/AbsHListView;->D:I

    .line 3020
    iput v5, p0, Lit/sephiroth/android/library/widget/AbsHListView;->E:I

    .line 3021
    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->A:I

    .line 3022
    const/high16 v0, -0x80000000

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->G:I

    .line 3023
    :goto_9a
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v3, 0xe

    if-lt v0, v3, :cond_d8

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getButtonState()I

    move-result v0

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_d8

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v3

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getMetaState()I

    :cond_b3
    float-to-int v4, v0

    float-to-int v5, v3

    invoke-direct {p0, v4, v5}, Lit/sephiroth/android/library/widget/AbsHListView;->b(II)I

    move-result v4

    if-eq v4, v10, :cond_b3

    iget-object v5, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    invoke-interface {v5, v4}, Landroid/widget/ListAdapter;->getItemId(I)J

    move-result-wide v5

    iget v7, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    sub-int v7, v4, v7

    invoke-virtual {p0, v7}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v7

    if-eqz v7, :cond_b3

    invoke-static {v7, v4, v5, v6}, Lit/sephiroth/android/library/widget/AbsHListView;->c(Landroid/view/View;IJ)Landroid/view/ContextMenu$ContextMenuInfo;

    move-result-object v0

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ay:Landroid/view/ContextMenu$ContextMenuInfo;

    invoke-super {p0, p0}, Lit/sephiroth/android/library/widget/AdapterView;->showContextMenuForChild(Landroid/view/View;)Z

    move-result v0

    if-eqz v0, :cond_d8

    move v1, v2

    :cond_d8
    if-eqz v1, :cond_37

    .line 3028
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    if-nez v0, :cond_37

    .line 3029
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aB:Ljava/lang/Runnable;

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->removeCallbacks(Ljava/lang/Runnable;)Z

    goto/16 :goto_37

    .line 2972
    :pswitch_e5
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/e;->b()V

    .line 2973
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->I:Lit/sephiroth/android/library/widget/i;

    if-eqz v0, :cond_f3

    .line 2974
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->I:Lit/sephiroth/android/library/widget/i;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/i;->a()V

    .line 2976
    :cond_f3
    const/4 v0, 0x5

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 2977
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v0

    float-to-int v0, v0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->E:I

    .line 2978
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    float-to-int v0, v0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->G:I

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->D:I

    .line 2979
    iput v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->H:I

    .line 2980
    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aO:I

    .line 2981
    iput v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aT:I

    goto :goto_9a

    .line 3003
    :cond_111
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    if-ne v0, v6, :cond_3d6

    .line 3005
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->G()V

    .line 3006
    const/4 v0, 0x3

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 3007
    iput v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->H:I

    .line 3008
    invoke-virtual {p0, v4}, Lit/sephiroth/android/library/widget/AbsHListView;->c(I)I

    move-result v0

    .line 3009
    iget-object v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    invoke-virtual {v3}, Lit/sephiroth/android/library/widget/e;->c()V

    goto/16 :goto_80

    .line 3036
    :pswitch_128
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aO:I

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    move-result v0

    .line 3037
    if-ne v0, v10, :cond_137

    .line 3039
    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aO:I

    move v0, v1

    .line 3041
    :cond_137
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    move-result v0

    float-to-int v0, v0

    .line 3043
    iget-boolean v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ai:Z

    if-eqz v1, :cond_143

    .line 3046
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->e()V

    .line 3049
    :cond_143
    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    packed-switch v1, :pswitch_data_3f2

    :pswitch_148
    goto/16 :goto_37

    .line 3055
    :pswitch_14a
    invoke-direct {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->j(I)Z

    goto/16 :goto_37

    .line 3059
    :pswitch_14f
    invoke-direct {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->k(I)V

    goto/16 :goto_37

    .line 3066
    :pswitch_154
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    packed-switch v0, :pswitch_data_402

    .line 3207
    :cond_159
    :goto_159
    :pswitch_159
    invoke-virtual {p0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->setPressed(Z)V

    .line 3209
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aP:Lit/sephiroth/android/library/widget/s;

    if-eqz v0, :cond_16a

    .line 3210
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aP:Lit/sephiroth/android/library/widget/s;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/s;->c()V

    .line 3211
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aQ:Lit/sephiroth/android/library/widget/s;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/s;->c()V

    .line 3215
    :cond_16a
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->invalidate()V

    .line 3217
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getHandler()Landroid/os/Handler;

    move-result-object v0

    .line 3218
    if-eqz v0, :cond_178

    .line 3219
    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aA:Lit/sephiroth/android/library/widget/c;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 3222
    :cond_178
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->F()V

    .line 3224
    iput v10, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aO:I

    goto/16 :goto_37

    .line 3070
    :pswitch_17f
    iget v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->A:I

    .line 3071
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    sub-int v0, v3, v0

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    .line 3073
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v0

    .line 3074
    iget-object v5, p0, Lit/sephiroth/android/library/widget/AbsHListView;->u:Landroid/graphics/Rect;

    iget v5, v5, Landroid/graphics/Rect;->left:I

    int-to-float v5, v5

    cmpl-float v5, v0, v5

    if-lez v5, :cond_236

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v5

    iget-object v6, p0, Lit/sephiroth/android/library/widget/AbsHListView;->u:Landroid/graphics/Rect;

    iget v6, v6, Landroid/graphics/Rect;->right:I

    sub-int/2addr v5, v6

    int-to-float v5, v5

    cmpg-float v0, v0, v5

    if-gez v0, :cond_236

    move v0, v2

    .line 3076
    :goto_1a5
    if-eqz v4, :cond_251

    invoke-virtual {v4}, Landroid/view/View;->hasFocusable()Z

    move-result v5

    if-nez v5, :cond_251

    if-eqz v0, :cond_251

    .line 3077
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    if-eqz v0, :cond_1b6

    .line 3078
    invoke-virtual {v4, v1}, Landroid/view/View;->setPressed(Z)V

    .line 3081
    :cond_1b6
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aD:Lit/sephiroth/android/library/widget/h;

    if-nez v0, :cond_1c1

    .line 3082
    new-instance v0, Lit/sephiroth/android/library/widget/h;

    invoke-direct {v0, p0, v1}, Lit/sephiroth/android/library/widget/h;-><init>(Lit/sephiroth/android/library/widget/AbsHListView;B)V

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aD:Lit/sephiroth/android/library/widget/h;

    .line 3085
    :cond_1c1
    iget-object v5, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aD:Lit/sephiroth/android/library/widget/h;

    .line 3086
    iput v3, v5, Lit/sephiroth/android/library/widget/h;->a:I

    .line 3087
    invoke-virtual {v5}, Lit/sephiroth/android/library/widget/h;->a()V

    .line 3089
    iput v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->M:I

    .line 3091
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    if-eqz v0, :cond_1d2

    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    if-ne v0, v2, :cond_242

    .line 3092
    :cond_1d2
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getHandler()Landroid/os/Handler;

    move-result-object v6

    .line 3093
    if-eqz v6, :cond_1e1

    .line 3094
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    if-nez v0, :cond_239

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aB:Ljava/lang/Runnable;

    :goto_1de
    invoke-virtual {v6, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 3097
    :cond_1e1
    iput v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->h:I

    .line 3099
    iget-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ai:Z

    if-nez v0, :cond_23c

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    invoke-interface {v0, v3}, Landroid/widget/ListAdapter;->isEnabled(I)Z

    move-result v0

    if-eqz v0, :cond_23c

    .line 3100
    iput v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 3101
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->A:I

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->h(I)V

    .line 3102
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->e()V

    .line 3103
    invoke-virtual {v4, v2}, Landroid/view/View;->setPressed(Z)V

    .line 3104
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->A:I

    invoke-virtual {p0, v0, v4}, Lit/sephiroth/android/library/widget/AbsHListView;->a(ILandroid/view/View;)V

    .line 3105
    invoke-virtual {p0, v2}, Lit/sephiroth/android/library/widget/AbsHListView;->setPressed(Z)V

    .line 3106
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->m:Landroid/graphics/drawable/Drawable;

    if-eqz v0, :cond_219

    .line 3107
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->m:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getCurrent()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    .line 3108
    if-eqz v0, :cond_219

    instance-of v1, v0, Landroid/graphics/drawable/TransitionDrawable;

    if-eqz v1, :cond_219

    .line 3109
    check-cast v0, Landroid/graphics/drawable/TransitionDrawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/TransitionDrawable;->resetTransition()V

    .line 3112
    :cond_219
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aE:Ljava/lang/Runnable;

    if-eqz v0, :cond_222

    .line 3113
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aE:Ljava/lang/Runnable;

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 3115
    :cond_222
    new-instance v0, Lit/sephiroth/android/library/widget/AbsHListView$1;

    invoke-direct {v0, p0, v4, v5}, Lit/sephiroth/android/library/widget/AbsHListView$1;-><init>(Lit/sephiroth/android/library/widget/AbsHListView;Landroid/view/View;Lit/sephiroth/android/library/widget/h;)V

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aE:Ljava/lang/Runnable;

    .line 3127
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aE:Ljava/lang/Runnable;

    invoke-static {}, Landroid/view/ViewConfiguration;->getPressedStateDuration()I

    move-result v1

    int-to-long v3, v1

    invoke-virtual {p0, v0, v3, v4}, Lit/sephiroth/android/library/widget/AbsHListView;->postDelayed(Ljava/lang/Runnable;J)Z

    :goto_233
    move v1, v2

    .line 3133
    goto/16 :goto_18

    :cond_236
    move v0, v1

    .line 3074
    goto/16 :goto_1a5

    .line 3094
    :cond_239
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aA:Lit/sephiroth/android/library/widget/c;

    goto :goto_1de

    .line 3130
    :cond_23c
    iput v10, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 3131
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->C()V

    goto :goto_233

    .line 3134
    :cond_242
    iget-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ai:Z

    if-nez v0, :cond_251

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    invoke-interface {v0, v3}, Landroid/widget/ListAdapter;->isEnabled(I)Z

    move-result v0

    if-eqz v0, :cond_251

    .line 3135
    invoke-virtual {v5}, Lit/sephiroth/android/library/widget/h;->run()V

    .line 3138
    :cond_251
    iput v10, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 3139
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->C()V

    goto/16 :goto_159

    .line 3142
    :pswitch_258
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v0

    .line 3143
    if-lez v0, :cond_2f8

    .line 3144
    invoke-virtual {p0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/View;->getLeft()I

    move-result v3

    .line 3145
    add-int/lit8 v4, v0, -0x1

    invoke-virtual {p0, v4}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/View;->getRight()I

    move-result v4

    .line 3146
    iget-object v5, p0, Lit/sephiroth/android/library/widget/AbsHListView;->u:Landroid/graphics/Rect;

    iget v5, v5, Landroid/graphics/Rect;->left:I

    .line 3147
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v6

    iget-object v7, p0, Lit/sephiroth/android/library/widget/AbsHListView;->u:Landroid/graphics/Rect;

    iget v7, v7, Landroid/graphics/Rect;->right:I

    sub-int/2addr v6, v7

    .line 3148
    iget v7, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    if-nez v7, :cond_298

    if-lt v3, v5, :cond_298

    iget v7, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    add-int/2addr v7, v0

    iget v8, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    if-ge v7, v8, :cond_298

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v7

    sub-int/2addr v7, v6

    if-gt v4, v7, :cond_298

    .line 3150
    iput v10, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 3151
    invoke-virtual {p0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->a(I)V

    goto/16 :goto_159

    .line 3153
    :cond_298
    iget-object v7, p0, Lit/sephiroth/android/library/widget/AbsHListView;->at:Landroid/view/VelocityTracker;

    .line 3154
    const/16 v8, 0x3e8

    iget v9, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aM:I

    int-to-float v9, v9

    invoke-virtual {v7, v8, v9}, Landroid/view/VelocityTracker;->computeCurrentVelocity(IF)V

    .line 3156
    iget v8, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aO:I

    invoke-virtual {v7, v8}, Landroid/view/VelocityTracker;->getXVelocity(I)F

    move-result v7

    iget v8, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aN:F

    mul-float/2addr v7, v8

    float-to-int v7, v7

    .line 3161
    invoke-static {v7}, Ljava/lang/Math;->abs(I)I

    move-result v8

    iget v9, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aL:I

    if-le v8, v9, :cond_2df

    iget v8, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    if-nez v8, :cond_2bd

    iget v8, p0, Lit/sephiroth/android/library/widget/AbsHListView;->Q:I

    sub-int/2addr v5, v8

    if-eq v3, v5, :cond_2df

    :cond_2bd
    iget v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    add-int/2addr v0, v3

    iget v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    if-ne v0, v3, :cond_2c9

    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->Q:I

    add-int/2addr v0, v6

    if-eq v4, v0, :cond_2df

    .line 3166
    :cond_2c9
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    if-nez v0, :cond_2d4

    .line 3167
    new-instance v0, Lit/sephiroth/android/library/widget/e;

    invoke-direct {v0, p0}, Lit/sephiroth/android/library/widget/e;-><init>(Lit/sephiroth/android/library/widget/AbsHListView;)V

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    .line 3169
    :cond_2d4
    invoke-virtual {p0, v11}, Lit/sephiroth/android/library/widget/AbsHListView;->a(I)V

    .line 3171
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    neg-int v3, v7

    invoke-virtual {v0, v3}, Lit/sephiroth/android/library/widget/e;->a(I)V

    goto/16 :goto_159

    .line 3173
    :cond_2df
    iput v10, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 3174
    invoke-virtual {p0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->a(I)V

    .line 3175
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    if-eqz v0, :cond_2ed

    .line 3176
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/e;->b()V

    .line 3178
    :cond_2ed
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->I:Lit/sephiroth/android/library/widget/i;

    if-eqz v0, :cond_159

    .line 3179
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->I:Lit/sephiroth/android/library/widget/i;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/i;->a()V

    goto/16 :goto_159

    .line 3184
    :cond_2f8
    iput v10, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 3185
    invoke-virtual {p0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->a(I)V

    goto/16 :goto_159

    .line 3190
    :pswitch_2ff
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    if-nez v0, :cond_30a

    .line 3191
    new-instance v0, Lit/sephiroth/android/library/widget/e;

    invoke-direct {v0, p0}, Lit/sephiroth/android/library/widget/e;-><init>(Lit/sephiroth/android/library/widget/AbsHListView;)V

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    .line 3193
    :cond_30a
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->at:Landroid/view/VelocityTracker;

    .line 3194
    const/16 v3, 0x3e8

    iget v4, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aM:I

    int-to-float v4, v4

    invoke-virtual {v0, v3, v4}, Landroid/view/VelocityTracker;->computeCurrentVelocity(IF)V

    .line 3195
    iget v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aO:I

    invoke-virtual {v0, v3}, Landroid/view/VelocityTracker;->getXVelocity(I)F

    move-result v0

    float-to-int v0, v0

    .line 3197
    invoke-virtual {p0, v11}, Lit/sephiroth/android/library/widget/AbsHListView;->a(I)V

    .line 3198
    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result v3

    iget v4, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aL:I

    if-le v3, v4, :cond_32e

    .line 3199
    iget-object v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    neg-int v0, v0

    invoke-virtual {v3, v0}, Lit/sephiroth/android/library/widget/e;->b(I)V

    goto/16 :goto_159

    .line 3201
    :cond_32e
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/e;->a()V

    goto/16 :goto_159

    .line 3229
    :pswitch_335
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    packed-switch v0, :pswitch_data_412

    .line 3242
    iput v10, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 3243
    invoke-virtual {p0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->setPressed(Z)V

    .line 3244
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->A:I

    iget v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    sub-int/2addr v0, v3

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    .line 3245
    if-eqz v0, :cond_34d

    .line 3246
    invoke-virtual {v0, v1}, Landroid/view/View;->setPressed(Z)V

    .line 3248
    :cond_34d
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->H()V

    .line 3250
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getHandler()Landroid/os/Handler;

    move-result-object v0

    .line 3251
    if-eqz v0, :cond_35b

    .line 3252
    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aA:Lit/sephiroth/android/library/widget/c;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 3255
    :cond_35b
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->F()V

    .line 3258
    :goto_35e
    :pswitch_35e
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aP:Lit/sephiroth/android/library/widget/s;

    if-eqz v0, :cond_36c

    .line 3259
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aP:Lit/sephiroth/android/library/widget/s;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/s;->c()V

    .line 3260
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aQ:Lit/sephiroth/android/library/widget/s;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/s;->c()V

    .line 3262
    :cond_36c
    iput v10, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aO:I

    goto/16 :goto_37

    .line 3231
    :pswitch_370
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    if-nez v0, :cond_37b

    .line 3232
    new-instance v0, Lit/sephiroth/android/library/widget/e;

    invoke-direct {v0, p0}, Lit/sephiroth/android/library/widget/e;-><init>(Lit/sephiroth/android/library/widget/AbsHListView;)V

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    .line 3234
    :cond_37b
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/e;->a()V

    goto :goto_35e

    .line 3267
    :pswitch_381
    invoke-direct {p0, p1}, Lit/sephiroth/android/library/widget/AbsHListView;->a(Landroid/view/MotionEvent;)V

    .line 3268
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->D:I

    .line 3269
    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->E:I

    .line 3270
    invoke-direct {p0, v0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->b(II)I

    move-result v1

    .line 3271
    if-ltz v1, :cond_39e

    .line 3273
    iget v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    sub-int v3, v1, v3

    invoke-virtual {p0, v3}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    .line 3274
    invoke-virtual {v3}, Landroid/view/View;->getLeft()I

    move-result v3

    iput v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->B:I

    .line 3275
    iput v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->A:I

    .line 3277
    :cond_39e
    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->G:I

    goto/16 :goto_37

    .line 3283
    :pswitch_3a2
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionIndex()I

    move-result v0

    .line 3284
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v3

    .line 3285
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    move-result v4

    float-to-int v4, v4

    .line 3286
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    move-result v0

    float-to-int v0, v0

    .line 3287
    iput v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->H:I

    .line 3288
    iput v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aO:I

    .line 3289
    iput v4, p0, Lit/sephiroth/android/library/widget/AbsHListView;->D:I

    .line 3290
    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->E:I

    .line 3291
    invoke-direct {p0, v4, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->b(II)I

    move-result v0

    .line 3292
    if-ltz v0, :cond_3d2

    .line 3294
    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    sub-int v1, v0, v1

    invoke-virtual {p0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    .line 3295
    invoke-virtual {v1}, Landroid/view/View;->getLeft()I

    move-result v1

    iput v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->B:I

    .line 3296
    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->A:I

    .line 3298
    :cond_3d2
    iput v4, p0, Lit/sephiroth/android/library/widget/AbsHListView;->G:I

    goto/16 :goto_37

    :cond_3d6
    move v0, v3

    goto/16 :goto_80

    .line 2968
    nop

    :pswitch_data_3da
    .packed-switch 0x0
        :pswitch_39
        :pswitch_154
        :pswitch_128
        :pswitch_335
        :pswitch_37
        :pswitch_3a2
        :pswitch_381
    .end packed-switch

    .line 2970
    :pswitch_data_3ec
    .packed-switch 0x6
        :pswitch_e5
    .end packed-switch

    .line 3049
    :pswitch_data_3f2
    .packed-switch 0x0
        :pswitch_14a
        :pswitch_14a
        :pswitch_14a
        :pswitch_14f
        :pswitch_148
        :pswitch_14f
    .end packed-switch

    .line 3066
    :pswitch_data_402
    .packed-switch 0x0
        :pswitch_17f
        :pswitch_17f
        :pswitch_17f
        :pswitch_258
        :pswitch_159
        :pswitch_2ff
    .end packed-switch

    .line 3229
    :pswitch_data_412
    .packed-switch 0x5
        :pswitch_370
        :pswitch_35e
    .end packed-switch
.end method

.method public onTouchModeChanged(Z)V
    .registers 4

    .prologue
    .line 2890
    if-eqz p1, :cond_18

    .line 2892
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->l()V

    .line 2896
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v0

    if-lez v0, :cond_14

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v0

    if-lez v0, :cond_14

    .line 2899
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->e()V

    .line 2901
    :cond_14
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->C()V

    .line 2919
    :cond_17
    :goto_17
    return-void

    .line 2903
    :cond_18
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 2904
    const/4 v1, 0x5

    if-eq v0, v1, :cond_20

    const/4 v1, 0x6

    if-ne v0, v1, :cond_17

    .line 2905
    :cond_20
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    if-eqz v0, :cond_29

    .line 2906
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/e;->b()V

    .line 2908
    :cond_29
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->I:Lit/sephiroth/android/library/widget/i;

    if-eqz v0, :cond_32

    .line 2909
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->I:Lit/sephiroth/android/library/widget/i;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/i;->a()V

    .line 2912
    :cond_32
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getScrollX()I

    move-result v0

    if-eqz v0, :cond_17

    .line 2913
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->a:Lit/sephiroth/android/library/a/b;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lit/sephiroth/android/library/a/b;->a(I)V

    .line 2914
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->J()V

    .line 2915
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->invalidate()V

    goto :goto_17
.end method

.method public onWindowFocusChanged(Z)V
    .registers 7

    .prologue
    const/4 v2, 0x1

    const/4 v1, 0x0

    .line 2336
    invoke-super {p0, p1}, Lit/sephiroth/android/library/widget/AdapterView;->onWindowFocusChanged(Z)V

    .line 2338
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->isInTouchMode()Z

    move-result v0

    if-eqz v0, :cond_42

    move v0, v1

    .line 2340
    :goto_c
    if-nez p1, :cond_44

    .line 2341
    invoke-virtual {p0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->setChildrenDrawingCacheEnabled(Z)V

    .line 2342
    iget-object v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    if-eqz v3, :cond_39

    .line 2343
    iget-object v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    invoke-virtual {p0, v3}, Lit/sephiroth/android/library/widget/AbsHListView;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 2346
    iget-object v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->au:Lit/sephiroth/android/library/widget/e;

    invoke-virtual {v3}, Lit/sephiroth/android/library/widget/e;->b()V

    .line 2347
    iget-object v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->I:Lit/sephiroth/android/library/widget/i;

    if-eqz v3, :cond_28

    .line 2348
    iget-object v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->I:Lit/sephiroth/android/library/widget/i;

    invoke-virtual {v3}, Lit/sephiroth/android/library/widget/i;->a()V

    .line 2350
    :cond_28
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getScrollX()I

    move-result v3

    if-eqz v3, :cond_39

    .line 2351
    iget-object v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->a:Lit/sephiroth/android/library/a/b;

    invoke-virtual {v3, v1}, Lit/sephiroth/android/library/a/b;->a(I)V

    .line 2352
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->J()V

    .line 2353
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->invalidate()V

    .line 2358
    :cond_39
    if-ne v0, v2, :cond_3f

    .line 2360
    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->al:I

    iput v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->M:I

    .line 2379
    :cond_3f
    :goto_3f
    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->az:I

    .line 2380
    return-void

    :cond_42
    move v0, v2

    .line 2338
    goto :goto_c

    .line 2364
    :cond_44
    iget v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->az:I

    if-eq v0, v3, :cond_3f

    iget v3, p0, Lit/sephiroth/android/library/widget/AbsHListView;->az:I

    const/4 v4, -0x1

    if-eq v3, v4, :cond_3f

    .line 2366
    if-ne v0, v2, :cond_53

    .line 2368
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->I()Z

    goto :goto_3f

    .line 2372
    :cond_53
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->l()V

    .line 2373
    iput v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->h:I

    .line 2374
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->e()V

    goto :goto_3f
.end method

.method public final p()I
    .registers 2
    .annotation runtime Landroid/view/ViewDebug$ExportedProperty;
        category = "drawing"
    .end annotation

    .prologue
    .line 5220
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aG:I

    return v0
.end method

.method public performAccessibilityAction(ILandroid/os/Bundle;)Z
    .registers 7
    .annotation build Landroid/annotation/TargetApi;
        value = 0xe
    .end annotation

    .prologue
    const/4 v0, 0x1

    const/4 v1, 0x0

    .line 1197
    invoke-super {p0, p1, p2}, Lit/sephiroth/android/library/widget/AdapterView;->performAccessibilityAction(ILandroid/os/Bundle;)Z

    move-result v2

    if-eqz v2, :cond_9

    .line 1218
    :goto_8
    return v0

    .line 1200
    :cond_9
    sparse-switch p1, :sswitch_data_54

    move v0, v1

    .line 1218
    goto :goto_8

    .line 1202
    :sswitch_e
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->isEnabled()Z

    move-result v2

    if-eqz v2, :cond_32

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->v()I

    move-result v2

    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->t()I

    move-result v3

    add-int/lit8 v3, v3, -0x1

    if-ge v2, v3, :cond_32

    .line 1203
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v1

    iget-object v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->u:Landroid/graphics/Rect;

    iget v2, v2, Landroid/graphics/Rect;->left:I

    sub-int/2addr v1, v2

    iget-object v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->u:Landroid/graphics/Rect;

    iget v2, v2, Landroid/graphics/Rect;->right:I

    sub-int/2addr v1, v2

    .line 1204
    invoke-direct {p0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->l(I)V

    goto :goto_8

    :cond_32
    move v0, v1

    .line 1208
    goto :goto_8

    .line 1210
    :sswitch_34
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->isEnabled()Z

    move-result v2

    if-eqz v2, :cond_51

    iget v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    if-lez v2, :cond_51

    .line 1211
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v1

    iget-object v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->u:Landroid/graphics/Rect;

    iget v2, v2, Landroid/graphics/Rect;->left:I

    sub-int/2addr v1, v2

    iget-object v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->u:Landroid/graphics/Rect;

    iget v2, v2, Landroid/graphics/Rect;->right:I

    sub-int/2addr v1, v2

    .line 1212
    neg-int v1, v1

    invoke-direct {p0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->l(I)V

    goto :goto_8

    :cond_51
    move v0, v1

    .line 1216
    goto :goto_8

    .line 1200
    nop

    :sswitch_data_54
    .sparse-switch
        0x1000 -> :sswitch_e
        0x2000 -> :sswitch_34
    .end sparse-switch
.end method

.method public requestDisallowInterceptTouchEvent(Z)V
    .registers 2

    .prologue
    .line 3449
    if-eqz p1, :cond_5

    .line 3450
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->F()V

    .line 3452
    :cond_5
    invoke-super {p0, p1}, Lit/sephiroth/android/library/widget/AdapterView;->requestDisallowInterceptTouchEvent(Z)V

    .line 3453
    return-void
.end method

.method public requestLayout()V
    .registers 2

    .prologue
    .line 1546
    iget-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->as:Z

    if-nez v0, :cond_b

    iget-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ae:Z

    if-nez v0, :cond_b

    .line 1547
    invoke-super {p0}, Lit/sephiroth/android/library/widget/AdapterView;->requestLayout()V

    .line 1549
    :cond_b
    return-void
.end method

.method public sendAccessibilityEvent(I)V
    .registers 5

    .prologue
    .line 1158
    const/16 v0, 0x1000

    if-ne p1, v0, :cond_19

    .line 1159
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->u()I

    move-result v0

    .line 1160
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->v()I

    move-result v1

    .line 1161
    iget v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aY:I

    if-ne v2, v0, :cond_15

    iget v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aZ:I

    if-ne v2, v1, :cond_15

    .line 1170
    :goto_14
    return-void

    .line 1165
    :cond_15
    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aY:I

    .line 1166
    iput v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aZ:I

    .line 1169
    :cond_19
    invoke-super {p0, p1}, Lit/sephiroth/android/library/widget/AdapterView;->sendAccessibilityEvent(I)V

    goto :goto_14
.end method

.method public setOverScrollMode(I)V
    .registers 4

    .prologue
    const/4 v1, 0x0

    .line 720
    const/4 v0, 0x2

    if-eq p1, v0, :cond_1e

    .line 721
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aP:Lit/sephiroth/android/library/widget/s;

    if-nez v0, :cond_1a

    .line 722
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/AbsHListView;->getContext()Landroid/content/Context;

    move-result-object v0

    .line 723
    new-instance v1, Lit/sephiroth/android/library/widget/s;

    invoke-direct {v1, v0}, Lit/sephiroth/android/library/widget/s;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aP:Lit/sephiroth/android/library/widget/s;

    .line 724
    new-instance v1, Lit/sephiroth/android/library/widget/s;

    invoke-direct {v1, v0}, Lit/sephiroth/android/library/widget/s;-><init>(Landroid/content/Context;)V

    iput-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aQ:Lit/sephiroth/android/library/widget/s;

    .line 730
    :cond_1a
    :goto_1a
    invoke-super {p0, p1}, Lit/sephiroth/android/library/widget/AdapterView;->setOverScrollMode(I)V

    .line 731
    return-void

    .line 727
    :cond_1e
    iput-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aP:Lit/sephiroth/android/library/widget/s;

    .line 728
    iput-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView;->aQ:Lit/sephiroth/android/library/widget/s;

    goto :goto_1a
.end method

.method public showContextMenuForChild(Landroid/view/View;)Z
    .registers 7

    .prologue
    const/4 v0, 0x0

    .line 2540
    invoke-virtual {p0, p1}, Lit/sephiroth/android/library/widget/AbsHListView;->a(Landroid/view/View;)I

    move-result v1

    .line 2541
    if-ltz v1, :cond_2b

    .line 2542
    iget-object v2, p0, Lit/sephiroth/android/library/widget/AbsHListView;->j:Landroid/widget/ListAdapter;

    invoke-interface {v2, v1}, Landroid/widget/ListAdapter;->getItemId(I)J

    move-result-wide v2

    .line 2545
    iget-object v4, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ah:Lit/sephiroth/android/library/widget/p;

    if-eqz v4, :cond_17

    .line 2546
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ah:Lit/sephiroth/android/library/widget/p;

    invoke-interface {v0}, Lit/sephiroth/android/library/widget/p;->a()Z

    move-result v0

    .line 2549
    :cond_17
    if-nez v0, :cond_2b

    .line 2550
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    sub-int v0, v1, v0

    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    invoke-static {v0, v1, v2, v3}, Lit/sephiroth/android/library/widget/AbsHListView;->c(Landroid/view/View;IJ)Landroid/view/ContextMenu$ContextMenuInfo;

    move-result-object v0

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->ay:Landroid/view/ContextMenu$ContextMenuInfo;

    .line 2553
    invoke-super {p0, p1}, Lit/sephiroth/android/library/widget/AdapterView;->showContextMenuForChild(Landroid/view/View;)Z

    move-result v0

    .line 2558
    :cond_2b
    return v0
.end method

.method public verifyDrawable(Landroid/graphics/drawable/Drawable;)Z
    .registers 3

    .prologue
    .line 2265
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView;->m:Landroid/graphics/drawable/Drawable;

    if-eq v0, p1, :cond_a

    invoke-super {p0, p1}, Lit/sephiroth/android/library/widget/AdapterView;->verifyDrawable(Landroid/graphics/drawable/Drawable;)Z

    move-result v0

    if-eqz v0, :cond_c

    :cond_a
    const/4 v0, 0x1

    :goto_b
    return v0

    :cond_c
    const/4 v0, 0x0

    goto :goto_b
.end method

###### Class it.sephiroth.android.library.widget.AbsHListView.AnonymousClass1 (it.sephiroth.android.library.widget.AbsHListView$1)
.class final Lit/sephiroth/android/library/widget/AbsHListView$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lit/sephiroth/android/library/widget/AbsHListView;->onTouchEvent(Landroid/view/MotionEvent;)Z
.end annotation


# instance fields
.field final synthetic a:Landroid/view/View;

.field final synthetic b:Lit/sephiroth/android/library/widget/h;

.field final synthetic c:Lit/sephiroth/android/library/widget/AbsHListView;


# direct methods
.method constructor <init>(Lit/sephiroth/android/library/widget/AbsHListView;Landroid/view/View;Lit/sephiroth/android/library/widget/h;)V
    .registers 4

    .prologue
    .line 3115
    iput-object p1, p0, Lit/sephiroth/android/library/widget/AbsHListView$1;->c:Lit/sephiroth/android/library/widget/AbsHListView;

    iput-object p2, p0, Lit/sephiroth/android/library/widget/AbsHListView$1;->a:Landroid/view/View;

    iput-object p3, p0, Lit/sephiroth/android/library/widget/AbsHListView$1;->b:Lit/sephiroth/android/library/widget/h;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    .prologue
    const/4 v2, 0x0

    .line 3119
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$1;->c:Lit/sephiroth/android/library/widget/AbsHListView;

    const/4 v1, -0x1

    iput v1, v0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 3120
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$1;->a:Landroid/view/View;

    invoke-virtual {v0, v2}, Landroid/view/View;->setPressed(Z)V

    .line 3121
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$1;->c:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v0, v2}, Lit/sephiroth/android/library/widget/AbsHListView;->setPressed(Z)V

    .line 3122
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$1;->c:Lit/sephiroth/android/library/widget/AbsHListView;

    iget-boolean v0, v0, Lit/sephiroth/android/library/widget/AbsHListView;->ai:Z

    if-nez v0, :cond_1b

    .line 3123
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$1;->b:Lit/sephiroth/android/library/widget/h;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/h;->run()V

    .line 3125
    :cond_1b
    return-void
.end method

###### Class it.sephiroth.android.library.widget.AbsHListView.AnonymousClass2 (it.sephiroth.android.library.widget.AbsHListView$2)
.class final Lit/sephiroth/android/library/widget/AbsHListView$2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lit/sephiroth/android/library/widget/AbsHListView;->H()V
.end annotation


# instance fields
.field final synthetic a:Lit/sephiroth/android/library/widget/AbsHListView;


# direct methods
.method constructor <init>(Lit/sephiroth/android/library/widget/AbsHListView;)V
    .registers 2

    .prologue
    .line 4453
    iput-object p1, p0, Lit/sephiroth/android/library/widget/AbsHListView$2;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 4

    .prologue
    .line 4457
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$2;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget-boolean v0, v0, Lit/sephiroth/android/library/widget/AbsHListView;->y:Z

    if-eqz v0, :cond_30

    .line 4458
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$2;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView$2;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    const/4 v2, 0x0

    iput-boolean v2, v1, Lit/sephiroth/android/library/widget/AbsHListView;->z:Z

    iput-boolean v2, v0, Lit/sephiroth/android/library/widget/AbsHListView;->y:Z

    .line 4459
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$2;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-static {v0}, Lit/sephiroth/android/library/widget/AbsHListView;->m(Lit/sephiroth/android/library/widget/AbsHListView;)V

    .line 4460
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$2;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/AbsHListView;->getPersistentDrawingCache()I

    move-result v0

    and-int/lit8 v0, v0, 0x2

    if-nez v0, :cond_23

    .line 4461
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$2;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-static {v0}, Lit/sephiroth/android/library/widget/AbsHListView;->n(Lit/sephiroth/android/library/widget/AbsHListView;)V

    .line 4463
    :cond_23
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$2;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/AbsHListView;->isAlwaysDrawnWithCacheEnabled()Z

    move-result v0

    if-nez v0, :cond_30

    .line 4464
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$2;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/AbsHListView;->invalidate()V

    .line 4467
    :cond_30
    return-void
.end method

###### Class it.sephiroth.android.library.widget.AbsHListView.LayoutParams (it.sephiroth.android.library.widget.AbsHListView$LayoutParams)
.class public Lit/sephiroth/android/library/widget/AbsHListView$LayoutParams;
.super Landroid/view/ViewGroup$LayoutParams;
.source "SourceFile"


# instance fields
.field public a:I

.field public b:Z

.field public c:Z

.field public d:I

.field public e:J


# direct methods
.method public constructor <init>()V
    .registers 3

    .prologue
    .line 5341
    const/4 v0, -0x2

    const/4 v1, -0x1

    invoke-direct {p0, v0, v1}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    .line 5330
    const-wide/16 v0, -0x1

    iput-wide v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$LayoutParams;->e:J

    .line 5342
    const/4 v0, 0x0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$LayoutParams;->a:I

    .line 5343
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 5

    .prologue
    .line 5333
    invoke-direct {p0, p1, p2}, Landroid/view/ViewGroup$LayoutParams;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 5330
    const-wide/16 v0, -0x1

    iput-wide v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$LayoutParams;->e:J

    .line 5334
    return-void
.end method

.method public constructor <init>(Landroid/view/ViewGroup$LayoutParams;)V
    .registers 4

    .prologue
    .line 5346
    invoke-direct {p0, p1}, Landroid/view/ViewGroup$LayoutParams;-><init>(Landroid/view/ViewGroup$LayoutParams;)V

    .line 5330
    const-wide/16 v0, -0x1

    iput-wide v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$LayoutParams;->e:J

    .line 5347
    return-void
.end method

###### Class it.sephiroth.android.library.widget.AbsHListView.SavedState (it.sephiroth.android.library.widget.AbsHListView$SavedState)
.class Lit/sephiroth/android/library/widget/AbsHListView$SavedState;
.super Landroid/view/View$BaseSavedState;
.source "SourceFile"


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator",
            "<",
            "Lit/sephiroth/android/library/widget/AbsHListView$SavedState;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field a:J

.field b:J

.field c:I

.field d:I

.field e:I

.field f:Ljava/lang/String;

.field g:Z

.field h:I

.field i:Landroid/util/SparseBooleanArray;

.field j:Landroid/support/v4/c/e;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/support/v4/c/e",
            "<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .prologue
    .line 1381
    new-instance v0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState$1;

    invoke-direct {v0}, Lit/sephiroth/android/library/widget/AbsHListView$SavedState$1;-><init>()V

    sput-object v0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method private constructor <init>(Landroid/os/Parcel;)V
    .registers 8

    .prologue
    const/4 v1, 0x0

    .line 1327
    invoke-direct {p0, p1}, Landroid/view/View$BaseSavedState;-><init>(Landroid/os/Parcel;)V

    .line 1328
    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v2

    iput-wide v2, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->a:J

    .line 1329
    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v2

    iput-wide v2, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->b:J

    .line 1330
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->c:I

    .line 1331
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->d:I

    .line 1332
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->e:I

    .line 1333
    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->f:Ljava/lang/String;

    .line 1334
    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    if-eqz v0, :cond_60

    const/4 v0, 0x1

    :goto_2f
    iput-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->g:Z

    .line 1335
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    iput v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->h:I

    .line 1336
    invoke-virtual {p1}, Landroid/os/Parcel;->readSparseBooleanArray()Landroid/util/SparseBooleanArray;

    move-result-object v0

    iput-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->i:Landroid/util/SparseBooleanArray;

    .line 1337
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    .line 1338
    if-lez v0, :cond_62

    .line 1339
    new-instance v2, Landroid/support/v4/c/e;

    invoke-direct {v2}, Landroid/support/v4/c/e;-><init>()V

    iput-object v2, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->j:Landroid/support/v4/c/e;

    .line 1340
    :goto_4a
    if-ge v1, v0, :cond_62

    .line 1341
    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v2

    .line 1342
    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v4

    .line 1343
    iget-object v5, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->j:Landroid/support/v4/c/e;

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v5, v2, v3, v4}, Landroid/support/v4/c/e;->a(JLjava/lang/Object;)V

    .line 1340
    add-int/lit8 v1, v1, 0x1

    goto :goto_4a

    :cond_60
    move v0, v1

    .line 1334
    goto :goto_2f

    .line 1346
    :cond_62
    return-void
.end method

.method synthetic constructor <init>(Landroid/os/Parcel;B)V
    .registers 3

    .prologue
    .line 1303
    invoke-direct {p0, p1}, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;-><init>(Landroid/os/Parcel;)V

    return-void
.end method

.method constructor <init>(Landroid/os/Parcelable;)V
    .registers 2

    .prologue
    .line 1320
    invoke-direct {p0, p1}, Landroid/view/View$BaseSavedState;-><init>(Landroid/os/Parcelable;)V

    .line 1321
    return-void
.end method


# virtual methods
.method public toString()Ljava/lang/String;
    .registers 4

    .prologue
    .line 1370
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "AbsListView.SavedState{"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " selectedId="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-wide v1, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->a:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " firstId="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-wide v1, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->b:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " viewLeft="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->c:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " position="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->d:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " width="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->e:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " filter="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->f:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " checkState="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->i:Landroid/util/SparseBooleanArray;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "}"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .registers 8

    .prologue
    const/4 v1, 0x0

    .line 1350
    invoke-super {p0, p1, p2}, Landroid/view/View$BaseSavedState;->writeToParcel(Landroid/os/Parcel;I)V

    .line 1351
    iget-wide v2, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->a:J

    invoke-virtual {p1, v2, v3}, Landroid/os/Parcel;->writeLong(J)V

    .line 1352
    iget-wide v2, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->b:J

    invoke-virtual {p1, v2, v3}, Landroid/os/Parcel;->writeLong(J)V

    .line 1353
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->c:I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 1354
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->d:I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 1355
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->e:I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 1356
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->f:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    .line 1357
    iget-boolean v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->g:Z

    if-eqz v0, :cond_60

    const/4 v0, 0x1

    :goto_27
    int-to-byte v0, v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeByte(B)V

    .line 1358
    iget v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->h:I

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 1359
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->i:Landroid/util/SparseBooleanArray;

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeSparseBooleanArray(Landroid/util/SparseBooleanArray;)V

    .line 1360
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->j:Landroid/support/v4/c/e;

    if-eqz v0, :cond_62

    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->j:Landroid/support/v4/c/e;

    invoke-virtual {v0}, Landroid/support/v4/c/e;->a()I

    move-result v0

    move v2, v0

    .line 1361
    :goto_40
    invoke-virtual {p1, v2}, Landroid/os/Parcel;->writeInt(I)V

    .line 1362
    :goto_43
    if-ge v1, v2, :cond_64

    .line 1363
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->j:Landroid/support/v4/c/e;

    invoke-virtual {v0, v1}, Landroid/support/v4/c/e;->a(I)J

    move-result-wide v3

    invoke-virtual {p1, v3, v4}, Landroid/os/Parcel;->writeLong(J)V

    .line 1364
    iget-object v0, p0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;->j:Landroid/support/v4/c/e;

    invoke-virtual {v0, v1}, Landroid/support/v4/c/e;->b(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->writeInt(I)V

    .line 1362
    add-int/lit8 v1, v1, 0x1

    goto :goto_43

    :cond_60
    move v0, v1

    .line 1357
    goto :goto_27

    :cond_62
    move v2, v1

    .line 1360
    goto :goto_40

    .line 1366
    :cond_64
    return-void
.end method

###### Class it.sephiroth.android.library.widget.AbsHListView.SavedState.AnonymousClass1 (it.sephiroth.android.library.widget.AbsHListView$SavedState$1)
.class final Lit/sephiroth/android/library/widget/AbsHListView$SavedState$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lit/sephiroth/android/library/widget/AbsHListView$SavedState;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$Creator",
        "<",
        "Lit/sephiroth/android/library/widget/AbsHListView$SavedState;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 1381
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .registers 4

    .prologue
    .line 1381
    new-instance v0, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;

    const/4 v1, 0x0

    invoke-direct {v0, p1, v1}, Lit/sephiroth/android/library/widget/AbsHListView$SavedState;-><init>(Landroid/os/Parcel;B)V

    return-object v0
.end method

.method public final bridge synthetic newArray(I)[Ljava/lang/Object;
    .registers 3

    .prologue
    .line 1381
    new-array v0, p1, [Lit/sephiroth/android/library/widget/AbsHListView$SavedState;

    return-object v0
.end method
