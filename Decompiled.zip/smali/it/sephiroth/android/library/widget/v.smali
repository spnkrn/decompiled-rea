###### Class it.sephiroth.android.library.widget.v (it.sephiroth.android.library.widget.v)
.class final Lit/sephiroth/android/library/widget/v;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lit/sephiroth/android/library/widget/HListView;

.field private b:I

.field private c:I


# direct methods
.method private constructor <init>(Lit/sephiroth/android/library/widget/HListView;)V
    .registers 2

    .prologue
    .line 1077
    iput-object p1, p0, Lit/sephiroth/android/library/widget/v;->a:Lit/sephiroth/android/library/widget/HListView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lit/sephiroth/android/library/widget/HListView;B)V
    .registers 3

    .prologue
    .line 1077
    invoke-direct {p0, p1}, Lit/sephiroth/android/library/widget/v;-><init>(Lit/sephiroth/android/library/widget/HListView;)V

    return-void
.end method


# virtual methods
.method public final a(II)Lit/sephiroth/android/library/widget/v;
    .registers 3

    .prologue
    .line 1083
    iput p1, p0, Lit/sephiroth/android/library/widget/v;->b:I

    .line 1084
    iput p2, p0, Lit/sephiroth/android/library/widget/v;->c:I

    .line 1085
    return-object p0
.end method

.method public final run()V
    .registers 4

    .prologue
    .line 1090
    iget-object v0, p0, Lit/sephiroth/android/library/widget/v;->a:Lit/sephiroth/android/library/widget/HListView;

    iget v1, p0, Lit/sephiroth/android/library/widget/v;->b:I

    iget v2, p0, Lit/sephiroth/android/library/widget/v;->c:I

    invoke-virtual {v0, v1, v2}, Lit/sephiroth/android/library/widget/HListView;->b(II)V

    .line 1091
    return-void
.end method
