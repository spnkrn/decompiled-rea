###### Class it.sephiroth.android.library.widget.m (it.sephiroth.android.library.widget.m)
.class public final Lit/sephiroth/android/library/widget/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/ContextMenu$ContextMenuInfo;


# instance fields
.field public a:Landroid/view/View;

.field public b:I

.field public c:J


# direct methods
.method public constructor <init>(Landroid/view/View;IJ)V
    .registers 5

    .prologue
    .line 400
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 401
    iput-object p1, p0, Lit/sephiroth/android/library/widget/m;->a:Landroid/view/View;

    .line 402
    iput p2, p0, Lit/sephiroth/android/library/widget/m;->b:I

    .line 403
    iput-wide p3, p0, Lit/sephiroth/android/library/widget/m;->c:J

    .line 404
    return-void
.end method
