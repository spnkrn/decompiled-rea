###### Class it.sephiroth.android.library.widget.k (it.sephiroth.android.library.widget.k)
.class public interface abstract Lit/sephiroth/android/library/widget/k;
.super Ljava/lang/Object;
.source "SourceFile"
