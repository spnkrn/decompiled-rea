###### Class it.sephiroth.android.library.widget.e (it.sephiroth.android.library.widget.e)
.class final Lit/sephiroth/android/library/widget/e;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field final synthetic a:Lit/sephiroth/android/library/widget/AbsHListView;

.field private final b:Lit/sephiroth/android/library/widget/x;

.field private c:I

.field private final d:Ljava/lang/Runnable;


# direct methods
.method constructor <init>(Lit/sephiroth/android/library/widget/AbsHListView;)V
    .registers 4

    .prologue
    .line 3640
    iput-object p1, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 3613
    new-instance v0, Lit/sephiroth/android/library/widget/e$1;

    invoke-direct {v0, p0}, Lit/sephiroth/android/library/widget/e$1;-><init>(Lit/sephiroth/android/library/widget/e;)V

    iput-object v0, p0, Lit/sephiroth/android/library/widget/e;->d:Ljava/lang/Runnable;

    .line 3641
    new-instance v0, Lit/sephiroth/android/library/widget/x;

    invoke-virtual {p1}, Lit/sephiroth/android/library/widget/AbsHListView;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Lit/sephiroth/android/library/widget/x;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lit/sephiroth/android/library/widget/e;->b:Lit/sephiroth/android/library/widget/x;

    .line 3642
    return-void
.end method

.method static synthetic a(Lit/sephiroth/android/library/widget/e;)Lit/sephiroth/android/library/widget/x;
    .registers 2

    .prologue
    .line 3601
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->b:Lit/sephiroth/android/library/widget/x;

    return-object v0
.end method


# virtual methods
.method final a()V
    .registers 3

    .prologue
    .line 3654
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->b:Lit/sephiroth/android/library/widget/x;

    iget-object v1, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v1}, Lit/sephiroth/android/library/widget/AbsHListView;->getScrollX()I

    move-result v1

    invoke-virtual {v0, v1}, Lit/sephiroth/android/library/widget/x;->a(I)Z

    move-result v0

    if-eqz v0, :cond_20

    .line 3655
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    const/4 v1, 0x6

    iput v1, v0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 3656
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/AbsHListView;->invalidate()V

    .line 3657
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget-object v0, v0, Lit/sephiroth/android/library/widget/AbsHListView;->a:Lit/sephiroth/android/library/a/b;

    invoke-virtual {v0, p0}, Lit/sephiroth/android/library/a/b;->a(Ljava/lang/Runnable;)V

    .line 3662
    :goto_1f
    return-void

    .line 3659
    :cond_20
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    const/4 v1, -0x1

    iput v1, v0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 3660
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->a(I)V

    goto :goto_1f
.end method

.method final a(I)V
    .registers 9

    .prologue
    const v5, 0x7fffffff

    const/4 v3, 0x0

    .line 3645
    if-gez p1, :cond_24

    move v1, v5

    .line 3646
    :goto_7
    iput v1, p0, Lit/sephiroth/android/library/widget/e;->c:I

    .line 3647
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->b:Lit/sephiroth/android/library/widget/x;

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Lit/sephiroth/android/library/widget/x;->a(Landroid/view/animation/Interpolator;)V

    .line 3648
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->b:Lit/sephiroth/android/library/widget/x;

    move v2, p1

    move v4, v3

    move v6, v3

    invoke-virtual/range {v0 .. v6}, Lit/sephiroth/android/library/widget/x;->a(IIIIII)V

    .line 3649
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    const/4 v1, 0x4

    iput v1, v0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 3650
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget-object v0, v0, Lit/sephiroth/android/library/widget/AbsHListView;->a:Lit/sephiroth/android/library/a/b;

    invoke-virtual {v0, p0}, Lit/sephiroth/android/library/a/b;->a(Ljava/lang/Runnable;)V

    .line 3651
    return-void

    :cond_24
    move v1, v3

    .line 3645
    goto :goto_7
.end method

.method final a(IIZ)V
    .registers 7

    .prologue
    .line 3694
    if-gez p1, :cond_22

    const v0, 0x7fffffff

    .line 3695
    :goto_5
    iput v0, p0, Lit/sephiroth/android/library/widget/e;->c:I

    .line 3696
    iget-object v2, p0, Lit/sephiroth/android/library/widget/e;->b:Lit/sephiroth/android/library/widget/x;

    if-eqz p3, :cond_24

    sget-object v1, Lit/sephiroth/android/library/widget/AbsHListView;->T:Landroid/view/animation/Interpolator;

    :goto_d
    invoke-virtual {v2, v1}, Lit/sephiroth/android/library/widget/x;->a(Landroid/view/animation/Interpolator;)V

    .line 3697
    iget-object v1, p0, Lit/sephiroth/android/library/widget/e;->b:Lit/sephiroth/android/library/widget/x;

    invoke-virtual {v1, v0, p1, p2}, Lit/sephiroth/android/library/widget/x;->a(III)V

    .line 3698
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    const/4 v1, 0x4

    iput v1, v0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 3699
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget-object v0, v0, Lit/sephiroth/android/library/widget/AbsHListView;->a:Lit/sephiroth/android/library/a/b;

    invoke-virtual {v0, p0}, Lit/sephiroth/android/library/a/b;->a(Ljava/lang/Runnable;)V

    .line 3700
    return-void

    .line 3694
    :cond_22
    const/4 v0, 0x0

    goto :goto_5

    .line 3696
    :cond_24
    const/4 v1, 0x0

    goto :goto_d
.end method

.method final b()V
    .registers 3

    .prologue
    .line 3703
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    const/4 v1, -0x1

    iput v1, v0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 3705
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v0, p0}, Lit/sephiroth/android/library/widget/AbsHListView;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 3706
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget-object v1, p0, Lit/sephiroth/android/library/widget/e;->d:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 3708
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->a(I)V

    .line 3709
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-static {v0}, Lit/sephiroth/android/library/widget/AbsHListView;->k(Lit/sephiroth/android/library/widget/AbsHListView;)V

    .line 3710
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->b:Lit/sephiroth/android/library/widget/x;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/x;->e()V

    .line 3712
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-static {v0}, Lit/sephiroth/android/library/widget/AbsHListView;->l(Lit/sephiroth/android/library/widget/AbsHListView;)Z

    .line 3714
    return-void
.end method

.method final b(I)V
    .registers 9

    .prologue
    const/4 v3, 0x0

    .line 3665
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->b:Lit/sephiroth/android/library/widget/x;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lit/sephiroth/android/library/widget/x;->a(Landroid/view/animation/Interpolator;)V

    .line 3666
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->b:Lit/sephiroth/android/library/widget/x;

    iget-object v1, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v1}, Lit/sephiroth/android/library/widget/AbsHListView;->getScrollX()I

    move-result v1

    const/high16 v4, -0x80000000

    iget-object v2, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v2}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v6

    move v2, p1

    move v5, v3

    invoke-virtual/range {v0 .. v6}, Lit/sephiroth/android/library/widget/x;->a(IIIIII)V

    .line 3667
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    const/4 v1, 0x6

    iput v1, v0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 3668
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/AbsHListView;->invalidate()V

    .line 3669
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget-object v0, v0, Lit/sephiroth/android/library/widget/AbsHListView;->a:Lit/sephiroth/android/library/a/b;

    invoke-virtual {v0, p0}, Lit/sephiroth/android/library/a/b;->a(Ljava/lang/Runnable;)V

    .line 3670
    return-void
.end method

.method final c()V
    .registers 5

    .prologue
    .line 3717
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget-object v1, p0, Lit/sephiroth/android/library/widget/e;->d:Ljava/lang/Runnable;

    const-wide/16 v2, 0x28

    invoke-virtual {v0, v1, v2, v3}, Lit/sephiroth/android/library/widget/AbsHListView;->postDelayed(Ljava/lang/Runnable;J)Z

    .line 3718
    return-void
.end method

.method public final run()V
    .registers 9

    .prologue
    const/4 v3, 0x1

    const/4 v2, 0x0

    .line 3722
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget v0, v0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    packed-switch v0, :pswitch_data_1c4

    .line 3724
    :pswitch_9
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/e;->b()V

    .line 3830
    :cond_c
    :goto_c
    return-void

    .line 3728
    :pswitch_d
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->b:Lit/sephiroth/android/library/widget/x;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/x;->a()Z

    move-result v0

    if-nez v0, :cond_c

    .line 3733
    :pswitch_15
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget-boolean v0, v0, Lit/sephiroth/android/library/widget/AbsHListView;->ai:Z

    if-eqz v0, :cond_20

    .line 3734
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/AbsHListView;->e()V

    .line 3737
    :cond_20
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget v0, v0, Lit/sephiroth/android/library/widget/AbsHListView;->an:I

    if-eqz v0, :cond_2e

    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v0

    if-nez v0, :cond_32

    .line 3738
    :cond_2e
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/e;->b()V

    goto :goto_c

    .line 3742
    :cond_32
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->b:Lit/sephiroth/android/library/widget/x;

    .line 3743
    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/x;->d()Z

    move-result v4

    .line 3744
    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/x;->b()I

    move-result v5

    .line 3748
    iget v0, p0, Lit/sephiroth/android/library/widget/e;->c:I

    sub-int/2addr v0, v5

    .line 3751
    if-lez v0, :cond_f5

    .line 3753
    iget-object v1, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget-object v6, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget v6, v6, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    iput v6, v1, Lit/sephiroth/android/library/widget/AbsHListView;->A:I

    .line 3754
    iget-object v1, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v1, v2}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    .line 3755
    iget-object v6, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v1}, Landroid/view/View;->getLeft()I

    move-result v1

    iput v1, v6, Lit/sephiroth/android/library/widget/AbsHListView;->B:I

    .line 3758
    iget-object v1, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v1}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v1

    iget-object v6, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v6}, Lit/sephiroth/android/library/widget/AbsHListView;->getPaddingRight()I

    move-result v6

    sub-int/2addr v1, v6

    iget-object v6, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v6}, Lit/sephiroth/android/library/widget/AbsHListView;->getPaddingLeft()I

    move-result v6

    sub-int/2addr v1, v6

    add-int/lit8 v1, v1, -0x1

    invoke-static {v1, v0}, Ljava/lang/Math;->min(II)I

    move-result v0

    .line 3772
    :goto_71
    iget-object v1, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget-object v6, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget v6, v6, Lit/sephiroth/android/library/widget/AbsHListView;->A:I

    iget-object v7, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget v7, v7, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    sub-int/2addr v6, v7

    invoke-virtual {v1, v6}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v6

    .line 3774
    if-eqz v6, :cond_1c1

    .line 3775
    invoke-virtual {v6}, Landroid/view/View;->getLeft()I

    move-result v1

    .line 3779
    :goto_86
    iget-object v7, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v7, v0, v0}, Lit/sephiroth/android/library/widget/AbsHListView;->a(II)Z

    move-result v7

    .line 3780
    if-eqz v7, :cond_91

    if-eqz v0, :cond_91

    move v2, v3

    .line 3781
    :cond_91
    if-eqz v2, :cond_14e

    .line 3782
    if-eqz v6, :cond_ad

    .line 3784
    invoke-virtual {v6}, Landroid/view/View;->getLeft()I

    move-result v2

    sub-int v1, v2, v1

    sub-int v1, v0, v1

    neg-int v1, v1

    .line 3785
    iget-object v2, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget-object v5, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v5}, Lit/sephiroth/android/library/widget/AbsHListView;->getScrollX()I

    move-result v5

    iget-object v6, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget v6, v6, Lit/sephiroth/android/library/widget/AbsHListView;->R:I

    invoke-static {v2, v1, v5, v6}, Lit/sephiroth/android/library/widget/AbsHListView;->a(Lit/sephiroth/android/library/widget/AbsHListView;III)Z

    .line 3787
    :cond_ad
    if-eqz v4, :cond_c

    .line 3788
    iget-object v1, p0, Lit/sephiroth/android/library/widget/e;->b:Lit/sephiroth/android/library/widget/x;

    iget-object v2, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v2}, Lit/sephiroth/android/library/widget/AbsHListView;->getScrollX()I

    move-result v2

    iget-object v4, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget v4, v4, Lit/sephiroth/android/library/widget/AbsHListView;->R:I

    invoke-virtual {v1, v2, v4}, Lit/sephiroth/android/library/widget/x;->a(II)V

    iget-object v1, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v1}, Lit/sephiroth/android/library/widget/AbsHListView;->getOverScrollMode()I

    move-result v1

    if-eqz v1, :cond_d0

    if-ne v1, v3, :cond_13b

    iget-object v1, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-static {v1}, Lit/sephiroth/android/library/widget/AbsHListView;->h(Lit/sephiroth/android/library/widget/AbsHListView;)Z

    move-result v1

    if-nez v1, :cond_13b

    :cond_d0
    iget-object v1, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    const/4 v2, 0x6

    iput v2, v1, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    iget-object v1, p0, Lit/sephiroth/android/library/widget/e;->b:Lit/sephiroth/android/library/widget/x;

    invoke-virtual {v1}, Lit/sephiroth/android/library/widget/x;->c()F

    move-result v1

    float-to-int v1, v1

    if-lez v0, :cond_131

    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-static {v0}, Lit/sephiroth/android/library/widget/AbsHListView;->i(Lit/sephiroth/android/library/widget/AbsHListView;)Lit/sephiroth/android/library/widget/s;

    move-result-object v0

    invoke-virtual {v0, v1}, Lit/sephiroth/android/library/widget/s;->a(I)V

    :cond_e7
    :goto_e7
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/AbsHListView;->invalidate()V

    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget-object v0, v0, Lit/sephiroth/android/library/widget/AbsHListView;->a:Lit/sephiroth/android/library/a/b;

    invoke-virtual {v0, p0}, Lit/sephiroth/android/library/a/b;->a(Ljava/lang/Runnable;)V

    goto/16 :goto_c

    .line 3761
    :cond_f5
    iget-object v1, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v1}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildCount()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    .line 3762
    iget-object v6, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget-object v7, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget v7, v7, Lit/sephiroth/android/library/widget/AbsHListView;->V:I

    add-int/2addr v7, v1

    iput v7, v6, Lit/sephiroth/android/library/widget/AbsHListView;->A:I

    .line 3764
    iget-object v6, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v6, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->getChildAt(I)Landroid/view/View;

    move-result-object v1

    .line 3765
    iget-object v6, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v1}, Landroid/view/View;->getLeft()I

    move-result v1

    iput v1, v6, Lit/sephiroth/android/library/widget/AbsHListView;->B:I

    .line 3768
    iget-object v1, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v1}, Lit/sephiroth/android/library/widget/AbsHListView;->getWidth()I

    move-result v1

    iget-object v6, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v6}, Lit/sephiroth/android/library/widget/AbsHListView;->getPaddingRight()I

    move-result v6

    sub-int/2addr v1, v6

    iget-object v6, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v6}, Lit/sephiroth/android/library/widget/AbsHListView;->getPaddingLeft()I

    move-result v6

    sub-int/2addr v1, v6

    add-int/lit8 v1, v1, -0x1

    neg-int v1, v1

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    goto/16 :goto_71

    .line 3788
    :cond_131
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-static {v0}, Lit/sephiroth/android/library/widget/AbsHListView;->j(Lit/sephiroth/android/library/widget/AbsHListView;)Lit/sephiroth/android/library/widget/s;

    move-result-object v0

    invoke-virtual {v0, v1}, Lit/sephiroth/android/library/widget/s;->a(I)V

    goto :goto_e7

    :cond_13b
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    const/4 v1, -0x1

    iput v1, v0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget-object v0, v0, Lit/sephiroth/android/library/widget/AbsHListView;->I:Lit/sephiroth/android/library/widget/i;

    if-eqz v0, :cond_e7

    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget-object v0, v0, Lit/sephiroth/android/library/widget/AbsHListView;->I:Lit/sephiroth/android/library/widget/i;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/i;->a()V

    goto :goto_e7

    .line 3793
    :cond_14e
    if-eqz v4, :cond_164

    if-nez v2, :cond_164

    .line 3794
    if-eqz v7, :cond_159

    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/AbsHListView;->invalidate()V

    .line 3795
    :cond_159
    iput v5, p0, Lit/sephiroth/android/library/widget/e;->c:I

    .line 3796
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget-object v0, v0, Lit/sephiroth/android/library/widget/AbsHListView;->a:Lit/sephiroth/android/library/a/b;

    invoke-virtual {v0, p0}, Lit/sephiroth/android/library/a/b;->a(Ljava/lang/Runnable;)V

    goto/16 :goto_c

    .line 3798
    :cond_164
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/e;->b()V

    goto/16 :goto_c

    .line 3805
    :pswitch_169
    iget-object v1, p0, Lit/sephiroth/android/library/widget/e;->b:Lit/sephiroth/android/library/widget/x;

    .line 3806
    invoke-virtual {v1}, Lit/sephiroth/android/library/widget/x;->d()Z

    move-result v0

    if-eqz v0, :cond_1bc

    .line 3807
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/AbsHListView;->getScrollX()I

    move-result v4

    .line 3808
    invoke-virtual {v1}, Lit/sephiroth/android/library/widget/x;->b()I

    move-result v5

    .line 3809
    sub-int v0, v5, v4

    .line 3810
    iget-object v6, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget-object v7, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget v7, v7, Lit/sephiroth/android/library/widget/AbsHListView;->R:I

    invoke-static {v6, v0, v4, v7}, Lit/sephiroth/android/library/widget/AbsHListView;->b(Lit/sephiroth/android/library/widget/AbsHListView;III)Z

    move-result v0

    if-eqz v0, :cond_1ae

    .line 3811
    if-gtz v4, :cond_1a7

    if-lez v5, :cond_1a7

    move v0, v3

    .line 3812
    :goto_18e
    if-ltz v4, :cond_193

    if-gez v5, :cond_193

    move v2, v3

    .line 3813
    :cond_193
    if-nez v0, :cond_197

    if-eqz v2, :cond_1a9

    .line 3814
    :cond_197
    invoke-virtual {v1}, Lit/sephiroth/android/library/widget/x;->c()F

    move-result v0

    float-to-int v0, v0

    .line 3815
    if-eqz v2, :cond_19f

    neg-int v0, v0

    .line 3818
    :cond_19f
    invoke-virtual {v1}, Lit/sephiroth/android/library/widget/x;->e()V

    .line 3819
    invoke-virtual {p0, v0}, Lit/sephiroth/android/library/widget/e;->a(I)V

    goto/16 :goto_c

    :cond_1a7
    move v0, v2

    .line 3811
    goto :goto_18e

    .line 3821
    :cond_1a9
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/e;->a()V

    goto/16 :goto_c

    .line 3824
    :cond_1ae
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/AbsHListView;->invalidate()V

    .line 3825
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    iget-object v0, v0, Lit/sephiroth/android/library/widget/AbsHListView;->a:Lit/sephiroth/android/library/a/b;

    invoke-virtual {v0, p0}, Lit/sephiroth/android/library/a/b;->a(Ljava/lang/Runnable;)V

    goto/16 :goto_c

    .line 3828
    :cond_1bc
    invoke-virtual {p0}, Lit/sephiroth/android/library/widget/e;->b()V

    goto/16 :goto_c

    :cond_1c1
    move v1, v2

    goto/16 :goto_86

    .line 3722
    :pswitch_data_1c4
    .packed-switch 0x3
        :pswitch_d
        :pswitch_15
        :pswitch_9
        :pswitch_169
    .end packed-switch
.end method

###### Class it.sephiroth.android.library.widget.e.AnonymousClass1 (it.sephiroth.android.library.widget.e$1)
.class final Lit/sephiroth/android/library/widget/e$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lit/sephiroth/android/library/widget/e;
.end annotation


# instance fields
.field final synthetic a:Lit/sephiroth/android/library/widget/e;


# direct methods
.method constructor <init>(Lit/sephiroth/android/library/widget/e;)V
    .registers 2

    .prologue
    .line 3613
    iput-object p1, p0, Lit/sephiroth/android/library/widget/e$1;->a:Lit/sephiroth/android/library/widget/e;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 6

    .prologue
    .line 3617
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e$1;->a:Lit/sephiroth/android/library/widget/e;

    iget-object v0, v0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-static {v0}, Lit/sephiroth/android/library/widget/AbsHListView;->d(Lit/sephiroth/android/library/widget/AbsHListView;)I

    move-result v0

    .line 3618
    iget-object v1, p0, Lit/sephiroth/android/library/widget/e$1;->a:Lit/sephiroth/android/library/widget/e;

    iget-object v1, v1, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-static {v1}, Lit/sephiroth/android/library/widget/AbsHListView;->e(Lit/sephiroth/android/library/widget/AbsHListView;)Landroid/view/VelocityTracker;

    move-result-object v1

    .line 3619
    iget-object v2, p0, Lit/sephiroth/android/library/widget/e$1;->a:Lit/sephiroth/android/library/widget/e;

    invoke-static {v2}, Lit/sephiroth/android/library/widget/e;->a(Lit/sephiroth/android/library/widget/e;)Lit/sephiroth/android/library/widget/x;

    move-result-object v2

    .line 3620
    if-eqz v1, :cond_1b

    const/4 v3, -0x1

    if-ne v0, v3, :cond_1c

    .line 3635
    :cond_1b
    :goto_1b
    return-void

    .line 3624
    :cond_1c
    const/16 v3, 0x3e8

    iget-object v4, p0, Lit/sephiroth/android/library/widget/e$1;->a:Lit/sephiroth/android/library/widget/e;

    iget-object v4, v4, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-static {v4}, Lit/sephiroth/android/library/widget/AbsHListView;->f(Lit/sephiroth/android/library/widget/AbsHListView;)I

    move-result v4

    int-to-float v4, v4

    invoke-virtual {v1, v3, v4}, Landroid/view/VelocityTracker;->computeCurrentVelocity(IF)V

    .line 3625
    invoke-virtual {v1, v0}, Landroid/view/VelocityTracker;->getXVelocity(I)F

    move-result v0

    neg-float v0, v0

    .line 3627
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v1

    iget-object v3, p0, Lit/sephiroth/android/library/widget/e$1;->a:Lit/sephiroth/android/library/widget/e;

    iget-object v3, v3, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    invoke-static {v3}, Lit/sephiroth/android/library/widget/AbsHListView;->g(Lit/sephiroth/android/library/widget/AbsHListView;)I

    move-result v3

    int-to-float v3, v3

    cmpl-float v1, v1, v3

    if-ltz v1, :cond_50

    invoke-virtual {v2, v0}, Lit/sephiroth/android/library/widget/x;->a(F)Z

    move-result v0

    if-eqz v0, :cond_50

    .line 3629
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e$1;->a:Lit/sephiroth/android/library/widget/e;

    iget-object v0, v0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    const-wide/16 v1, 0x28

    invoke-virtual {v0, p0, v1, v2}, Lit/sephiroth/android/library/widget/AbsHListView;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_1b

    .line 3631
    :cond_50
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e$1;->a:Lit/sephiroth/android/library/widget/e;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/e;->b()V

    .line 3632
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e$1;->a:Lit/sephiroth/android/library/widget/e;

    iget-object v0, v0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    const/4 v1, 0x3

    iput v1, v0, Lit/sephiroth/android/library/widget/AbsHListView;->F:I

    .line 3633
    iget-object v0, p0, Lit/sephiroth/android/library/widget/e$1;->a:Lit/sephiroth/android/library/widget/e;

    iget-object v0, v0, Lit/sephiroth/android/library/widget/e;->a:Lit/sephiroth/android/library/widget/AbsHListView;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lit/sephiroth/android/library/widget/AbsHListView;->a(I)V

    goto :goto_1b
.end method
