###### Class it.sephiroth.android.library.widget.g (it.sephiroth.android.library.widget.g)
.class public interface abstract Lit/sephiroth/android/library/widget/g;
.super Ljava/lang/Object;
.source "SourceFile"
