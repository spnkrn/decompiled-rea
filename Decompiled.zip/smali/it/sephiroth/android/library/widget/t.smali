###### Class it.sephiroth.android.library.widget.t (it.sephiroth.android.library.widget.t)
.class final Lit/sephiroth/android/library/widget/t;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field private a:I

.field private b:I


# direct methods
.method private constructor <init>()V
    .registers 1

    .prologue
    .line 2762
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(B)V
    .registers 2

    .prologue
    .line 2762
    invoke-direct {p0}, Lit/sephiroth/android/library/widget/t;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()I
    .registers 2

    .prologue
    .line 2776
    iget v0, p0, Lit/sephiroth/android/library/widget/t;->a:I

    return v0
.end method

.method final a(II)V
    .registers 3

    .prologue
    .line 2771
    iput p1, p0, Lit/sephiroth/android/library/widget/t;->a:I

    .line 2772
    iput p2, p0, Lit/sephiroth/android/library/widget/t;->b:I

    .line 2773
    return-void
.end method

.method public final b()I
    .registers 2

    .prologue
    .line 2780
    iget v0, p0, Lit/sephiroth/android/library/widget/t;->b:I

    return v0
.end method
