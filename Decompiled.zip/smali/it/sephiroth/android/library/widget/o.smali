###### Class it.sephiroth.android.library.widget.o (it.sephiroth.android.library.widget.o)
.class public interface abstract Lit/sephiroth/android/library/widget/o;
.super Ljava/lang/Object;
.source "SourceFile"
