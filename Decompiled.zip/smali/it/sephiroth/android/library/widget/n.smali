###### Class it.sephiroth.android.library.widget.n (it.sephiroth.android.library.widget.n)
.class Lit/sephiroth/android/library/widget/n;
.super Landroid/database/DataSetObserver;
.source "SourceFile"


# instance fields
.field private a:Landroid/os/Parcelable;

.field final synthetic b:Lit/sephiroth/android/library/widget/AdapterView;


# direct methods
.method constructor <init>(Lit/sephiroth/android/library/widget/AdapterView;)V
    .registers 3

    .prologue
    .line 800
    iput-object p1, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    invoke-direct {p0}, Landroid/database/DataSetObserver;-><init>()V

    .line 802
    const/4 v0, 0x0

    iput-object v0, p0, Lit/sephiroth/android/library/widget/n;->a:Landroid/os/Parcelable;

    return-void
.end method


# virtual methods
.method public onChanged()V
    .registers 3

    .prologue
    .line 806
    const-string v0, "View"

    const-string v1, "onChanged"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 807
    iget-object v0, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    const/4 v1, 0x1

    iput-boolean v1, v0, Lit/sephiroth/android/library/widget/AdapterView;->ai:Z

    .line 808
    iget-object v0, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    iget-object v1, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    iget v1, v1, Lit/sephiroth/android/library/widget/AdapterView;->an:I

    iput v1, v0, Lit/sephiroth/android/library/widget/AdapterView;->ao:I

    .line 809
    iget-object v0, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    iget-object v1, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    invoke-virtual {v1}, Lit/sephiroth/android/library/widget/AdapterView;->q()Landroid/widget/Adapter;

    move-result-object v1

    invoke-interface {v1}, Landroid/widget/Adapter;->getCount()I

    move-result v1

    iput v1, v0, Lit/sephiroth/android/library/widget/AdapterView;->an:I

    .line 813
    iget-object v0, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/AdapterView;->q()Landroid/widget/Adapter;

    move-result-object v0

    invoke-interface {v0}, Landroid/widget/Adapter;->hasStableIds()Z

    move-result v0

    if-eqz v0, :cond_5a

    iget-object v0, p0, Lit/sephiroth/android/library/widget/n;->a:Landroid/os/Parcelable;

    if-eqz v0, :cond_5a

    iget-object v0, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    iget v0, v0, Lit/sephiroth/android/library/widget/AdapterView;->ao:I

    if-nez v0, :cond_5a

    iget-object v0, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    iget v0, v0, Lit/sephiroth/android/library/widget/AdapterView;->an:I

    if-lez v0, :cond_5a

    .line 815
    const-string v0, "View"

    const-string v1, "calling onRestoreInstanceState"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 816
    iget-object v0, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    iget-object v1, p0, Lit/sephiroth/android/library/widget/n;->a:Landroid/os/Parcelable;

    invoke-static {v0, v1}, Lit/sephiroth/android/library/widget/AdapterView;->a(Lit/sephiroth/android/library/widget/AdapterView;Landroid/os/Parcelable;)V

    .line 817
    const/4 v0, 0x0

    iput-object v0, p0, Lit/sephiroth/android/library/widget/n;->a:Landroid/os/Parcelable;

    .line 822
    :goto_4f
    iget-object v0, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/AdapterView;->w()V

    .line 823
    iget-object v0, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/AdapterView;->requestLayout()V

    .line 824
    return-void

    .line 819
    :cond_5a
    const-string v0, "View"

    const-string v1, "else calling rememberSyncState"

    invoke-static {v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 820
    iget-object v0, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/AdapterView;->z()V

    goto :goto_4f
.end method

.method public onInvalidated()V
    .registers 7

    .prologue
    const-wide/high16 v4, -0x8000000000000000L

    const/4 v3, 0x0

    const/4 v2, -0x1

    .line 828
    const-string v0, "View"

    const-string v1, "onInvalidated"

    invoke-static {v0, v1}, Landroid/util/Log;->i(Ljava/lang/String;Ljava/lang/String;)I

    .line 829
    iget-object v0, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    const/4 v1, 0x1

    iput-boolean v1, v0, Lit/sephiroth/android/library/widget/AdapterView;->ai:Z

    .line 831
    iget-object v0, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/AdapterView;->q()Landroid/widget/Adapter;

    move-result-object v0

    invoke-interface {v0}, Landroid/widget/Adapter;->hasStableIds()Z

    move-result v0

    if-eqz v0, :cond_24

    .line 834
    iget-object v0, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    invoke-static {v0}, Lit/sephiroth/android/library/widget/AdapterView;->a(Lit/sephiroth/android/library/widget/AdapterView;)Landroid/os/Parcelable;

    move-result-object v0

    iput-object v0, p0, Lit/sephiroth/android/library/widget/n;->a:Landroid/os/Parcelable;

    .line 838
    :cond_24
    iget-object v0, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    iget-object v1, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    iget v1, v1, Lit/sephiroth/android/library/widget/AdapterView;->an:I

    iput v1, v0, Lit/sephiroth/android/library/widget/AdapterView;->ao:I

    .line 839
    iget-object v0, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    iput v3, v0, Lit/sephiroth/android/library/widget/AdapterView;->an:I

    .line 840
    iget-object v0, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    iput v2, v0, Lit/sephiroth/android/library/widget/AdapterView;->al:I

    .line 841
    iget-object v0, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    iput-wide v4, v0, Lit/sephiroth/android/library/widget/AdapterView;->am:J

    .line 842
    iget-object v0, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    iput v2, v0, Lit/sephiroth/android/library/widget/AdapterView;->aj:I

    .line 843
    iget-object v0, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    iput-wide v4, v0, Lit/sephiroth/android/library/widget/AdapterView;->ak:J

    .line 844
    iget-object v0, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    iput-boolean v3, v0, Lit/sephiroth/android/library/widget/AdapterView;->ac:Z

    .line 846
    iget-object v0, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/AdapterView;->w()V

    .line 847
    iget-object v0, p0, Lit/sephiroth/android/library/widget/n;->b:Lit/sephiroth/android/library/widget/AdapterView;

    invoke-virtual {v0}, Lit/sephiroth/android/library/widget/AdapterView;->requestLayout()V

    .line 848
    return-void
.end method
