###### Class it.sephiroth.android.library.widget.q (it.sephiroth.android.library.widget.q)
.class public interface abstract Lit/sephiroth/android/library/widget/q;
.super Ljava/lang/Object;
.source "SourceFile"
