###### Class com.d.c.a (com.d.c.a)
.class public final Lcom/d/c/a;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(Landroid/view/View;F)V
    .registers 3

    .prologue
    .line 16
    sget-boolean v0, Lcom/d/c/a/a;->a:Z

    if-eqz v0, :cond_c

    .line 17
    invoke-static {p0}, Lcom/d/c/a/a;->a(Landroid/view/View;)Lcom/d/c/a/a;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/d/c/a/a;->a(F)V

    .line 21
    :goto_b
    return-void

    .line 19
    :cond_c
    invoke-virtual {p0, p1}, Landroid/view/View;->setAlpha(F)V

    goto :goto_b
.end method
