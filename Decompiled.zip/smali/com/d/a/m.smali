###### Class com.d.a.m (com.d.a.m)
.class final Lcom/d/a/m;
.super Lcom/d/a/l;
.source "SourceFile"


# instance fields
.field h:Lcom/d/a/e;

.field i:F

.field private j:Lcom/d/b/a;


# direct methods
.method public varargs constructor <init>(Lcom/d/b/c;[F)V
    .registers 4

    .prologue
    .line 923
    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Lcom/d/a/l;-><init>(Lcom/d/b/c;B)V

    .line 924
    invoke-virtual {p0, p2}, Lcom/d/a/m;->a([F)V

    .line 925
    instance-of v0, p1, Lcom/d/b/a;

    if-eqz v0, :cond_11

    .line 926
    iget-object v0, p0, Lcom/d/a/m;->b:Lcom/d/b/c;

    check-cast v0, Lcom/d/b/a;

    iput-object v0, p0, Lcom/d/a/m;->j:Lcom/d/b/a;

    .line 928
    :cond_11
    return-void
.end method

.method public varargs constructor <init>(Ljava/lang/String;[F)V
    .registers 4

    .prologue
    .line 918
    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Lcom/d/a/l;-><init>(Ljava/lang/String;B)V

    .line 919
    invoke-virtual {p0, p2}, Lcom/d/a/m;->a([F)V

    .line 920
    return-void
.end method

.method private d()Lcom/d/a/m;
    .registers 3

    .prologue
    .line 948
    invoke-super {p0}, Lcom/d/a/l;->a()Lcom/d/a/l;

    move-result-object v0

    check-cast v0, Lcom/d/a/m;

    .line 949
    iget-object v1, v0, Lcom/d/a/m;->e:Lcom/d/a/i;

    check-cast v1, Lcom/d/a/e;

    iput-object v1, v0, Lcom/d/a/m;->h:Lcom/d/a/e;

    .line 950
    return-object v0
.end method


# virtual methods
.method public final synthetic a()Lcom/d/a/l;
    .registers 2

    .prologue
    .line 889
    invoke-direct {p0}, Lcom/d/a/m;->d()Lcom/d/a/m;

    move-result-object v0

    return-object v0
.end method

.method final a(F)V
    .registers 3

    .prologue
    .line 938
    iget-object v0, p0, Lcom/d/a/m;->h:Lcom/d/a/e;

    invoke-virtual {v0, p1}, Lcom/d/a/e;->b(F)F

    move-result v0

    iput v0, p0, Lcom/d/a/m;->i:F

    .line 939
    return-void
.end method

.method final a(Ljava/lang/Class;)V
    .registers 3

    .prologue
    .line 988
    iget-object v0, p0, Lcom/d/a/m;->b:Lcom/d/b/c;

    if-eqz v0, :cond_5

    .line 1022
    :goto_4
    return-void

    .line 1020
    :cond_5
    invoke-super {p0, p1}, Lcom/d/a/l;->a(Ljava/lang/Class;)V

    goto :goto_4
.end method

.method public final varargs a([F)V
    .registers 3

    .prologue
    .line 932
    invoke-super {p0, p1}, Lcom/d/a/l;->a([F)V

    .line 933
    iget-object v0, p0, Lcom/d/a/m;->e:Lcom/d/a/i;

    check-cast v0, Lcom/d/a/e;

    iput-object v0, p0, Lcom/d/a/m;->h:Lcom/d/a/e;

    .line 934
    return-void
.end method

.method final b(Ljava/lang/Object;)V
    .registers 5

    .prologue
    .line 962
    iget-object v0, p0, Lcom/d/a/m;->j:Lcom/d/b/a;

    if-eqz v0, :cond_c

    .line 963
    iget-object v0, p0, Lcom/d/a/m;->j:Lcom/d/b/a;

    iget v1, p0, Lcom/d/a/m;->i:F

    invoke-virtual {v0, p1, v1}, Lcom/d/b/a;->a(Ljava/lang/Object;F)V

    .line 984
    :cond_b
    :goto_b
    return-void

    .line 966
    :cond_c
    iget-object v0, p0, Lcom/d/a/m;->b:Lcom/d/b/c;

    if-eqz v0, :cond_1c

    .line 967
    iget-object v0, p0, Lcom/d/a/m;->b:Lcom/d/b/c;

    iget v1, p0, Lcom/d/a/m;->i:F

    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    invoke-virtual {v0, p1, v1}, Lcom/d/b/c;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_b

    .line 974
    :cond_1c
    iget-object v0, p0, Lcom/d/a/m;->c:Ljava/lang/reflect/Method;

    if-eqz v0, :cond_b

    .line 976
    :try_start_20
    iget-object v0, p0, Lcom/d/a/m;->g:[Ljava/lang/Object;

    const/4 v1, 0x0

    iget v2, p0, Lcom/d/a/m;->i:F

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    aput-object v2, v0, v1

    .line 977
    iget-object v0, p0, Lcom/d/a/m;->c:Ljava/lang/reflect/Method;

    iget-object v1, p0, Lcom/d/a/m;->g:[Ljava/lang/Object;

    invoke-virtual {v0, p1, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_32
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_20 .. :try_end_32} :catch_33
    .catch Ljava/lang/IllegalAccessException; {:try_start_20 .. :try_end_32} :catch_3e

    goto :goto_b

    .line 978
    :catch_33
    move-exception v0

    .line 979
    const-string v1, "PropertyValuesHolder"

    invoke-virtual {v0}, Ljava/lang/reflect/InvocationTargetException;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_b

    .line 980
    :catch_3e
    move-exception v0

    .line 981
    const-string v1, "PropertyValuesHolder"

    invoke-virtual {v0}, Ljava/lang/IllegalAccessException;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_b
.end method

.method final c()Ljava/lang/Object;
    .registers 2

    .prologue
    .line 943
    iget v0, p0, Lcom/d/a/m;->i:F

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    return-object v0
.end method

.method public final synthetic clone()Ljava/lang/Object;
    .registers 2

    .prologue
    .line 889
    invoke-direct {p0}, Lcom/d/a/m;->d()Lcom/d/a/m;

    move-result-object v0

    return-object v0
.end method
