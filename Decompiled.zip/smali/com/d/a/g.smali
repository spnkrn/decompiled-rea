###### Class com.d.a.g (com.d.a.g)
.class public abstract Lcom/d/a/g;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Cloneable;


# instance fields
.field a:F

.field b:Ljava/lang/Class;

.field c:Z

.field private d:Landroid/view/animation/Interpolator;


# direct methods
.method public constructor <init>()V
    .registers 2

    .prologue
    .line 38
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 54
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/d/a/g;->d:Landroid/view/animation/Interpolator;

    .line 61
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/d/a/g;->c:Z

    .line 320
    return-void
.end method

.method public static a(FF)Lcom/d/a/g;
    .registers 3

    .prologue
    .line 108
    new-instance v0, Lcom/d/a/h;

    invoke-direct {v0, p0, p1}, Lcom/d/a/h;-><init>(FF)V

    return-object v0
.end method


# virtual methods
.method public abstract a()Ljava/lang/Object;
.end method

.method public final a(Landroid/view/animation/Interpolator;)V
    .registers 2

    .prologue
    .line 221
    iput-object p1, p0, Lcom/d/a/g;->d:Landroid/view/animation/Interpolator;

    .line 222
    return-void
.end method

.method public abstract a(Ljava/lang/Object;)V
.end method

.method public final b()Landroid/view/animation/Interpolator;
    .registers 2

    .prologue
    .line 211
    iget-object v0, p0, Lcom/d/a/g;->d:Landroid/view/animation/Interpolator;

    return-object v0
.end method

.method public abstract c()Lcom/d/a/g;
.end method

.method public synthetic clone()Ljava/lang/Object;
    .registers 2

    .prologue
    .line 38
    invoke-virtual {p0}, Lcom/d/a/g;->c()Lcom/d/a/g;

    move-result-object v0

    return-object v0
.end method
