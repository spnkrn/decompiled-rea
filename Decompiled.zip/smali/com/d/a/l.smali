###### Class com.d.a.l (com.d.a.l)
.class public Lcom/d/a/l;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Cloneable;


# static fields
.field private static final i:Lcom/d/a/n;

.field private static final j:Lcom/d/a/n;

.field private static k:[Ljava/lang/Class;

.field private static l:[Ljava/lang/Class;

.field private static m:[Ljava/lang/Class;

.field private static final n:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap",
            "<",
            "Ljava/lang/Class;",
            "Ljava/util/HashMap",
            "<",
            "Ljava/lang/String;",
            "Ljava/lang/reflect/Method;",
            ">;>;"
        }
    .end annotation
.end field

.field private static final o:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap",
            "<",
            "Ljava/lang/Class;",
            "Ljava/util/HashMap",
            "<",
            "Ljava/lang/String;",
            "Ljava/lang/reflect/Method;",
            ">;>;"
        }
    .end annotation
.end field


# instance fields
.field a:Ljava/lang/String;

.field protected b:Lcom/d/b/c;

.field c:Ljava/lang/reflect/Method;

.field d:Ljava/lang/Class;

.field e:Lcom/d/a/i;

.field final f:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

.field final g:[Ljava/lang/Object;

.field private h:Ljava/lang/reflect/Method;

.field private p:Lcom/d/a/n;

.field private q:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .registers 8

    .prologue
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x0

    .line 80
    new-instance v0, Lcom/d/a/f;

    invoke-direct {v0}, Lcom/d/a/f;-><init>()V

    sput-object v0, Lcom/d/a/l;->i:Lcom/d/a/n;

    .line 81
    new-instance v0, Lcom/d/a/d;

    invoke-direct {v0}, Lcom/d/a/d;-><init>()V

    sput-object v0, Lcom/d/a/l;->j:Lcom/d/a/n;

    .line 90
    const/4 v0, 0x6

    new-array v0, v0, [Ljava/lang/Class;

    sget-object v1, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    aput-object v1, v0, v3

    const-class v1, Ljava/lang/Float;

    aput-object v1, v0, v4

    sget-object v1, Ljava/lang/Double;->TYPE:Ljava/lang/Class;

    aput-object v1, v0, v5

    sget-object v1, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    aput-object v1, v0, v6

    const-class v1, Ljava/lang/Double;

    aput-object v1, v0, v7

    const/4 v1, 0x5

    const-class v2, Ljava/lang/Integer;

    aput-object v2, v0, v1

    sput-object v0, Lcom/d/a/l;->k:[Ljava/lang/Class;

    .line 92
    const/4 v0, 0x6

    new-array v0, v0, [Ljava/lang/Class;

    sget-object v1, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    aput-object v1, v0, v3

    const-class v1, Ljava/lang/Integer;

    aput-object v1, v0, v4

    sget-object v1, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    aput-object v1, v0, v5

    sget-object v1, Ljava/lang/Double;->TYPE:Ljava/lang/Class;

    aput-object v1, v0, v6

    const-class v1, Ljava/lang/Float;

    aput-object v1, v0, v7

    const/4 v1, 0x5

    const-class v2, Ljava/lang/Double;

    aput-object v2, v0, v1

    sput-object v0, Lcom/d/a/l;->l:[Ljava/lang/Class;

    .line 94
    const/4 v0, 0x6

    new-array v0, v0, [Ljava/lang/Class;

    sget-object v1, Ljava/lang/Double;->TYPE:Ljava/lang/Class;

    aput-object v1, v0, v3

    const-class v1, Ljava/lang/Double;

    aput-object v1, v0, v4

    sget-object v1, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    aput-object v1, v0, v5

    sget-object v1, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    aput-object v1, v0, v6

    const-class v1, Ljava/lang/Float;

    aput-object v1, v0, v7

    const/4 v1, 0x5

    const-class v2, Ljava/lang/Integer;

    aput-object v2, v0, v1

    sput-object v0, Lcom/d/a/l;->m:[Ljava/lang/Class;

    .line 100
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lcom/d/a/l;->n:Ljava/util/HashMap;

    .line 102
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lcom/d/a/l;->o:Ljava/util/HashMap;

    return-void
.end method

.method private constructor <init>(Lcom/d/b/c;)V
    .registers 3

    .prologue
    const/4 v0, 0x0

    .line 139
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 56
    iput-object v0, p0, Lcom/d/a/l;->c:Ljava/lang/reflect/Method;

    .line 65
    iput-object v0, p0, Lcom/d/a/l;->h:Ljava/lang/reflect/Method;

    .line 76
    iput-object v0, p0, Lcom/d/a/l;->e:Lcom/d/a/i;

    .line 107
    new-instance v0, Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;-><init>()V

    iput-object v0, p0, Lcom/d/a/l;->f:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 110
    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    iput-object v0, p0, Lcom/d/a/l;->g:[Ljava/lang/Object;

    .line 140
    iput-object p1, p0, Lcom/d/a/l;->b:Lcom/d/b/c;

    .line 141
    if-eqz p1, :cond_20

    .line 142
    invoke-virtual {p1}, Lcom/d/b/c;->a()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/d/a/l;->a:Ljava/lang/String;

    .line 144
    :cond_20
    return-void
.end method

.method synthetic constructor <init>(Lcom/d/b/c;B)V
    .registers 3

    .prologue
    .line 36
    invoke-direct {p0, p1}, Lcom/d/a/l;-><init>(Lcom/d/b/c;)V

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;)V
    .registers 3

    .prologue
    const/4 v0, 0x0

    .line 131
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 56
    iput-object v0, p0, Lcom/d/a/l;->c:Ljava/lang/reflect/Method;

    .line 65
    iput-object v0, p0, Lcom/d/a/l;->h:Ljava/lang/reflect/Method;

    .line 76
    iput-object v0, p0, Lcom/d/a/l;->e:Lcom/d/a/i;

    .line 107
    new-instance v0, Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;-><init>()V

    iput-object v0, p0, Lcom/d/a/l;->f:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    .line 110
    const/4 v0, 0x1

    new-array v0, v0, [Ljava/lang/Object;

    iput-object v0, p0, Lcom/d/a/l;->g:[Ljava/lang/Object;

    .line 132
    iput-object p1, p0, Lcom/d/a/l;->a:Ljava/lang/String;

    .line 133
    return-void
.end method

.method synthetic constructor <init>(Ljava/lang/String;B)V
    .registers 3

    .prologue
    .line 36
    invoke-direct {p0, p1}, Lcom/d/a/l;-><init>(Ljava/lang/String;)V

    return-void
.end method

.method public static varargs a(Lcom/d/b/c;[F)Lcom/d/a/l;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/d/b/c",
            "<*",
            "Ljava/lang/Float;",
            ">;[F)",
            "Lcom/d/a/l;"
        }
    .end annotation

    .prologue
    .line 187
    new-instance v0, Lcom/d/a/m;

    invoke-direct {v0, p0, p1}, Lcom/d/a/m;-><init>(Lcom/d/b/c;[F)V

    return-object v0
.end method

.method public static varargs a(Ljava/lang/String;[F)Lcom/d/a/l;
    .registers 3

    .prologue
    .line 176
    new-instance v0, Lcom/d/a/m;

    invoke-direct {v0, p0, p1}, Lcom/d/a/m;-><init>(Ljava/lang/String;[F)V

    return-object v0
.end method

.method private a(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/reflect/Method;
    .registers 12

    .prologue
    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v5, 0x1

    .line 381
    .line 382
    iget-object v0, p0, Lcom/d/a/l;->a:Ljava/lang/String;

    if-eqz v0, :cond_d

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v2

    if-nez v2, :cond_15

    .line 383
    :cond_d
    :goto_d
    if-nez p3, :cond_64

    .line 386
    const/4 v0, 0x0

    :try_start_10
    invoke-virtual {p1, p2, v0}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    :try_end_13
    .catch Ljava/lang/NoSuchMethodException; {:try_start_10 .. :try_end_13} :catch_37

    move-result-object v0

    .line 440
    :goto_14
    return-object v0

    .line 382
    :cond_15
    invoke-virtual {v0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v2

    invoke-static {v2}, Ljava/lang/Character;->toUpperCase(C)C

    move-result v2

    invoke-virtual {v0, v5}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    goto :goto_d

    .line 387
    :catch_37
    move-exception v2

    .line 392
    const/4 v0, 0x0

    :try_start_39
    invoke-virtual {p1, p2, v0}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
    :try_end_3c
    .catch Ljava/lang/NoSuchMethodException; {:try_start_39 .. :try_end_3c} :catch_da

    move-result-object v0

    .line 393
    const/4 v1, 0x1

    :try_start_3e
    invoke-virtual {v0, v1}, Ljava/lang/reflect/Method;->setAccessible(Z)V
    :try_end_41
    .catch Ljava/lang/NoSuchMethodException; {:try_start_3e .. :try_end_41} :catch_42

    goto :goto_14

    .line 395
    :catch_42
    move-exception v1

    :goto_43
    const-string v1, "PropertyValuesHolder"

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "Couldn\'t find no-arg method for property "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v4, p0, Lcom/d/a/l;->a:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, ": "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v1, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_14

    .line 400
    :cond_64
    new-array v4, v5, [Ljava/lang/Class;

    .line 402
    iget-object v0, p0, Lcom/d/a/l;->d:Ljava/lang/Class;

    const-class v2, Ljava/lang/Float;

    invoke-virtual {v0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_82

    .line 403
    sget-object v0, Lcom/d/a/l;->k:[Ljava/lang/Class;

    .line 412
    :goto_72
    array-length v5, v0

    move v2, v3

    :goto_74
    if-ge v2, v5, :cond_b5

    aget-object v6, v0, v2

    .line 413
    aput-object v6, v4, v3

    .line 415
    :try_start_7a
    invoke-virtual {p1, p2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    .line 417
    iput-object v6, p0, Lcom/d/a/l;->d:Ljava/lang/Class;
    :try_end_80
    .catch Ljava/lang/NoSuchMethodException; {:try_start_7a .. :try_end_80} :catch_a3

    move-object v0, v1

    .line 418
    goto :goto_14

    .line 404
    :cond_82
    iget-object v0, p0, Lcom/d/a/l;->d:Ljava/lang/Class;

    const-class v2, Ljava/lang/Integer;

    invoke-virtual {v0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_8f

    .line 405
    sget-object v0, Lcom/d/a/l;->l:[Ljava/lang/Class;

    goto :goto_72

    .line 406
    :cond_8f
    iget-object v0, p0, Lcom/d/a/l;->d:Ljava/lang/Class;

    const-class v2, Ljava/lang/Double;

    invoke-virtual {v0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_9c

    .line 407
    sget-object v0, Lcom/d/a/l;->m:[Ljava/lang/Class;

    goto :goto_72

    .line 409
    :cond_9c
    new-array v0, v5, [Ljava/lang/Class;

    .line 410
    iget-object v2, p0, Lcom/d/a/l;->d:Ljava/lang/Class;

    aput-object v2, v0, v3

    goto :goto_72

    :catch_a3
    move-exception v7

    .line 424
    :try_start_a4
    invoke-virtual {p1, p2, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    .line 425
    const/4 v7, 0x1

    invoke-virtual {v1, v7}, Ljava/lang/reflect/Method;->setAccessible(Z)V

    .line 427
    iput-object v6, p0, Lcom/d/a/l;->d:Ljava/lang/Class;
    :try_end_ae
    .catch Ljava/lang/NoSuchMethodException; {:try_start_a4 .. :try_end_ae} :catch_b1

    move-object v0, v1

    .line 428
    goto/16 :goto_14

    .line 412
    :catch_b1
    move-exception v6

    add-int/lit8 v2, v2, 0x1

    goto :goto_74

    .line 435
    :cond_b5
    const-string v0, "PropertyValuesHolder"

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Couldn\'t find setter/getter for property "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v3, p0, Lcom/d/a/l;->a:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " with value type "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    iget-object v3, p0, Lcom/d/a/l;->d:Ljava/lang/Class;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    move-object v0, v1

    goto/16 :goto_14

    .line 395
    :catch_da
    move-exception v0

    move-object v0, v1

    goto/16 :goto_43
.end method

.method private a(Ljava/lang/Class;Ljava/util/HashMap;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/reflect/Method;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Class;",
            "Ljava/util/HashMap",
            "<",
            "Ljava/lang/Class;",
            "Ljava/util/HashMap",
            "<",
            "Ljava/lang/String;",
            "Ljava/lang/reflect/Method;",
            ">;>;",
            "Ljava/lang/String;",
            "Ljava/lang/Class;",
            ")",
            "Ljava/lang/reflect/Method;"
        }
    .end annotation

    .prologue
    .line 457
    const/4 v1, 0x0

    .line 462
    :try_start_1
    iget-object v0, p0, Lcom/d/a/l;->f:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->lock()V

    .line 463
    invoke-virtual {p2, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/HashMap;

    .line 464
    if-eqz v0, :cond_1a

    .line 465
    iget-object v1, p0, Lcom/d/a/l;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/reflect/Method;

    .line 467
    :cond_1a
    if-nez v1, :cond_2f

    .line 468
    invoke-direct {p0, p1, p3, p4}, Lcom/d/a/l;->a(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    .line 469
    if-nez v0, :cond_2a

    .line 470
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 471
    invoke-virtual {p2, p1, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 473
    :cond_2a
    iget-object v2, p0, Lcom/d/a/l;->a:Ljava/lang/String;

    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_2f
    .catchall {:try_start_1 .. :try_end_2f} :catchall_3a

    :cond_2f
    move-object v0, v1

    .line 476
    iget-object v1, p0, Lcom/d/a/l;->f:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    .line 478
    return-object v0

    .line 476
    :catchall_3a
    move-exception v0

    iget-object v1, p0, Lcom/d/a/l;->f:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/concurrent/locks/ReentrantReadWriteLock$WriteLock;->unlock()V

    throw v0
.end method


# virtual methods
.method public a()Lcom/d/a/l;
    .registers 3

    .prologue
    .line 594
    :try_start_0
    invoke-super {p0}, Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/d/a/l;

    .line 595
    iget-object v1, p0, Lcom/d/a/l;->a:Ljava/lang/String;

    iput-object v1, v0, Lcom/d/a/l;->a:Ljava/lang/String;

    .line 596
    iget-object v1, p0, Lcom/d/a/l;->b:Lcom/d/b/c;

    iput-object v1, v0, Lcom/d/a/l;->b:Lcom/d/b/c;

    .line 597
    iget-object v1, p0, Lcom/d/a/l;->e:Lcom/d/a/i;

    invoke-virtual {v1}, Lcom/d/a/i;->a()Lcom/d/a/i;

    move-result-object v1

    iput-object v1, v0, Lcom/d/a/l;->e:Lcom/d/a/i;

    .line 598
    iget-object v1, p0, Lcom/d/a/l;->p:Lcom/d/a/n;

    iput-object v1, v0, Lcom/d/a/l;->p:Lcom/d/a/n;
    :try_end_1a
    .catch Ljava/lang/CloneNotSupportedException; {:try_start_0 .. :try_end_1a} :catch_1b

    .line 602
    :goto_1a
    return-object v0

    :catch_1b
    move-exception v0

    const/4 v0, 0x0

    goto :goto_1a
.end method

.method a(F)V
    .registers 3

    .prologue
    .line 670
    iget-object v0, p0, Lcom/d/a/l;->e:Lcom/d/a/i;

    invoke-virtual {v0, p1}, Lcom/d/a/i;->a(F)Ljava/lang/Object;

    move-result-object v0

    iput-object v0, p0, Lcom/d/a/l;->q:Ljava/lang/Object;

    .line 671
    return-void
.end method

.method public final a(Lcom/d/b/c;)V
    .registers 2

    .prologue
    .line 701
    iput-object p1, p0, Lcom/d/a/l;->b:Lcom/d/b/c;

    .line 702
    return-void
.end method

.method a(Ljava/lang/Class;)V
    .registers 5

    .prologue
    .line 486
    sget-object v0, Lcom/d/a/l;->n:Ljava/util/HashMap;

    const-string v1, "set"

    iget-object v2, p0, Lcom/d/a/l;->d:Ljava/lang/Class;

    invoke-direct {p0, p1, v0, v1, v2}, Lcom/d/a/l;->a(Ljava/lang/Class;Ljava/util/HashMap;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    iput-object v0, p0, Lcom/d/a/l;->c:Ljava/lang/reflect/Method;

    .line 487
    return-void
.end method

.method final a(Ljava/lang/Object;)V
    .registers 8

    .prologue
    const/4 v5, 0x0

    .line 507
    iget-object v0, p0, Lcom/d/a/l;->b:Lcom/d/b/c;

    if-eqz v0, :cond_59

    .line 510
    :try_start_5
    iget-object v0, p0, Lcom/d/a/l;->b:Lcom/d/b/c;

    invoke-virtual {v0, p1}, Lcom/d/b/c;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 511
    iget-object v0, p0, Lcom/d/a/l;->e:Lcom/d/a/i;

    iget-object v0, v0, Lcom/d/a/i;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_12
    :goto_12
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_ad

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/d/a/g;

    .line 512
    iget-boolean v2, v0, Lcom/d/a/g;->c:Z

    if-nez v2, :cond_12

    .line 513
    iget-object v2, p0, Lcom/d/a/l;->b:Lcom/d/b/c;

    invoke-virtual {v2, p1}, Lcom/d/b/c;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/d/a/g;->a(Ljava/lang/Object;)V
    :try_end_2b
    .catch Ljava/lang/ClassCastException; {:try_start_5 .. :try_end_2b} :catch_2c

    goto :goto_12

    .line 518
    :catch_2c
    move-exception v0

    const-string v0, "PropertyValuesHolder"

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "No such property ("

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lcom/d/a/l;->b:Lcom/d/b/c;

    invoke-virtual {v2}, Lcom/d/b/c;->a()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ") on target object "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ". Trying reflection instead"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 520
    iput-object v5, p0, Lcom/d/a/l;->b:Lcom/d/b/c;

    .line 523
    :cond_59
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    .line 524
    iget-object v0, p0, Lcom/d/a/l;->c:Ljava/lang/reflect/Method;

    if-nez v0, :cond_64

    .line 525
    invoke-virtual {p0, v1}, Lcom/d/a/l;->a(Ljava/lang/Class;)V

    .line 527
    :cond_64
    iget-object v0, p0, Lcom/d/a/l;->e:Lcom/d/a/i;

    iget-object v0, v0, Lcom/d/a/i;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_6c
    :goto_6c
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_ad

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/d/a/g;

    .line 528
    iget-boolean v3, v0, Lcom/d/a/g;->c:Z

    if-nez v3, :cond_6c

    .line 529
    iget-object v3, p0, Lcom/d/a/l;->h:Ljava/lang/reflect/Method;

    if-nez v3, :cond_8a

    .line 530
    sget-object v3, Lcom/d/a/l;->o:Ljava/util/HashMap;

    const-string v4, "get"

    invoke-direct {p0, v1, v3, v4, v5}, Lcom/d/a/l;->a(Ljava/lang/Class;Ljava/util/HashMap;Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    iput-object v3, p0, Lcom/d/a/l;->h:Ljava/lang/reflect/Method;

    .line 533
    :cond_8a
    :try_start_8a
    iget-object v3, p0, Lcom/d/a/l;->h:Ljava/lang/reflect/Method;

    const/4 v4, 0x0

    new-array v4, v4, [Ljava/lang/Object;

    invoke-virtual {v3, p1, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v0, v3}, Lcom/d/a/g;->a(Ljava/lang/Object;)V
    :try_end_96
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_8a .. :try_end_96} :catch_97
    .catch Ljava/lang/IllegalAccessException; {:try_start_8a .. :try_end_96} :catch_a2

    goto :goto_6c

    .line 534
    :catch_97
    move-exception v0

    .line 535
    const-string v3, "PropertyValuesHolder"

    invoke-virtual {v0}, Ljava/lang/reflect/InvocationTargetException;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_6c

    .line 536
    :catch_a2
    move-exception v0

    .line 537
    const-string v3, "PropertyValuesHolder"

    invoke-virtual {v0}, Ljava/lang/IllegalAccessException;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_6c

    .line 541
    :cond_ad
    return-void
.end method

.method public varargs a([F)V
    .registers 8

    .prologue
    const/4 v1, 0x1

    const/4 v5, 0x0

    .line 327
    sget-object v0, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    iput-object v0, p0, Lcom/d/a/l;->d:Ljava/lang/Class;

    .line 328
    array-length v2, p1

    const/4 v0, 0x2

    invoke-static {v2, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    new-array v3, v0, [Lcom/d/a/h;

    if-ne v2, v1, :cond_2d

    new-instance v0, Lcom/d/a/h;

    invoke-direct {v0}, Lcom/d/a/h;-><init>()V

    check-cast v0, Lcom/d/a/h;

    aput-object v0, v3, v5

    const/high16 v0, 0x3f800000    # 1.0f

    aget v2, p1, v5

    invoke-static {v0, v2}, Lcom/d/a/g;->a(FF)Lcom/d/a/g;

    move-result-object v0

    check-cast v0, Lcom/d/a/h;

    aput-object v0, v3, v1

    :cond_25
    new-instance v0, Lcom/d/a/e;

    invoke-direct {v0, v3}, Lcom/d/a/e;-><init>([Lcom/d/a/h;)V

    iput-object v0, p0, Lcom/d/a/l;->e:Lcom/d/a/i;

    .line 329
    return-void

    .line 328
    :cond_2d
    const/4 v0, 0x0

    aget v4, p1, v5

    invoke-static {v0, v4}, Lcom/d/a/g;->a(FF)Lcom/d/a/g;

    move-result-object v0

    check-cast v0, Lcom/d/a/h;

    aput-object v0, v3, v5

    :goto_38
    if-ge v1, v2, :cond_25

    int-to-float v0, v1

    add-int/lit8 v4, v2, -0x1

    int-to-float v4, v4

    div-float/2addr v0, v4

    aget v4, p1, v1

    invoke-static {v0, v4}, Lcom/d/a/g;->a(FF)Lcom/d/a/g;

    move-result-object v0

    check-cast v0, Lcom/d/a/h;

    aput-object v0, v3, v1

    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_38
.end method

.method final b()V
    .registers 3

    .prologue
    .line 634
    iget-object v0, p0, Lcom/d/a/l;->p:Lcom/d/a/n;

    if-nez v0, :cond_e

    .line 637
    iget-object v0, p0, Lcom/d/a/l;->d:Ljava/lang/Class;

    const-class v1, Ljava/lang/Integer;

    if-ne v0, v1, :cond_19

    sget-object v0, Lcom/d/a/l;->i:Lcom/d/a/n;

    :goto_c
    iput-object v0, p0, Lcom/d/a/l;->p:Lcom/d/a/n;

    .line 641
    :cond_e
    iget-object v0, p0, Lcom/d/a/l;->p:Lcom/d/a/n;

    if-eqz v0, :cond_18

    .line 644
    iget-object v0, p0, Lcom/d/a/l;->e:Lcom/d/a/i;

    iget-object v1, p0, Lcom/d/a/l;->p:Lcom/d/a/n;

    iput-object v1, v0, Lcom/d/a/i;->f:Lcom/d/a/n;

    .line 646
    :cond_18
    return-void

    .line 637
    :cond_19
    iget-object v0, p0, Lcom/d/a/l;->d:Ljava/lang/Class;

    const-class v1, Ljava/lang/Float;

    if-ne v0, v1, :cond_22

    sget-object v0, Lcom/d/a/l;->j:Lcom/d/a/n;

    goto :goto_c

    :cond_22
    const/4 v0, 0x0

    goto :goto_c
.end method

.method b(Ljava/lang/Object;)V
    .registers 5

    .prologue
    .line 614
    iget-object v0, p0, Lcom/d/a/l;->b:Lcom/d/b/c;

    if-eqz v0, :cond_d

    .line 615
    iget-object v0, p0, Lcom/d/a/l;->b:Lcom/d/b/c;

    invoke-virtual {p0}, Lcom/d/a/l;->c()Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v0, p1, v1}, Lcom/d/b/c;->a(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 617
    :cond_d
    iget-object v0, p0, Lcom/d/a/l;->c:Ljava/lang/reflect/Method;

    if-eqz v0, :cond_21

    .line 619
    :try_start_11
    iget-object v0, p0, Lcom/d/a/l;->g:[Ljava/lang/Object;

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/d/a/l;->c()Ljava/lang/Object;

    move-result-object v2

    aput-object v2, v0, v1

    .line 620
    iget-object v0, p0, Lcom/d/a/l;->c:Ljava/lang/reflect/Method;

    iget-object v1, p0, Lcom/d/a/l;->g:[Ljava/lang/Object;

    invoke-virtual {v0, p1, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_21
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_11 .. :try_end_21} :catch_22
    .catch Ljava/lang/IllegalAccessException; {:try_start_11 .. :try_end_21} :catch_2d

    .line 627
    :cond_21
    :goto_21
    return-void

    .line 621
    :catch_22
    move-exception v0

    .line 622
    const-string v1, "PropertyValuesHolder"

    invoke-virtual {v0}, Ljava/lang/reflect/InvocationTargetException;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_21

    .line 623
    :catch_2d
    move-exception v0

    .line 624
    const-string v1, "PropertyValuesHolder"

    invoke-virtual {v0}, Ljava/lang/IllegalAccessException;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_21
.end method

.method c()Ljava/lang/Object;
    .registers 2

    .prologue
    .line 722
    iget-object v0, p0, Lcom/d/a/l;->q:Ljava/lang/Object;

    return-object v0
.end method

.method public synthetic clone()Ljava/lang/Object;
    .registers 2

    .prologue
    .line 36
    invoke-virtual {p0}, Lcom/d/a/l;->a()Lcom/d/a/l;

    move-result-object v0

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    .prologue
    .line 727
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lcom/d/a/l;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ": "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/d/a/l;->e:Lcom/d/a/i;

    invoke-virtual {v1}, Lcom/d/a/i;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method
