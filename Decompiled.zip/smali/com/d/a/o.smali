###### Class com.d.a.o (com.d.a.o)
.class public Lcom/d/a/o;
.super Lcom/d/a/a;
.source "SourceFile"


# static fields
.field private static h:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal",
            "<",
            "Lcom/d/a/p;",
            ">;"
        }
    .end annotation
.end field

.field private static final i:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal",
            "<",
            "Ljava/util/ArrayList",
            "<",
            "Lcom/d/a/o;",
            ">;>;"
        }
    .end annotation
.end field

.field private static final j:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal",
            "<",
            "Ljava/util/ArrayList",
            "<",
            "Lcom/d/a/o;",
            ">;>;"
        }
    .end annotation
.end field

.field private static final k:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal",
            "<",
            "Ljava/util/ArrayList",
            "<",
            "Lcom/d/a/o;",
            ">;>;"
        }
    .end annotation
.end field

.field private static final l:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal",
            "<",
            "Ljava/util/ArrayList",
            "<",
            "Lcom/d/a/o;",
            ">;>;"
        }
    .end annotation
.end field

.field private static final m:Ljava/lang/ThreadLocal;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/ThreadLocal",
            "<",
            "Ljava/util/ArrayList",
            "<",
            "Lcom/d/a/o;",
            ">;>;"
        }
    .end annotation
.end field

.field private static final n:Landroid/view/animation/Interpolator;

.field private static final o:Lcom/d/a/n;

.field private static final p:Lcom/d/a/n;

.field private static z:J


# instance fields
.field private A:I

.field private B:I

.field private C:Landroid/view/animation/Interpolator;

.field private D:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList",
            "<",
            "Lcom/d/a/q;",
            ">;"
        }
    .end annotation
.end field

.field b:J

.field c:J

.field d:I

.field e:Z

.field f:[Lcom/d/a/l;

.field g:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap",
            "<",
            "Ljava/lang/String;",
            "Lcom/d/a/l;",
            ">;"
        }
    .end annotation
.end field

.field private q:Z

.field private r:I

.field private s:F

.field private t:Z

.field private u:J

.field private v:Z

.field private w:Z

.field private x:J

.field private y:J


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .prologue
    .line 94
    new-instance v0, Ljava/lang/ThreadLocal;

    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    sput-object v0, Lcom/d/a/o;->h:Ljava/lang/ThreadLocal;

    .line 98
    new-instance v0, Lcom/d/a/o$1;

    invoke-direct {v0}, Lcom/d/a/o$1;-><init>()V

    sput-object v0, Lcom/d/a/o;->i:Ljava/lang/ThreadLocal;

    .line 107
    new-instance v0, Lcom/d/a/o$2;

    invoke-direct {v0}, Lcom/d/a/o$2;-><init>()V

    sput-object v0, Lcom/d/a/o;->j:Ljava/lang/ThreadLocal;

    .line 119
    new-instance v0, Lcom/d/a/o$3;

    invoke-direct {v0}, Lcom/d/a/o$3;-><init>()V

    sput-object v0, Lcom/d/a/o;->k:Ljava/lang/ThreadLocal;

    .line 127
    new-instance v0, Lcom/d/a/o$4;

    invoke-direct {v0}, Lcom/d/a/o$4;-><init>()V

    sput-object v0, Lcom/d/a/o;->l:Ljava/lang/ThreadLocal;

    .line 135
    new-instance v0, Lcom/d/a/o$5;

    invoke-direct {v0}, Lcom/d/a/o$5;-><init>()V

    sput-object v0, Lcom/d/a/o;->m:Ljava/lang/ThreadLocal;

    .line 144
    new-instance v0, Landroid/view/animation/AccelerateDecelerateInterpolator;

    invoke-direct {v0}, Landroid/view/animation/AccelerateDecelerateInterpolator;-><init>()V

    sput-object v0, Lcom/d/a/o;->n:Landroid/view/animation/Interpolator;

    .line 148
    new-instance v0, Lcom/d/a/f;

    invoke-direct {v0}, Lcom/d/a/f;-><init>()V

    sput-object v0, Lcom/d/a/o;->o:Lcom/d/a/n;

    .line 149
    new-instance v0, Lcom/d/a/d;

    invoke-direct {v0}, Lcom/d/a/d;-><init>()V

    sput-object v0, Lcom/d/a/o;->p:Lcom/d/a/n;

    .line 222
    const-wide/16 v0, 0xa

    sput-wide v0, Lcom/d/a/o;->z:J

    return-void
.end method

.method public constructor <init>()V
    .registers 4

    .prologue
    const/4 v2, 0x0

    .line 283
    invoke-direct {p0}, Lcom/d/a/a;-><init>()V

    .line 85
    const-wide/16 v0, -0x1

    iput-wide v0, p0, Lcom/d/a/o;->c:J

    .line 155
    iput-boolean v2, p0, Lcom/d/a/o;->q:Z

    .line 161
    iput v2, p0, Lcom/d/a/o;->r:I

    .line 166
    const/4 v0, 0x0

    iput v0, p0, Lcom/d/a/o;->s:F

    .line 171
    iput-boolean v2, p0, Lcom/d/a/o;->t:Z

    .line 187
    iput v2, p0, Lcom/d/a/o;->d:I

    .line 197
    iput-boolean v2, p0, Lcom/d/a/o;->v:Z

    .line 203
    iput-boolean v2, p0, Lcom/d/a/o;->w:Z

    .line 209
    iput-boolean v2, p0, Lcom/d/a/o;->e:Z

    .line 216
    const-wide/16 v0, 0x12c

    iput-wide v0, p0, Lcom/d/a/o;->x:J

    .line 219
    const-wide/16 v0, 0x0

    iput-wide v0, p0, Lcom/d/a/o;->y:J

    .line 226
    iput v2, p0, Lcom/d/a/o;->A:I

    .line 233
    const/4 v0, 0x1

    iput v0, p0, Lcom/d/a/o;->B:I

    .line 240
    sget-object v0, Lcom/d/a/o;->n:Landroid/view/animation/Interpolator;

    iput-object v0, p0, Lcom/d/a/o;->C:Landroid/view/animation/Interpolator;

    .line 245
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/d/a/o;->D:Ljava/util/ArrayList;

    .line 284
    return-void
.end method

.method static synthetic a(Lcom/d/a/o;)J
    .registers 3

    .prologue
    .line 43
    iget-wide v0, p0, Lcom/d/a/o;->y:J

    return-wide v0
.end method

.method static synthetic a(Lcom/d/a/o;J)Z
    .registers 8

    .prologue
    const/4 v0, 0x1

    .line 43
    iget-boolean v1, p0, Lcom/d/a/o;->t:Z

    if-nez v1, :cond_b

    iput-boolean v0, p0, Lcom/d/a/o;->t:Z

    iput-wide p1, p0, Lcom/d/a/o;->u:J

    :cond_9
    const/4 v0, 0x0

    :goto_a
    return v0

    :cond_b
    iget-wide v1, p0, Lcom/d/a/o;->u:J

    sub-long v1, p1, v1

    iget-wide v3, p0, Lcom/d/a/o;->y:J

    cmp-long v3, v1, v3

    if-lez v3, :cond_9

    iget-wide v3, p0, Lcom/d/a/o;->y:J

    sub-long/2addr v1, v3

    sub-long v1, p1, v1

    iput-wide v1, p0, Lcom/d/a/o;->b:J

    iput v0, p0, Lcom/d/a/o;->d:I

    goto :goto_a
.end method

.method public static varargs b([F)Lcom/d/a/o;
    .registers 2

    .prologue
    .line 315
    new-instance v0, Lcom/d/a/o;

    invoke-direct {v0}, Lcom/d/a/o;-><init>()V

    .line 316
    invoke-virtual {v0, p0}, Lcom/d/a/o;->a([F)V

    .line 317
    return-object v0
.end method

.method static synthetic b(Lcom/d/a/o;)V
    .registers 1

    .prologue
    .line 43
    invoke-direct {p0}, Lcom/d/a/o;->s()V

    return-void
.end method

.method static synthetic c(Lcom/d/a/o;)Z
    .registers 2

    .prologue
    .line 43
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/d/a/o;->v:Z

    return v0
.end method

.method private d(J)V
    .registers 7

    .prologue
    .line 538
    invoke-virtual {p0}, Lcom/d/a/o;->f()V

    .line 539
    invoke-static {}, Landroid/view/animation/AnimationUtils;->currentAnimationTimeMillis()J

    move-result-wide v0

    .line 540
    iget v2, p0, Lcom/d/a/o;->d:I

    const/4 v3, 0x1

    if-eq v2, v3, :cond_11

    .line 541
    iput-wide p1, p0, Lcom/d/a/o;->c:J

    .line 542
    const/4 v2, 0x2

    iput v2, p0, Lcom/d/a/o;->d:I

    .line 544
    :cond_11
    sub-long v2, v0, p1

    iput-wide v2, p0, Lcom/d/a/o;->b:J

    .line 545
    invoke-virtual {p0, v0, v1}, Lcom/d/a/o;->c(J)Z

    .line 546
    return-void
.end method

.method static synthetic d(Lcom/d/a/o;)V
    .registers 1

    .prologue
    .line 43
    invoke-direct {p0}, Lcom/d/a/o;->r()V

    return-void
.end method

.method static synthetic l()Ljava/lang/ThreadLocal;
    .registers 1

    .prologue
    .line 43
    sget-object v0, Lcom/d/a/o;->i:Ljava/lang/ThreadLocal;

    return-object v0
.end method

.method static synthetic m()Ljava/lang/ThreadLocal;
    .registers 1

    .prologue
    .line 43
    sget-object v0, Lcom/d/a/o;->k:Ljava/lang/ThreadLocal;

    return-object v0
.end method

.method static synthetic n()Ljava/lang/ThreadLocal;
    .registers 1

    .prologue
    .line 43
    sget-object v0, Lcom/d/a/o;->j:Ljava/lang/ThreadLocal;

    return-object v0
.end method

.method static synthetic o()Ljava/lang/ThreadLocal;
    .registers 1

    .prologue
    .line 43
    sget-object v0, Lcom/d/a/o;->m:Ljava/lang/ThreadLocal;

    return-object v0
.end method

.method static synthetic p()Ljava/lang/ThreadLocal;
    .registers 1

    .prologue
    .line 43
    sget-object v0, Lcom/d/a/o;->l:Ljava/lang/ThreadLocal;

    return-object v0
.end method

.method static synthetic q()J
    .registers 2

    .prologue
    .line 43
    sget-wide v0, Lcom/d/a/o;->z:J

    return-wide v0
.end method

.method private r()V
    .registers 6

    .prologue
    const/4 v3, 0x0

    .line 1025
    sget-object v0, Lcom/d/a/o;->i:Ljava/lang/ThreadLocal;

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 1026
    sget-object v0, Lcom/d/a/o;->j:Ljava/lang/ThreadLocal;

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 1027
    sget-object v0, Lcom/d/a/o;->k:Ljava/lang/ThreadLocal;

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 1028
    iput v3, p0, Lcom/d/a/o;->d:I

    .line 1029
    iget-boolean v0, p0, Lcom/d/a/o;->v:Z

    if-eqz v0, :cond_48

    iget-object v0, p0, Lcom/d/a/o;->a:Ljava/util/ArrayList;

    if-eqz v0, :cond_48

    .line 1030
    iget-object v0, p0, Lcom/d/a/o;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/ArrayList;

    .line 1032
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v4

    move v2, v3

    .line 1033
    :goto_39
    if-ge v2, v4, :cond_48

    .line 1034
    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/d/a/b;

    invoke-interface {v1}, Lcom/d/a/b;->a()V

    .line 1033
    add-int/lit8 v1, v2, 0x1

    move v2, v1

    goto :goto_39

    .line 1037
    :cond_48
    iput-boolean v3, p0, Lcom/d/a/o;->v:Z

    .line 1038
    iput-boolean v3, p0, Lcom/d/a/o;->w:Z

    .line 1039
    return-void
.end method

.method private s()V
    .registers 5

    .prologue
    .line 1046
    invoke-virtual {p0}, Lcom/d/a/o;->f()V

    .line 1047
    sget-object v0, Lcom/d/a/o;->i:Ljava/lang/ThreadLocal;

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1048
    iget-wide v0, p0, Lcom/d/a/o;->y:J

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    if-lez v0, :cond_2f

    iget-object v0, p0, Lcom/d/a/o;->a:Ljava/util/ArrayList;

    if-eqz v0, :cond_2f

    .line 1051
    iget-object v0, p0, Lcom/d/a/o;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/ArrayList;

    .line 1053
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    .line 1054
    const/4 v1, 0x0

    :goto_27
    if-ge v1, v2, :cond_2f

    .line 1055
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1054
    add-int/lit8 v1, v1, 0x1

    goto :goto_27

    .line 1058
    :cond_2f
    return-void
.end method


# virtual methods
.method public synthetic a(J)Lcom/d/a/a;
    .registers 4

    .prologue
    .line 43
    invoke-virtual {p0, p1, p2}, Lcom/d/a/o;->b(J)Lcom/d/a/o;

    move-result-object v0

    return-object v0
.end method

.method public a()V
    .registers 8

    .prologue
    const-wide/16 v1, 0x0

    const/4 v6, 0x1

    const/4 v3, 0x0

    .line 951
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    if-nez v0, :cond_12

    new-instance v0, Landroid/util/AndroidRuntimeException;

    const-string v1, "Animators may only be run on Looper threads"

    invoke-direct {v0, v1}, Landroid/util/AndroidRuntimeException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_12
    iput-boolean v3, p0, Lcom/d/a/o;->q:Z

    iput v3, p0, Lcom/d/a/o;->r:I

    iput v3, p0, Lcom/d/a/o;->d:I

    iput-boolean v6, p0, Lcom/d/a/o;->w:Z

    iput-boolean v3, p0, Lcom/d/a/o;->t:Z

    sget-object v0, Lcom/d/a/o;->j:Ljava/lang/ThreadLocal;

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-wide v4, p0, Lcom/d/a/o;->y:J

    cmp-long v0, v4, v1

    if-nez v0, :cond_5e

    iget-boolean v0, p0, Lcom/d/a/o;->e:Z

    if-eqz v0, :cond_35

    iget v0, p0, Lcom/d/a/o;->d:I

    if-nez v0, :cond_56

    :cond_35
    move-wide v0, v1

    :goto_36
    invoke-direct {p0, v0, v1}, Lcom/d/a/o;->d(J)V

    iput v3, p0, Lcom/d/a/o;->d:I

    iput-boolean v6, p0, Lcom/d/a/o;->v:Z

    iget-object v0, p0, Lcom/d/a/o;->a:Ljava/util/ArrayList;

    if-eqz v0, :cond_5e

    iget-object v0, p0, Lcom/d/a/o;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    move v1, v3

    :goto_4e
    if-ge v1, v2, :cond_5e

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    add-int/lit8 v1, v1, 0x1

    goto :goto_4e

    :cond_56
    invoke-static {}, Landroid/view/animation/AnimationUtils;->currentAnimationTimeMillis()J

    move-result-wide v0

    iget-wide v4, p0, Lcom/d/a/o;->b:J

    sub-long/2addr v0, v4

    goto :goto_36

    :cond_5e
    sget-object v0, Lcom/d/a/o;->h:Ljava/lang/ThreadLocal;

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/d/a/p;

    if-nez v0, :cond_72

    new-instance v0, Lcom/d/a/p;

    invoke-direct {v0, v3}, Lcom/d/a/p;-><init>(B)V

    sget-object v1, Lcom/d/a/o;->h:Ljava/lang/ThreadLocal;

    invoke-virtual {v1, v0}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    :cond_72
    invoke-virtual {v0, v3}, Lcom/d/a/p;->sendEmptyMessage(I)Z

    .line 952
    return-void
.end method

.method a(F)V
    .registers 7

    .prologue
    const/4 v0, 0x0

    .line 1169
    iget-object v1, p0, Lcom/d/a/o;->C:Landroid/view/animation/Interpolator;

    invoke-interface {v1, p1}, Landroid/view/animation/Interpolator;->getInterpolation(F)F

    move-result v2

    .line 1170
    iput v2, p0, Lcom/d/a/o;->s:F

    .line 1171
    iget-object v1, p0, Lcom/d/a/o;->f:[Lcom/d/a/l;

    array-length v3, v1

    move v1, v0

    .line 1172
    :goto_d
    if-ge v1, v3, :cond_19

    .line 1173
    iget-object v4, p0, Lcom/d/a/o;->f:[Lcom/d/a/l;

    aget-object v4, v4, v1

    invoke-virtual {v4, v2}, Lcom/d/a/l;->a(F)V

    .line 1172
    add-int/lit8 v1, v1, 0x1

    goto :goto_d

    .line 1175
    :cond_19
    iget-object v1, p0, Lcom/d/a/o;->D:Ljava/util/ArrayList;

    if-eqz v1, :cond_35

    .line 1176
    iget-object v1, p0, Lcom/d/a/o;->D:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    move v1, v0

    .line 1177
    :goto_24
    if-ge v1, v2, :cond_35

    .line 1178
    iget-object v0, p0, Lcom/d/a/o;->D:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/d/a/q;

    invoke-interface {v0, p0}, Lcom/d/a/q;->a(Lcom/d/a/o;)V

    .line 1177
    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_24

    .line 1181
    :cond_35
    return-void
.end method

.method public final a(I)V
    .registers 2

    .prologue
    .line 780
    iput p1, p0, Lcom/d/a/o;->A:I

    .line 781
    return-void
.end method

.method public final a(Lcom/d/a/q;)V
    .registers 3

    .prologue
    .line 820
    iget-object v0, p0, Lcom/d/a/o;->D:Ljava/util/ArrayList;

    if-nez v0, :cond_b

    .line 821
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/d/a/o;->D:Ljava/util/ArrayList;

    .line 823
    :cond_b
    iget-object v0, p0, Lcom/d/a/o;->D:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 824
    return-void
.end method

.method public varargs a([F)V
    .registers 5

    .prologue
    const/4 v2, 0x0

    .line 401
    if-eqz p1, :cond_6

    array-length v0, p1

    if-nez v0, :cond_7

    .line 412
    :cond_6
    :goto_6
    return-void

    .line 404
    :cond_7
    iget-object v0, p0, Lcom/d/a/o;->f:[Lcom/d/a/l;

    if-eqz v0, :cond_10

    iget-object v0, p0, Lcom/d/a/o;->f:[Lcom/d/a/l;

    array-length v0, v0

    if-nez v0, :cond_21

    .line 405
    :cond_10
    const/4 v0, 0x1

    new-array v0, v0, [Lcom/d/a/l;

    const-string v1, ""

    invoke-static {v1, p1}, Lcom/d/a/l;->a(Ljava/lang/String;[F)Lcom/d/a/l;

    move-result-object v1

    aput-object v1, v0, v2

    invoke-virtual {p0, v0}, Lcom/d/a/o;->a([Lcom/d/a/l;)V

    .line 411
    :goto_1e
    iput-boolean v2, p0, Lcom/d/a/o;->e:Z

    goto :goto_6

    .line 407
    :cond_21
    iget-object v0, p0, Lcom/d/a/o;->f:[Lcom/d/a/l;

    aget-object v0, v0, v2

    .line 408
    invoke-virtual {v0, p1}, Lcom/d/a/l;->a([F)V

    goto :goto_1e
.end method

.method public final varargs a([Lcom/d/a/l;)V
    .registers 7

    .prologue
    const/4 v1, 0x0

    .line 456
    iput-object p1, p0, Lcom/d/a/o;->f:[Lcom/d/a/l;

    .line 458
    new-instance v0, Ljava/util/HashMap;

    const/4 v2, 0x1

    invoke-direct {v0, v2}, Ljava/util/HashMap;-><init>(I)V

    iput-object v0, p0, Lcom/d/a/o;->g:Ljava/util/HashMap;

    move v0, v1

    .line 459
    :goto_c
    if-gtz v0, :cond_1a

    .line 460
    aget-object v2, p1, v1

    .line 461
    iget-object v3, p0, Lcom/d/a/o;->g:Ljava/util/HashMap;

    iget-object v4, v2, Lcom/d/a/l;->a:Ljava/lang/String;

    invoke-virtual {v3, v4, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 459
    add-int/lit8 v0, v0, 0x1

    goto :goto_c

    .line 464
    :cond_1a
    iput-boolean v1, p0, Lcom/d/a/o;->e:Z

    .line 465
    return-void
.end method

.method public b(J)Lcom/d/a/o;
    .registers 6

    .prologue
    .line 510
    const-wide/16 v0, 0x0

    cmp-long v0, p1, v0

    if-gez v0, :cond_1b

    .line 511
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Animators cannot have negative duration: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 514
    :cond_1b
    iput-wide p1, p0, Lcom/d/a/o;->x:J

    .line 515
    return-object p0
.end method

.method public final b()V
    .registers 3

    .prologue
    .line 958
    iget v0, p0, Lcom/d/a/o;->d:I

    if-nez v0, :cond_20

    sget-object v0, Lcom/d/a/o;->j:Ljava/lang/ThreadLocal;

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_20

    sget-object v0, Lcom/d/a/o;->k:Ljava/lang/ThreadLocal;

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_47

    .line 961
    :cond_20
    iget-boolean v0, p0, Lcom/d/a/o;->v:Z

    if-eqz v0, :cond_44

    iget-object v0, p0, Lcom/d/a/o;->a:Ljava/util/ArrayList;

    if-eqz v0, :cond_44

    .line 962
    iget-object v0, p0, Lcom/d/a/o;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/ArrayList;

    .line 964
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_34
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_44

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/d/a/b;

    .line 965
    invoke-interface {v0}, Lcom/d/a/b;->b()V

    goto :goto_34

    .line 968
    :cond_44
    invoke-direct {p0}, Lcom/d/a/o;->r()V

    .line 970
    :cond_47
    return-void
.end method

.method public final c()V
    .registers 3

    .prologue
    .line 974
    sget-object v0, Lcom/d/a/o;->i:Ljava/lang/ThreadLocal;

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_35

    sget-object v0, Lcom/d/a/o;->j:Ljava/lang/ThreadLocal;

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_35

    .line 976
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/d/a/o;->t:Z

    .line 977
    invoke-direct {p0}, Lcom/d/a/o;->s()V

    .line 983
    :cond_22
    :goto_22
    iget v0, p0, Lcom/d/a/o;->A:I

    if-lez v0, :cond_3d

    iget v0, p0, Lcom/d/a/o;->A:I

    and-int/lit8 v0, v0, 0x1

    const/4 v1, 0x1

    if-ne v0, v1, :cond_3d

    .line 984
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/d/a/o;->a(F)V

    .line 988
    :goto_31
    invoke-direct {p0}, Lcom/d/a/o;->r()V

    .line 989
    return-void

    .line 978
    :cond_35
    iget-boolean v0, p0, Lcom/d/a/o;->e:Z

    if-nez v0, :cond_22

    .line 979
    invoke-virtual {p0}, Lcom/d/a/o;->f()V

    goto :goto_22

    .line 986
    :cond_3d
    const/high16 v0, 0x3f800000    # 1.0f

    invoke-virtual {p0, v0}, Lcom/d/a/o;->a(F)V

    goto :goto_31
.end method

.method final c(J)Z
    .registers 11

    .prologue
    const-wide/16 v5, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    const/high16 v4, 0x3f800000    # 1.0f

    .line 1100
    .line 1102
    iget v2, p0, Lcom/d/a/o;->d:I

    if-nez v2, :cond_14

    .line 1103
    iput v0, p0, Lcom/d/a/o;->d:I

    .line 1104
    iget-wide v2, p0, Lcom/d/a/o;->c:J

    cmp-long v2, v2, v5

    if-gez v2, :cond_1a

    .line 1105
    iput-wide p1, p0, Lcom/d/a/o;->b:J

    .line 1112
    :cond_14
    :goto_14
    iget v2, p0, Lcom/d/a/o;->d:I

    packed-switch v2, :pswitch_data_8a

    .line 1143
    :goto_19
    return v1

    .line 1107
    :cond_1a
    iget-wide v2, p0, Lcom/d/a/o;->c:J

    sub-long v2, p1, v2

    iput-wide v2, p0, Lcom/d/a/o;->b:J

    .line 1109
    const-wide/16 v2, -0x1

    iput-wide v2, p0, Lcom/d/a/o;->c:J

    goto :goto_14

    .line 1115
    :pswitch_25
    iget-wide v2, p0, Lcom/d/a/o;->x:J

    cmp-long v2, v2, v5

    if-lez v2, :cond_58

    iget-wide v2, p0, Lcom/d/a/o;->b:J

    sub-long v2, p1, v2

    long-to-float v2, v2

    iget-wide v5, p0, Lcom/d/a/o;->x:J

    long-to-float v3, v5

    div-float/2addr v2, v3

    .line 1116
    :goto_34
    cmpl-float v3, v2, v4

    if-ltz v3, :cond_87

    .line 1117
    iget v3, p0, Lcom/d/a/o;->r:I

    iget v5, p0, Lcom/d/a/o;->A:I

    if-lt v3, v5, :cond_43

    iget v3, p0, Lcom/d/a/o;->A:I

    const/4 v5, -0x1

    if-ne v3, v5, :cond_7f

    .line 1119
    :cond_43
    iget-object v3, p0, Lcom/d/a/o;->a:Ljava/util/ArrayList;

    if-eqz v3, :cond_5a

    .line 1120
    iget-object v3, p0, Lcom/d/a/o;->a:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v5

    move v3, v1

    .line 1121
    :goto_4e
    if-ge v3, v5, :cond_5a

    .line 1122
    iget-object v6, p0, Lcom/d/a/o;->a:Ljava/util/ArrayList;

    invoke-virtual {v6, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 1121
    add-int/lit8 v3, v3, 0x1

    goto :goto_4e

    :cond_58
    move v2, v4

    .line 1115
    goto :goto_34

    .line 1125
    :cond_5a
    iget v3, p0, Lcom/d/a/o;->B:I

    const/4 v5, 0x2

    if-ne v3, v5, :cond_66

    .line 1126
    iget-boolean v3, p0, Lcom/d/a/o;->q:Z

    if-eqz v3, :cond_64

    move v0, v1

    :cond_64
    iput-boolean v0, p0, Lcom/d/a/o;->q:Z

    .line 1128
    :cond_66
    iget v0, p0, Lcom/d/a/o;->r:I

    float-to-int v3, v2

    add-int/2addr v0, v3

    iput v0, p0, Lcom/d/a/o;->r:I

    .line 1129
    rem-float v0, v2, v4

    .line 1130
    iget-wide v2, p0, Lcom/d/a/o;->b:J

    iget-wide v5, p0, Lcom/d/a/o;->x:J

    add-long/2addr v2, v5

    iput-wide v2, p0, Lcom/d/a/o;->b:J

    .line 1136
    :goto_75
    iget-boolean v2, p0, Lcom/d/a/o;->q:Z

    if-eqz v2, :cond_7b

    .line 1137
    sub-float v0, v4, v0

    .line 1139
    :cond_7b
    invoke-virtual {p0, v0}, Lcom/d/a/o;->a(F)V

    goto :goto_19

    .line 1133
    :cond_7f
    invoke-static {v2, v4}, Ljava/lang/Math;->min(FF)F

    move-result v1

    move v7, v1

    move v1, v0

    move v0, v7

    goto :goto_75

    :cond_87
    move v0, v2

    goto :goto_75

    .line 1112
    nop

    :pswitch_data_8a
    .packed-switch 0x1
        :pswitch_25
        :pswitch_25
    .end packed-switch
.end method

.method public synthetic clone()Ljava/lang/Object;
    .registers 2

    .prologue
    .line 43
    invoke-virtual {p0}, Lcom/d/a/o;->g()Lcom/d/a/o;

    move-result-object v0

    return-object v0
.end method

.method public synthetic e()Lcom/d/a/a;
    .registers 2

    .prologue
    .line 43
    invoke-virtual {p0}, Lcom/d/a/o;->g()Lcom/d/a/o;

    move-result-object v0

    return-object v0
.end method

.method f()V
    .registers 4

    .prologue
    .line 490
    iget-boolean v0, p0, Lcom/d/a/o;->e:Z

    if-nez v0, :cond_17

    .line 491
    iget-object v0, p0, Lcom/d/a/o;->f:[Lcom/d/a/l;

    array-length v1, v0

    .line 492
    const/4 v0, 0x0

    :goto_8
    if-ge v0, v1, :cond_14

    .line 493
    iget-object v2, p0, Lcom/d/a/o;->f:[Lcom/d/a/l;

    aget-object v2, v2, v0

    invoke-virtual {v2}, Lcom/d/a/l;->b()V

    .line 492
    add-int/lit8 v0, v0, 0x1

    goto :goto_8

    .line 495
    :cond_14
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/d/a/o;->e:Z

    .line 497
    :cond_17
    return-void
.end method

.method public g()Lcom/d/a/o;
    .registers 8

    .prologue
    const/4 v1, 0x0

    .line 1185
    invoke-super {p0}, Lcom/d/a/a;->e()Lcom/d/a/a;

    move-result-object v0

    check-cast v0, Lcom/d/a/o;

    .line 1186
    iget-object v2, p0, Lcom/d/a/o;->D:Ljava/util/ArrayList;

    if-eqz v2, :cond_27

    .line 1187
    iget-object v3, p0, Lcom/d/a/o;->D:Ljava/util/ArrayList;

    .line 1188
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    iput-object v2, v0, Lcom/d/a/o;->D:Ljava/util/ArrayList;

    .line 1189
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v4

    move v2, v1

    .line 1190
    :goto_19
    if-ge v2, v4, :cond_27

    .line 1191
    iget-object v5, v0, Lcom/d/a/o;->D:Ljava/util/ArrayList;

    invoke-virtual {v3, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1190
    add-int/lit8 v2, v2, 0x1

    goto :goto_19

    .line 1194
    :cond_27
    const-wide/16 v2, -0x1

    iput-wide v2, v0, Lcom/d/a/o;->c:J

    .line 1195
    iput-boolean v1, v0, Lcom/d/a/o;->q:Z

    .line 1196
    iput v1, v0, Lcom/d/a/o;->r:I

    .line 1197
    iput-boolean v1, v0, Lcom/d/a/o;->e:Z

    .line 1198
    iput v1, v0, Lcom/d/a/o;->d:I

    .line 1199
    iput-boolean v1, v0, Lcom/d/a/o;->t:Z

    .line 1200
    iget-object v2, p0, Lcom/d/a/o;->f:[Lcom/d/a/l;

    .line 1201
    if-eqz v2, :cond_5b

    .line 1202
    array-length v3, v2

    .line 1203
    new-array v4, v3, [Lcom/d/a/l;

    iput-object v4, v0, Lcom/d/a/o;->f:[Lcom/d/a/l;

    .line 1204
    new-instance v4, Ljava/util/HashMap;

    invoke-direct {v4, v3}, Ljava/util/HashMap;-><init>(I)V

    iput-object v4, v0, Lcom/d/a/o;->g:Ljava/util/HashMap;

    .line 1205
    :goto_45
    if-ge v1, v3, :cond_5b

    .line 1206
    aget-object v4, v2, v1

    invoke-virtual {v4}, Lcom/d/a/l;->a()Lcom/d/a/l;

    move-result-object v4

    .line 1207
    iget-object v5, v0, Lcom/d/a/o;->f:[Lcom/d/a/l;

    aput-object v4, v5, v1

    .line 1208
    iget-object v5, v0, Lcom/d/a/o;->g:Ljava/util/HashMap;

    iget-object v6, v4, Lcom/d/a/l;->a:Ljava/lang/String;

    invoke-virtual {v5, v6, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1205
    add-int/lit8 v1, v1, 0x1

    goto :goto_45

    .line 1211
    :cond_5b
    return-object v0
.end method

.method public final h()Ljava/lang/Object;
    .registers 3

    .prologue
    .line 744
    iget-object v0, p0, Lcom/d/a/o;->f:[Lcom/d/a/l;

    if-eqz v0, :cond_13

    iget-object v0, p0, Lcom/d/a/o;->f:[Lcom/d/a/l;

    array-length v0, v0

    if-lez v0, :cond_13

    .line 745
    iget-object v0, p0, Lcom/d/a/o;->f:[Lcom/d/a/l;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    invoke-virtual {v0}, Lcom/d/a/l;->c()Ljava/lang/Object;

    move-result-object v0

    .line 748
    :goto_12
    return-object v0

    :cond_13
    const/4 v0, 0x0

    goto :goto_12
.end method

.method public final i()V
    .registers 2

    .prologue
    .line 800
    const/4 v0, 0x1

    iput v0, p0, Lcom/d/a/o;->B:I

    .line 801
    return-void
.end method

.method public final j()V
    .registers 2

    .prologue
    .line 830
    iget-object v0, p0, Lcom/d/a/o;->D:Ljava/util/ArrayList;

    if-nez v0, :cond_5

    .line 835
    :goto_4
    return-void

    .line 833
    :cond_5
    iget-object v0, p0, Lcom/d/a/o;->D:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 834
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/d/a/o;->D:Ljava/util/ArrayList;

    goto :goto_4
.end method

.method public final k()Z
    .registers 3

    .prologue
    const/4 v0, 0x1

    .line 993
    iget v1, p0, Lcom/d/a/o;->d:I

    if-eq v1, v0, :cond_9

    iget-boolean v1, p0, Lcom/d/a/o;->v:Z

    if-eqz v1, :cond_a

    :cond_9
    :goto_9
    return v0

    :cond_a
    const/4 v0, 0x0

    goto :goto_9
.end method

.method public toString()Ljava/lang/String;
    .registers 4

    .prologue
    .line 1256
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "ValueAnimator@"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 1257
    iget-object v0, p0, Lcom/d/a/o;->f:[Lcom/d/a/l;

    if-eqz v0, :cond_43

    .line 1258
    const/4 v0, 0x0

    :goto_1c
    iget-object v2, p0, Lcom/d/a/o;->f:[Lcom/d/a/l;

    array-length v2, v2

    if-ge v0, v2, :cond_43

    .line 1259
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\n    "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/d/a/o;->f:[Lcom/d/a/l;

    aget-object v2, v2, v0

    invoke-virtual {v2}, Lcom/d/a/l;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 1258
    add-int/lit8 v0, v0, 0x1

    goto :goto_1c

    .line 1262
    :cond_43
    return-object v1
.end method

###### Class com.d.a.o.AnonymousClass1 (com.d.a.o$1)
.class final Lcom/d/a/o$1;
.super Ljava/lang/ThreadLocal;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/d/a/o;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/ThreadLocal",
        "<",
        "Ljava/util/ArrayList",
        "<",
        "Lcom/d/a/o;",
        ">;>;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 99
    invoke-direct {p0}, Ljava/lang/ThreadLocal;-><init>()V

    return-void
.end method


# virtual methods
.method protected final synthetic initialValue()Ljava/lang/Object;
    .registers 2

    .prologue
    .line 99
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    return-object v0
.end method

###### Class com.d.a.o.AnonymousClass2 (com.d.a.o$2)
.class final Lcom/d/a/o$2;
.super Ljava/lang/ThreadLocal;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/d/a/o;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/ThreadLocal",
        "<",
        "Ljava/util/ArrayList",
        "<",
        "Lcom/d/a/o;",
        ">;>;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 108
    invoke-direct {p0}, Ljava/lang/ThreadLocal;-><init>()V

    return-void
.end method


# virtual methods
.method protected final synthetic initialValue()Ljava/lang/Object;
    .registers 2

    .prologue
    .line 108
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    return-object v0
.end method

###### Class com.d.a.o.AnonymousClass3 (com.d.a.o$3)
.class final Lcom/d/a/o$3;
.super Ljava/lang/ThreadLocal;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/d/a/o;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/ThreadLocal",
        "<",
        "Ljava/util/ArrayList",
        "<",
        "Lcom/d/a/o;",
        ">;>;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 120
    invoke-direct {p0}, Ljava/lang/ThreadLocal;-><init>()V

    return-void
.end method


# virtual methods
.method protected final synthetic initialValue()Ljava/lang/Object;
    .registers 2

    .prologue
    .line 120
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    return-object v0
.end method

###### Class com.d.a.o.AnonymousClass4 (com.d.a.o$4)
.class final Lcom/d/a/o$4;
.super Ljava/lang/ThreadLocal;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/d/a/o;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/ThreadLocal",
        "<",
        "Ljava/util/ArrayList",
        "<",
        "Lcom/d/a/o;",
        ">;>;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 128
    invoke-direct {p0}, Ljava/lang/ThreadLocal;-><init>()V

    return-void
.end method


# virtual methods
.method protected final synthetic initialValue()Ljava/lang/Object;
    .registers 2

    .prologue
    .line 128
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    return-object v0
.end method

###### Class com.d.a.o.AnonymousClass5 (com.d.a.o$5)
.class final Lcom/d/a/o$5;
.super Ljava/lang/ThreadLocal;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/d/a/o;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/ThreadLocal",
        "<",
        "Ljava/util/ArrayList",
        "<",
        "Lcom/d/a/o;",
        ">;>;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 136
    invoke-direct {p0}, Ljava/lang/ThreadLocal;-><init>()V

    return-void
.end method


# virtual methods
.method protected final synthetic initialValue()Ljava/lang/Object;
    .registers 2

    .prologue
    .line 136
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    return-object v0
.end method
