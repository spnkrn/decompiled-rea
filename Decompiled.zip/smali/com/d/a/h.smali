###### Class com.d.a.h (com.d.a.h)
.class final Lcom/d/a/h;
.super Lcom/d/a/g;
.source "SourceFile"


# instance fields
.field d:F


# direct methods
.method constructor <init>()V
    .registers 2

    .prologue
    .line 333
    invoke-direct {p0}, Lcom/d/a/g;-><init>()V

    .line 334
    const/4 v0, 0x0

    iput v0, p0, Lcom/d/a/h;->a:F

    .line 335
    sget-object v0, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    iput-object v0, p0, Lcom/d/a/h;->b:Ljava/lang/Class;

    .line 336
    return-void
.end method

.method constructor <init>(FF)V
    .registers 4

    .prologue
    .line 326
    invoke-direct {p0}, Lcom/d/a/g;-><init>()V

    .line 327
    iput p1, p0, Lcom/d/a/h;->a:F

    .line 328
    iput p2, p0, Lcom/d/a/h;->d:F

    .line 329
    sget-object v0, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    iput-object v0, p0, Lcom/d/a/h;->b:Ljava/lang/Class;

    .line 330
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/d/a/h;->c:Z

    .line 331
    return-void
.end method

.method private d()Lcom/d/a/h;
    .registers 4

    .prologue
    .line 355
    new-instance v0, Lcom/d/a/h;

    iget v1, p0, Lcom/d/a/g;->a:F

    iget v2, p0, Lcom/d/a/h;->d:F

    invoke-direct {v0, v1, v2}, Lcom/d/a/h;-><init>(FF)V

    .line 356
    invoke-virtual {p0}, Lcom/d/a/h;->b()Landroid/view/animation/Interpolator;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/d/a/h;->a(Landroid/view/animation/Interpolator;)V

    .line 357
    return-object v0
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 2

    .prologue
    .line 343
    iget v0, p0, Lcom/d/a/h;->d:F

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    return-object v0
.end method

.method public final a(Ljava/lang/Object;)V
    .registers 4

    .prologue
    .line 347
    if-eqz p1, :cond_15

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const-class v1, Ljava/lang/Float;

    if-ne v0, v1, :cond_15

    .line 348
    check-cast p1, Ljava/lang/Float;

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result v0

    iput v0, p0, Lcom/d/a/h;->d:F

    .line 349
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/d/a/h;->c:Z

    .line 351
    :cond_15
    return-void
.end method

.method public final synthetic c()Lcom/d/a/g;
    .registers 2

    .prologue
    .line 320
    invoke-direct {p0}, Lcom/d/a/h;->d()Lcom/d/a/h;

    move-result-object v0

    return-object v0
.end method

.method public final synthetic clone()Ljava/lang/Object;
    .registers 2

    .prologue
    .line 320
    invoke-direct {p0}, Lcom/d/a/h;->d()Lcom/d/a/h;

    move-result-object v0

    return-object v0
.end method
