###### Class com.d.a.b (com.d.a.b)
.class public interface abstract Lcom/d/a/b;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()V
.end method

.method public abstract b()V
.end method
