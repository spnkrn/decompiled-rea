###### Class com.d.a.j (com.d.a.j)
.class public final Lcom/d/a/j;
.super Lcom/d/a/o;
.source "SourceFile"


# static fields
.field private static final h:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map",
            "<",
            "Ljava/lang/String;",
            "Lcom/d/b/c;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private i:Ljava/lang/Object;

.field private j:Ljava/lang/String;

.field private k:Lcom/d/b/c;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .prologue
    .line 41
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    .line 44
    sput-object v0, Lcom/d/a/j;->h:Ljava/util/Map;

    const-string v1, "alpha"

    sget-object v2, Lcom/d/a/k;->a:Lcom/d/b/c;

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 45
    sget-object v0, Lcom/d/a/j;->h:Ljava/util/Map;

    const-string v1, "pivotX"

    sget-object v2, Lcom/d/a/k;->b:Lcom/d/b/c;

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 46
    sget-object v0, Lcom/d/a/j;->h:Ljava/util/Map;

    const-string v1, "pivotY"

    sget-object v2, Lcom/d/a/k;->c:Lcom/d/b/c;

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 47
    sget-object v0, Lcom/d/a/j;->h:Ljava/util/Map;

    const-string v1, "translationX"

    sget-object v2, Lcom/d/a/k;->d:Lcom/d/b/c;

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 48
    sget-object v0, Lcom/d/a/j;->h:Ljava/util/Map;

    const-string v1, "translationY"

    sget-object v2, Lcom/d/a/k;->e:Lcom/d/b/c;

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 49
    sget-object v0, Lcom/d/a/j;->h:Ljava/util/Map;

    const-string v1, "rotation"

    sget-object v2, Lcom/d/a/k;->f:Lcom/d/b/c;

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 50
    sget-object v0, Lcom/d/a/j;->h:Ljava/util/Map;

    const-string v1, "rotationX"

    sget-object v2, Lcom/d/a/k;->g:Lcom/d/b/c;

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 51
    sget-object v0, Lcom/d/a/j;->h:Ljava/util/Map;

    const-string v1, "rotationY"

    sget-object v2, Lcom/d/a/k;->h:Lcom/d/b/c;

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 52
    sget-object v0, Lcom/d/a/j;->h:Ljava/util/Map;

    const-string v1, "scaleX"

    sget-object v2, Lcom/d/a/k;->i:Lcom/d/b/c;

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 53
    sget-object v0, Lcom/d/a/j;->h:Ljava/util/Map;

    const-string v1, "scaleY"

    sget-object v2, Lcom/d/a/k;->j:Lcom/d/b/c;

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 54
    sget-object v0, Lcom/d/a/j;->h:Ljava/util/Map;

    const-string v1, "scrollX"

    sget-object v2, Lcom/d/a/k;->k:Lcom/d/b/c;

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 55
    sget-object v0, Lcom/d/a/j;->h:Ljava/util/Map;

    const-string v1, "scrollY"

    sget-object v2, Lcom/d/a/k;->l:Lcom/d/b/c;

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 56
    sget-object v0, Lcom/d/a/j;->h:Ljava/util/Map;

    const-string v1, "x"

    sget-object v2, Lcom/d/a/k;->m:Lcom/d/b/c;

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 57
    sget-object v0, Lcom/d/a/j;->h:Ljava/util/Map;

    const-string v1, "y"

    sget-object v2, Lcom/d/a/k;->n:Lcom/d/b/c;

    invoke-interface {v0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 58
    return-void
.end method

.method public constructor <init>()V
    .registers 1

    .prologue
    .line 150
    invoke-direct {p0}, Lcom/d/a/o;-><init>()V

    .line 151
    return-void
.end method

.method private constructor <init>(Ljava/lang/Object;Lcom/d/b/c;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Lcom/d/b/c",
            "<TT;*>;)V"
        }
    .end annotation

    .prologue
    .line 173
    invoke-direct {p0}, Lcom/d/a/o;-><init>()V

    .line 174
    iput-object p1, p0, Lcom/d/a/j;->i:Ljava/lang/Object;

    .line 175
    invoke-direct {p0, p2}, Lcom/d/a/j;->a(Lcom/d/b/c;)V

    .line 176
    return-void
.end method

.method public static varargs a(Ljava/lang/Object;Lcom/d/b/c;[F)Lcom/d/a/j;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Lcom/d/b/c",
            "<TT;",
            "Ljava/lang/Float;",
            ">;[F)",
            "Lcom/d/a/j;"
        }
    .end annotation

    .prologue
    .line 250
    new-instance v0, Lcom/d/a/j;

    invoke-direct {v0, p0, p1}, Lcom/d/a/j;-><init>(Ljava/lang/Object;Lcom/d/b/c;)V

    .line 251
    invoke-virtual {v0, p2}, Lcom/d/a/j;->a([F)V

    .line 252
    return-object v0
.end method

.method private a(Lcom/d/b/c;)V
    .registers 6

    .prologue
    const/4 v3, 0x0

    .line 118
    iget-object v0, p0, Lcom/d/a/j;->f:[Lcom/d/a/l;

    if-eqz v0, :cond_1a

    .line 119
    iget-object v0, p0, Lcom/d/a/j;->f:[Lcom/d/a/l;

    aget-object v0, v0, v3

    .line 120
    iget-object v1, v0, Lcom/d/a/l;->a:Ljava/lang/String;

    .line 121
    invoke-virtual {v0, p1}, Lcom/d/a/l;->a(Lcom/d/b/c;)V

    .line 122
    iget-object v2, p0, Lcom/d/a/j;->g:Ljava/util/HashMap;

    invoke-virtual {v2, v1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 123
    iget-object v1, p0, Lcom/d/a/j;->g:Ljava/util/HashMap;

    iget-object v2, p0, Lcom/d/a/j;->j:Ljava/lang/String;

    invoke-virtual {v1, v2, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 125
    :cond_1a
    iget-object v0, p0, Lcom/d/a/j;->k:Lcom/d/b/c;

    if-eqz v0, :cond_24

    .line 126
    invoke-virtual {p1}, Lcom/d/b/c;->a()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/d/a/j;->j:Ljava/lang/String;

    .line 128
    :cond_24
    iput-object p1, p0, Lcom/d/a/j;->k:Lcom/d/b/c;

    .line 130
    iput-boolean v3, p0, Lcom/d/a/j;->e:Z

    .line 131
    return-void
.end method


# virtual methods
.method public final synthetic a(J)Lcom/d/a/a;
    .registers 3

    .prologue
    .line 39
    invoke-super {p0, p1, p2}, Lcom/d/a/o;->b(J)Lcom/d/a/o;

    return-object p0
.end method

.method public final a()V
    .registers 1

    .prologue
    .line 385
    invoke-super {p0}, Lcom/d/a/o;->a()V

    .line 386
    return-void
.end method

.method final a(F)V
    .registers 6

    .prologue
    .line 491
    invoke-super {p0, p1}, Lcom/d/a/o;->a(F)V

    .line 492
    iget-object v0, p0, Lcom/d/a/j;->f:[Lcom/d/a/l;

    array-length v1, v0

    .line 493
    const/4 v0, 0x0

    :goto_7
    if-ge v0, v1, :cond_15

    .line 494
    iget-object v2, p0, Lcom/d/a/j;->f:[Lcom/d/a/l;

    aget-object v2, v2, v0

    iget-object v3, p0, Lcom/d/a/j;->i:Ljava/lang/Object;

    invoke-virtual {v2, v3}, Lcom/d/a/l;->b(Ljava/lang/Object;)V

    .line 493
    add-int/lit8 v0, v0, 0x1

    goto :goto_7

    .line 496
    :cond_15
    return-void
.end method

.method public final varargs a([F)V
    .registers 5

    .prologue
    const/4 v1, 0x1

    const/4 v2, 0x0

    .line 345
    iget-object v0, p0, Lcom/d/a/j;->f:[Lcom/d/a/l;

    if-eqz v0, :cond_b

    iget-object v0, p0, Lcom/d/a/j;->f:[Lcom/d/a/l;

    array-length v0, v0

    if-nez v0, :cond_2b

    .line 348
    :cond_b
    iget-object v0, p0, Lcom/d/a/j;->k:Lcom/d/b/c;

    if-eqz v0, :cond_1d

    .line 349
    new-array v0, v1, [Lcom/d/a/l;

    iget-object v1, p0, Lcom/d/a/j;->k:Lcom/d/b/c;

    invoke-static {v1, p1}, Lcom/d/a/l;->a(Lcom/d/b/c;[F)Lcom/d/a/l;

    move-result-object v1

    aput-object v1, v0, v2

    invoke-virtual {p0, v0}, Lcom/d/a/j;->a([Lcom/d/a/l;)V

    .line 356
    :goto_1c
    return-void

    .line 351
    :cond_1d
    new-array v0, v1, [Lcom/d/a/l;

    iget-object v1, p0, Lcom/d/a/j;->j:Ljava/lang/String;

    invoke-static {v1, p1}, Lcom/d/a/l;->a(Ljava/lang/String;[F)Lcom/d/a/l;

    move-result-object v1

    aput-object v1, v0, v2

    invoke-virtual {p0, v0}, Lcom/d/a/j;->a([Lcom/d/a/l;)V

    goto :goto_1c

    .line 354
    :cond_2b
    invoke-super {p0, p1}, Lcom/d/a/o;->a([F)V

    goto :goto_1c
.end method

.method public final bridge synthetic b(J)Lcom/d/a/o;
    .registers 3

    .prologue
    .line 39
    invoke-super {p0, p1, p2}, Lcom/d/a/o;->b(J)Lcom/d/a/o;

    return-object p0
.end method

.method public final synthetic clone()Ljava/lang/Object;
    .registers 2

    .prologue
    .line 39
    invoke-super {p0}, Lcom/d/a/o;->g()Lcom/d/a/o;

    move-result-object v0

    check-cast v0, Lcom/d/a/j;

    return-object v0
.end method

.method public final synthetic e()Lcom/d/a/a;
    .registers 2

    .prologue
    .line 39
    invoke-super {p0}, Lcom/d/a/o;->g()Lcom/d/a/o;

    move-result-object v0

    check-cast v0, Lcom/d/a/j;

    return-object v0
.end method

.method final f()V
    .registers 5

    .prologue
    .line 402
    iget-boolean v0, p0, Lcom/d/a/j;->e:Z

    if-nez v0, :cond_3e

    .line 405
    iget-object v0, p0, Lcom/d/a/j;->k:Lcom/d/b/c;

    if-nez v0, :cond_29

    sget-boolean v0, Lcom/d/c/a/a;->a:Z

    if-eqz v0, :cond_29

    iget-object v0, p0, Lcom/d/a/j;->i:Ljava/lang/Object;

    instance-of v0, v0, Landroid/view/View;

    if-eqz v0, :cond_29

    sget-object v0, Lcom/d/a/j;->h:Ljava/util/Map;

    iget-object v1, p0, Lcom/d/a/j;->j:Ljava/lang/String;

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_29

    .line 406
    sget-object v0, Lcom/d/a/j;->h:Ljava/util/Map;

    iget-object v1, p0, Lcom/d/a/j;->j:Ljava/lang/String;

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/d/b/c;

    invoke-direct {p0, v0}, Lcom/d/a/j;->a(Lcom/d/b/c;)V

    .line 408
    :cond_29
    iget-object v0, p0, Lcom/d/a/j;->f:[Lcom/d/a/l;

    array-length v1, v0

    .line 409
    const/4 v0, 0x0

    :goto_2d
    if-ge v0, v1, :cond_3b

    .line 410
    iget-object v2, p0, Lcom/d/a/j;->f:[Lcom/d/a/l;

    aget-object v2, v2, v0

    iget-object v3, p0, Lcom/d/a/j;->i:Ljava/lang/Object;

    invoke-virtual {v2, v3}, Lcom/d/a/l;->a(Ljava/lang/Object;)V

    .line 409
    add-int/lit8 v0, v0, 0x1

    goto :goto_2d

    .line 412
    :cond_3b
    invoke-super {p0}, Lcom/d/a/o;->f()V

    .line 414
    :cond_3e
    return-void
.end method

.method public final bridge synthetic g()Lcom/d/a/o;
    .registers 2

    .prologue
    .line 39
    invoke-super {p0}, Lcom/d/a/o;->g()Lcom/d/a/o;

    move-result-object v0

    check-cast v0, Lcom/d/a/j;

    return-object v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    .prologue
    .line 506
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "ObjectAnimator@"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", target "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lcom/d/a/j;->i:Ljava/lang/Object;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 508
    iget-object v0, p0, Lcom/d/a/j;->f:[Lcom/d/a/l;

    if-eqz v0, :cond_4f

    .line 509
    const/4 v0, 0x0

    :goto_28
    iget-object v2, p0, Lcom/d/a/j;->f:[Lcom/d/a/l;

    array-length v2, v2

    if-ge v0, v2, :cond_4f

    .line 510
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\n    "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    iget-object v2, p0, Lcom/d/a/j;->f:[Lcom/d/a/l;

    aget-object v2, v2, v0

    invoke-virtual {v2}, Lcom/d/a/l;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .line 509
    add-int/lit8 v0, v0, 0x1

    goto :goto_28

    .line 513
    :cond_4f
    return-object v1
.end method
