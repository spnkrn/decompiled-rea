###### Class com.d.a.q (com.d.a.q)
.class public interface abstract Lcom/d/a/q;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Lcom/d/a/o;)V
.end method
