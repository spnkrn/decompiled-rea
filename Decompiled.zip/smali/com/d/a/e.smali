###### Class com.d.a.e (com.d.a.e)
.class final Lcom/d/a/e;
.super Lcom/d/a/i;
.source "SourceFile"


# instance fields
.field private g:F

.field private h:F

.field private i:F

.field private j:Z


# direct methods
.method public varargs constructor <init>([Lcom/d/a/h;)V
    .registers 3

    .prologue
    .line 42
    invoke-direct {p0, p1}, Lcom/d/a/i;-><init>([Lcom/d/a/g;)V

    .line 39
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/d/a/e;->j:Z

    .line 43
    return-void
.end method

.method private b()Lcom/d/a/e;
    .registers 6

    .prologue
    .line 52
    iget-object v2, p0, Lcom/d/a/e;->e:Ljava/util/ArrayList;

    .line 53
    iget-object v0, p0, Lcom/d/a/e;->e:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v3

    .line 54
    new-array v4, v3, [Lcom/d/a/h;

    .line 55
    const/4 v0, 0x0

    move v1, v0

    :goto_c
    if-ge v1, v3, :cond_20

    .line 56
    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/d/a/g;

    invoke-virtual {v0}, Lcom/d/a/g;->c()Lcom/d/a/g;

    move-result-object v0

    check-cast v0, Lcom/d/a/h;

    aput-object v0, v4, v1

    .line 55
    add-int/lit8 v0, v1, 0x1

    move v1, v0

    goto :goto_c

    .line 58
    :cond_20
    new-instance v0, Lcom/d/a/e;

    invoke-direct {v0, v4}, Lcom/d/a/e;-><init>([Lcom/d/a/h;)V

    .line 59
    return-object v0
.end method


# virtual methods
.method public final synthetic a()Lcom/d/a/i;
    .registers 2

    .prologue
    .line 35
    invoke-direct {p0}, Lcom/d/a/e;->b()Lcom/d/a/e;

    move-result-object v0

    return-object v0
.end method

.method public final a(F)Ljava/lang/Object;
    .registers 3

    .prologue
    .line 47
    invoke-virtual {p0, p1}, Lcom/d/a/e;->b(F)F

    move-result v0

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    return-object v0
.end method

.method public final b(F)F
    .registers 7

    .prologue
    const/4 v1, 0x1

    const/4 v3, 0x0

    .line 63
    iget v0, p0, Lcom/d/a/e;->a:I

    const/4 v2, 0x2

    if-ne v0, v2, :cond_5a

    .line 64
    iget-boolean v0, p0, Lcom/d/a/e;->j:Z

    if-eqz v0, :cond_2c

    .line 65
    iput-boolean v3, p0, Lcom/d/a/e;->j:Z

    .line 66
    iget-object v0, p0, Lcom/d/a/e;->e:Ljava/util/ArrayList;

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/d/a/h;

    iget v0, v0, Lcom/d/a/h;->d:F

    iput v0, p0, Lcom/d/a/e;->g:F

    .line 67
    iget-object v0, p0, Lcom/d/a/e;->e:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/d/a/h;

    iget v0, v0, Lcom/d/a/h;->d:F

    iput v0, p0, Lcom/d/a/e;->h:F

    .line 68
    iget v0, p0, Lcom/d/a/e;->h:F

    iget v1, p0, Lcom/d/a/e;->g:F

    sub-float/2addr v0, v1

    iput v0, p0, Lcom/d/a/e;->i:F

    .line 70
    :cond_2c
    iget-object v0, p0, Lcom/d/a/e;->d:Landroid/view/animation/Interpolator;

    if-eqz v0, :cond_36

    .line 71
    iget-object v0, p0, Lcom/d/a/e;->d:Landroid/view/animation/Interpolator;

    invoke-interface {v0, p1}, Landroid/view/animation/Interpolator;->getInterpolation(F)F

    move-result p1

    .line 73
    :cond_36
    iget-object v0, p0, Lcom/d/a/e;->f:Lcom/d/a/n;

    if-nez v0, :cond_41

    .line 74
    iget v0, p0, Lcom/d/a/e;->g:F

    iget v1, p0, Lcom/d/a/e;->i:F

    mul-float/2addr v1, p1

    add-float/2addr v0, v1

    .line 132
    :goto_40
    return v0

    .line 76
    :cond_41
    iget-object v0, p0, Lcom/d/a/e;->f:Lcom/d/a/n;

    iget v1, p0, Lcom/d/a/e;->g:F

    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    iget v2, p0, Lcom/d/a/e;->h:F

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    invoke-interface {v0, p1, v1, v2}, Lcom/d/a/n;->a(FLjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    move-result v0

    goto :goto_40

    .line 79
    :cond_5a
    const/4 v0, 0x0

    cmpg-float v0, p1, v0

    if-gtz v0, :cond_a5

    .line 80
    iget-object v0, p0, Lcom/d/a/e;->e:Ljava/util/ArrayList;

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/d/a/h;

    .line 81
    iget-object v2, p0, Lcom/d/a/e;->e:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/d/a/h;

    .line 82
    iget v2, v0, Lcom/d/a/h;->d:F

    .line 83
    iget v3, v1, Lcom/d/a/h;->d:F

    .line 84
    iget v0, v0, Lcom/d/a/g;->a:F

    .line 85
    iget v4, v1, Lcom/d/a/g;->a:F

    .line 86
    invoke-virtual {v1}, Lcom/d/a/h;->b()Landroid/view/animation/Interpolator;

    move-result-object v1

    .line 87
    if-eqz v1, :cond_81

    .line 88
    invoke-interface {v1, p1}, Landroid/view/animation/Interpolator;->getInterpolation(F)F

    move-result p1

    .line 90
    :cond_81
    sub-float v1, p1, v0

    sub-float v0, v4, v0

    div-float v0, v1, v0

    .line 91
    iget-object v1, p0, Lcom/d/a/e;->f:Lcom/d/a/n;

    if-nez v1, :cond_90

    sub-float v1, v3, v2

    mul-float/2addr v0, v1

    add-float/2addr v0, v2

    goto :goto_40

    :cond_90
    iget-object v1, p0, Lcom/d/a/e;->f:Lcom/d/a/n;

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    invoke-interface {v1, v0, v2, v3}, Lcom/d/a/n;->a(FLjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    move-result v0

    goto :goto_40

    .line 95
    :cond_a5
    const/high16 v0, 0x3f800000    # 1.0f

    cmpl-float v0, p1, v0

    if-ltz v0, :cond_fb

    .line 96
    iget-object v0, p0, Lcom/d/a/e;->e:Ljava/util/ArrayList;

    iget v1, p0, Lcom/d/a/e;->a:I

    add-int/lit8 v1, v1, -0x2

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/d/a/h;

    .line 97
    iget-object v1, p0, Lcom/d/a/e;->e:Ljava/util/ArrayList;

    iget v2, p0, Lcom/d/a/e;->a:I

    add-int/lit8 v2, v2, -0x1

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/d/a/h;

    .line 98
    iget v2, v0, Lcom/d/a/h;->d:F

    .line 99
    iget v3, v1, Lcom/d/a/h;->d:F

    .line 100
    iget v0, v0, Lcom/d/a/g;->a:F

    .line 101
    iget v4, v1, Lcom/d/a/g;->a:F

    .line 102
    invoke-virtual {v1}, Lcom/d/a/h;->b()Landroid/view/animation/Interpolator;

    move-result-object v1

    .line 103
    if-eqz v1, :cond_d5

    .line 104
    invoke-interface {v1, p1}, Landroid/view/animation/Interpolator;->getInterpolation(F)F

    move-result p1

    .line 106
    :cond_d5
    sub-float v1, p1, v0

    sub-float v0, v4, v0

    div-float v0, v1, v0

    .line 107
    iget-object v1, p0, Lcom/d/a/e;->f:Lcom/d/a/n;

    if-nez v1, :cond_e5

    sub-float v1, v3, v2

    mul-float/2addr v0, v1

    add-float/2addr v0, v2

    goto/16 :goto_40

    :cond_e5
    iget-object v1, p0, Lcom/d/a/e;->f:Lcom/d/a/n;

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v3

    invoke-interface {v1, v0, v2, v3}, Lcom/d/a/n;->a(FLjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    move-result v0

    goto/16 :goto_40

    .line 112
    :cond_fb
    iget-object v0, p0, Lcom/d/a/e;->e:Ljava/util/ArrayList;

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/d/a/h;

    move-object v2, v0

    .line 113
    :goto_104
    iget v0, p0, Lcom/d/a/e;->a:I

    if-ge v1, v0, :cond_151

    .line 114
    iget-object v0, p0, Lcom/d/a/e;->e:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/d/a/h;

    .line 115
    iget v3, v0, Lcom/d/a/g;->a:F

    cmpg-float v3, p1, v3

    if-gez v3, :cond_14d

    .line 116
    invoke-virtual {v0}, Lcom/d/a/h;->b()Landroid/view/animation/Interpolator;

    move-result-object v1

    .line 117
    if-eqz v1, :cond_120

    .line 118
    invoke-interface {v1, p1}, Landroid/view/animation/Interpolator;->getInterpolation(F)F

    move-result p1

    .line 120
    :cond_120
    iget v1, v2, Lcom/d/a/g;->a:F

    sub-float v1, p1, v1

    iget v3, v0, Lcom/d/a/g;->a:F

    iget v4, v2, Lcom/d/a/g;->a:F

    sub-float/2addr v3, v4

    div-float/2addr v1, v3

    .line 122
    iget v2, v2, Lcom/d/a/h;->d:F

    .line 123
    iget v0, v0, Lcom/d/a/h;->d:F

    .line 124
    iget-object v3, p0, Lcom/d/a/e;->f:Lcom/d/a/n;

    if-nez v3, :cond_137

    sub-float/2addr v0, v2

    mul-float/2addr v0, v1

    add-float/2addr v0, v2

    goto/16 :goto_40

    :cond_137
    iget-object v3, p0, Lcom/d/a/e;->f:Lcom/d/a/n;

    invoke-static {v2}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v2

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v0

    invoke-interface {v3, v1, v2, v0}, Lcom/d/a/n;->a(FLjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    move-result v0

    goto/16 :goto_40

    .line 113
    :cond_14d
    add-int/lit8 v1, v1, 0x1

    move-object v2, v0

    goto :goto_104

    .line 132
    :cond_151
    iget-object v0, p0, Lcom/d/a/e;->e:Ljava/util/ArrayList;

    iget v1, p0, Lcom/d/a/e;->a:I

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/d/a/g;

    invoke-virtual {v0}, Lcom/d/a/g;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    move-result v0

    goto/16 :goto_40
.end method

.method public final synthetic clone()Ljava/lang/Object;
    .registers 2

    .prologue
    .line 35
    invoke-direct {p0}, Lcom/d/a/e;->b()Lcom/d/a/e;

    move-result-object v0

    return-object v0
.end method
