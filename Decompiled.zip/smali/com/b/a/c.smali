###### Class com.b.a.c (com.b.a.c)
.class final Lcom/b/a/c;
.super Ljava/io/FilterOutputStream;
.source "SourceFile"


# instance fields
.field final synthetic a:Lcom/b/a/b;


# direct methods
.method private constructor <init>(Lcom/b/a/b;Ljava/io/OutputStream;)V
    .registers 3

    .prologue
    .line 837
    iput-object p1, p0, Lcom/b/a/c;->a:Lcom/b/a/b;

    .line 838
    invoke-direct {p0, p2}, Ljava/io/FilterOutputStream;-><init>(Ljava/io/OutputStream;)V

    .line 839
    return-void
.end method

.method synthetic constructor <init>(Lcom/b/a/b;Ljava/io/OutputStream;B)V
    .registers 4

    .prologue
    .line 836
    invoke-direct {p0, p1, p2}, Lcom/b/a/c;-><init>(Lcom/b/a/b;Ljava/io/OutputStream;)V

    return-void
.end method


# virtual methods
.method public final close()V
    .registers 2

    .prologue
    .line 859
    :try_start_0
    iget-object v0, p0, Lcom/b/a/c;->out:Ljava/io/OutputStream;

    invoke-virtual {v0}, Ljava/io/OutputStream;->close()V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_5} :catch_6

    .line 863
    :goto_5
    return-void

    .line 861
    :catch_6
    move-exception v0

    iget-object v0, p0, Lcom/b/a/c;->a:Lcom/b/a/b;

    invoke-static {v0}, Lcom/b/a/b;->c(Lcom/b/a/b;)Z

    goto :goto_5
.end method

.method public final flush()V
    .registers 2

    .prologue
    .line 867
    :try_start_0
    iget-object v0, p0, Lcom/b/a/c;->out:Ljava/io/OutputStream;

    invoke-virtual {v0}, Ljava/io/OutputStream;->flush()V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_5} :catch_6

    .line 871
    :goto_5
    return-void

    .line 869
    :catch_6
    move-exception v0

    iget-object v0, p0, Lcom/b/a/c;->a:Lcom/b/a/b;

    invoke-static {v0}, Lcom/b/a/b;->c(Lcom/b/a/b;)Z

    goto :goto_5
.end method

.method public final write(I)V
    .registers 3

    .prologue
    .line 843
    :try_start_0
    iget-object v0, p0, Lcom/b/a/c;->out:Ljava/io/OutputStream;

    invoke-virtual {v0, p1}, Ljava/io/OutputStream;->write(I)V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_5} :catch_6

    .line 847
    :goto_5
    return-void

    .line 845
    :catch_6
    move-exception v0

    iget-object v0, p0, Lcom/b/a/c;->a:Lcom/b/a/b;

    invoke-static {v0}, Lcom/b/a/b;->c(Lcom/b/a/b;)Z

    goto :goto_5
.end method

.method public final write([BII)V
    .registers 5

    .prologue
    .line 851
    :try_start_0
    iget-object v0, p0, Lcom/b/a/c;->out:Ljava/io/OutputStream;

    invoke-virtual {v0, p1, p2, p3}, Ljava/io/OutputStream;->write([BII)V
    :try_end_5
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_5} :catch_6

    .line 855
    :goto_5
    return-void

    .line 853
    :catch_6
    move-exception v0

    iget-object v0, p0, Lcom/b/a/c;->a:Lcom/b/a/b;

    invoke-static {v0}, Lcom/b/a/b;->c(Lcom/b/a/b;)Z

    goto :goto_5
.end method
