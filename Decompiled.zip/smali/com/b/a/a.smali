###### Class com.b.a.a (com.b.a.a)
.class public final Lcom/b/a/a;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/io/Closeable;


# static fields
.field static final a:Ljava/util/regex/Pattern;

.field private static final p:Ljava/io/OutputStream;


# instance fields
.field final b:Ljava/util/concurrent/ThreadPoolExecutor;

.field private final c:Ljava/io/File;

.field private final d:Ljava/io/File;

.field private final e:Ljava/io/File;

.field private final f:Ljava/io/File;

.field private final g:I

.field private h:J

.field private final i:I

.field private j:J

.field private k:Ljava/io/Writer;

.field private final l:Ljava/util/LinkedHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/LinkedHashMap",
            "<",
            "Ljava/lang/String;",
            "Lcom/b/a/d;",
            ">;"
        }
    .end annotation
.end field

.field private m:I

.field private n:J

.field private final o:Ljava/util/concurrent/Callable;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/Callable",
            "<",
            "Ljava/lang/Void;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .prologue
    .line 95
    const-string v0, "[a-z0-9_-]{1,64}"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, Lcom/b/a/a;->a:Ljava/util/regex/Pattern;

    .line 713
    new-instance v0, Lcom/b/a/a$2;

    invoke-direct {v0}, Lcom/b/a/a$2;-><init>()V

    sput-object v0, Lcom/b/a/a;->p:Ljava/io/OutputStream;

    return-void
.end method

.method private constructor <init>(Ljava/io/File;)V
    .registers 9

    .prologue
    const-wide/16 v4, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    .line 180
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 148
    iput-wide v4, p0, Lcom/b/a/a;->j:J

    .line 150
    new-instance v0, Ljava/util/LinkedHashMap;

    const/high16 v3, 0x3f400000    # 0.75f

    invoke-direct {v0, v1, v3, v2}, Ljava/util/LinkedHashMap;-><init>(IFZ)V

    iput-object v0, p0, Lcom/b/a/a;->l:Ljava/util/LinkedHashMap;

    .line 159
    iput-wide v4, p0, Lcom/b/a/a;->n:J

    .line 162
    new-instance v0, Ljava/util/concurrent/ThreadPoolExecutor;

    const-wide/16 v3, 0x3c

    sget-object v5, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    new-instance v6, Ljava/util/concurrent/LinkedBlockingQueue;

    invoke-direct {v6}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V

    invoke-direct/range {v0 .. v6}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;)V

    iput-object v0, p0, Lcom/b/a/a;->b:Ljava/util/concurrent/ThreadPoolExecutor;

    .line 164
    new-instance v0, Lcom/b/a/a$1;

    invoke-direct {v0, p0}, Lcom/b/a/a$1;-><init>(Lcom/b/a/a;)V

    iput-object v0, p0, Lcom/b/a/a;->o:Ljava/util/concurrent/Callable;

    .line 181
    iput-object p1, p0, Lcom/b/a/a;->c:Ljava/io/File;

    .line 182
    iput v2, p0, Lcom/b/a/a;->g:I

    .line 183
    new-instance v0, Ljava/io/File;

    const-string v1, "journal"

    invoke-direct {v0, p1, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    iput-object v0, p0, Lcom/b/a/a;->d:Ljava/io/File;

    .line 184
    new-instance v0, Ljava/io/File;

    const-string v1, "journal.tmp"

    invoke-direct {v0, p1, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    iput-object v0, p0, Lcom/b/a/a;->e:Ljava/io/File;

    .line 185
    new-instance v0, Ljava/io/File;

    const-string v1, "journal.bkp"

    invoke-direct {v0, p1, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    iput-object v0, p0, Lcom/b/a/a;->f:Ljava/io/File;

    .line 186
    iput v2, p0, Lcom/b/a/a;->i:I

    .line 187
    const-wide/32 v0, 0xa00000

    iput-wide v0, p0, Lcom/b/a/a;->h:J

    .line 188
    return-void
.end method

.method public static a(Ljava/io/File;)Lcom/b/a/a;
    .registers 7

    .prologue
    .line 201
    const-wide/32 v0, 0xa00000

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    if-gtz v0, :cond_11

    .line 202
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "maxSize <= 0"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 204
    :cond_11
    new-instance v0, Ljava/io/File;

    const-string v1, "journal.bkp"

    invoke-direct {v0, p0, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 210
    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_2e

    .line 211
    new-instance v1, Ljava/io/File;

    const-string v2, "journal"

    invoke-direct {v1, p0, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    .line 213
    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v2

    if-eqz v2, :cond_58

    .line 214
    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    .line 221
    :cond_2e
    :goto_2e
    new-instance v0, Lcom/b/a/a;

    invoke-direct {v0, p0}, Lcom/b/a/a;-><init>(Ljava/io/File;)V

    .line 222
    iget-object v1, v0, Lcom/b/a/a;->d:Ljava/io/File;

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v1

    if-eqz v1, :cond_8e

    .line 224
    :try_start_3b
    invoke-direct {v0}, Lcom/b/a/a;->c()V

    .line 225
    invoke-direct {v0}, Lcom/b/a/a;->d()V

    .line 226
    new-instance v1, Ljava/io/BufferedWriter;

    new-instance v2, Ljava/io/OutputStreamWriter;

    new-instance v3, Ljava/io/FileOutputStream;

    iget-object v4, v0, Lcom/b/a/a;->d:Ljava/io/File;

    const/4 v5, 0x1

    invoke-direct {v3, v4, v5}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;Z)V

    sget-object v4, Lcom/b/a/g;->a:Ljava/nio/charset/Charset;

    invoke-direct {v2, v3, v4}, Ljava/io/OutputStreamWriter;-><init>(Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V

    invoke-direct {v1, v2}, Ljava/io/BufferedWriter;-><init>(Ljava/io/Writer;)V

    iput-object v1, v0, Lcom/b/a/a;->k:Ljava/io/Writer;
    :try_end_57
    .catch Ljava/io/IOException; {:try_start_3b .. :try_end_57} :catch_5d

    .line 244
    :goto_57
    return-object v0

    .line 216
    :cond_58
    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Lcom/b/a/a;->a(Ljava/io/File;Ljava/io/File;Z)V

    goto :goto_2e

    .line 229
    :catch_5d
    move-exception v1

    .line 230
    sget-object v2, Ljava/lang/System;->out:Ljava/io/PrintStream;

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "DiskLruCache "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " is corrupt: "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v1}, Ljava/io/IOException;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, ", removing"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v2, v1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    .line 236
    invoke-virtual {v0}, Lcom/b/a/a;->close()V

    iget-object v0, v0, Lcom/b/a/a;->c:Ljava/io/File;

    invoke-static {v0}, Lcom/b/a/g;->a(Ljava/io/File;)V

    .line 241
    :cond_8e
    invoke-virtual {p0}, Ljava/io/File;->mkdirs()Z

    .line 242
    new-instance v0, Lcom/b/a/a;

    invoke-direct {v0, p0}, Lcom/b/a/a;-><init>(Ljava/io/File;)V

    .line 243
    invoke-direct {v0}, Lcom/b/a/a;->e()V

    goto :goto_57
.end method

.method static synthetic a(Lcom/b/a/a;)Ljava/io/Writer;
    .registers 2

    .prologue
    .line 88
    iget-object v0, p0, Lcom/b/a/a;->k:Ljava/io/Writer;

    return-object v0
.end method

.method static synthetic a(Lcom/b/a/a;Lcom/b/a/b;Z)V
    .registers 3

    .prologue
    .line 88
    invoke-direct {p0, p1, p2}, Lcom/b/a/a;->a(Lcom/b/a/b;Z)V

    return-void
.end method

.method private declared-synchronized a(Lcom/b/a/b;Z)V
    .registers 13

    .prologue
    const/4 v0, 0x0

    .line 509
    monitor-enter p0

    :try_start_2
    invoke-static {p1}, Lcom/b/a/b;->a(Lcom/b/a/b;)Lcom/b/a/d;

    move-result-object v2

    .line 510
    invoke-static {v2}, Lcom/b/a/d;->b(Lcom/b/a/d;)Lcom/b/a/b;

    move-result-object v1

    if-eq v1, p1, :cond_15

    .line 511
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    throw v0
    :try_end_12
    .catchall {:try_start_2 .. :try_end_12} :catchall_12

    .line 509
    :catchall_12
    move-exception v0

    monitor-exit p0

    throw v0

    .line 515
    :cond_15
    if-eqz p2, :cond_54

    :try_start_17
    invoke-static {v2}, Lcom/b/a/d;->e(Lcom/b/a/d;)Z

    move-result v1

    if-nez v1, :cond_54

    move v1, v0

    .line 516
    :goto_1e
    iget v3, p0, Lcom/b/a/a;->i:I

    if-ge v1, v3, :cond_54

    .line 517
    invoke-static {p1}, Lcom/b/a/b;->b(Lcom/b/a/b;)[Z

    move-result-object v3

    aget-boolean v3, v3, v1

    if-nez v3, :cond_42

    .line 518
    invoke-virtual {p1}, Lcom/b/a/b;->c()V

    .line 519
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Newly created entry didn\'t create value for index "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 521
    :cond_42
    invoke-virtual {v2, v1}, Lcom/b/a/d;->b(I)Ljava/io/File;

    move-result-object v3

    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result v3

    if-nez v3, :cond_51

    .line 522
    invoke-virtual {p1}, Lcom/b/a/b;->c()V
    :try_end_4f
    .catchall {:try_start_17 .. :try_end_4f} :catchall_12

    .line 561
    :cond_4f
    :goto_4f
    monitor-exit p0

    return-void

    .line 516
    :cond_51
    add-int/lit8 v1, v1, 0x1

    goto :goto_1e

    .line 528
    :cond_54
    :goto_54
    :try_start_54
    iget v1, p0, Lcom/b/a/a;->i:I

    if-ge v0, v1, :cond_89

    .line 529
    invoke-virtual {v2, v0}, Lcom/b/a/d;->b(I)Ljava/io/File;

    move-result-object v1

    .line 530
    if-eqz p2, :cond_85

    .line 531
    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v3

    if-eqz v3, :cond_82

    .line 532
    invoke-virtual {v2, v0}, Lcom/b/a/d;->a(I)Ljava/io/File;

    move-result-object v3

    .line 533
    invoke-virtual {v1, v3}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    .line 534
    invoke-static {v2}, Lcom/b/a/d;->c(Lcom/b/a/d;)[J

    move-result-object v1

    aget-wide v4, v1, v0

    .line 535
    invoke-virtual {v3}, Ljava/io/File;->length()J

    move-result-wide v6

    .line 536
    invoke-static {v2}, Lcom/b/a/d;->c(Lcom/b/a/d;)[J

    move-result-object v1

    aput-wide v6, v1, v0

    .line 537
    iget-wide v8, p0, Lcom/b/a/a;->j:J

    sub-long v3, v8, v4

    add-long/2addr v3, v6

    iput-wide v3, p0, Lcom/b/a/a;->j:J

    .line 528
    :cond_82
    :goto_82
    add-int/lit8 v0, v0, 0x1

    goto :goto_54

    .line 540
    :cond_85
    invoke-static {v1}, Lcom/b/a/a;->b(Ljava/io/File;)V

    goto :goto_82

    .line 544
    :cond_89
    iget v0, p0, Lcom/b/a/a;->m:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/b/a/a;->m:I

    .line 545
    const/4 v0, 0x0

    invoke-static {v2, v0}, Lcom/b/a/d;->a(Lcom/b/a/d;Lcom/b/a/b;)Lcom/b/a/b;

    .line 546
    invoke-static {v2}, Lcom/b/a/d;->e(Lcom/b/a/d;)Z

    move-result v0

    or-int/2addr v0, p2

    if-eqz v0, :cond_eb

    .line 547
    invoke-static {v2}, Lcom/b/a/d;->a(Lcom/b/a/d;)Z

    .line 548
    iget-object v0, p0, Lcom/b/a/a;->k:Ljava/io/Writer;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "CLEAN "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v2}, Lcom/b/a/d;->d(Lcom/b/a/d;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v2}, Lcom/b/a/d;->a()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const/16 v3, 0xa

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 549
    if-eqz p2, :cond_cf

    .line 550
    iget-wide v0, p0, Lcom/b/a/a;->n:J

    const-wide/16 v3, 0x1

    add-long/2addr v3, v0

    iput-wide v3, p0, Lcom/b/a/a;->n:J

    invoke-static {v2, v0, v1}, Lcom/b/a/d;->a(Lcom/b/a/d;J)J

    .line 556
    :cond_cf
    :goto_cf
    iget-object v0, p0, Lcom/b/a/a;->k:Ljava/io/Writer;

    invoke-virtual {v0}, Ljava/io/Writer;->flush()V

    .line 558
    iget-wide v0, p0, Lcom/b/a/a;->j:J

    iget-wide v2, p0, Lcom/b/a/a;->h:J

    cmp-long v0, v0, v2

    if-gtz v0, :cond_e2

    invoke-direct {p0}, Lcom/b/a/a;->f()Z

    move-result v0

    if-eqz v0, :cond_4f

    .line 559
    :cond_e2
    iget-object v0, p0, Lcom/b/a/a;->b:Ljava/util/concurrent/ThreadPoolExecutor;

    iget-object v1, p0, Lcom/b/a/a;->o:Ljava/util/concurrent/Callable;

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ThreadPoolExecutor;->submit(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;

    goto/16 :goto_4f

    .line 553
    :cond_eb
    iget-object v0, p0, Lcom/b/a/a;->l:Ljava/util/LinkedHashMap;

    invoke-static {v2}, Lcom/b/a/d;->d(Lcom/b/a/d;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/LinkedHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 554
    iget-object v0, p0, Lcom/b/a/a;->k:Ljava/io/Writer;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "REMOVE "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v2}, Lcom/b/a/d;->d(Lcom/b/a/d;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const/16 v2, 0xa

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/io/Writer;->write(Ljava/lang/String;)V
    :try_end_112
    .catchall {:try_start_54 .. :try_end_112} :catchall_12

    goto :goto_cf
.end method

.method private static a(Ljava/io/File;Ljava/io/File;Z)V
    .registers 4

    .prologue
    .line 391
    if-eqz p2, :cond_5

    .line 392
    invoke-static {p1}, Lcom/b/a/a;->b(Ljava/io/File;)V

    .line 394
    :cond_5
    invoke-virtual {p0, p1}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result v0

    if-nez v0, :cond_11

    .line 395
    new-instance v0, Ljava/io/IOException;

    invoke-direct {v0}, Ljava/io/IOException;-><init>()V

    throw v0

    .line 397
    :cond_11
    return-void
.end method

.method static synthetic b()Ljava/io/OutputStream;
    .registers 1

    .prologue
    .line 88
    sget-object v0, Lcom/b/a/a;->p:Ljava/io/OutputStream;

    return-object v0
.end method

.method static synthetic b(Lcom/b/a/a;)V
    .registers 1

    .prologue
    .line 88
    invoke-direct {p0}, Lcom/b/a/a;->h()V

    return-void
.end method

.method private static b(Ljava/io/File;)V
    .registers 2

    .prologue
    .line 385
    invoke-virtual {p0}, Ljava/io/File;->exists()Z

    move-result v0

    if-eqz v0, :cond_12

    invoke-virtual {p0}, Ljava/io/File;->delete()Z

    move-result v0

    if-nez v0, :cond_12

    .line 386
    new-instance v0, Ljava/io/IOException;

    invoke-direct {v0}, Ljava/io/IOException;-><init>()V

    throw v0

    .line 388
    :cond_12
    return-void
.end method

.method private c()V
    .registers 11

    .prologue
    const/4 v9, 0x5

    const/4 v0, 0x0

    const/4 v8, -0x1

    .line 248
    new-instance v3, Lcom/b/a/f;

    new-instance v1, Ljava/io/FileInputStream;

    iget-object v2, p0, Lcom/b/a/a;->d:Ljava/io/File;

    invoke-direct {v1, v2}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    sget-object v2, Lcom/b/a/g;->a:Ljava/nio/charset/Charset;

    invoke-direct {v3, v1, v2}, Lcom/b/a/f;-><init>(Ljava/io/InputStream;Ljava/nio/charset/Charset;)V

    .line 250
    :try_start_11
    invoke-virtual {v3}, Lcom/b/a/f;->a()Ljava/lang/String;

    move-result-object v1

    .line 251
    invoke-virtual {v3}, Lcom/b/a/f;->a()Ljava/lang/String;

    move-result-object v2

    .line 252
    invoke-virtual {v3}, Lcom/b/a/f;->a()Ljava/lang/String;

    move-result-object v4

    .line 253
    invoke-virtual {v3}, Lcom/b/a/f;->a()Ljava/lang/String;

    move-result-object v5

    .line 254
    invoke-virtual {v3}, Lcom/b/a/f;->a()Ljava/lang/String;

    move-result-object v6

    .line 255
    const-string v7, "libcore.io.DiskLruCache"

    invoke-virtual {v7, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_55

    const-string v7, "1"

    invoke-virtual {v7, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_55

    iget v7, p0, Lcom/b/a/a;->g:I

    invoke-static {v7}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_55

    iget v4, p0, Lcom/b/a/a;->i:I

    invoke-static {v4}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_55

    const-string v4, ""

    invoke-virtual {v4, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_93

    .line 260
    :cond_55
    new-instance v0, Ljava/io/IOException;

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v7, "unexpected journal header: ["

    invoke-direct {v4, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v4, ", "

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, ", "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "]"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_8e
    .catchall {:try_start_11 .. :try_end_8e} :catchall_8e

    .line 275
    :catchall_8e
    move-exception v0

    invoke-static {v3}, Lcom/b/a/g;->a(Ljava/io/Closeable;)V

    throw v0

    :cond_93
    move v2, v0

    .line 267
    :goto_94
    :try_start_94
    invoke-virtual {v3}, Lcom/b/a/f;->a()Ljava/lang/String;

    move-result-object v4

    const/16 v0, 0x20

    invoke-virtual {v4, v0}, Ljava/lang/String;->indexOf(I)I

    move-result v5

    if-ne v5, v8, :cond_c4

    new-instance v0, Ljava/io/IOException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v5, "unexpected journal line: "

    invoke-direct {v1, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_b5
    .catch Ljava/io/EOFException; {:try_start_94 .. :try_end_b5} :catch_b5
    .catchall {:try_start_94 .. :try_end_b5} :catchall_8e

    .line 270
    :catch_b5
    move-exception v0

    :try_start_b6
    iget-object v0, p0, Lcom/b/a/a;->l:Ljava/util/LinkedHashMap;

    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->size()I

    move-result v0

    sub-int v0, v2, v0

    iput v0, p0, Lcom/b/a/a;->m:I
    :try_end_c0
    .catchall {:try_start_b6 .. :try_end_c0} :catchall_8e

    .line 275
    invoke-static {v3}, Lcom/b/a/g;->a(Ljava/io/Closeable;)V

    .line 276
    return-void

    .line 267
    :cond_c4
    add-int/lit8 v0, v5, 0x1

    const/16 v1, 0x20

    :try_start_c8
    invoke-virtual {v4, v1, v0}, Ljava/lang/String;->indexOf(II)I

    move-result v6

    if-ne v6, v8, :cond_e6

    invoke-virtual {v4, v0}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x6

    if-ne v5, v1, :cond_15b

    const-string v1, "REMOVE"

    invoke-virtual {v4, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_15b

    iget-object v1, p0, Lcom/b/a/a;->l:Ljava/util/LinkedHashMap;

    invoke-virtual {v1, v0}, Ljava/util/LinkedHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 268
    :cond_e2
    :goto_e2
    add-int/lit8 v0, v2, 0x1

    move v2, v0

    .line 271
    goto :goto_94

    .line 267
    :cond_e6
    invoke-virtual {v4, v0, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    move-object v1, v0

    :goto_eb
    iget-object v0, p0, Lcom/b/a/a;->l:Ljava/util/LinkedHashMap;

    invoke-virtual {v0, v1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/b/a/d;

    if-nez v0, :cond_100

    new-instance v0, Lcom/b/a/d;

    const/4 v7, 0x0

    invoke-direct {v0, p0, v1, v7}, Lcom/b/a/d;-><init>(Lcom/b/a/a;Ljava/lang/String;B)V

    iget-object v7, p0, Lcom/b/a/a;->l:Ljava/util/LinkedHashMap;

    invoke-virtual {v7, v1, v0}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_100
    if-eq v6, v8, :cond_123

    if-ne v5, v9, :cond_123

    const-string v1, "CLEAN"

    invoke-virtual {v4, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_123

    add-int/lit8 v1, v6, 0x1

    invoke-virtual {v4, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v1

    const-string v4, " "

    invoke-virtual {v1, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    invoke-static {v0}, Lcom/b/a/d;->a(Lcom/b/a/d;)Z

    const/4 v4, 0x0

    invoke-static {v0, v4}, Lcom/b/a/d;->a(Lcom/b/a/d;Lcom/b/a/b;)Lcom/b/a/b;

    invoke-static {v0, v1}, Lcom/b/a/d;->a(Lcom/b/a/d;[Ljava/lang/String;)V

    goto :goto_e2

    :cond_123
    if-ne v6, v8, :cond_139

    if-ne v5, v9, :cond_139

    const-string v1, "DIRTY"

    invoke-virtual {v4, v1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_139

    new-instance v1, Lcom/b/a/b;

    const/4 v4, 0x0

    invoke-direct {v1, p0, v0, v4}, Lcom/b/a/b;-><init>(Lcom/b/a/a;Lcom/b/a/d;B)V

    invoke-static {v0, v1}, Lcom/b/a/d;->a(Lcom/b/a/d;Lcom/b/a/b;)Lcom/b/a/b;

    goto :goto_e2

    :cond_139
    if-ne v6, v8, :cond_146

    const/4 v0, 0x4

    if-ne v5, v0, :cond_146

    const-string v0, "READ"

    invoke-virtual {v4, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_e2

    :cond_146
    new-instance v0, Ljava/io/IOException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v5, "unexpected journal line: "

    invoke-direct {v1, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_15b
    .catch Ljava/io/EOFException; {:try_start_c8 .. :try_end_15b} :catch_b5
    .catchall {:try_start_c8 .. :try_end_15b} :catchall_8e

    :cond_15b
    move-object v1, v0

    goto :goto_eb
.end method

.method static synthetic c(Lcom/b/a/a;)Z
    .registers 2

    .prologue
    .line 88
    invoke-direct {p0}, Lcom/b/a/a;->f()Z

    move-result v0

    return v0
.end method

.method private declared-synchronized d(Ljava/lang/String;)Lcom/b/a/b;
    .registers 8

    .prologue
    const/4 v1, 0x0

    const-wide/16 v4, -0x1

    .line 454
    monitor-enter p0

    :try_start_4
    invoke-direct {p0}, Lcom/b/a/a;->g()V

    .line 455
    invoke-static {p1}, Lcom/b/a/a;->e(Ljava/lang/String;)V

    .line 456
    iget-object v0, p0, Lcom/b/a/a;->l:Ljava/util/LinkedHashMap;

    invoke-virtual {v0, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/b/a/d;

    .line 457
    cmp-long v2, v4, v4

    if-eqz v2, :cond_23

    if-eqz v0, :cond_20

    invoke-static {v0}, Lcom/b/a/d;->f(Lcom/b/a/d;)J
    :try_end_1b
    .catchall {:try_start_4 .. :try_end_1b} :catchall_5a

    move-result-wide v2

    cmp-long v2, v2, v4

    if-eqz v2, :cond_23

    :cond_20
    move-object v0, v1

    .line 474
    :goto_21
    monitor-exit p0

    return-object v0

    .line 461
    :cond_23
    if-nez v0, :cond_5d

    .line 462
    :try_start_25
    new-instance v0, Lcom/b/a/d;

    const/4 v1, 0x0

    invoke-direct {v0, p0, p1, v1}, Lcom/b/a/d;-><init>(Lcom/b/a/a;Ljava/lang/String;B)V

    .line 463
    iget-object v1, p0, Lcom/b/a/a;->l:Ljava/util/LinkedHashMap;

    invoke-virtual {v1, p1, v0}, Ljava/util/LinkedHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-object v1, v0

    .line 468
    :goto_31
    new-instance v0, Lcom/b/a/b;

    const/4 v2, 0x0

    invoke-direct {v0, p0, v1, v2}, Lcom/b/a/b;-><init>(Lcom/b/a/a;Lcom/b/a/d;B)V

    .line 469
    invoke-static {v1, v0}, Lcom/b/a/d;->a(Lcom/b/a/d;Lcom/b/a/b;)Lcom/b/a/b;

    .line 472
    iget-object v1, p0, Lcom/b/a/a;->k:Ljava/io/Writer;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "DIRTY "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const/16 v3, 0xa

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 473
    iget-object v1, p0, Lcom/b/a/a;->k:Ljava/io/Writer;

    invoke-virtual {v1}, Ljava/io/Writer;->flush()V
    :try_end_59
    .catchall {:try_start_25 .. :try_end_59} :catchall_5a

    goto :goto_21

    .line 454
    :catchall_5a
    move-exception v0

    monitor-exit p0

    throw v0

    .line 464
    :cond_5d
    :try_start_5d
    invoke-static {v0}, Lcom/b/a/d;->b(Lcom/b/a/d;)Lcom/b/a/b;
    :try_end_60
    .catchall {:try_start_5d .. :try_end_60} :catchall_5a

    move-result-object v2

    if-eqz v2, :cond_65

    move-object v0, v1

    .line 465
    goto :goto_21

    :cond_65
    move-object v1, v0

    goto :goto_31
.end method

.method private d()V
    .registers 9

    .prologue
    const/4 v2, 0x0

    .line 323
    iget-object v0, p0, Lcom/b/a/a;->e:Ljava/io/File;

    invoke-static {v0}, Lcom/b/a/a;->b(Ljava/io/File;)V

    .line 324
    iget-object v0, p0, Lcom/b/a/a;->l:Ljava/util/LinkedHashMap;

    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_10
    :goto_10
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_53

    .line 325
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/b/a/d;

    .line 326
    invoke-static {v0}, Lcom/b/a/d;->b(Lcom/b/a/d;)Lcom/b/a/b;

    move-result-object v1

    if-nez v1, :cond_35

    move v1, v2

    .line 327
    :goto_23
    iget v4, p0, Lcom/b/a/a;->i:I

    if-ge v1, v4, :cond_10

    .line 328
    iget-wide v4, p0, Lcom/b/a/a;->j:J

    invoke-static {v0}, Lcom/b/a/d;->c(Lcom/b/a/d;)[J

    move-result-object v6

    aget-wide v6, v6, v1

    add-long/2addr v4, v6

    iput-wide v4, p0, Lcom/b/a/a;->j:J

    .line 327
    add-int/lit8 v1, v1, 0x1

    goto :goto_23

    .line 331
    :cond_35
    const/4 v1, 0x0

    invoke-static {v0, v1}, Lcom/b/a/d;->a(Lcom/b/a/d;Lcom/b/a/b;)Lcom/b/a/b;

    move v1, v2

    .line 332
    :goto_3a
    iget v4, p0, Lcom/b/a/a;->i:I

    if-ge v1, v4, :cond_4f

    .line 333
    invoke-virtual {v0, v1}, Lcom/b/a/d;->a(I)Ljava/io/File;

    move-result-object v4

    invoke-static {v4}, Lcom/b/a/a;->b(Ljava/io/File;)V

    .line 334
    invoke-virtual {v0, v1}, Lcom/b/a/d;->b(I)Ljava/io/File;

    move-result-object v4

    invoke-static {v4}, Lcom/b/a/a;->b(Ljava/io/File;)V

    .line 332
    add-int/lit8 v1, v1, 0x1

    goto :goto_3a

    .line 336
    :cond_4f
    invoke-interface {v3}, Ljava/util/Iterator;->remove()V

    goto :goto_10

    .line 339
    :cond_53
    return-void
.end method

.method static synthetic d(Lcom/b/a/a;)V
    .registers 1

    .prologue
    .line 88
    invoke-direct {p0}, Lcom/b/a/a;->e()V

    return-void
.end method

.method static synthetic e(Lcom/b/a/a;)I
    .registers 2

    .prologue
    .line 88
    const/4 v0, 0x0

    iput v0, p0, Lcom/b/a/a;->m:I

    return v0
.end method

.method private declared-synchronized e()V
    .registers 6

    .prologue
    .line 346
    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lcom/b/a/a;->k:Ljava/io/Writer;

    if-eqz v0, :cond_a

    .line 347
    iget-object v0, p0, Lcom/b/a/a;->k:Ljava/io/Writer;

    invoke-virtual {v0}, Ljava/io/Writer;->close()V

    .line 350
    :cond_a
    new-instance v1, Ljava/io/BufferedWriter;

    new-instance v0, Ljava/io/OutputStreamWriter;

    new-instance v2, Ljava/io/FileOutputStream;

    iget-object v3, p0, Lcom/b/a/a;->e:Ljava/io/File;

    invoke-direct {v2, v3}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    sget-object v3, Lcom/b/a/g;->a:Ljava/nio/charset/Charset;

    invoke-direct {v0, v2, v3}, Ljava/io/OutputStreamWriter;-><init>(Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V

    invoke-direct {v1, v0}, Ljava/io/BufferedWriter;-><init>(Ljava/io/Writer;)V
    :try_end_1d
    .catchall {:try_start_1 .. :try_end_1d} :catchall_90

    .line 353
    :try_start_1d
    const-string v0, "libcore.io.DiskLruCache"

    invoke-virtual {v1, v0}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 354
    const-string v0, "\n"

    invoke-virtual {v1, v0}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 355
    const-string v0, "1"

    invoke-virtual {v1, v0}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 356
    const-string v0, "\n"

    invoke-virtual {v1, v0}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 357
    iget v0, p0, Lcom/b/a/a;->g:I

    invoke-static {v0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 358
    const-string v0, "\n"

    invoke-virtual {v1, v0}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 359
    iget v0, p0, Lcom/b/a/a;->i:I

    invoke-static {v0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 360
    const-string v0, "\n"

    invoke-virtual {v1, v0}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 361
    const-string v0, "\n"

    invoke-virtual {v1, v0}, Ljava/io/Writer;->write(Ljava/lang/String;)V

    .line 363
    iget-object v0, p0, Lcom/b/a/a;->l:Ljava/util/LinkedHashMap;

    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_5c
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_b8

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/b/a/d;

    .line 364
    invoke-static {v0}, Lcom/b/a/d;->b(Lcom/b/a/d;)Lcom/b/a/b;

    move-result-object v3

    if-eqz v3, :cond_93

    .line 365
    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "DIRTY "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v0}, Lcom/b/a/d;->d(Lcom/b/a/d;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const/16 v3, 0xa

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/io/Writer;->write(Ljava/lang/String;)V
    :try_end_8a
    .catchall {:try_start_1d .. :try_end_8a} :catchall_8b

    goto :goto_5c

    .line 371
    :catchall_8b
    move-exception v0

    :try_start_8c
    invoke-virtual {v1}, Ljava/io/Writer;->close()V

    throw v0
    :try_end_90
    .catchall {:try_start_8c .. :try_end_90} :catchall_90

    .line 346
    :catchall_90
    move-exception v0

    monitor-exit p0

    throw v0

    .line 367
    :cond_93
    :try_start_93
    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "CLEAN "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {v0}, Lcom/b/a/d;->d(Lcom/b/a/d;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v0}, Lcom/b/a/d;->a()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const/16 v3, 0xa

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/io/Writer;->write(Ljava/lang/String;)V
    :try_end_b7
    .catchall {:try_start_93 .. :try_end_b7} :catchall_8b

    goto :goto_5c

    .line 371
    :cond_b8
    :try_start_b8
    invoke-virtual {v1}, Ljava/io/Writer;->close()V

    .line 374
    iget-object v0, p0, Lcom/b/a/a;->d:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v0

    if-eqz v0, :cond_cb

    .line 375
    iget-object v0, p0, Lcom/b/a/a;->d:Ljava/io/File;

    iget-object v1, p0, Lcom/b/a/a;->f:Ljava/io/File;

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Lcom/b/a/a;->a(Ljava/io/File;Ljava/io/File;Z)V

    .line 377
    :cond_cb
    iget-object v0, p0, Lcom/b/a/a;->e:Ljava/io/File;

    iget-object v1, p0, Lcom/b/a/a;->d:Ljava/io/File;

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Lcom/b/a/a;->a(Ljava/io/File;Ljava/io/File;Z)V

    .line 378
    iget-object v0, p0, Lcom/b/a/a;->f:Ljava/io/File;

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    .line 380
    new-instance v0, Ljava/io/BufferedWriter;

    new-instance v1, Ljava/io/OutputStreamWriter;

    new-instance v2, Ljava/io/FileOutputStream;

    iget-object v3, p0, Lcom/b/a/a;->d:Ljava/io/File;

    const/4 v4, 0x1

    invoke-direct {v2, v3, v4}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;Z)V

    sget-object v3, Lcom/b/a/g;->a:Ljava/nio/charset/Charset;

    invoke-direct {v1, v2, v3}, Ljava/io/OutputStreamWriter;-><init>(Ljava/io/OutputStream;Ljava/nio/charset/Charset;)V

    invoke-direct {v0, v1}, Ljava/io/BufferedWriter;-><init>(Ljava/io/Writer;)V

    iput-object v0, p0, Lcom/b/a/a;->k:Ljava/io/Writer;
    :try_end_ee
    .catchall {:try_start_b8 .. :try_end_ee} :catchall_90

    .line 382
    monitor-exit p0

    return-void
.end method

.method private static e(Ljava/lang/String;)V
    .registers 4

    .prologue
    .line 658
    sget-object v0, Lcom/b/a/a;->a:Ljava/util/regex/Pattern;

    invoke-virtual {v0, p0}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v0

    .line 659
    invoke-virtual {v0}, Ljava/util/regex/Matcher;->matches()Z

    move-result v0

    if-nez v0, :cond_27

    .line 660
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "keys must match regex [a-z0-9_-]{1,64}: \""

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, "\""

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 662
    :cond_27
    return-void
.end method

.method static synthetic f(Lcom/b/a/a;)I
    .registers 2

    .prologue
    .line 88
    iget v0, p0, Lcom/b/a/a;->i:I

    return v0
.end method

.method private f()Z
    .registers 3

    .prologue
    .line 568
    iget v0, p0, Lcom/b/a/a;->m:I

    const/16 v1, 0x7d0

    if-lt v0, v1, :cond_12

    iget v0, p0, Lcom/b/a/a;->m:I

    iget-object v1, p0, Lcom/b/a/a;->l:Ljava/util/LinkedHashMap;

    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->size()I

    move-result v1

    if-lt v0, v1, :cond_12

    const/4 v0, 0x1

    :goto_11
    return v0

    :cond_12
    const/4 v0, 0x0

    goto :goto_11
.end method

.method static synthetic g(Lcom/b/a/a;)Ljava/io/File;
    .registers 2

    .prologue
    .line 88
    iget-object v0, p0, Lcom/b/a/a;->c:Ljava/io/File;

    return-object v0
.end method

.method private g()V
    .registers 3

    .prologue
    .line 613
    iget-object v0, p0, Lcom/b/a/a;->k:Ljava/io/Writer;

    if-nez v0, :cond_c

    .line 614
    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "cache is closed"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    .line 616
    :cond_c
    return-void
.end method

.method private h()V
    .registers 5

    .prologue
    .line 641
    :goto_0
    iget-wide v0, p0, Lcom/b/a/a;->j:J

    iget-wide v2, p0, Lcom/b/a/a;->h:J

    cmp-long v0, v0, v2

    if-lez v0, :cond_22

    .line 642
    iget-object v0, p0, Lcom/b/a/a;->l:Ljava/util/LinkedHashMap;

    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    .line 643
    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-virtual {p0, v0}, Lcom/b/a/a;->c(Ljava/lang/String;)Z

    goto :goto_0

    .line 645
    :cond_22
    return-void
.end method


# virtual methods
.method public final declared-synchronized a(Ljava/lang/String;)Lcom/b/a/e;
    .registers 11

    .prologue
    const/4 v3, 0x0

    const/4 v4, 0x0

    .line 405
    monitor-enter p0

    :try_start_3
    invoke-direct {p0}, Lcom/b/a/a;->g()V

    .line 406
    invoke-static {p1}, Lcom/b/a/a;->e(Ljava/lang/String;)V

    .line 407
    iget-object v1, p0, Lcom/b/a/a;->l:Ljava/util/LinkedHashMap;

    invoke-virtual {v1, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    move-object v0, v1

    check-cast v0, Lcom/b/a/d;

    move-object v2, v0
    :try_end_13
    .catchall {:try_start_3 .. :try_end_13} :catchall_89

    .line 408
    if-nez v2, :cond_18

    move-object v1, v3

    .line 442
    :goto_16
    monitor-exit p0

    return-object v1

    .line 412
    :cond_18
    :try_start_18
    invoke-static {v2}, Lcom/b/a/d;->e(Lcom/b/a/d;)Z

    move-result v1

    if-nez v1, :cond_20

    move-object v1, v3

    .line 413
    goto :goto_16

    .line 419
    :cond_20
    iget v1, p0, Lcom/b/a/a;->i:I

    new-array v6, v1, [Ljava/io/InputStream;
    :try_end_24
    .catchall {:try_start_18 .. :try_end_24} :catchall_89

    move v1, v4

    .line 421
    :goto_25
    :try_start_25
    iget v5, p0, Lcom/b/a/a;->i:I

    if-ge v1, v5, :cond_4b

    .line 422
    new-instance v5, Ljava/io/FileInputStream;

    invoke-virtual {v2, v1}, Lcom/b/a/d;->a(I)Ljava/io/File;

    move-result-object v7

    invoke-direct {v5, v7}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    aput-object v5, v6, v1
    :try_end_34
    .catch Ljava/io/FileNotFoundException; {:try_start_25 .. :try_end_34} :catch_37
    .catchall {:try_start_25 .. :try_end_34} :catchall_89

    .line 421
    add-int/lit8 v1, v1, 0x1

    goto :goto_25

    .line 426
    :catch_37
    move-exception v1

    move v1, v4

    :goto_39
    :try_start_39
    iget v2, p0, Lcom/b/a/a;->i:I

    if-ge v1, v2, :cond_49

    .line 427
    aget-object v2, v6, v1

    if-eqz v2, :cond_49

    .line 428
    aget-object v2, v6, v1

    invoke-static {v2}, Lcom/b/a/g;->a(Ljava/io/Closeable;)V

    .line 426
    add-int/lit8 v1, v1, 0x1

    goto :goto_39

    :cond_49
    move-object v1, v3

    .line 433
    goto :goto_16

    .line 436
    :cond_4b
    iget v1, p0, Lcom/b/a/a;->m:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Lcom/b/a/a;->m:I

    .line 437
    iget-object v1, p0, Lcom/b/a/a;->k:Ljava/io/Writer;

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "READ "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const/16 v4, 0xa

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/io/Writer;->append(Ljava/lang/CharSequence;)Ljava/io/Writer;

    .line 438
    invoke-direct {p0}, Lcom/b/a/a;->f()Z

    move-result v1

    if-eqz v1, :cond_78

    .line 439
    iget-object v1, p0, Lcom/b/a/a;->b:Ljava/util/concurrent/ThreadPoolExecutor;

    iget-object v3, p0, Lcom/b/a/a;->o:Ljava/util/concurrent/Callable;

    invoke-virtual {v1, v3}, Ljava/util/concurrent/ThreadPoolExecutor;->submit(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;

    .line 442
    :cond_78
    new-instance v1, Lcom/b/a/e;

    invoke-static {v2}, Lcom/b/a/d;->f(Lcom/b/a/d;)J

    move-result-wide v4

    invoke-static {v2}, Lcom/b/a/d;->c(Lcom/b/a/d;)[J

    move-result-object v7

    const/4 v8, 0x0

    move-object v2, p0

    move-object v3, p1

    invoke-direct/range {v1 .. v8}, Lcom/b/a/e;-><init>(Lcom/b/a/a;Ljava/lang/String;J[Ljava/io/InputStream;[JB)V
    :try_end_88
    .catchall {:try_start_39 .. :try_end_88} :catchall_89

    goto :goto_16

    .line 405
    :catchall_89
    move-exception v1

    monitor-exit p0

    throw v1
.end method

.method public final declared-synchronized a()V
    .registers 2

    .prologue
    .line 620
    monitor-enter p0

    :try_start_1
    invoke-direct {p0}, Lcom/b/a/a;->g()V

    .line 621
    invoke-direct {p0}, Lcom/b/a/a;->h()V

    .line 622
    iget-object v0, p0, Lcom/b/a/a;->k:Ljava/io/Writer;

    invoke-virtual {v0}, Ljava/io/Writer;->flush()V
    :try_end_c
    .catchall {:try_start_1 .. :try_end_c} :catchall_e

    .line 623
    monitor-exit p0

    return-void

    .line 620
    :catchall_e
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final b(Ljava/lang/String;)Lcom/b/a/b;
    .registers 3

    .prologue
    .line 450
    invoke-direct {p0, p1}, Lcom/b/a/a;->d(Ljava/lang/String;)Lcom/b/a/b;

    move-result-object v0

    return-object v0
.end method

.method public final declared-synchronized c(Ljava/lang/String;)Z
    .registers 8

    .prologue
    const/4 v1, 0x0

    .line 580
    monitor-enter p0

    :try_start_2
    invoke-direct {p0}, Lcom/b/a/a;->g()V

    .line 581
    invoke-static {p1}, Lcom/b/a/a;->e(Ljava/lang/String;)V

    .line 582
    iget-object v0, p0, Lcom/b/a/a;->l:Ljava/util/LinkedHashMap;

    invoke-virtual {v0, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/b/a/d;

    .line 583
    if-eqz v0, :cond_18

    invoke-static {v0}, Lcom/b/a/d;->b(Lcom/b/a/d;)Lcom/b/a/b;
    :try_end_15
    .catchall {:try_start_2 .. :try_end_15} :catchall_59

    move-result-object v2

    if-eqz v2, :cond_30

    :cond_18
    move v0, v1

    .line 604
    :goto_19
    monitor-exit p0

    return v0

    .line 592
    :cond_1b
    :try_start_1b
    iget-wide v2, p0, Lcom/b/a/a;->j:J

    invoke-static {v0}, Lcom/b/a/d;->c(Lcom/b/a/d;)[J

    move-result-object v4

    aget-wide v4, v4, v1

    sub-long/2addr v2, v4

    iput-wide v2, p0, Lcom/b/a/a;->j:J

    .line 593
    invoke-static {v0}, Lcom/b/a/d;->c(Lcom/b/a/d;)[J

    move-result-object v2

    const-wide/16 v3, 0x0

    aput-wide v3, v2, v1

    .line 587
    add-int/lit8 v1, v1, 0x1

    :cond_30
    iget v2, p0, Lcom/b/a/a;->i:I

    if-ge v1, v2, :cond_5c

    .line 588
    invoke-virtual {v0, v1}, Lcom/b/a/d;->a(I)Ljava/io/File;

    move-result-object v2

    .line 589
    invoke-virtual {v2}, Ljava/io/File;->exists()Z

    move-result v3

    if-eqz v3, :cond_1b

    invoke-virtual {v2}, Ljava/io/File;->delete()Z

    move-result v3

    if-nez v3, :cond_1b

    .line 590
    new-instance v0, Ljava/io/IOException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v3, "failed to delete "

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_59
    .catchall {:try_start_1b .. :try_end_59} :catchall_59

    .line 580
    :catchall_59
    move-exception v0

    monitor-exit p0

    throw v0

    .line 596
    :cond_5c
    :try_start_5c
    iget v0, p0, Lcom/b/a/a;->m:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/b/a/a;->m:I

    .line 597
    iget-object v0, p0, Lcom/b/a/a;->k:Ljava/io/Writer;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "REMOVE "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const/16 v2, 0xa

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/io/Writer;->append(Ljava/lang/CharSequence;)Ljava/io/Writer;

    .line 598
    iget-object v0, p0, Lcom/b/a/a;->l:Ljava/util/LinkedHashMap;

    invoke-virtual {v0, p1}, Ljava/util/LinkedHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 600
    invoke-direct {p0}, Lcom/b/a/a;->f()Z

    move-result v0

    if-eqz v0, :cond_8e

    .line 601
    iget-object v0, p0, Lcom/b/a/a;->b:Ljava/util/concurrent/ThreadPoolExecutor;

    iget-object v1, p0, Lcom/b/a/a;->o:Ljava/util/concurrent/Callable;

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ThreadPoolExecutor;->submit(Ljava/util/concurrent/Callable;)Ljava/util/concurrent/Future;
    :try_end_8e
    .catchall {:try_start_5c .. :try_end_8e} :catchall_59

    .line 604
    :cond_8e
    const/4 v0, 0x1

    goto :goto_19
.end method

.method public final declared-synchronized close()V
    .registers 4

    .prologue
    .line 627
    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lcom/b/a/a;->k:Ljava/io/Writer;
    :try_end_3
    .catchall {:try_start_1 .. :try_end_3} :catchall_30

    if-nez v0, :cond_7

    .line 638
    :goto_5
    monitor-exit p0

    return-void

    .line 630
    :cond_7
    :try_start_7
    new-instance v0, Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/b/a/a;->l:Ljava/util/LinkedHashMap;

    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_16
    :goto_16
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_33

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/b/a/d;

    .line 631
    invoke-static {v0}, Lcom/b/a/d;->b(Lcom/b/a/d;)Lcom/b/a/b;

    move-result-object v2

    if-eqz v2, :cond_16

    .line 632
    invoke-static {v0}, Lcom/b/a/d;->b(Lcom/b/a/d;)Lcom/b/a/b;

    move-result-object v0

    invoke-virtual {v0}, Lcom/b/a/b;->c()V
    :try_end_2f
    .catchall {:try_start_7 .. :try_end_2f} :catchall_30

    goto :goto_16

    .line 627
    :catchall_30
    move-exception v0

    monitor-exit p0

    throw v0

    .line 635
    :cond_33
    :try_start_33
    invoke-direct {p0}, Lcom/b/a/a;->h()V

    .line 636
    iget-object v0, p0, Lcom/b/a/a;->k:Ljava/io/Writer;

    invoke-virtual {v0}, Ljava/io/Writer;->close()V

    .line 637
    const/4 v0, 0x0

    iput-object v0, p0, Lcom/b/a/a;->k:Ljava/io/Writer;
    :try_end_3e
    .catchall {:try_start_33 .. :try_end_3e} :catchall_30

    goto :goto_5
.end method

###### Class com.b.a.a.AnonymousClass1 (com.b.a.a$1)
.class final Lcom/b/a/a$1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/concurrent/Callable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/b/a/a;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/concurrent/Callable",
        "<",
        "Ljava/lang/Void;",
        ">;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/b/a/a;


# direct methods
.method constructor <init>(Lcom/b/a/a;)V
    .registers 2

    .prologue
    .line 164
    iput-object p1, p0, Lcom/b/a/a$1;->a:Lcom/b/a/a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private a()Ljava/lang/Void;
    .registers 4

    .prologue
    const/4 v2, 0x0

    .line 166
    iget-object v1, p0, Lcom/b/a/a$1;->a:Lcom/b/a/a;

    monitor-enter v1

    .line 167
    :try_start_4
    iget-object v0, p0, Lcom/b/a/a$1;->a:Lcom/b/a/a;

    invoke-static {v0}, Lcom/b/a/a;->a(Lcom/b/a/a;)Ljava/io/Writer;

    move-result-object v0

    if-nez v0, :cond_e

    .line 168
    monitor-exit v1

    .line 176
    :goto_d
    return-object v2

    .line 170
    :cond_e
    iget-object v0, p0, Lcom/b/a/a$1;->a:Lcom/b/a/a;

    invoke-static {v0}, Lcom/b/a/a;->b(Lcom/b/a/a;)V

    .line 171
    iget-object v0, p0, Lcom/b/a/a$1;->a:Lcom/b/a/a;

    invoke-static {v0}, Lcom/b/a/a;->c(Lcom/b/a/a;)Z

    move-result v0

    if-eqz v0, :cond_25

    .line 172
    iget-object v0, p0, Lcom/b/a/a$1;->a:Lcom/b/a/a;

    invoke-static {v0}, Lcom/b/a/a;->d(Lcom/b/a/a;)V

    .line 173
    iget-object v0, p0, Lcom/b/a/a$1;->a:Lcom/b/a/a;

    invoke-static {v0}, Lcom/b/a/a;->e(Lcom/b/a/a;)I

    .line 175
    :cond_25
    monitor-exit v1
    :try_end_26
    .catchall {:try_start_4 .. :try_end_26} :catchall_27

    goto :goto_d

    :catchall_27
    move-exception v0

    monitor-exit v1

    throw v0
.end method


# virtual methods
.method public final synthetic call()Ljava/lang/Object;
    .registers 2

    .prologue
    .line 164
    invoke-direct {p0}, Lcom/b/a/a$1;->a()Ljava/lang/Void;

    move-result-object v0

    return-object v0
.end method

###### Class com.b.a.a.AnonymousClass2 (com.b.a.a$2)
.class final Lcom/b/a/a$2;
.super Ljava/io/OutputStream;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/b/a/a;
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 713
    invoke-direct {p0}, Ljava/io/OutputStream;-><init>()V

    return-void
.end method


# virtual methods
.method public final write(I)V
    .registers 2

    .prologue
    .line 717
    return-void
.end method
