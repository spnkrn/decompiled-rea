###### Class com.devsmart.android.ui.HorizontalListView (com.devsmart.android.ui.HorizontalListView)
.class public Lcom/devsmart/android/ui/HorizontalListView;
.super Landroid/widget/AdapterView;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/widget/AdapterView",
        "<",
        "Landroid/widget/ListAdapter;",
        ">;"
    }
.end annotation


# instance fields
.field public a:Z

.field protected b:Landroid/widget/ListAdapter;

.field protected c:I

.field protected d:I

.field protected e:Landroid/widget/Scroller;

.field f:Z

.field private g:I

.field private h:I

.field private i:I

.field private j:I

.field private k:Landroid/view/GestureDetector;

.field private l:Ljava/util/Queue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Queue",
            "<",
            "Landroid/view/View;",
            ">;"
        }
    .end annotation
.end field

.field private m:Z

.field private n:I

.field private o:F

.field private p:F

.field private q:F

.field private r:I

.field private s:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList",
            "<",
            "Landroid/widget/ListView$FixedViewInfo;",
            ">;"
        }
    .end annotation
.end field

.field private t:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList",
            "<",
            "Landroid/widget/ListView$FixedViewInfo;",
            ">;"
        }
    .end annotation
.end field

.field private u:Landroid/widget/ListView;

.field private v:Z

.field private w:Landroid/database/DataSetObserver;

.field private x:Ljava/lang/Runnable;

.field private y:Landroid/view/GestureDetector$OnGestureListener;


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 5

    .prologue
    const/4 v1, 0x0

    .line 82
    invoke-direct {p0, p1, p2}, Landroid/widget/AdapterView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    .line 58
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->a:Z

    .line 60
    const/4 v0, -0x1

    iput v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->g:I

    .line 61
    iput v1, p0, Lcom/devsmart/android/ui/HorizontalListView;->h:I

    .line 64
    const v0, 0x7fffffff

    iput v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->i:I

    .line 65
    iput v1, p0, Lcom/devsmart/android/ui/HorizontalListView;->j:I

    .line 68
    new-instance v0, Ljava/util/LinkedList;

    invoke-direct {v0}, Ljava/util/LinkedList;-><init>()V

    iput-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->l:Ljava/util/Queue;

    .line 69
    iput-boolean v1, p0, Lcom/devsmart/android/ui/HorizontalListView;->m:Z

    .line 70
    iput v1, p0, Lcom/devsmart/android/ui/HorizontalListView;->n:I

    .line 75
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->s:Ljava/util/ArrayList;

    .line 76
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->t:Ljava/util/ArrayList;

    .line 99
    new-instance v0, Lcom/devsmart/android/ui/HorizontalListView$1;

    invoke-direct {v0, p0}, Lcom/devsmart/android/ui/HorizontalListView$1;-><init>(Lcom/devsmart/android/ui/HorizontalListView;)V

    iput-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->w:Landroid/database/DataSetObserver;

    .line 373
    new-instance v0, Lcom/devsmart/android/ui/HorizontalListView$2;

    invoke-direct {v0, p0}, Lcom/devsmart/android/ui/HorizontalListView$2;-><init>(Lcom/devsmart/android/ui/HorizontalListView;)V

    iput-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->x:Ljava/lang/Runnable;

    .line 581
    new-instance v0, Lcom/devsmart/android/ui/HorizontalListView$3;

    invoke-direct {v0, p0}, Lcom/devsmart/android/ui/HorizontalListView$3;-><init>(Lcom/devsmart/android/ui/HorizontalListView;)V

    iput-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->y:Landroid/view/GestureDetector$OnGestureListener;

    .line 83
    invoke-direct {p0}, Lcom/devsmart/android/ui/HorizontalListView;->c()V

    .line 84
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v0

    iget v0, v0, Landroid/util/DisplayMetrics;->density:F

    const/high16 v1, 0x41200000    # 10.0f

    mul-float/2addr v0, v1

    iput v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->q:F

    .line 85
    return-void
.end method

.method private a(Landroid/view/View;I)V
    .registers 6

    .prologue
    const/4 v1, -0x1

    const/high16 v2, -0x80000000

    .line 320
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    .line 321
    if-nez v0, :cond_e

    .line 322
    new-instance v0, Landroid/view/ViewGroup$LayoutParams;

    invoke-direct {v0, v1, v1}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    .line 325
    :cond_e
    const/4 v1, 0x1

    invoke-virtual {p0, p1, p2, v0, v1}, Lcom/devsmart/android/ui/HorizontalListView;->addViewInLayout(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;Z)Z

    .line 326
    invoke-virtual {p0}, Lcom/devsmart/android/ui/HorizontalListView;->getWidth()I

    move-result v0

    invoke-static {v0, v2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v0

    .line 327
    invoke-virtual {p0}, Lcom/devsmart/android/ui/HorizontalListView;->getHeight()I

    move-result v1

    invoke-static {v1, v2}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    move-result v1

    .line 326
    invoke-virtual {p1, v0, v1}, Landroid/view/View;->measure(II)V

    .line 328
    return-void
.end method

.method static synthetic a(Lcom/devsmart/android/ui/HorizontalListView;)Z
    .registers 2

    .prologue
    .line 51
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->m:Z

    return v0
.end method

.method private b(Landroid/view/View;I)Landroid/view/View;
    .registers 8

    .prologue
    const/4 v1, 0x0

    .line 398
    iget v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->r:I

    div-int/lit8 v0, v0, 0x2

    .line 399
    iget v2, p0, Lcom/devsmart/android/ui/HorizontalListView;->r:I

    div-int/lit8 v2, v2, 0x2

    .line 400
    if-nez p2, :cond_c

    move v0, v1

    .line 402
    :cond_c
    add-int/lit8 v3, p2, 0x1

    iget-object v4, p0, Lcom/devsmart/android/ui/HorizontalListView;->b:Landroid/widget/ListAdapter;

    invoke-interface {v4}, Landroid/widget/ListAdapter;->getCount()I

    move-result v4

    if-lt v3, v4, :cond_22

    .line 405
    :goto_16
    invoke-virtual {p1}, Landroid/view/View;->getPaddingTop()I

    move-result v2

    invoke-virtual {p1}, Landroid/view/View;->getPaddingBottom()I

    move-result v3

    invoke-virtual {p1, v0, v2, v1, v3}, Landroid/view/View;->setPadding(IIII)V

    .line 406
    return-object p1

    :cond_22
    move v1, v2

    goto :goto_16
.end method

.method static synthetic b(Lcom/devsmart/android/ui/HorizontalListView;)V
    .registers 1

    .prologue
    .line 51
    invoke-direct {p0}, Lcom/devsmart/android/ui/HorizontalListView;->d()V

    return-void
.end method

.method static synthetic c(Lcom/devsmart/android/ui/HorizontalListView;)I
    .registers 2

    .prologue
    .line 51
    iget v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->g:I

    return v0
.end method

.method private declared-synchronized c()V
    .registers 4

    .prologue
    .line 88
    monitor-enter p0

    const/4 v0, -0x1

    :try_start_2
    iput v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->g:I

    .line 89
    const/4 v0, 0x0

    iput v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->h:I

    .line 90
    const/4 v0, 0x0

    iput v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->j:I

    .line 91
    const/4 v0, 0x0

    iput v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->c:I

    .line 92
    const/4 v0, 0x0

    iput v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->d:I

    .line 93
    const v0, 0x7fffffff

    iput v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->i:I

    .line 94
    new-instance v0, Landroid/widget/Scroller;

    invoke-virtual {p0}, Lcom/devsmart/android/ui/HorizontalListView;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/Scroller;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->e:Landroid/widget/Scroller;

    .line 95
    new-instance v0, Landroid/view/GestureDetector;

    invoke-virtual {p0}, Lcom/devsmart/android/ui/HorizontalListView;->getContext()Landroid/content/Context;

    move-result-object v1

    iget-object v2, p0, Lcom/devsmart/android/ui/HorizontalListView;->y:Landroid/view/GestureDetector$OnGestureListener;

    invoke-direct {v0, v1, v2}, Landroid/view/GestureDetector;-><init>(Landroid/content/Context;Landroid/view/GestureDetector$OnGestureListener;)V

    iput-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->k:Landroid/view/GestureDetector;

    .line 96
    new-instance v0, Landroid/widget/ListView;

    invoke-virtual {p0}, Lcom/devsmart/android/ui/HorizontalListView;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/widget/ListView;-><init>(Landroid/content/Context;)V

    iput-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->u:Landroid/widget/ListView;
    :try_end_38
    .catchall {:try_start_2 .. :try_end_38} :catchall_3a

    .line 97
    monitor-exit p0

    return-void

    .line 88
    :catchall_3a
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method private declared-synchronized d()V
    .registers 2

    .prologue
    .line 160
    monitor-enter p0

    :try_start_1
    invoke-direct {p0}, Lcom/devsmart/android/ui/HorizontalListView;->c()V

    .line 161
    invoke-virtual {p0}, Lcom/devsmart/android/ui/HorizontalListView;->removeAllViewsInLayout()V

    .line 162
    invoke-virtual {p0}, Lcom/devsmart/android/ui/HorizontalListView;->requestLayout()V
    :try_end_a
    .catchall {:try_start_1 .. :try_end_a} :catchall_c

    .line 163
    monitor-exit p0

    return-void

    .line 160
    :catchall_c
    move-exception v0

    monitor-exit p0

    throw v0
.end method


# virtual methods
.method public final a()Landroid/widget/ListAdapter;
    .registers 2

    .prologue
    .line 121
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->b:Landroid/widget/ListAdapter;

    return-object v0
.end method

.method public final a(Landroid/widget/ListAdapter;)V
    .registers 4

    .prologue
    .line 132
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->b:Landroid/widget/ListAdapter;

    if-eqz v0, :cond_b

    .line 133
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->b:Landroid/widget/ListAdapter;

    iget-object v1, p0, Lcom/devsmart/android/ui/HorizontalListView;->w:Landroid/database/DataSetObserver;

    invoke-interface {v0, v1}, Landroid/widget/ListAdapter;->unregisterDataSetObserver(Landroid/database/DataSetObserver;)V

    .line 135
    :cond_b
    iput-object p1, p0, Lcom/devsmart/android/ui/HorizontalListView;->b:Landroid/widget/ListAdapter;

    .line 136
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->b:Landroid/widget/ListAdapter;

    iget-object v1, p0, Lcom/devsmart/android/ui/HorizontalListView;->w:Landroid/database/DataSetObserver;

    invoke-interface {v0, v1}, Landroid/widget/ListAdapter;->registerDataSetObserver(Landroid/database/DataSetObserver;)V

    .line 137
    invoke-direct {p0}, Lcom/devsmart/android/ui/HorizontalListView;->d()V

    .line 138
    return-void
.end method

.method protected final a(F)Z
    .registers 11

    .prologue
    .line 567
    monitor-enter p0

    .line 568
    :try_start_1
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->e:Landroid/widget/Scroller;

    iget v1, p0, Lcom/devsmart/android/ui/HorizontalListView;->d:I

    const/4 v2, 0x0

    neg-float v3, p1

    float-to-int v3, v3

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget v6, p0, Lcom/devsmart/android/ui/HorizontalListView;->i:I

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual/range {v0 .. v8}, Landroid/widget/Scroller;->fling(IIIIIIII)V

    .line 569
    monitor-exit p0
    :try_end_12
    .catchall {:try_start_1 .. :try_end_12} :catchall_17

    .line 570
    invoke-virtual {p0}, Lcom/devsmart/android/ui/HorizontalListView;->requestLayout()V

    .line 572
    const/4 v0, 0x1

    return v0

    .line 569
    :catchall_17
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method protected final b()Z
    .registers 3

    .prologue
    const/4 v1, 0x1

    .line 576
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->e:Landroid/widget/Scroller;

    invoke-virtual {v0}, Landroid/widget/Scroller;->isFinished()Z

    move-result v0

    iput-boolean v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->f:Z

    .line 577
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->e:Landroid/widget/Scroller;

    invoke-virtual {v0, v1}, Landroid/widget/Scroller;->forceFinished(Z)V

    .line 578
    return v1
.end method

.method public bridge synthetic getAdapter()Landroid/widget/Adapter;
    .registers 2

    .prologue
    .line 51
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->b:Landroid/widget/ListAdapter;

    return-object v0
.end method

.method public getSelectedView()Landroid/view/View;
    .registers 2

    .prologue
    .line 127
    const/4 v0, 0x0

    return-object v0
.end method

.method public onInterceptTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 6

    .prologue
    const/4 v1, 0x1

    const/4 v0, 0x0

    .line 484
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v2

    .line 485
    invoke-virtual {p0}, Lcom/devsmart/android/ui/HorizontalListView;->getParent()Landroid/view/ViewParent;

    move-result-object v3

    .line 487
    if-nez v3, :cond_d

    .line 499
    :goto_c
    return v0

    .line 490
    :cond_d
    packed-switch v2, :pswitch_data_24

    goto :goto_c

    .line 492
    :pswitch_11
    invoke-interface {v3, v1}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 493
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v2

    iput v2, p0, Lcom/devsmart/android/ui/HorizontalListView;->o:F

    .line 494
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v2

    iput v2, p0, Lcom/devsmart/android/ui/HorizontalListView;->p:F

    .line 495
    iput v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->n:I

    move v0, v1

    .line 496
    goto :goto_c

    .line 490
    :pswitch_data_24
    .packed-switch 0x0
        :pswitch_11
    .end packed-switch
.end method

.method protected declared-synchronized onLayout(ZIIII)V
    .registers 13

    .prologue
    const/4 v5, -0x2

    const/4 v1, 0x0

    .line 332
    monitor-enter p0

    :try_start_3
    invoke-super/range {p0 .. p5}, Landroid/widget/AdapterView;->onLayout(ZIIII)V

    .line 334
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->b:Landroid/widget/ListAdapter;
    :try_end_8
    .catchall {:try_start_3 .. :try_end_8} :catchall_b9

    if-nez v0, :cond_c

    .line 371
    :cond_a
    :goto_a
    monitor-exit p0

    return-void

    .line 338
    :cond_c
    :try_start_c
    iget-boolean v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->m:Z

    if-eqz v0, :cond_1d

    .line 339
    iget v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->c:I

    .line 340
    invoke-direct {p0}, Lcom/devsmart/android/ui/HorizontalListView;->c()V

    .line 341
    invoke-virtual {p0}, Lcom/devsmart/android/ui/HorizontalListView;->removeAllViewsInLayout()V

    .line 342
    iput v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->d:I

    .line 343
    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->m:Z

    .line 346
    :cond_1d
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->e:Landroid/widget/Scroller;

    invoke-virtual {v0}, Landroid/widget/Scroller;->computeScrollOffset()Z

    move-result v0

    if-eqz v0, :cond_2d

    .line 347
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->e:Landroid/widget/Scroller;

    invoke-virtual {v0}, Landroid/widget/Scroller;->getCurrX()I

    move-result v0

    iput v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->d:I

    .line 350
    :cond_2d
    iget v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->d:I

    if-gtz v0, :cond_3a

    .line 351
    const/4 v0, 0x0

    iput v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->d:I

    .line 352
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->e:Landroid/widget/Scroller;

    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Landroid/widget/Scroller;->forceFinished(Z)V

    .line 354
    :cond_3a
    iget v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->d:I

    iget v2, p0, Lcom/devsmart/android/ui/HorizontalListView;->i:I

    if-lt v0, v2, :cond_4a

    .line 355
    iget v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->i:I

    iput v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->d:I

    .line 356
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->e:Landroid/widget/Scroller;

    const/4 v2, 0x1

    invoke-virtual {v0, v2}, Landroid/widget/Scroller;->forceFinished(Z)V

    .line 359
    :cond_4a
    iget v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->c:I

    iget v2, p0, Lcom/devsmart/android/ui/HorizontalListView;->d:I

    sub-int v3, v0, v2

    .line 361
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/devsmart/android/ui/HorizontalListView;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    :goto_55
    if-eqz v0, :cond_87

    invoke-virtual {v0}, Landroid/view/View;->getRight()I

    move-result v2

    add-int/2addr v2, v3

    if-gtz v2, :cond_87

    iget v2, p0, Lcom/devsmart/android/ui/HorizontalListView;->j:I

    invoke-virtual {v0}, Landroid/view/View;->getMeasuredWidth()I

    move-result v4

    add-int/2addr v2, v4

    iput v2, p0, Lcom/devsmart/android/ui/HorizontalListView;->j:I

    iget-object v2, p0, Lcom/devsmart/android/ui/HorizontalListView;->b:Landroid/widget/ListAdapter;

    iget v4, p0, Lcom/devsmart/android/ui/HorizontalListView;->g:I

    add-int/lit8 v4, v4, 0x1

    invoke-interface {v2, v4}, Landroid/widget/ListAdapter;->getItemViewType(I)I

    move-result v2

    if-eq v2, v5, :cond_78

    iget-object v2, p0, Lcom/devsmart/android/ui/HorizontalListView;->l:Ljava/util/Queue;

    invoke-interface {v2, v0}, Ljava/util/Queue;->offer(Ljava/lang/Object;)Z

    :cond_78
    invoke-virtual {p0, v0}, Lcom/devsmart/android/ui/HorizontalListView;->removeViewInLayout(Landroid/view/View;)V

    iget v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->g:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->g:I

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/devsmart/android/ui/HorizontalListView;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    goto :goto_55

    :cond_87
    :goto_87
    invoke-virtual {p0}, Lcom/devsmart/android/ui/HorizontalListView;->getChildCount()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {p0, v0}, Lcom/devsmart/android/ui/HorizontalListView;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_bc

    invoke-virtual {v0}, Landroid/view/View;->getLeft()I

    move-result v2

    add-int/2addr v2, v3

    invoke-virtual {p0}, Lcom/devsmart/android/ui/HorizontalListView;->getWidth()I

    move-result v4

    if-lt v2, v4, :cond_bc

    iget-object v2, p0, Lcom/devsmart/android/ui/HorizontalListView;->b:Landroid/widget/ListAdapter;

    iget v4, p0, Lcom/devsmart/android/ui/HorizontalListView;->h:I

    add-int/lit8 v4, v4, -0x1

    invoke-interface {v2, v4}, Landroid/widget/ListAdapter;->getItemViewType(I)I

    move-result v2

    if-eq v2, v5, :cond_af

    iget-object v2, p0, Lcom/devsmart/android/ui/HorizontalListView;->l:Ljava/util/Queue;

    invoke-interface {v2, v0}, Ljava/util/Queue;->offer(Ljava/lang/Object;)Z

    :cond_af
    invoke-virtual {p0, v0}, Lcom/devsmart/android/ui/HorizontalListView;->removeViewInLayout(Landroid/view/View;)V

    iget v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->h:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->h:I
    :try_end_b8
    .catchall {:try_start_c .. :try_end_b8} :catchall_b9

    goto :goto_87

    .line 332
    :catchall_b9
    move-exception v0

    monitor-exit p0

    throw v0

    .line 362
    :cond_bc
    :try_start_bc
    invoke-virtual {p0}, Lcom/devsmart/android/ui/HorizontalListView;->getChildCount()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {p0, v0}, Lcom/devsmart/android/ui/HorizontalListView;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_1a6

    invoke-virtual {v0}, Landroid/view/View;->getRight()I

    move-result v0

    :goto_cc
    move v2, v0

    :goto_cd
    add-int v0, v2, v3

    invoke-virtual {p0}, Lcom/devsmart/android/ui/HorizontalListView;->getWidth()I

    move-result v4

    if-ge v0, v4, :cond_123

    iget v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->h:I

    iget-object v4, p0, Lcom/devsmart/android/ui/HorizontalListView;->b:Landroid/widget/ListAdapter;

    invoke-interface {v4}, Landroid/widget/ListAdapter;->getCount()I

    move-result v4

    if-ge v0, v4, :cond_123

    iget-object v4, p0, Lcom/devsmart/android/ui/HorizontalListView;->b:Landroid/widget/ListAdapter;

    iget v5, p0, Lcom/devsmart/android/ui/HorizontalListView;->h:I

    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->l:Ljava/util/Queue;

    invoke-interface {v0}, Ljava/util/Queue;->poll()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-interface {v4, v5, v0, p0}, Landroid/widget/ListAdapter;->getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    iget v4, p0, Lcom/devsmart/android/ui/HorizontalListView;->h:I

    invoke-direct {p0, v0, v4}, Lcom/devsmart/android/ui/HorizontalListView;->b(Landroid/view/View;I)Landroid/view/View;

    move-result-object v0

    const/4 v4, -0x1

    invoke-direct {p0, v0, v4}, Lcom/devsmart/android/ui/HorizontalListView;->a(Landroid/view/View;I)V

    invoke-virtual {v0}, Landroid/view/View;->getMeasuredWidth()I

    move-result v0

    add-int/2addr v0, v2

    iget v2, p0, Lcom/devsmart/android/ui/HorizontalListView;->h:I

    iget-object v4, p0, Lcom/devsmart/android/ui/HorizontalListView;->b:Landroid/widget/ListAdapter;

    invoke-interface {v4}, Landroid/widget/ListAdapter;->getCount()I

    move-result v4

    add-int/lit8 v4, v4, -0x1

    if-ne v2, v4, :cond_114

    iget v2, p0, Lcom/devsmart/android/ui/HorizontalListView;->c:I

    add-int/2addr v2, v0

    invoke-virtual {p0}, Lcom/devsmart/android/ui/HorizontalListView;->getWidth()I

    move-result v4

    sub-int/2addr v2, v4

    iput v2, p0, Lcom/devsmart/android/ui/HorizontalListView;->i:I

    :cond_114
    iget v2, p0, Lcom/devsmart/android/ui/HorizontalListView;->i:I

    if-gez v2, :cond_11b

    const/4 v2, 0x0

    iput v2, p0, Lcom/devsmart/android/ui/HorizontalListView;->i:I

    :cond_11b
    iget v2, p0, Lcom/devsmart/android/ui/HorizontalListView;->h:I

    add-int/lit8 v2, v2, 0x1

    iput v2, p0, Lcom/devsmart/android/ui/HorizontalListView;->h:I

    move v2, v0

    goto :goto_cd

    :cond_123
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcom/devsmart/android/ui/HorizontalListView;->getChildAt(I)Landroid/view/View;

    move-result-object v0

    if-eqz v0, :cond_1a4

    invoke-virtual {v0}, Landroid/view/View;->getLeft()I

    move-result v0

    :goto_12e
    move v2, v0

    :goto_12f
    add-int v0, v2, v3

    if-lez v0, :cond_168

    iget v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->g:I

    if-ltz v0, :cond_168

    iget-object v4, p0, Lcom/devsmart/android/ui/HorizontalListView;->b:Landroid/widget/ListAdapter;

    iget v5, p0, Lcom/devsmart/android/ui/HorizontalListView;->g:I

    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->l:Ljava/util/Queue;

    invoke-interface {v0}, Ljava/util/Queue;->poll()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/View;

    invoke-interface {v4, v5, v0, p0}, Landroid/widget/ListAdapter;->getView(ILandroid/view/View;Landroid/view/ViewGroup;)Landroid/view/View;

    move-result-object v0

    iget v4, p0, Lcom/devsmart/android/ui/HorizontalListView;->g:I

    invoke-direct {p0, v0, v4}, Lcom/devsmart/android/ui/HorizontalListView;->b(Landroid/view/View;I)Landroid/view/View;

    move-result-object v4

    const/4 v0, 0x0

    invoke-direct {p0, v4, v0}, Lcom/devsmart/android/ui/HorizontalListView;->a(Landroid/view/View;I)V

    invoke-virtual {v4}, Landroid/view/View;->getMeasuredWidth()I

    move-result v0

    sub-int v0, v2, v0

    iget v2, p0, Lcom/devsmart/android/ui/HorizontalListView;->g:I

    add-int/lit8 v2, v2, -0x1

    iput v2, p0, Lcom/devsmart/android/ui/HorizontalListView;->g:I

    iget v2, p0, Lcom/devsmart/android/ui/HorizontalListView;->j:I

    invoke-virtual {v4}, Landroid/view/View;->getMeasuredWidth()I

    move-result v4

    sub-int/2addr v2, v4

    iput v2, p0, Lcom/devsmart/android/ui/HorizontalListView;->j:I

    move v2, v0

    goto :goto_12f

    .line 363
    :cond_168
    invoke-virtual {p0}, Lcom/devsmart/android/ui/HorizontalListView;->getChildCount()I

    move-result v0

    if-lez v0, :cond_191

    iget v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->j:I

    add-int/2addr v0, v3

    iput v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->j:I

    iget v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->j:I

    :goto_175
    invoke-virtual {p0}, Lcom/devsmart/android/ui/HorizontalListView;->getChildCount()I

    move-result v2

    if-ge v1, v2, :cond_191

    invoke-virtual {p0, v1}, Lcom/devsmart/android/ui/HorizontalListView;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    invoke-virtual {v2}, Landroid/view/View;->getMeasuredWidth()I

    move-result v3

    const/4 v4, 0x0

    add-int v5, v0, v3

    invoke-virtual {v2}, Landroid/view/View;->getMeasuredHeight()I

    move-result v6

    invoke-virtual {v2, v0, v4, v5, v6}, Landroid/view/View;->layout(IIII)V

    add-int/2addr v0, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_175

    .line 365
    :cond_191
    iget v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->d:I

    iput v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->c:I

    .line 367
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->e:Landroid/widget/Scroller;

    invoke-virtual {v0}, Landroid/widget/Scroller;->isFinished()Z

    move-result v0

    if-nez v0, :cond_a

    .line 368
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->x:Ljava/lang/Runnable;

    invoke-virtual {p0, v0}, Lcom/devsmart/android/ui/HorizontalListView;->post(Ljava/lang/Runnable;)Z
    :try_end_1a2
    .catchall {:try_start_bc .. :try_end_1a2} :catchall_b9

    goto/16 :goto_a

    :cond_1a4
    move v0, v1

    goto :goto_12e

    :cond_1a6
    move v0, v1

    goto/16 :goto_cc
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 8

    .prologue
    const/4 v5, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x0

    .line 504
    .line 505
    invoke-virtual {p0}, Lcom/devsmart/android/ui/HorizontalListView;->getParent()Landroid/view/ViewParent;

    move-result-object v2

    .line 507
    if-nez v2, :cond_a

    .line 562
    :cond_9
    :goto_9
    return v0

    .line 510
    :cond_a
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v3

    packed-switch v3, :pswitch_data_7c

    :cond_11
    move v1, v0

    .line 557
    :cond_12
    :goto_12
    :pswitch_12
    if-eqz v1, :cond_9

    .line 558
    invoke-super {p0, p1}, Landroid/widget/AdapterView;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result v0

    .line 559
    iget-object v1, p0, Lcom/devsmart/android/ui/HorizontalListView;->k:Landroid/view/GestureDetector;

    invoke-virtual {v1, p1}, Landroid/view/GestureDetector;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result v1

    or-int/2addr v0, v1

    goto :goto_9

    .line 516
    :pswitch_20
    iget-boolean v3, p0, Lcom/devsmart/android/ui/HorizontalListView;->v:Z

    if-eqz v3, :cond_41

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v3

    iget v4, p0, Lcom/devsmart/android/ui/HorizontalListView;->p:F

    sub-float/2addr v3, v4

    invoke-static {v3}, Ljava/lang/Math;->abs(F)F

    move-result v3

    invoke-virtual {p0}, Lcom/devsmart/android/ui/HorizontalListView;->getHeight()I

    move-result v4

    div-int/lit8 v4, v4, 0x4

    int-to-float v4, v4

    cmpl-float v3, v3, v4

    if-lez v3, :cond_41

    .line 517
    invoke-interface {v2, v0}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 519
    iput v0, p0, Lcom/devsmart/android/ui/HorizontalListView;->n:I

    move v1, v0

    .line 520
    goto :goto_12

    .line 523
    :cond_41
    iget v3, p0, Lcom/devsmart/android/ui/HorizontalListView;->n:I

    if-ne v3, v5, :cond_47

    move v1, v0

    .line 525
    goto :goto_12

    .line 528
    :cond_47
    iget v3, p0, Lcom/devsmart/android/ui/HorizontalListView;->n:I

    if-eq v3, v1, :cond_12

    .line 533
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v3

    iget v4, p0, Lcom/devsmart/android/ui/HorizontalListView;->o:F

    sub-float/2addr v3, v4

    invoke-static {v3}, Ljava/lang/Math;->abs(F)F

    move-result v3

    iget v4, p0, Lcom/devsmart/android/ui/HorizontalListView;->q:F

    cmpl-float v3, v3, v4

    if-lez v3, :cond_5f

    .line 534
    iput v1, p0, Lcom/devsmart/android/ui/HorizontalListView;->n:I

    goto :goto_12

    .line 539
    :cond_5f
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    iget v3, p0, Lcom/devsmart/android/ui/HorizontalListView;->p:F

    sub-float/2addr v1, v3

    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    move-result v1

    iget v3, p0, Lcom/devsmart/android/ui/HorizontalListView;->q:F

    cmpl-float v1, v1, v3

    if-lez v1, :cond_11

    .line 540
    invoke-interface {v2, v0}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 541
    iput v5, p0, Lcom/devsmart/android/ui/HorizontalListView;->n:I

    move v1, v0

    .line 543
    goto :goto_12

    .line 549
    :pswitch_77
    invoke-interface {v2, v0}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    goto :goto_12

    .line 510
    nop

    :pswitch_data_7c
    .packed-switch 0x0
        :pswitch_12
        :pswitch_77
        :pswitch_20
        :pswitch_77
    .end packed-switch
.end method

.method public synthetic setAdapter(Landroid/widget/Adapter;)V
    .registers 2

    .prologue
    .line 51
    check-cast p1, Landroid/widget/ListAdapter;

    invoke-virtual {p0, p1}, Lcom/devsmart/android/ui/HorizontalListView;->a(Landroid/widget/ListAdapter;)V

    return-void
.end method

.method public setSelection(I)V
    .registers 2

    .prologue
    .line 168
    return-void
.end method

###### Class com.devsmart.android.ui.HorizontalListView.AnonymousClass1 (com.devsmart.android.ui.HorizontalListView$1)
.class final Lcom/devsmart/android/ui/HorizontalListView$1;
.super Landroid/database/DataSetObserver;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/devsmart/android/ui/HorizontalListView;
.end annotation


# instance fields
.field final synthetic a:Lcom/devsmart/android/ui/HorizontalListView;


# direct methods
.method constructor <init>(Lcom/devsmart/android/ui/HorizontalListView;)V
    .registers 2

    .prologue
    .line 99
    iput-object p1, p0, Lcom/devsmart/android/ui/HorizontalListView$1;->a:Lcom/devsmart/android/ui/HorizontalListView;

    invoke-direct {p0}, Landroid/database/DataSetObserver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onChanged()V
    .registers 3

    .prologue
    .line 103
    iget-object v1, p0, Lcom/devsmart/android/ui/HorizontalListView$1;->a:Lcom/devsmart/android/ui/HorizontalListView;

    monitor-enter v1

    .line 104
    :try_start_3
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView$1;->a:Lcom/devsmart/android/ui/HorizontalListView;

    invoke-static {v0}, Lcom/devsmart/android/ui/HorizontalListView;->a(Lcom/devsmart/android/ui/HorizontalListView;)Z

    .line 105
    monitor-exit v1
    :try_end_9
    .catchall {:try_start_3 .. :try_end_9} :catchall_14

    .line 106
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView$1;->a:Lcom/devsmart/android/ui/HorizontalListView;

    invoke-virtual {v0}, Lcom/devsmart/android/ui/HorizontalListView;->invalidate()V

    .line 107
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView$1;->a:Lcom/devsmart/android/ui/HorizontalListView;

    invoke-virtual {v0}, Lcom/devsmart/android/ui/HorizontalListView;->requestLayout()V

    .line 108
    return-void

    .line 105
    :catchall_14
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method public final onInvalidated()V
    .registers 2

    .prologue
    .line 112
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView$1;->a:Lcom/devsmart/android/ui/HorizontalListView;

    invoke-static {v0}, Lcom/devsmart/android/ui/HorizontalListView;->b(Lcom/devsmart/android/ui/HorizontalListView;)V

    .line 113
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView$1;->a:Lcom/devsmart/android/ui/HorizontalListView;

    invoke-virtual {v0}, Lcom/devsmart/android/ui/HorizontalListView;->invalidate()V

    .line 114
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView$1;->a:Lcom/devsmart/android/ui/HorizontalListView;

    invoke-virtual {v0}, Lcom/devsmart/android/ui/HorizontalListView;->requestLayout()V

    .line 115
    return-void
.end method

###### Class com.devsmart.android.ui.HorizontalListView.AnonymousClass2 (com.devsmart.android.ui.HorizontalListView$2)
.class final Lcom/devsmart/android/ui/HorizontalListView$2;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/devsmart/android/ui/HorizontalListView;
.end annotation


# instance fields
.field final synthetic a:Lcom/devsmart/android/ui/HorizontalListView;


# direct methods
.method constructor <init>(Lcom/devsmart/android/ui/HorizontalListView;)V
    .registers 2

    .prologue
    .line 373
    iput-object p1, p0, Lcom/devsmart/android/ui/HorizontalListView$2;->a:Lcom/devsmart/android/ui/HorizontalListView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .prologue
    .line 375
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView$2;->a:Lcom/devsmart/android/ui/HorizontalListView;

    invoke-virtual {v0}, Lcom/devsmart/android/ui/HorizontalListView;->requestLayout()V

    .line 376
    return-void
.end method

###### Class com.devsmart.android.ui.HorizontalListView.AnonymousClass3 (com.devsmart.android.ui.HorizontalListView$3)
.class final Lcom/devsmart/android/ui/HorizontalListView$3;
.super Landroid/view/GestureDetector$SimpleOnGestureListener;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/devsmart/android/ui/HorizontalListView;
.end annotation


# instance fields
.field final synthetic a:Lcom/devsmart/android/ui/HorizontalListView;


# direct methods
.method constructor <init>(Lcom/devsmart/android/ui/HorizontalListView;)V
    .registers 2

    .prologue
    .line 581
    iput-object p1, p0, Lcom/devsmart/android/ui/HorizontalListView$3;->a:Lcom/devsmart/android/ui/HorizontalListView;

    invoke-direct {p0}, Landroid/view/GestureDetector$SimpleOnGestureListener;-><init>()V

    return-void
.end method

.method private static a(Landroid/view/MotionEvent;Landroid/view/View;)Z
    .registers 7

    .prologue
    .line 657
    new-instance v0, Landroid/graphics/Rect;

    invoke-direct {v0}, Landroid/graphics/Rect;-><init>()V

    .line 658
    const/4 v1, 0x2

    new-array v1, v1, [I

    .line 659
    invoke-virtual {p1, v1}, Landroid/view/View;->getLocationOnScreen([I)V

    .line 660
    const/4 v2, 0x0

    aget v2, v1, v2

    .line 661
    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v3

    add-int/2addr v3, v2

    .line 662
    const/4 v4, 0x1

    aget v1, v1, v4

    .line 663
    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result v4

    add-int/2addr v4, v1

    .line 664
    invoke-virtual {v0, v2, v1, v3, v4}, Landroid/graphics/Rect;->set(IIII)V

    .line 665
    invoke-virtual {p0}, Landroid/view/MotionEvent;->getRawX()F

    move-result v1

    float-to-int v1, v1

    invoke-virtual {p0}, Landroid/view/MotionEvent;->getRawY()F

    move-result v2

    float-to-int v2, v2

    invoke-virtual {v0, v1, v2}, Landroid/graphics/Rect;->contains(II)Z

    move-result v0

    return v0
.end method


# virtual methods
.method public final onDown(Landroid/view/MotionEvent;)Z
    .registers 3

    .prologue
    .line 585
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView$3;->a:Lcom/devsmart/android/ui/HorizontalListView;

    invoke-virtual {v0}, Lcom/devsmart/android/ui/HorizontalListView;->b()Z

    move-result v0

    return v0
.end method

.method public final onFling(Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
    .registers 6

    .prologue
    .line 591
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView$3;->a:Lcom/devsmart/android/ui/HorizontalListView;

    invoke-virtual {v0, p3}, Lcom/devsmart/android/ui/HorizontalListView;->a(F)Z

    move-result v0

    return v0
.end method

.method public final onLongPress(Landroid/view/MotionEvent;)V
    .registers 8

    .prologue
    .line 637
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView$3;->a:Lcom/devsmart/android/ui/HorizontalListView;

    invoke-virtual {v0}, Lcom/devsmart/android/ui/HorizontalListView;->getChildCount()I

    move-result v1

    .line 638
    const/4 v0, 0x0

    :goto_7
    if-ge v0, v1, :cond_44

    .line 639
    iget-object v2, p0, Lcom/devsmart/android/ui/HorizontalListView$3;->a:Lcom/devsmart/android/ui/HorizontalListView;

    invoke-virtual {v2, v0}, Lcom/devsmart/android/ui/HorizontalListView;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    .line 640
    iget-object v3, p0, Lcom/devsmart/android/ui/HorizontalListView$3;->a:Lcom/devsmart/android/ui/HorizontalListView;

    invoke-static {v3}, Lcom/devsmart/android/ui/HorizontalListView;->c(Lcom/devsmart/android/ui/HorizontalListView;)I

    move-result v3

    add-int/lit8 v3, v3, 0x1

    add-int/2addr v3, v0

    .line 641
    invoke-static {p1, v2}, Lcom/devsmart/android/ui/HorizontalListView$3;->a(Landroid/view/MotionEvent;Landroid/view/View;)Z

    move-result v4

    if-eqz v4, :cond_2c

    .line 642
    iget-object v4, p0, Lcom/devsmart/android/ui/HorizontalListView$3;->a:Lcom/devsmart/android/ui/HorizontalListView;

    iget-object v4, v4, Lcom/devsmart/android/ui/HorizontalListView;->b:Landroid/widget/ListAdapter;

    invoke-interface {v4, v3}, Landroid/widget/ListAdapter;->getItemViewType(I)I

    move-result v4

    const/4 v5, -0x2

    if-ne v4, v5, :cond_2f

    .line 643
    invoke-virtual {v2}, Landroid/view/View;->performLongClick()Z

    .line 638
    :cond_2c
    add-int/lit8 v0, v0, 0x1

    goto :goto_7

    .line 646
    :cond_2f
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView$3;->a:Lcom/devsmart/android/ui/HorizontalListView;

    invoke-virtual {v0}, Lcom/devsmart/android/ui/HorizontalListView;->getOnItemLongClickListener()Landroid/widget/AdapterView$OnItemLongClickListener;

    move-result-object v0

    .line 647
    if-eqz v0, :cond_44

    .line 648
    iget-object v1, p0, Lcom/devsmart/android/ui/HorizontalListView$3;->a:Lcom/devsmart/android/ui/HorizontalListView;

    iget-object v4, p0, Lcom/devsmart/android/ui/HorizontalListView$3;->a:Lcom/devsmart/android/ui/HorizontalListView;

    iget-object v4, v4, Lcom/devsmart/android/ui/HorizontalListView;->b:Landroid/widget/ListAdapter;

    invoke-interface {v4, v3}, Landroid/widget/ListAdapter;->getItemId(I)J

    move-result-wide v4

    invoke-interface/range {v0 .. v5}, Landroid/widget/AdapterView$OnItemLongClickListener;->onItemLongClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)Z

    .line 654
    :cond_44
    return-void
.end method

.method public final onScroll(Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
    .registers 9

    .prologue
    .line 598
    iget-object v1, p0, Lcom/devsmart/android/ui/HorizontalListView$3;->a:Lcom/devsmart/android/ui/HorizontalListView;

    monitor-enter v1

    .line 599
    :try_start_3
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView$3;->a:Lcom/devsmart/android/ui/HorizontalListView;

    iget v2, v0, Lcom/devsmart/android/ui/HorizontalListView;->d:I

    float-to-int v3, p3

    add-int/2addr v2, v3

    iput v2, v0, Lcom/devsmart/android/ui/HorizontalListView;->d:I

    .line 600
    monitor-exit v1
    :try_end_c
    .catchall {:try_start_3 .. :try_end_c} :catchall_13

    .line 601
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView$3;->a:Lcom/devsmart/android/ui/HorizontalListView;

    invoke-virtual {v0}, Lcom/devsmart/android/ui/HorizontalListView;->requestLayout()V

    .line 603
    const/4 v0, 0x1

    return v0

    .line 600
    :catchall_13
    move-exception v0

    monitor-exit v1

    throw v0
.end method

.method public final onSingleTapConfirmed(Landroid/view/MotionEvent;)Z
    .registers 8

    .prologue
    const/4 v0, 0x0

    .line 609
    iget-object v1, p0, Lcom/devsmart/android/ui/HorizontalListView$3;->a:Lcom/devsmart/android/ui/HorizontalListView;

    iget-boolean v1, v1, Lcom/devsmart/android/ui/HorizontalListView;->f:Z

    if-nez v1, :cond_8

    .line 632
    :goto_7
    return v0

    .line 612
    :cond_8
    :goto_8
    iget-object v1, p0, Lcom/devsmart/android/ui/HorizontalListView$3;->a:Lcom/devsmart/android/ui/HorizontalListView;

    invoke-virtual {v1}, Lcom/devsmart/android/ui/HorizontalListView;->getChildCount()I

    move-result v1

    if-ge v0, v1, :cond_61

    .line 613
    iget-object v1, p0, Lcom/devsmart/android/ui/HorizontalListView$3;->a:Lcom/devsmart/android/ui/HorizontalListView;

    invoke-virtual {v1, v0}, Lcom/devsmart/android/ui/HorizontalListView;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    .line 614
    iget-object v1, p0, Lcom/devsmart/android/ui/HorizontalListView$3;->a:Lcom/devsmart/android/ui/HorizontalListView;

    invoke-static {v1}, Lcom/devsmart/android/ui/HorizontalListView;->c(Lcom/devsmart/android/ui/HorizontalListView;)I

    move-result v1

    add-int/lit8 v1, v1, 0x1

    add-int v3, v1, v0

    .line 615
    invoke-static {p1, v2}, Lcom/devsmart/android/ui/HorizontalListView$3;->a(Landroid/view/MotionEvent;Landroid/view/View;)Z

    move-result v1

    if-eqz v1, :cond_34

    .line 616
    iget-object v1, p0, Lcom/devsmart/android/ui/HorizontalListView$3;->a:Lcom/devsmart/android/ui/HorizontalListView;

    iget-object v1, v1, Lcom/devsmart/android/ui/HorizontalListView;->b:Landroid/widget/ListAdapter;

    invoke-interface {v1, v3}, Landroid/widget/ListAdapter;->getItemViewType(I)I

    move-result v1

    const/4 v4, -0x2

    if-ne v1, v4, :cond_37

    .line 617
    invoke-virtual {v2}, Landroid/view/View;->performClick()Z

    .line 612
    :cond_34
    add-int/lit8 v0, v0, 0x1

    goto :goto_8

    .line 620
    :cond_37
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView$3;->a:Lcom/devsmart/android/ui/HorizontalListView;

    invoke-virtual {v0}, Lcom/devsmart/android/ui/HorizontalListView;->getOnItemClickListener()Landroid/widget/AdapterView$OnItemClickListener;

    move-result-object v0

    .line 621
    if-eqz v0, :cond_4c

    .line 622
    iget-object v1, p0, Lcom/devsmart/android/ui/HorizontalListView$3;->a:Lcom/devsmart/android/ui/HorizontalListView;

    iget-object v4, p0, Lcom/devsmart/android/ui/HorizontalListView$3;->a:Lcom/devsmart/android/ui/HorizontalListView;

    iget-object v4, v4, Lcom/devsmart/android/ui/HorizontalListView;->b:Landroid/widget/ListAdapter;

    invoke-interface {v4, v3}, Landroid/widget/ListAdapter;->getItemId(I)J

    move-result-wide v4

    invoke-interface/range {v0 .. v5}, Landroid/widget/AdapterView$OnItemClickListener;->onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V

    .line 624
    :cond_4c
    iget-object v0, p0, Lcom/devsmart/android/ui/HorizontalListView$3;->a:Lcom/devsmart/android/ui/HorizontalListView;

    invoke-virtual {v0}, Lcom/devsmart/android/ui/HorizontalListView;->getOnItemSelectedListener()Landroid/widget/AdapterView$OnItemSelectedListener;

    move-result-object v0

    .line 625
    if-eqz v0, :cond_61

    .line 626
    iget-object v1, p0, Lcom/devsmart/android/ui/HorizontalListView$3;->a:Lcom/devsmart/android/ui/HorizontalListView;

    iget-object v4, p0, Lcom/devsmart/android/ui/HorizontalListView$3;->a:Lcom/devsmart/android/ui/HorizontalListView;

    iget-object v4, v4, Lcom/devsmart/android/ui/HorizontalListView;->b:Landroid/widget/ListAdapter;

    invoke-interface {v4, v3}, Landroid/widget/ListAdapter;->getItemId(I)J

    move-result-wide v4

    invoke-interface/range {v0 .. v5}, Landroid/widget/AdapterView$OnItemSelectedListener;->onItemSelected(Landroid/widget/AdapterView;Landroid/view/View;IJ)V

    .line 632
    :cond_61
    const/4 v0, 0x1

    goto :goto_7
.end method
