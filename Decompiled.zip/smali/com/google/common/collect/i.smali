###### Class com.google.common.collect.i (com.google.common.collect.i)
.class public final Lcom/google/common/collect/i;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field static final a:Lcom/google/common/collect/ar;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/ar",
            "<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field private static final b:Ljava/util/Iterator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Iterator",
            "<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .prologue
    .line 69
    new-instance v0, Lcom/google/common/collect/i$1;

    invoke-direct {v0}, Lcom/google/common/collect/i$1;-><init>()V

    sput-object v0, Lcom/google/common/collect/i;->a:Lcom/google/common/collect/ar;

    .line 119
    new-instance v0, Lcom/google/common/collect/i$5;

    invoke-direct {v0}, Lcom/google/common/collect/i$5;-><init>()V

    sput-object v0, Lcom/google/common/collect/i;->b:Ljava/util/Iterator;

    return-void
.end method

.method public static a()Lcom/google/common/collect/aq;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">()",
            "Lcom/google/common/collect/aq",
            "<TT;>;"
        }
    .end annotation

    .prologue
    .line 104
    sget-object v0, Lcom/google/common/collect/i;->a:Lcom/google/common/collect/ar;

    return-object v0
.end method

.method public static a(Ljava/lang/Object;)Lcom/google/common/collect/aq;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;)",
            "Lcom/google/common/collect/aq",
            "<TT;>;"
        }
    .end annotation

    .prologue
    .line 1140
    new-instance v0, Lcom/google/common/collect/i$4;

    invoke-direct {v0, p0}, Lcom/google/common/collect/i$4;-><init>(Ljava/lang/Object;)V

    return-object v0
.end method

.method public static a(Ljava/util/Iterator;)Lcom/google/common/collect/aq;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/Iterator",
            "<TT;>;)",
            "Lcom/google/common/collect/aq",
            "<TT;>;"
        }
    .end annotation

    .prologue
    .line 149
    invoke-static {p0}, Lcom/google/common/base/i;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 150
    instance-of v0, p0, Lcom/google/common/collect/aq;

    if-eqz v0, :cond_a

    .line 151
    check-cast p0, Lcom/google/common/collect/aq;

    .line 153
    :goto_9
    return-object p0

    :cond_a
    new-instance v0, Lcom/google/common/collect/i$6;

    invoke-direct {v0, p0}, Lcom/google/common/collect/i$6;-><init>(Ljava/util/Iterator;)V

    move-object p0, v0

    goto :goto_9
.end method

.method public static varargs a([Ljava/lang/Object;)Lcom/google/common/collect/aq;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;)",
            "Lcom/google/common/collect/aq",
            "<TT;>;"
        }
    .end annotation

    .prologue
    .line 1097
    invoke-static {p0}, Lcom/google/common/base/i;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1098
    new-instance v0, Lcom/google/common/collect/i$2;

    array-length v1, p0

    invoke-direct {v0, v1, p0}, Lcom/google/common/collect/i$2;-><init>(I[Ljava/lang/Object;)V

    return-object v0
.end method

.method static a([Ljava/lang/Object;III)Lcom/google/common/collect/ar;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;III)",
            "Lcom/google/common/collect/ar",
            "<TT;>;"
        }
    .end annotation

    .prologue
    .line 1114
    if-ltz p2, :cond_12

    const/4 v0, 0x1

    :goto_3
    invoke-static {v0}, Lcom/google/common/base/i;->a(Z)V

    .line 1115
    add-int v0, p1, p2

    .line 1118
    array-length v1, p0

    invoke-static {p1, v0, v1}, Lcom/google/common/base/i;->a(III)V

    .line 1125
    new-instance v0, Lcom/google/common/collect/i$3;

    invoke-direct {v0, p2, p3, p0, p1}, Lcom/google/common/collect/i$3;-><init>(II[Ljava/lang/Object;I)V

    return-object v0

    .line 1114
    :cond_12
    const/4 v0, 0x0

    goto :goto_3
.end method

.method public static a(Ljava/util/Iterator;Lcom/google/common/base/b;)Ljava/util/Iterator;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<F:",
            "Ljava/lang/Object;",
            "T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/Iterator",
            "<TF;>;",
            "Lcom/google/common/base/b",
            "<-TF;+TT;>;)",
            "Ljava/util/Iterator",
            "<TT;>;"
        }
    .end annotation

    .prologue
    .line 856
    invoke-static {p1}, Lcom/google/common/base/i;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 857
    new-instance v0, Lcom/google/common/collect/i$8;

    invoke-direct {v0, p0, p1}, Lcom/google/common/collect/i$8;-><init>(Ljava/util/Iterator;Lcom/google/common/base/b;)V

    return-object v0
.end method

.method public static a(Ljava/util/Iterator;Lcom/google/common/base/j;)Z
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/Iterator",
            "<TT;>;",
            "Lcom/google/common/base/j",
            "<-TT;>;)Z"
        }
    .end annotation

    .prologue
    .line 246
    invoke-static {p1}, Lcom/google/common/base/i;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 247
    const/4 v0, 0x0

    .line 248
    :cond_4
    :goto_4
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_19

    .line 249
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    invoke-interface {p1, v1}, Lcom/google/common/base/j;->a(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4

    .line 250
    invoke-interface {p0}, Ljava/util/Iterator;->remove()V

    .line 251
    const/4 v0, 0x1

    goto :goto_4

    .line 254
    :cond_19
    return v0
.end method

.method public static a(Ljava/util/Iterator;Ljava/lang/Object;)Z
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Iterator",
            "<*>;",
            "Ljava/lang/Object;",
            ")Z"
        }
    .end annotation

    .prologue
    const/4 v0, 0x1

    .line 195
    if-nez p1, :cond_10

    .line 196
    :cond_3
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_21

    .line 197
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    if-nez v1, :cond_3

    .line 208
    :goto_f
    return v0

    .line 202
    :cond_10
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_21

    .line 203
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {p1, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_10

    goto :goto_f

    .line 208
    :cond_21
    const/4 v0, 0x0

    goto :goto_f
.end method

.method public static a(Ljava/util/Iterator;Ljava/util/Iterator;)Z
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Iterator",
            "<*>;",
            "Ljava/util/Iterator",
            "<*>;)Z"
        }
    .end annotation

    .prologue
    const/4 v0, 0x0

    .line 291
    :cond_1
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1d

    .line 292
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-nez v1, :cond_e

    .line 301
    :cond_d
    :goto_d
    return v0

    .line 295
    :cond_e
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    .line 296
    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    .line 297
    invoke-static {v1, v2}, Lcom/google/common/base/e;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    goto :goto_d

    .line 301
    :cond_1d
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-nez v1, :cond_d

    const/4 v0, 0x1

    goto :goto_d
.end method

.method public static b(Ljava/util/Iterator;Lcom/google/common/base/j;)Lcom/google/common/collect/aq;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/Iterator",
            "<TT;>;",
            "Lcom/google/common/base/j",
            "<-TT;>;)",
            "Lcom/google/common/collect/aq",
            "<TT;>;"
        }
    .end annotation

    .prologue
    .line 696
    invoke-static {p0}, Lcom/google/common/base/i;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 697
    invoke-static {p1}, Lcom/google/common/base/i;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 698
    new-instance v0, Lcom/google/common/collect/i$7;

    invoke-direct {v0, p0, p1}, Lcom/google/common/collect/i$7;-><init>(Ljava/util/Iterator;Lcom/google/common/base/j;)V

    return-object v0
.end method

.method public static b(Ljava/util/Iterator;)Ljava/lang/String;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Iterator",
            "<*>;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .prologue
    .line 310
    const-string v0, ", "

    invoke-static {v0}, Lcom/google/common/base/c;->a(Ljava/lang/String;)Lcom/google/common/base/c;

    move-result-object v0

    const-string v1, "null"

    invoke-virtual {v0, v1}, Lcom/google/common/base/c;->b(Ljava/lang/String;)Lcom/google/common/base/c;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "["

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1, p0}, Lcom/google/common/base/c;->a(Ljava/lang/StringBuilder;Ljava/util/Iterator;)Ljava/lang/StringBuilder;

    move-result-object v0

    const/16 v1, 0x5d

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method static c(Ljava/util/Iterator;)Ljava/util/ListIterator;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/Iterator",
            "<TT;>;)",
            "Ljava/util/ListIterator",
            "<TT;>;"
        }
    .end annotation

    .prologue
    .line 1395
    check-cast p0, Ljava/util/ListIterator;

    return-object p0
.end method

###### Class com.google.common.collect.i.AnonymousClass1 (com.google.common.collect.i$1)
.class final Lcom/google/common/collect/i$1;
.super Lcom/google/common/collect/ar;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/i;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/ar",
        "<",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 70
    invoke-direct {p0}, Lcom/google/common/collect/ar;-><init>()V

    return-void
.end method


# virtual methods
.method public final hasNext()Z
    .registers 2

    .prologue
    .line 73
    const/4 v0, 0x0

    return v0
.end method

.method public final hasPrevious()Z
    .registers 2

    .prologue
    .line 81
    const/4 v0, 0x0

    return v0
.end method

.method public final next()Ljava/lang/Object;
    .registers 2

    .prologue
    .line 77
    new-instance v0, Ljava/util/NoSuchElementException;

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    throw v0
.end method

.method public final nextIndex()I
    .registers 2

    .prologue
    .line 89
    const/4 v0, 0x0

    return v0
.end method

.method public final previous()Ljava/lang/Object;
    .registers 2

    .prologue
    .line 85
    new-instance v0, Ljava/util/NoSuchElementException;

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    throw v0
.end method

.method public final previousIndex()I
    .registers 2

    .prologue
    .line 93
    const/4 v0, -0x1

    return v0
.end method

###### Class com.google.common.collect.i.AnonymousClass2 (com.google.common.collect.i$2)
.class final Lcom/google/common/collect/i$2;
.super Lcom/google/common/collect/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/collect/i;->a([Ljava/lang/Object;)Lcom/google/common/collect/aq;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/a",
        "<TT;>;"
    }
.end annotation


# instance fields
.field final synthetic a:[Ljava/lang/Object;


# direct methods
.method constructor <init>(I[Ljava/lang/Object;)V
    .registers 3

    .prologue
    .line 1098
    iput-object p2, p0, Lcom/google/common/collect/i$2;->a:[Ljava/lang/Object;

    invoke-direct {p0, p1}, Lcom/google/common/collect/a;-><init>(I)V

    return-void
.end method


# virtual methods
.method protected final a(I)Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TT;"
        }
    .end annotation

    .prologue
    .line 1100
    iget-object v0, p0, Lcom/google/common/collect/i$2;->a:[Ljava/lang/Object;

    aget-object v0, v0, p1

    return-object v0
.end method

###### Class com.google.common.collect.i.AnonymousClass3 (com.google.common.collect.i$3)
.class final Lcom/google/common/collect/i$3;
.super Lcom/google/common/collect/a;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/collect/i;->a([Ljava/lang/Object;III)Lcom/google/common/collect/ar;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/a",
        "<TT;>;"
    }
.end annotation


# instance fields
.field final synthetic a:[Ljava/lang/Object;

.field final synthetic b:I


# direct methods
.method constructor <init>(II[Ljava/lang/Object;I)V
    .registers 5

    .prologue
    .line 1125
    iput-object p3, p0, Lcom/google/common/collect/i$3;->a:[Ljava/lang/Object;

    iput p4, p0, Lcom/google/common/collect/i$3;->b:I

    invoke-direct {p0, p1, p2}, Lcom/google/common/collect/a;-><init>(II)V

    return-void
.end method


# virtual methods
.method protected final a(I)Ljava/lang/Object;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)TT;"
        }
    .end annotation

    .prologue
    .line 1127
    iget-object v0, p0, Lcom/google/common/collect/i$3;->a:[Ljava/lang/Object;

    iget v1, p0, Lcom/google/common/collect/i$3;->b:I

    add-int/2addr v1, p1

    aget-object v0, v0, v1

    return-object v0
.end method

###### Class com.google.common.collect.i.AnonymousClass4 (com.google.common.collect.i$4)
.class final Lcom/google/common/collect/i$4;
.super Lcom/google/common/collect/aq;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/collect/i;->a(Ljava/lang/Object;)Lcom/google/common/collect/aq;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/aq",
        "<TT;>;"
    }
.end annotation


# instance fields
.field a:Z

.field final synthetic b:Ljava/lang/Object;


# direct methods
.method constructor <init>(Ljava/lang/Object;)V
    .registers 2

    .prologue
    .line 1140
    iput-object p1, p0, Lcom/google/common/collect/i$4;->b:Ljava/lang/Object;

    invoke-direct {p0}, Lcom/google/common/collect/aq;-><init>()V

    return-void
.end method


# virtual methods
.method public final hasNext()Z
    .registers 2

    .prologue
    .line 1144
    iget-boolean v0, p0, Lcom/google/common/collect/i$4;->a:Z

    if-nez v0, :cond_6

    const/4 v0, 0x1

    :goto_5
    return v0

    :cond_6
    const/4 v0, 0x0

    goto :goto_5
.end method

.method public final next()Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .prologue
    .line 1148
    iget-boolean v0, p0, Lcom/google/common/collect/i$4;->a:Z

    if-eqz v0, :cond_a

    .line 1149
    new-instance v0, Ljava/util/NoSuchElementException;

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    throw v0

    .line 1151
    :cond_a
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/google/common/collect/i$4;->a:Z

    .line 1152
    iget-object v0, p0, Lcom/google/common/collect/i$4;->b:Ljava/lang/Object;

    return-object v0
.end method

###### Class com.google.common.collect.i.AnonymousClass5 (com.google.common.collect.i$5)
.class final Lcom/google/common/collect/i$5;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Iterator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/i;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/util/Iterator",
        "<",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .registers 1

    .prologue
    .line 120
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final hasNext()Z
    .registers 2

    .prologue
    .line 122
    const/4 v0, 0x0

    return v0
.end method

.method public final next()Ljava/lang/Object;
    .registers 2

    .prologue
    .line 126
    new-instance v0, Ljava/util/NoSuchElementException;

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    throw v0
.end method

.method public final remove()V
    .registers 2

    .prologue
    .line 130
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    throw v0
.end method

###### Class com.google.common.collect.i.AnonymousClass6 (com.google.common.collect.i$6)
.class final Lcom/google/common/collect/i$6;
.super Lcom/google/common/collect/aq;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/collect/i;->a(Ljava/util/Iterator;)Lcom/google/common/collect/aq;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/aq",
        "<TT;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Ljava/util/Iterator;


# direct methods
.method constructor <init>(Ljava/util/Iterator;)V
    .registers 2

    .prologue
    .line 153
    iput-object p1, p0, Lcom/google/common/collect/i$6;->a:Ljava/util/Iterator;

    invoke-direct {p0}, Lcom/google/common/collect/aq;-><init>()V

    return-void
.end method


# virtual methods
.method public final hasNext()Z
    .registers 2

    .prologue
    .line 156
    iget-object v0, p0, Lcom/google/common/collect/i$6;->a:Ljava/util/Iterator;

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    return v0
.end method

.method public final next()Ljava/lang/Object;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .prologue
    .line 160
    iget-object v0, p0, Lcom/google/common/collect/i$6;->a:Ljava/util/Iterator;

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

###### Class com.google.common.collect.i.AnonymousClass7 (com.google.common.collect.i$7)
.class final Lcom/google/common/collect/i$7;
.super Lcom/google/common/collect/AbstractIterator;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/collect/i;->b(Ljava/util/Iterator;Lcom/google/common/base/j;)Lcom/google/common/collect/aq;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/AbstractIterator",
        "<TT;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Ljava/util/Iterator;

.field final synthetic b:Lcom/google/common/base/j;


# direct methods
.method constructor <init>(Ljava/util/Iterator;Lcom/google/common/base/j;)V
    .registers 3

    .prologue
    .line 698
    iput-object p1, p0, Lcom/google/common/collect/i$7;->a:Ljava/util/Iterator;

    iput-object p2, p0, Lcom/google/common/collect/i$7;->b:Lcom/google/common/base/j;

    invoke-direct {p0}, Lcom/google/common/collect/AbstractIterator;-><init>()V

    return-void
.end method


# virtual methods
.method protected final a()Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()TT;"
        }
    .end annotation

    .prologue
    .line 700
    :cond_0
    iget-object v0, p0, Lcom/google/common/collect/i$7;->a:Ljava/util/Iterator;

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_17

    .line 701
    iget-object v0, p0, Lcom/google/common/collect/i$7;->a:Ljava/util/Iterator;

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    .line 702
    iget-object v1, p0, Lcom/google/common/collect/i$7;->b:Lcom/google/common/base/j;

    invoke-interface {v1, v0}, Lcom/google/common/base/j;->a(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_0

    .line 706
    :goto_16
    return-object v0

    :cond_17
    invoke-virtual {p0}, Lcom/google/common/collect/i$7;->b()Ljava/lang/Object;

    move-result-object v0

    goto :goto_16
.end method

###### Class com.google.common.collect.i.AnonymousClass8 (com.google.common.collect.i$8)
.class final Lcom/google/common/collect/i$8;
.super Lcom/google/common/collect/ao;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/collect/i;->a(Ljava/util/Iterator;Lcom/google/common/base/b;)Ljava/util/Iterator;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/ao",
        "<TF;TT;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/google/common/base/b;


# direct methods
.method constructor <init>(Ljava/util/Iterator;Lcom/google/common/base/b;)V
    .registers 3

    .prologue
    .line 857
    iput-object p2, p0, Lcom/google/common/collect/i$8;->a:Lcom/google/common/base/b;

    invoke-direct {p0, p1}, Lcom/google/common/collect/ao;-><init>(Ljava/util/Iterator;)V

    return-void
.end method


# virtual methods
.method final a(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TF;)TT;"
        }
    .end annotation

    .prologue
    .line 860
    iget-object v0, p0, Lcom/google/common/collect/i$8;->a:Lcom/google/common/base/b;

    invoke-interface {v0, p1}, Lcom/google/common/base/b;->a(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method
