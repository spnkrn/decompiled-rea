###### Class com.google.common.collect.p (com.google.common.collect.p)
.class final Lcom/google/common/collect/p;
.super Ljava/util/AbstractQueue;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<K:",
        "Ljava/lang/Object;",
        "V:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/util/AbstractQueue",
        "<",
        "Lcom/google/common/collect/u",
        "<TK;TV;>;>;"
    }
.end annotation


# instance fields
.field final a:Lcom/google/common/collect/u;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/u",
            "<TK;TV;>;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>()V
    .registers 2

    .prologue
    .line 3111
    invoke-direct {p0}, Ljava/util/AbstractQueue;-><init>()V

    .line 3112
    new-instance v0, Lcom/google/common/collect/p$1;

    invoke-direct {v0, p0}, Lcom/google/common/collect/p$1;-><init>(Lcom/google/common/collect/p;)V

    iput-object v0, p0, Lcom/google/common/collect/p;->a:Lcom/google/common/collect/u;

    return-void
.end method

.method private a()Lcom/google/common/collect/u;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/u",
            "<TK;TV;>;"
        }
    .end annotation

    .prologue
    .line 3155
    iget-object v0, p0, Lcom/google/common/collect/p;->a:Lcom/google/common/collect/u;

    invoke-interface {v0}, Lcom/google/common/collect/u;->h()Lcom/google/common/collect/u;

    move-result-object v0

    .line 3156
    iget-object v1, p0, Lcom/google/common/collect/p;->a:Lcom/google/common/collect/u;

    if-ne v0, v1, :cond_b

    const/4 v0, 0x0

    :cond_b
    return-object v0
.end method


# virtual methods
.method public final clear()V
    .registers 3

    .prologue
    .line 3205
    iget-object v0, p0, Lcom/google/common/collect/p;->a:Lcom/google/common/collect/u;

    invoke-interface {v0}, Lcom/google/common/collect/u;->h()Lcom/google/common/collect/u;

    move-result-object v0

    .line 3206
    :goto_6
    iget-object v1, p0, Lcom/google/common/collect/p;->a:Lcom/google/common/collect/u;

    if-eq v0, v1, :cond_13

    .line 3207
    invoke-interface {v0}, Lcom/google/common/collect/u;->h()Lcom/google/common/collect/u;

    move-result-object v1

    .line 3208
    invoke-static {v0}, Lcom/google/common/collect/MapMakerInternalMap;->c(Lcom/google/common/collect/u;)V

    move-object v0, v1

    .line 3210
    goto :goto_6

    .line 3212
    :cond_13
    iget-object v0, p0, Lcom/google/common/collect/p;->a:Lcom/google/common/collect/u;

    iget-object v1, p0, Lcom/google/common/collect/p;->a:Lcom/google/common/collect/u;

    invoke-interface {v0, v1}, Lcom/google/common/collect/u;->c(Lcom/google/common/collect/u;)V

    .line 3213
    iget-object v0, p0, Lcom/google/common/collect/p;->a:Lcom/google/common/collect/u;

    iget-object v1, p0, Lcom/google/common/collect/p;->a:Lcom/google/common/collect/u;

    invoke-interface {v0, v1}, Lcom/google/common/collect/u;->d(Lcom/google/common/collect/u;)V

    .line 3214
    return-void
.end method

.method public final contains(Ljava/lang/Object;)Z
    .registers 4

    .prologue
    .line 3185
    check-cast p1, Lcom/google/common/collect/u;

    .line 3186
    invoke-interface {p1}, Lcom/google/common/collect/u;->h()Lcom/google/common/collect/u;

    move-result-object v0

    sget-object v1, Lcom/google/common/collect/MapMakerInternalMap$NullEntry;->a:Lcom/google/common/collect/MapMakerInternalMap$NullEntry;

    if-eq v0, v1, :cond_c

    const/4 v0, 0x1

    :goto_b
    return v0

    :cond_c
    const/4 v0, 0x0

    goto :goto_b
.end method

.method public final isEmpty()Z
    .registers 3

    .prologue
    .line 3191
    iget-object v0, p0, Lcom/google/common/collect/p;->a:Lcom/google/common/collect/u;

    invoke-interface {v0}, Lcom/google/common/collect/u;->h()Lcom/google/common/collect/u;

    move-result-object v0

    iget-object v1, p0, Lcom/google/common/collect/p;->a:Lcom/google/common/collect/u;

    if-ne v0, v1, :cond_c

    const/4 v0, 0x1

    :goto_b
    return v0

    :cond_c
    const/4 v0, 0x0

    goto :goto_b
.end method

.method public final iterator()Ljava/util/Iterator;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Iterator",
            "<",
            "Lcom/google/common/collect/u",
            "<TK;TV;>;>;"
        }
    .end annotation

    .prologue
    .line 3218
    new-instance v0, Lcom/google/common/collect/p$2;

    invoke-direct {p0}, Lcom/google/common/collect/p;->a()Lcom/google/common/collect/u;

    move-result-object v1

    invoke-direct {v0, p0, v1}, Lcom/google/common/collect/p$2;-><init>(Lcom/google/common/collect/p;Lcom/google/common/collect/u;)V

    return-object v0
.end method

.method public final synthetic offer(Ljava/lang/Object;)Z
    .registers 4

    .prologue
    .line 3111
    check-cast p1, Lcom/google/common/collect/u;

    invoke-interface {p1}, Lcom/google/common/collect/u;->i()Lcom/google/common/collect/u;

    move-result-object v0

    invoke-interface {p1}, Lcom/google/common/collect/u;->h()Lcom/google/common/collect/u;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/google/common/collect/MapMakerInternalMap;->b(Lcom/google/common/collect/u;Lcom/google/common/collect/u;)V

    iget-object v0, p0, Lcom/google/common/collect/p;->a:Lcom/google/common/collect/u;

    invoke-interface {v0}, Lcom/google/common/collect/u;->i()Lcom/google/common/collect/u;

    move-result-object v0

    invoke-static {v0, p1}, Lcom/google/common/collect/MapMakerInternalMap;->b(Lcom/google/common/collect/u;Lcom/google/common/collect/u;)V

    iget-object v0, p0, Lcom/google/common/collect/p;->a:Lcom/google/common/collect/u;

    invoke-static {p1, v0}, Lcom/google/common/collect/MapMakerInternalMap;->b(Lcom/google/common/collect/u;Lcom/google/common/collect/u;)V

    const/4 v0, 0x1

    return v0
.end method

.method public final synthetic peek()Ljava/lang/Object;
    .registers 2

    .prologue
    .line 3111
    invoke-direct {p0}, Lcom/google/common/collect/p;->a()Lcom/google/common/collect/u;

    move-result-object v0

    return-object v0
.end method

.method public final synthetic poll()Ljava/lang/Object;
    .registers 3

    .prologue
    .line 3111
    iget-object v0, p0, Lcom/google/common/collect/p;->a:Lcom/google/common/collect/u;

    invoke-interface {v0}, Lcom/google/common/collect/u;->h()Lcom/google/common/collect/u;

    move-result-object v0

    iget-object v1, p0, Lcom/google/common/collect/p;->a:Lcom/google/common/collect/u;

    if-ne v0, v1, :cond_c

    const/4 v0, 0x0

    :goto_b
    return-object v0

    :cond_c
    invoke-virtual {p0, v0}, Lcom/google/common/collect/p;->remove(Ljava/lang/Object;)Z

    goto :goto_b
.end method

.method public final remove(Ljava/lang/Object;)Z
    .registers 4

    .prologue
    .line 3173
    check-cast p1, Lcom/google/common/collect/u;

    .line 3174
    invoke-interface {p1}, Lcom/google/common/collect/u;->i()Lcom/google/common/collect/u;

    move-result-object v0

    .line 3175
    invoke-interface {p1}, Lcom/google/common/collect/u;->h()Lcom/google/common/collect/u;

    move-result-object v1

    .line 3176
    invoke-static {v0, v1}, Lcom/google/common/collect/MapMakerInternalMap;->b(Lcom/google/common/collect/u;Lcom/google/common/collect/u;)V

    .line 3177
    invoke-static {p1}, Lcom/google/common/collect/MapMakerInternalMap;->c(Lcom/google/common/collect/u;)V

    .line 3179
    sget-object v0, Lcom/google/common/collect/MapMakerInternalMap$NullEntry;->a:Lcom/google/common/collect/MapMakerInternalMap$NullEntry;

    if-eq v1, v0, :cond_16

    const/4 v0, 0x1

    :goto_15
    return v0

    :cond_16
    const/4 v0, 0x0

    goto :goto_15
.end method

.method public final size()I
    .registers 4

    .prologue
    .line 3196
    const/4 v1, 0x0

    .line 3197
    iget-object v0, p0, Lcom/google/common/collect/p;->a:Lcom/google/common/collect/u;

    invoke-interface {v0}, Lcom/google/common/collect/u;->h()Lcom/google/common/collect/u;

    move-result-object v0

    :goto_7
    iget-object v2, p0, Lcom/google/common/collect/p;->a:Lcom/google/common/collect/u;

    if-eq v0, v2, :cond_12

    .line 3198
    add-int/lit8 v1, v1, 0x1

    .line 3197
    invoke-interface {v0}, Lcom/google/common/collect/u;->h()Lcom/google/common/collect/u;

    move-result-object v0

    goto :goto_7

    .line 3200
    :cond_12
    return v1
.end method

###### Class com.google.common.collect.p.AnonymousClass1 (com.google.common.collect.p$1)
.class final Lcom/google/common/collect/p$1;
.super Lcom/google/common/collect/m;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/common/collect/p;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/m",
        "<TK;TV;>;"
    }
.end annotation


# instance fields
.field a:Lcom/google/common/collect/u;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/u",
            "<TK;TV;>;"
        }
    .end annotation
.end field

.field b:Lcom/google/common/collect/u;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lcom/google/common/collect/u",
            "<TK;TV;>;"
        }
    .end annotation
.end field

.field final synthetic c:Lcom/google/common/collect/p;


# direct methods
.method constructor <init>(Lcom/google/common/collect/p;)V
    .registers 2

    .prologue
    .line 3112
    iput-object p1, p0, Lcom/google/common/collect/p$1;->c:Lcom/google/common/collect/p;

    invoke-direct {p0}, Lcom/google/common/collect/m;-><init>()V

    .line 3114
    iput-object p0, p0, Lcom/google/common/collect/p$1;->a:Lcom/google/common/collect/u;

    .line 3126
    iput-object p0, p0, Lcom/google/common/collect/p$1;->b:Lcom/google/common/collect/u;

    return-void
.end method


# virtual methods
.method public final c(Lcom/google/common/collect/u;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/u",
            "<TK;TV;>;)V"
        }
    .end annotation

    .prologue
    .line 3123
    iput-object p1, p0, Lcom/google/common/collect/p$1;->a:Lcom/google/common/collect/u;

    .line 3124
    return-void
.end method

.method public final d(Lcom/google/common/collect/u;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/common/collect/u",
            "<TK;TV;>;)V"
        }
    .end annotation

    .prologue
    .line 3135
    iput-object p1, p0, Lcom/google/common/collect/p$1;->b:Lcom/google/common/collect/u;

    .line 3136
    return-void
.end method

.method public final h()Lcom/google/common/collect/u;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/u",
            "<TK;TV;>;"
        }
    .end annotation

    .prologue
    .line 3118
    iget-object v0, p0, Lcom/google/common/collect/p$1;->a:Lcom/google/common/collect/u;

    return-object v0
.end method

.method public final i()Lcom/google/common/collect/u;
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/google/common/collect/u",
            "<TK;TV;>;"
        }
    .end annotation

    .prologue
    .line 3130
    iget-object v0, p0, Lcom/google/common/collect/p$1;->b:Lcom/google/common/collect/u;

    return-object v0
.end method

###### Class com.google.common.collect.p.AnonymousClass2 (com.google.common.collect.p$2)
.class final Lcom/google/common/collect/p$2;
.super Lcom/google/common/collect/c;
.source "SourceFile"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/google/common/collect/p;->iterator()Ljava/util/Iterator;
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/google/common/collect/c",
        "<",
        "Lcom/google/common/collect/u",
        "<TK;TV;>;>;"
    }
.end annotation


# instance fields
.field final synthetic a:Lcom/google/common/collect/p;


# direct methods
.method constructor <init>(Lcom/google/common/collect/p;Lcom/google/common/collect/u;)V
    .registers 3

    .prologue
    .line 3218
    iput-object p1, p0, Lcom/google/common/collect/p$2;->a:Lcom/google/common/collect/p;

    invoke-direct {p0, p2}, Lcom/google/common/collect/c;-><init>(Ljava/lang/Object;)V

    return-void
.end method


# virtual methods
.method protected final synthetic a(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .prologue
    .line 3218
    check-cast p1, Lcom/google/common/collect/u;

    invoke-interface {p1}, Lcom/google/common/collect/u;->h()Lcom/google/common/collect/u;

    move-result-object v0

    iget-object v1, p0, Lcom/google/common/collect/p$2;->a:Lcom/google/common/collect/p;

    iget-object v1, v1, Lcom/google/common/collect/p;->a:Lcom/google/common/collect/u;

    if-ne v0, v1, :cond_d

    const/4 v0, 0x0

    :cond_d
    return-object v0
.end method
