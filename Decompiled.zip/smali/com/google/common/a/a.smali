###### Class com.google.common.a.a (com.google.common.a.a)
.class public final Lcom/google/common/a/a;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public static a(J)I
    .registers 4

    .prologue
    .line 101
    const-wide/32 v0, 0x7fffffff

    cmp-long v0, p0, v0

    if-lez v0, :cond_b

    .line 102
    const v0, 0x7fffffff

    .line 107
    :goto_a
    return v0

    .line 104
    :cond_b
    const-wide/32 v0, -0x80000000

    cmp-long v0, p0, v0

    if-gez v0, :cond_15

    .line 105
    const/high16 v0, -0x80000000

    goto :goto_a

    .line 107
    :cond_15
    long-to-int v0, p0

    goto :goto_a
.end method
